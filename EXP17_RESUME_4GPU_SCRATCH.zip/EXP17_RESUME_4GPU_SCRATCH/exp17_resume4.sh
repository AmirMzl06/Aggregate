#!/usr/bin/env bash
set -euo pipefail
SRC=/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
export USER=mirzaei LOGNAME=mirzaei USERNAME=mirzaei
export PYTHONUNBUFFERED=1 SKIP_PLOTS=1
cd "$SRC"
exec /data/hossein/aj_project/.venv/bin/python -u "$SRC/exp17_resume4.py" --run \
    --scratch /data/hossein/mm_project/EXP17_MIHILI_CO
