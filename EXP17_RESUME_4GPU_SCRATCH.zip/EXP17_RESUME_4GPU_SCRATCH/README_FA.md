# Exp17 — Resume با ۴ GPU و Scratch

نسخهٔ اصلاحی برای ادامهٔ **همان ۲۴ مدل Exp17**. این بسته هیچ مدل از قبل کامل‌شده را مجدداً آموزش نمی‌دهد؛ فقط فایل‌های جدید `exp17_resume4.py` و `exp17_cache_entry.py` و `exp17_resume4.sh` را به کپی مستقلی که پیش‌تر در Aggregate نصب شده بود اضافه می‌کند. الگوریتم‌ها، مدل استاد، PGD، Noise-Aware، AUTO و پارامترهای آموزشی عوض نمی‌شوند.

**۴ GPU** یعنی ۴ مدل مستقل همزمان (۴ فرآیند مجزا با `CUDA_VISIBLE_DEVICES=0,1,2,3`)، نه آموزش Distributed یک مدل روی چهار GPU. صف کارها بین Workerها تقسیم می‌شود، بنابراین اگر مدلی زودتر تمام شود، GPU آزاد بلافاصله کار بعدی را برمی‌دارد.

## مسیرها

- کد: `/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source`
- نتایج روی Headnode: `/mnt/upmwmathis/scratch/hossein/mm_project/EXP17_MIHILI_CO/runs`
- لاگ‌های کامل روی Headnode: `/mnt/upmwmathis/scratch/hossein/mm_project/EXP17_MIHILI_CO/logs`
- همان نتایج داخل RunAI Pod: `/data/hossein/mm_project/EXP17_MIHILI_CO/runs`
- داده‌های موقتی و Cache هر GPU: `/data/hossein/mm_project/EXP17_MIHILI_CO/tmp/gpuN` و `/data/hossein/mm_project/EXP17_MIHILI_CO/cache/gpuN`، نه `/home`

## نصب روی Headnode

بعد از انتقال ZIP اصلاحی به `Aggregate`:

```bash
cd /home/mirzaei/sam/result/Aggregate
unzip -oq EXP17_RESUME_4GPU_SCRATCH.zip -d EXP17_RESUME_4GPU_SCRATCH_PKG
cp EXP17_RESUME_4GPU_SCRATCH_PKG/EXP17_RESUME_4GPU_SCRATCH/exp17_{resume4.py,cache_entry.py,resume4.sh} \
  EXP17_MIHILI_CO/source/
cd EXP17_MIHILI_CO/source
python3 exp17_resume4.py --prepare
python3 exp17_resume4.py --plan
```

`--prepare` فقط مدل‌های **واقعاً کامل** را از HOME به Scratch **کپی** می‌کند، ازجمله checkpointها، بدون حذف HOME و بدون بازنویسی مدل‌های کامل Scratch. بر اساس آخرین خروجی کاربر انتظار داریم ۹ مدل منتقل شوند و ۱۵ مدل Pending بمانند. یک مدل فقط اگر `metrics.json` و `exp17_record.json` سالم با ده روز R² باشد، و Batch=1024 و تعداد مراحل درخواست‌شده=30000، تکمیل محسوب می‌شود.

## RunAI چهار GPU

Job قبلی شکست خورده است؛ برای جلوگیری از تداخل نام، از `sam-exp17-r4` استفاده کنید:

```bash
runai submit --name sam-exp17-r4 \
  --image registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.9 \
  --gpu 4 --cpu 32 --memory 256Gi \
  --node-pools h200 --large-shm \
  --pvc home:/home/mirzaei \
  --pvc upmwmathis-scratch:/data \
  -e HOME=/home/mirzaei -e USER=mirzaei -e LOGNAME=mirzaei \
  -e PYTHONUNBUFFERED=1 -e SKIP_PLOTS=1 \
  -p upmwmathis-mirzaei --run-as-user --command -- \
  bash /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source/exp17_resume4.sh
```

Log کلی:

```bash
runai logs sam-exp17-r4 -p upmwmathis-mirzaei -f
```

Log یک مدل در حال Train روی Headnode:

```bash
tail -f /mnt/upmwmathis/scratch/hossein/mm_project/EXP17_MIHILI_CO/logs/exp17-co-s42-noise-0p5.log
```

و پس از اجرا:

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
python3 exp17_resume4.py --plan
```

**اگر Job متوقف شود:** همان RunAI command را با نام Job جدید اجرا کنید؛ Scheduler از Scratch می‌خواند و فقط مدل‌های ناقص را مجدداً از ابتدا آموزش می‌دهد. پیشرفت درون یک مدل (قبل از ذخیرهٔ checkpoint نهایی) قابل Resume از همان Step نیست.

## احتیاط

- ۹ نتیجهٔ HOME نه حذف و نه بازنویسی می‌شوند. `--prepare` کپی می‌کند.
- برای مدل‌های مختلف فایل خروجی جداگانه ساخته می‌شود؛ خطای یک مدل هم در لاگ خودش باقی می‌ماند.
- به دلیل تفاوت مسیر Host و Pod، برای خروجی آموزش **مسیر `/data/...`** استفاده شده؛ در Headnode فایل‌ها را از **`/mnt/upmwmathis/scratch/...`** بخوانید.
- به‌دلیل فقدان Traceback نمی‌توان علت دقیق توقف قبلی را به Disk Quota نسبت داد. در این Runner یک تست نوشتن روی Scratch و گزارش مقدار فضای خالی انجام می‌شود، اما این تست جایگزین بررسی سهمیهٔ کاربر نیست.
- اجرای زندهٔ این فایل بر روی RunAI در محیط ChatGPT امکان‌پذیر نبود؛ پیش از Submit، خروجی `--prepare` و `--plan` باید با ۹ مدل کامل و ۱۵ مدل Pending تطبیق داشته باشد.
