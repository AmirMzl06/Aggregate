# Acorn-SVD: spectral-gap subspace attacks for CEBRA

Acorn-SVD is built on the previous project (CEBRA with PGD on `batch.reference`).
It keeps that PGD **bit-exact** and adds spectral-gap attacks: perturbations
whose directions are set by the singular vectors of every reference window and
whose per-window budget is set by its spectral gap, with a closed-form guarantee
that the dominant singular structure cannot collapse. The off-manifold variant
leaves the top-k structure exactly unchanged. The on-manifold variant moves
along it, but never far enough for the k-th and (k+1)-th singular values to
cross.

## Formulation

For a reference window `X` (neurons x time), centre each neuron over time and
take the SVD `Xc = U diag(s) V^T`, `s_1 >= s_2 >= ...`. For a chosen `k`, the
attack may only use perturbations in

```
S_k = { D : U_k^T D = 0  and  D V_k = 0 }        projection: D -> (I - U_k U_k^T) D (I - V_k V_k^T)
```

with the per-window L2 (Frobenius) budget

```
eps_i = min(adv_epsilon, gamma * (s_k - s_{k+1})),      0 < gamma < 1
k     = argmax_{k_min <= k <= k_max} (s_k - s_{k+1})      (the largest spectral gap)
```

**Guarantee.** `Xc + D = U_k diag(s_1..s_k) V_k^T + (R + D)`, where the residual
`R + D` is orthogonal to `U_k` and `V_k`. Its largest singular value is at most
`s_{k+1} + ||D||_2 < s_k` (Weyl, and `||D||_2 <= ||D||_F <= gamma * gap`). So the
top-k singular values **and** singular vectors of the attacked window are exactly
those of the clean window. `eps_i` is the largest radius with this guarantee: it
answers "how far can epsilon go before the SVD structure collapses", in closed
form, without search or backtracking. Centring commutes with the projection
(the right singular vectors are orthogonal to the constant vector), so the
guarantee holds for the centred window as well.

Every PGD iterate stays in the allowed set:

- random start: `P(noise)` scaled to a random radius in `[0, eps_i]`;
- step: `x <- x + alpha_i * P(g) / ||P(g)||` with `alpha_i = eps_i * adv_alpha / adv_epsilon`;
- projection: `delta <- P(delta)`, then scaled into the `eps_i` ball.

This projection is the exact Euclidean projection onto `S_k ∩ ball(eps_i)`,
because `S_k` is a linear subspace through the origin.

### On-manifold variant (`tangent`)

The orthogonal complement of `S_k` is the tangent space of the rank-k matrices at
the dominant structure, `T_k = { U_k A + B V_k^T }` (projection `D -> D - P_S(D)`).
These directions change the top-k singular values and vectors. With the budget

```
eps_i = min(adv_epsilon, gamma * (s_k - s_{k+1}) / 2)
```

every singular value moves by at most `||D||_2 < gap / 2` (Weyl). So `s_k` and
`s_{k+1}` cannot cross, and at least `(1 - gamma) * gap` of the gap survives: the
top-k structure is perturbed, but it cannot collapse into the rest of the
spectrum. The diagnostic `gap_kept` measures the surviving fraction.

## Modes (`adv_spectral_mode`)

| Mode | Projection | Budget | Purpose |
| --- | --- | --- | --- |
| `none` | no | `adv_epsilon` | Previous project's PGD (L2 or Linf), bit-exact |
| `gap` | complement `S_k` | `min(adv_epsilon, gamma * gap)` | Off-manifold: top-k exactly unchanged |
| `tangent` | tangent `T_k` | `min(adv_epsilon, gamma * gap / 2)` | On-manifold: top-k moves, no collapse |
| `split` | both, separately | complement `adv_epsilon`, tangent `min(adv_epsilon, gamma * gap / 2)`, then a joint operator-norm certificate | Both geometries, no collapse (THEORY.md, Proposition 5) |
| `subspace` | complement `S_k` | `adv_epsilon` | Ablation: directions only (exact only where `adv_epsilon < gap`) |
| `gap_budget` | no | `min(adv_epsilon, gamma * gap)` | Ablation: budget only (no guarantee) |
| `tangent_budget` | no | `min(adv_epsilon, gamma * gap / 2)` | Ablation: the budget of `tangent` without its projection |

Spectral modes need `attack_norm="l2"`. The step size of every window is the
same fraction `adv_alpha / adv_epsilon` of its own budget. To let the gap alone
set the budget, use a large `adv_epsilon` with the same ratio, e.g.
`adv_epsilon=1e3, adv_alpha=200`.

## Parameters

| Parameter | Default | Meaning |
| --- | --- | --- |
| `training_mode` | `"standard"` | `"adversarial"` adds one update on attacked references after each clean update |
| `adv_epsilon`, `adv_alpha`, `adv_steps`, `attack_norm` | as before | PGD budget, step, steps, norm |
| `adv_spectral_mode` | `"none"` | See the table above |
| `adv_spectral_gamma` | `0.9` | Fraction of the gap used as budget, in (0, 1) |
| `adv_spectral_k_min`, `adv_spectral_k_max` | `1`, `8` | Range searched for the largest gap; equal values fix `k` |
| `adv_spectral_center` | `True` | Centre each neuron over time before the SVD |
| `adv_spectral_preserve_mean` | `False` | Also protect the constant direction: no neuron's mean changes |
| `adv_attack_eval_mode` | `False` | Attack with dropout off and cached positive/negative embeddings. `False` matches the previous project |
| `adv_diagnostics_every` | `0` | Every n adversarial steps, record how much the attack changed the top-k structure |

```python
import cebra

model = cebra.CEBRA(
    model_architecture="offset36-model-more-dropout", batch_size=2048,
    max_iterations=3000, training_mode="adversarial", attack_norm="l2",
    adv_epsilon=3.0, adv_alpha=0.6, adv_steps=10,
    adv_spectral_mode="gap", adv_spectral_gamma=0.9,
    adv_diagnostics_every=50,
)
model.fit(X_train, y_train)          # X: time x neurons
model.solver_.log["adv_eps_mean"]     # realised budgets per iteration
model.solver_.log["adv_diagnostics"]  # top-k preservation checks
```

## Logged statistics (`solver_.log`)

| Key | Meaning |
| --- | --- |
| `total`, `pos`, `neg` | Clean update (always the clean loss, also for Linf) |
| `adv_loss` | Loss of the update on attacked references |
| `adv_delta_norm` | Mean perturbation norm |
| `adv_eps_mean`, `adv_eps_min` | Realised per-window budgets |
| `adv_gap_limited` | Fraction of windows whose budget is set by the gap rather than `adv_epsilon` |
| `adv_k_mean`, `adv_gap_mean` | Chosen `k` and gap `s_k - s_{k+1}` |
| `adv_diagnostics` | List of dicts: `sv_err` (top-k singular value change / s_1), left/right subspace distance, whole-spectrum drift, `delta_over_gap`, `gap_kept` (margin of the weakest clean dominant direction over the strongest complement direction, divided by the gap; `<= 0` is a collapse), `collapse_fraction`, `mode_exchange_fraction` (top-k subspace turned by more than 45°) |
| `adv_tangent_norm`, `adv_complement_norm` | Size of the tangent and complement parts of the realised perturbation |

The diagnostics use the same `k` for every mode, so plain PGD can be compared
with the gap attack: PGD changes the top-k structure, the gap attack keeps it to
float precision.

## Speed

Measured on one RTX A5000, batch 2048, 100 neurons, 36-bin windows,
`offset36-model-more-dropout`, 10 attack steps:

| Training | s / iteration | 3000 iterations |
| --- | --- | --- |
| clean | 0.04 | 2 min |
| PGD (`none`) | 0.26 | 13 min |
| `gap` | 0.32 | 16 min |
| `gap` with `adv_attack_eval_mode=True` | 0.24 | 12 min |
| previous SVD fork, gate / guided (counts) | 11 / 35 | 9 h / 30 h |

One SVD of all 2048 windows takes ~37 ms. It is computed from the float64
eigendecomposition of each window's small Gram matrix (time x time) on the CPU,
split over 8 single-threaded workers. PyTorch's default CUDA SVD takes ~2.4 s
for the same batch. cuSOLVER's faster `gesvda` driver fails on degenerate
windows, such as windows with several silent bins, which are common in spike
counts. The Gram route never fails and is exact to float64 precision for the
leading modes.

## Runner

`run_acorn_svd.py` trains the arms `clean`, `pgd`, `svd_gap`, `svd_tangent`,
`svd_split`, `svd_gap_uncapped` and the ablations `svd_subspace`,
`svd_gap_budget` and `svd_tangent_budget` for several seeds, with the same
encoder and decoder settings as the previous runner. `--train-epsilon` sets the
training budget, e.g. for a PGD arm that matches the mean budget of `svd_gap`.
`--gamma`, `--k-min` and `--k-max` change the spectral settings of training;
the evaluation attacks keep `gamma = 0.9` and `k ∈ [1, 8]`. For every (seed, arm)
it reports:

- validation R2;
- R2 under held-out attacks on the validation windows (frozen encoder and decoder, 20 steps, eps = 3 in every run): plain PGD, off-manifold gap and on-manifold tangent;
- R2 on corrupted recordings: Poisson resampling, 10% / 30% of units removed, per-neuron gain drift (log-normal, sigma 0.3), averaged over 5 draws;
- realised budgets, diagnostics and seconds per iteration.

Results are saved after every arm. `aggregate_results.py` combines run
directories into two tables: mean ± std, and paired differences to a baseline
arm, matched on (session, seed).

`analyze_corruption_geometry.py --data …` measures where each recording
corruption lives relative to every window's dominant structure. It reports
the fraction of the perturbation energy in the tangent space `T_k`, against
the fraction for a random direction. On a Perich CO session with the same
spectral statistics as C-CO12, Poisson resampling is at chance level (7% vs
5%). Removing units (14–17%) and gain drift (18%) are about three times
enriched in `T_k`.

## Reproducibility

Upstream CEBRA seeds its batch samplers (`cebra.distributions.base.HasGenerator`)
from system entropy, so `torch.manual_seed` did not fix the sequence of training
batches, and two runs with the same seed differed. Acorn-SVD derives the
sampler seed from `torch.initial_seed()` without consuming the global generator.
Two fits with the same seed now give bit-identical embeddings on CUDA. All arms
with the same seed train on the identical batch sequence, so the paired
comparisons between arms are exact.

```bash
python -u run_acorn_svd.py --data /path/to/C-CO12.npz                  # default arms x 3 seeds
python -u run_acorn_svd.py --data ... --arms pgd --train-epsilon 2.2      # budget-matched PGD
python aggregate_results.py ACORN_SVD_RESULTS --baseline pgd@3
```

## Verification

- `tests/test_spectral_gap.py` covers:
  - the guarantee in float64 (top-k values and vectors unchanged at the budget boundary, for centred and raw SVD, tall and wide windows), with a control that an unprojected perturbation of the same size changes them;
  - that the projection is an orthogonal projector;
  - the budget and `k` rule;
  - mean preservation;
  - degenerate windows;
  - the SVD on CUDA with degenerate windows (silent window, single spike), against float64 LAPACK;
  - that plain PGD equals a copy of the previous implementation;
  - solver logging and mode restoration;
  - checkpoint and sklearn round trips;
  - hybrid training.
- `none` mode reproduces the previous project's trained weights bit for bit (L2 and Linf, CPU and CUDA) when run side by side with the original package.
- Existing CEBRA tests: no new failures compared with the previous project. `trial_ids` handling now also works for datasets without trial information, which fixes 15 previously failing solver and loader tests.

## Notes

- Perturbations are continuous, as in the previous project. They are not integer spike counts.
- The guarantee concerns the top-k singular triplets of each window. It does not say that the window is physiologically valid, or that structure beyond the top k is preserved.
- Hybrid (`hybrid=True`) adversarial training now attacks the sum of the behavior and time losses for both norms. The previous project's hybrid L2 branch used only the behavior loss, and it accumulated attack gradients into the parameter update.
- Multi-session and full-batch adversarial training are rejected with an explicit error.
- `pkg_resources` (removed from recent setuptools) was replaced by `packaging`.
