# Acorn-SVD: spectral-gap subspace attacks for CEBRA

Acorn-SVD is built on the previous project (CEBRA with PGD on `batch.reference`).
It keeps that PGD **bit-exact** and adds spectral-gap attacks: perturbations
whose directions are set by the singular vectors of every reference window and
whose per-window budget is set by its spectral gap, with a closed-form guarantee
that the dominant singular structure cannot collapse. The off-manifold variant
leaves the top-k structure exactly unchanged. The on-manifold variant moves
along it, but never far enough for the k-th and (k+1)-th singular values to
cross.

## Formulation

For a reference window `X` (neurons x time), centre each neuron over time and
take the SVD `Xc = U diag(s) V^T`, `s_1 >= s_2 >= ...`. For a chosen `k`, the
attack may only use perturbations in

```
S_k = { D : U_k^T D = 0  and  D V_k = 0 }        projection: D -> (I - U_k U_k^T) D (I - V_k V_k^T)
```

with the per-window L2 (Frobenius) budget

```
eps_i = min(adv_epsilon, gamma * (s_k - s_{k+1})),      0 < gamma < 1
k     = argmax_{k_min <= k <= k_max} (s_k - s_{k+1})      (the largest spectral gap)
```

**Guarantee.** `Xc + D = U_k diag(s_1..s_k) V_k^T + (R + D)`, where the residual
`R + D` is orthogonal to `U_k` and `V_k`. Its largest singular value is at most
`s_{k+1} + ||D||_2 < s_k` (Weyl, and `||D||_2 <= ||D||_F <= gamma * gap`). So the
top-k singular values **and** singular vectors of the attacked window are exactly
those of the clean window. `eps_i` is the largest radius with this guarantee: it
answers "how far can epsilon go before the SVD structure collapses", in closed
form, without search or backtracking. Centring commutes with the projection
(the right singular vectors are orthogonal to the constant vector), so the
guarantee holds for the centred window as well.

Every PGD iterate stays in the allowed set:

- random start: `P(noise)` scaled to a random radius in `[0, eps_i]`;
- step: `x <- x + alpha_i * P(g) / ||P(g)||` with `alpha_i = eps_i * adv_alpha / adv_epsilon`;
- projection: `delta <- P(delta)`, then scaled into the `eps_i` ball.

This projection is the exact Euclidean projection onto `S_k ∩ ball(eps_i)`,
because `S_k` is a linear subspace through the origin.

### On-manifold variant (`tangent`)

The orthogonal complement of `S_k` is the tangent space of the rank-k matrices at
the dominant structure, `T_k = { U_k A + B V_k^T }` (projection `D -> D - P_S(D)`).
These directions change the top-k singular values and vectors. With the budget

```
eps_i = min(adv_epsilon, gamma * (s_k - s_{k+1}) / 2)
```

every singular value moves by at most `||D||_2 < gap / 2` (Weyl). So `s_k` and
`s_{k+1}` cannot cross, and at least `(1 - gamma) * gap` of the gap survives: the
top-k structure is perturbed, but it cannot collapse into the rest of the
spectrum. The diagnostic `gap_kept` measures the surviving fraction.

## Modes (`adv_spectral_mode`)

| Mode | Projection | Budget | Purpose |
| --- | --- | --- | --- |
| `none` | no | `adv_epsilon` | Previous project's PGD (L2 or Linf), bit-exact |
| `gap` | complement `S_k` | `min(adv_epsilon, gamma * gap)` | Off-manifold: top-k exactly unchanged |
| `tangent` | tangent `T_k` | `min(adv_epsilon, gamma * gap / 2)` | On-manifold: top-k moves, no collapse |
| `split` | both, separately | tangent `min(adv_epsilon, gamma * gap / 2)`, complement the rest of `adv_epsilon` (total ≤ `adv_epsilon`), then a joint operator-norm certificate | Both geometries, no collapse (THEORY.md, Proposition 5) |
| `subspace` | complement `S_k` | `adv_epsilon` | Full budget; exact wherever `‖D‖_2 < gap` (in practice everywhere) |
| `subspace_cert` | complement `S_k` | `adv_epsilon` and `‖D‖_2 ≤ gamma * gap` (exact projection, Proposition 6); with `adv_spectral_certify="collapse"`, `‖R + DC‖_2 ≤ s_{k+1} + gamma * gap` instead (Proposition 7) | Full budget with the guarantee of Proposition 1 |
| `gap_budget` | no | `min(adv_epsilon, gamma * gap)` | Ablation: budget only (no guarantee) |
| `tangent_budget` | no | `min(adv_epsilon, gamma * gap / 2)` | Ablation: the budget of `tangent` without its projection |
| `tangent_fixed` | tangent `T_k` | `adv_epsilon` | Equal-radius comparison of directions (no certificate) |
| `gap_share` | no | `adv_epsilon * gap_i / mean(gap)` per window: the same fraction of every window's collapse radius, batch mean `adv_epsilon` | Allocation of the PGD budget by the spectral gap (no certificate) |
| `norm_share` | no | `adv_epsilon * ‖Xc_i‖_F / mean(‖Xc‖_F)` per window | Control of `gap_share`: allocation by window scale instead of the gap |
| `pgd_cert` | no | `adv_epsilon`, then scaled along the direction to the largest verified no-collapse radius (Proposition 8) | Plain PGD that never collapses the dominant structure |
| `tangent_cert` | tangent `T_k` | the same | Tangent PGD with the verified radius instead of `gamma * gap / 2` |

Spectral modes need `attack_norm="l2"`. The step size of every window is the
same fraction `adv_alpha / adv_epsilon` of its own budget. To let the gap alone
set the budget, use a large `adv_epsilon` with the same ratio, e.g.
`adv_epsilon=1e3, adv_alpha=200`.

## Parameters

| Parameter | Default | Meaning |
| --- | --- | --- |
| `training_mode` | `"standard"` | `"adversarial"` adds one update on attacked references after each clean update |
| `adv_epsilon`, `adv_alpha`, `adv_steps`, `attack_norm` | as before | PGD budget, step, steps, norm |
| `adv_spectral_mode` | `"none"` | See the table above |
| `adv_spectral_gamma` | `0.9` | Fraction of the gap used as budget, in (0, 1) |
| `adv_spectral_k_min`, `adv_spectral_k_max` | `1`, `8` | Range searched for the largest gap; equal values fix `k` |
| `adv_spectral_center` | `True` | Centre each neuron over time before the SVD |
| `adv_spectral_preserve_mean` | `False` | Also protect the constant direction: no neuron's mean changes |
| `adv_spectral_certify` | `"final"` | `subspace_cert` / `split`: project the final perturbation (`"final"`) or every PGD iterate (`"every"`) onto the certified set; `"radial"` shrinks the final perturbation as a whole (Weyl radius); `"collapse"` (`subspace_cert` only) scales it along its direction to the exact collapse radius (Proposition 7) |
| `adv_spectral_energy_match` | `False` | Run the spectral attack only to measure each window's perturbation norm, then train on unrestricted PGD with that per-window budget |
| `adv_spectral_allocation` | `"window"` | Per-window budgets of `gap_budget`, `tangent_budget`, `gap_share` and energy-matched arms: as computed, `"shuffle"` (randomly permuted over the batch) or `"mean"` (the batch mean for every window) |
| `adv_spectral_split_complement` | `1.0` | `split`: fraction of the remaining budget given to the complement part (trade-off knob) |
| `adv_attack_eval_mode` | `False` | Attack with dropout off and cached positive/negative embeddings. `False` matches the previous project |
| `adv_diagnostics_every` | `0` | Every n adversarial steps, record how much the attack changed the top-k structure |

```python
import cebra

model = cebra.CEBRA(
    model_architecture="offset36-model-more-dropout", batch_size=2048,
    max_iterations=3000, training_mode="adversarial", attack_norm="l2",
    adv_epsilon=3.0, adv_alpha=0.6, adv_steps=10,
    adv_spectral_mode="gap", adv_spectral_gamma=0.9,
    adv_diagnostics_every=50,
)
model.fit(X_train, y_train)          # X: time x neurons
model.solver_.log["adv_eps_mean"]     # realised budgets per iteration
model.solver_.log["adv_diagnostics"]  # top-k preservation checks
```

## Logged statistics (`solver_.log`)

| Key | Meaning |
| --- | --- |
| `total`, `pos`, `neg` | Clean update (always the clean loss, also for Linf) |
| `adv_loss` | Loss of the update on attacked references |
| `adv_delta_norm` | Mean perturbation norm |
| `adv_eps_mean`, `adv_eps_min`, `adv_eps_max` | Realised per-window budgets |
| `adv_gap_limited` | Fraction of windows whose budget is set by the gap rather than `adv_epsilon` |
| `adv_k_mean`, `adv_gap_mean` | Chosen `k` and gap `s_k - s_{k+1}` |
| `adv_diagnostics` | List of dicts: `sv_err` (top-k singular value change / s_1), left/right subspace distance, whole-spectrum drift, `delta_over_gap`, `gap_kept` (margin of the weakest clean dominant direction over the strongest complement direction, divided by the gap; `<= 0` is a collapse), `collapse_fraction`, `mode_exchange_fraction` (top-k subspace turned by more than 45°), `norm_cv` and `norm_gap_corr` (spread of the per-window perturbation norms and their correlation with the gap) |
| `adv_tangent_norm`, `adv_complement_norm` | Size of the tangent and complement parts of the realised perturbation |
| `adv_cert_active`, `adv_cert_retained` | Fraction of windows where the operator-norm certificate binds, and the norm it keeps (relative to the perturbation inside its Frobenius ball) |
| `adv_cert_weyl_gain` | `collapse` only: exact collapse radius along the attack direction divided by the Weyl radius, over windows where it binds |
| `adv_top_unit_energy`, `adv_top_unit_signal` | Share of the perturbation energy, and of the clean centred signal, on the 20% most active units of the batch (uniform spread: 0.2) |

The diagnostics use the same `k` for every mode, so plain PGD can be compared
with the gap attack: PGD changes the top-k structure, the gap attack keeps it to
float precision.

## Speed

Measured on one RTX A5000, batch 2048, 100 neurons, 36-bin windows,
`offset36-model-more-dropout`, 10 attack steps:

| Training | s / iteration | 3000 iterations |
| --- | --- | --- |
| clean | 0.04 | 2 min |
| PGD (`none`) | 0.26 | 13 min |
| `gap`, `tangent` | 0.31–0.32 | 16 min |
| `subspace_cert` (final projection) | 0.36 | 18 min |
| `subspace_cert` with `adv_spectral_certify="every"` | 0.79 | 39 min |
| `subspace_cert` with `adv_spectral_certify="radial"` | 0.33 | 17 min |
| `subspace_cert` with `adv_spectral_certify="collapse"` | 0.35 | 17 min |
| energy-matched controls of `split` / radial `subspace_cert` | 0.59 / 0.52 | 29 / 26 min |
| `split` / `split` every step | 0.42 / 1.06 | 21 / 53 min |
| previous SVD fork, gate / guided (counts) | 11 / 35 | 9 h / 30 h |

The certified rows are worst cases: on noise windows with tiny gaps, almost
every window needs its SVD. In the same benchmark, the certificate is active in
99% of the windows; the exact projection keeps 66% of the perturbation norm and
the radial shrink 34%. The exact collapse radius binds in 0.1% of the windows
and keeps the full budget; where it binds, it reaches 5.6 times the Weyl
radius. A window needs no SVD when its scaled Frobenius
norm is already below the operator-norm bound, so on real data with larger gaps
the certified modes are faster. In the 72-run report of 2026-10-19 (H200, real
data), PGD ran at 0.20 s per iteration, `subspace_cert` at 0.26–0.29 s (final),
0.44–0.65 s (every) and 0.25–0.26 s (radial), and `split` at 0.29–0.35 s.

One SVD of all 2048 windows takes ~37 ms. It is computed from the float64
eigendecomposition of each window's small Gram matrix (time x time) on the CPU,
split over 8 single-threaded workers. PyTorch's default CUDA SVD takes ~2.4 s
for the same batch. cuSOLVER's faster `gesvda` driver fails on degenerate
windows, such as windows with several silent bins, which are common in spike
counts. The Gram route never fails and is exact to float64 precision for the
leading modes.

## Runner

`run_acorn_svd.py` trains, for several seeds and with the encoder and decoder
settings of the previous runner, the default arms:

- `clean`, `pgd`;
- `svd_cert_collapse`: complement directions at exactly PGD's energy (both use the full budget);
- `svd_tangent` and its energy-matched control `svd_tangent_budget` (unrestricted, same per-window budget);
- `svd_tangent_cert` and `pgd_cert`: tangent and plain PGD scaled to the verified no-collapse radius.

`pgd_gap_share` (per-window budget in proportion to the gap, same mean) with its
controls `pgd_gap_share_shuffle` and `pgd_norm_share`, and `pgd_match_radial`
with `pgd_match_radial_shuffle` and `pgd_match_radial_mean`, test the allocation
of the budget.

`clean`, `svd_cert_radial`, `svd_cert_collapse`, `svd_split`, `pgd_match_split`
(with `_shuffle` and `_mean`), `pgd_gap_share_mean`, `pgd_norm_share_*`, `svd_subspace_cert`,
`svd_cert_every`, `svd_tangent`, `svd_split_half`, `svd_split_every`,
`svd_subspace`, `svd_gap`, `svd_gap_uncapped`, `svd_gap_budget`,
`svd_tangent_budget` and `svd_tangent_fixed` are available as further arms and
ablations.

Budgets:

- `--train-epsilon` takes several budgets for a sweep; clean training runs once.
- With `--epsilon-unit window`, the training and evaluation budgets are fractions of the median norm of centred training windows. The attack strength is then comparable across sessions with different numbers of units or firing rates.
- `--scale-only` prints that norm, the budgets in both units, and the 10/50/90% quantiles of the selected gap `g_k`, then exits without training. It takes seconds and is the way to choose window fractions, for example the fractions that reproduce absolute budgets of an earlier session.

For every (seed, arm) the runner reports:

- validation R2;
- R2 under held-out attacks on the validation windows: plain PGD, off-manifold gap, on-manifold tangent, and the two directions at the same radius (`complement`, `tangent_fixed`). The radius is `--eval-epsilon`; the strength is set by `--eval-steps` and `--eval-restarts` (worst restart per window). `--eval-radii` adds plain PGD at further radii (`r2_pgd_eps<r>`), a robustness-versus-radius curve;
- R2 on corrupted recordings: Poisson resampling and gain drift (log-normal, sigma 0.3). For unit loss, the 10 and 30% random masks of earlier runs are kept, plus a nested curve (5–50%, each draw removes a growing prefix of one random order of units). All of these are averaged over 5 draws with their between-draw SD;
- removal of the 20% most active, most variable and most decoding-relevant units (leave-one-unit-out importance, per model);
- per-label R2 for every condition;
- training statistics: realised perturbation norms (mean, 10/50/90% quantiles), the fraction of windows whose perturbation the certificate changed and the norm it retained, the gain of the exact collapse radius over the Weyl radius, the share of the perturbation energy on the 20% most active units, and diagnostics;
- where the decoder is sensitive (`sens_*`, THEORY.md): the share of its input-gradient energy in the tangent space, along per-neuron means, and on the most sensitive and most active units.

Results are saved after every arm. `aggregate_results.py` combines run
directories into tables of mean ± std and of paired differences to a baseline
arm, matched on (session, seed), with a two-sided sign test. With several
sessions it adds the session-level differences (seed mean per session), the
unit for claims across recordings.

`analyze_corruption_geometry.py --data …` measures where each recording
corruption lives relative to every window's dominant structure. It reports
the fraction of the perturbation energy in the tangent space `T_k`, against
the fraction for a random direction. On a Perich CO session with the same
spectral statistics as C-CO12, Poisson resampling is at chance level (7% vs
5%). Removing units (14–17%) and gain drift (18%) are about three times
enriched in `T_k`.

## Reproducibility

Upstream CEBRA seeds its batch samplers (`cebra.distributions.base.HasGenerator`)
from system entropy, so `torch.manual_seed` did not fix the sequence of training
batches, and two runs with the same seed differed. Acorn-SVD derives the
sampler seed from `torch.initial_seed()` without consuming the global generator.
Two fits with the same seed now give bit-identical embeddings on CUDA. All arms
with the same seed train on the identical batch sequence, so the paired
comparisons between arms are exact.

```bash
python -u run_acorn_svd.py --data /path/to/C-CO12.npz                  # default arms x 3 seeds
python -u run_acorn_svd.py --data ... --arms pgd svd_subspace_cert --train-epsilon 1 3 6
python -u run_acorn_svd.py --data ... --scale-only --train-epsilon 1 3 6   # fractions of eps 1, 3, 6
python -u run_acorn_svd.py --data ... --epsilon-unit window --train-epsilon F3 F6 \
       --eval-epsilon F3 --eval-restarts 3             # session-comparable budgets
python -u run_acorn_svd.py --data ... --eval-restarts 3 --eval-radii 1 6   # PGD curve at 1, 3, 6
python aggregate_results.py ACORN_SVD_RESULTS --baseline pgd@3
```

## Verification

- `tests/test_spectral_gap.py` covers:
  - the guarantee in float64 (top-k values and vectors unchanged at the budget boundary, for centred and raw SVD, tall and wide windows), with a control that an unprojected perturbation of the same size changes them;
  - that the projection is an orthogonal projector;
  - the budget and `k` rule;
  - mean preservation;
  - degenerate windows;
  - the SVD on CUDA with degenerate windows (silent window, single spike), against float64 LAPACK;
  - that plain PGD equals a copy of the previous implementation;
  - solver logging and mode restoration;
  - checkpoint and sklearn round trips;
  - hybrid training.
- `none` mode reproduces the previous project's trained weights bit for bit (L2 and Linf, CPU and CUDA) when run side by side with the original package.
- Existing CEBRA tests: no new failures compared with the previous project. `trial_ids` handling now also works for datasets without trial information, which fixes 15 previously failing solver and loader tests.

## Notes

- Perturbations are continuous, as in the previous project. They are not integer spike counts.
- The guarantee concerns the top-k singular triplets of each window. It does not say that the window is physiologically valid, or that structure beyond the top k is preserved.
- Hybrid (`hybrid=True`) adversarial training now attacks the sum of the behavior and time losses for both norms. The previous project's hybrid L2 branch used only the behavior loss, and it accumulated attack gradients into the parameter update.
- Multi-session and full-batch adversarial training are rejected with an explicit error.
- `pkg_resources` (removed from recent setuptools) was replaced by `packaging`.
