"""Aggregate run_acorn_svd.py results over seeds, sessions and runs.

Usage:
    python aggregate_results.py RESULTS_DIR [RESULTS_DIR ...] [--baseline pgd@3]

Reads every results.json / results_so_far.json below the given directories and
groups rows by arm and training budget ("arm@eps"). It prints two tables:
mean ± std over runs, and the paired difference to the baseline arm. Pairs are
matched on (session, seed); arms with the same seed see the same training
batches.
"""

import argparse
import json
from pathlib import Path

import numpy as np

METRICS = ("valid_mean_r2", "r2_pgd", "r2_svd_gap", "r2_svd_tangent", "r2_poisson", "r2_dropout10",
           "r2_dropout30", "r2_gain30", "train_adv_eps_mean", "train_adv_tangent_norm",
           "train_adv_complement_norm", "diag_tangent_energy_fraction", "diag_collapse_fraction",
           "seconds_per_iteration")
PAIRED = ("valid_mean_r2", "r2_pgd", "r2_svd_gap", "r2_poisson", "r2_dropout10", "r2_dropout30",
          "r2_dropout50", "r2_droptop20", "r2_gain30")


def load_rows(directories):
    rows, seen = [], set()
    for directory in directories:
        for path in sorted(Path(directory).rglob("results*.json")):
            if path.name not in ("results.json", "results_so_far.json"):
                continue
            if path.name == "results_so_far.json" and (path.parent / "results.json").exists():
                continue
            session = path.parent.name.split("_")[0]
            config = path.parent / "run_config.json"
            if config.exists():
                session = Path(json.loads(config.read_text())["data_path"]).stem
            for row in json.loads(path.read_text()):
                key = (str(path.parent), row["model"], row["seed"], row.get("epsilon"),
                       row.get("gamma"), tuple(row.get("k_range", ())))
                if key in seen:
                    continue
                seen.add(key)
                group = (row["model"] if row["model"] == "clean" else
                         f"{row['model']}@{row['epsilon']:g}")
                if row.get("gamma", 0.9) != 0.9 and row["model"].startswith("svd"):
                    group += f"/g{row['gamma']:g}"
                if row.get("k_range", [1, 8]) != [1, 8] and row["model"].startswith("svd"):
                    group += "/k{}-{}".format(*row["k_range"])
                row["group"], row["session"] = group, session
                rows.append(row)
    return rows


def _cell(values):
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return "-"
    std = values.std(ddof=1) if values.size > 1 else 0.0
    return f"{values.mean():.4f} ± {std:.4f}"


def summarize(rows, baseline):
    groups = {}
    for row in rows:
        groups.setdefault(row["group"], []).append(row)
    lines = ["| arm | n | " + " | ".join(METRICS) + " |", "|" + "---|" * (len(METRICS) + 2)]
    for group in sorted(groups):
        items = groups[group]
        cells = [_cell([row[m] for row in items if m in row]) for m in METRICS]
        lines.append(f"| {group} | {len(items)} | " + " | ".join(cells) + " |")

    base = {(row["session"], row["seed"]): row for row in groups.get(baseline, [])}
    lines += ["", f"Paired difference to {baseline}, matched on (session, seed): "
              "mean ± std (wins/pairs)", "",
              "| arm | " + " | ".join(f"Δ {m}" for m in PAIRED) + " |",
              "|" + "---|" * (len(PAIRED) + 1)]
    for group in sorted(groups):
        if group == baseline:
            continue
        cells = []
        for metric in PAIRED:
            diffs = np.array([row[metric] - base[(row["session"], row["seed"])][metric]
                              for row in groups[group]
                              if (row["session"], row["seed"]) in base and metric in row
                              and metric in base[(row["session"], row["seed"])]])
            if diffs.size == 0:
                cells.append("-")
                continue
            std = diffs.std(ddof=1) if diffs.size > 1 else 0.0
            cells.append(f"{diffs.mean():+.4f} ± {std:.4f} ({int((diffs > 0).sum())}/{diffs.size})")
        lines.append(f"| {group} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("directories", nargs="+")
    parser.add_argument("--baseline", default="pgd@3")
    args = parser.parse_args()
    rows = load_rows(args.directories)
    if not rows:
        raise SystemExit("No results found.")
    print(summarize(rows, args.baseline))


if __name__ == "__main__":
    main()
