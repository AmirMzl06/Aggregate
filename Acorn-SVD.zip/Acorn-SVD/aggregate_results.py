"""Aggregate run_acorn_svd.py results over seeds and runs.

Usage:
    python aggregate_results.py RESULTS_DIR [RESULTS_DIR ...] [--baseline pgd@3]

Reads every results.json / results_so_far.json below the given directories,
groups rows by arm and training budget ("arm@eps"), and prints mean ± std over
seeds plus the paired difference to the baseline arm on the same seeds.
"""

import argparse
import json
from pathlib import Path

import numpy as np

METRICS = ("valid_mean_r2", "r2_pgd", "r2_svd_gap", "r2_svd_tangent", "r2_poisson", "r2_dropout10",
           "r2_dropout30", "r2_gain30", "train_adv_eps_mean", "seconds_per_iteration")


def load_rows(directories):
    rows, seen = [], set()
    for directory in directories:
        for path in sorted(Path(directory).rglob("results*.json")):
            if path.name not in ("results.json", "results_so_far.json"):
                continue
            if path.name == "results_so_far.json" and (path.parent / "results.json").exists():
                continue
            for row in json.loads(path.read_text()):
                key = (str(path.parent), row["model"], row["seed"])
                if key not in seen:
                    seen.add(key)
                    row["group"] = (row["model"] if row["model"] == "clean" else
                                    f"{row['model']}@{row['epsilon']:g}")
                    rows.append(row)
    return rows


def summarize(rows, baseline):
    groups = {}
    for row in rows:
        groups.setdefault(row["group"], []).append(row)
    base = {row["seed"]: row for row in groups.get(baseline, [])}
    lines = ["| arm | n | " + " | ".join(METRICS) + f" | Δ clean R2 vs {baseline} (paired) |",
             "|" + "---|" * (len(METRICS) + 3)]
    for group in sorted(groups):
        items = groups[group]
        cells = []
        for metric in METRICS:
            values = np.array([row[metric] for row in items if metric in row], dtype=float)
            if values.size == 0:
                cells.append("-")
            else:
                std = values.std(ddof=1) if values.size > 1 else 0.0
                cells.append(f"{values.mean():.4f} ± {std:.4f}")
        diffs = np.array([row["valid_mean_r2"] - base[row["seed"]]["valid_mean_r2"]
                          for row in items if row["seed"] in base])
        if group == baseline or diffs.size == 0:
            delta = "-"
        else:
            std = diffs.std(ddof=1) if diffs.size > 1 else 0.0
            wins = int((diffs > 0).sum())
            delta = f"{diffs.mean():+.4f} ± {std:.4f} ({wins}/{diffs.size} seeds better)"
        lines.append(f"| {group} | {len(items)} | " + " | ".join(cells) + f" | {delta} |")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("directories", nargs="+")
    parser.add_argument("--baseline", default="pgd@3")
    args = parser.parse_args()
    rows = load_rows(args.directories)
    if not rows:
        raise SystemExit("No results found.")
    print(summarize(rows, args.baseline))


if __name__ == "__main__":
    main()
