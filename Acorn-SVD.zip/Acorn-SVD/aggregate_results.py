"""Aggregate run_acorn_svd.py results over seeds, sessions and runs.

Usage:
    python aggregate_results.py RESULTS_DIR [RESULTS_DIR ...] [--baseline pgd@3]

Reads every results.json / results_so_far.json below the given directories and
groups rows by arm and training budget ("arm@eps"). It prints mean ± std over
runs and the paired difference to the baseline arm. Pairs are matched on
(session, seed); arms with the same seed see the same training batches. With
several sessions it also prints the session-level differences (mean over the
seeds of each session), the unit for claims across recordings. Both difference
tables give a two-sided sign test.
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np

METRICS = ("valid_mean_r2", "r2_pgd", "r2_svd_gap", "r2_svd_tangent", "r2_complement",
           "r2_tangent_fixed", "r2_poisson", "r2_dropout30", "r2_nested30", "r2_nested50",
           "r2_droptop20", "r2_dropvar20", "r2_dropimp20", "unit_importance_top_share",
           "r2_gain30", "train_adv_delta_norm", "train_adv_cert_active",
           "train_adv_cert_retained", "train_adv_cert_weyl_gain", "train_adv_top_unit_energy",
           "train_adv_top_unit_signal", "train_adv_tangent_norm", "train_adv_complement_norm",
           "train_adv_delta_norm_p10", "train_adv_delta_norm_p90", "diag_norm_gap_corr",
           "sens_tangent_fraction", "sens_tangent_chance", "sens_mean_fraction",
           "sens_unit_top_share",
           "diag_tangent_energy_fraction", "diag_collapse_fraction", "seconds_per_iteration")
PAIRED = ("valid_mean_r2", "r2_pgd", "r2_complement", "r2_tangent_fixed", "r2_poisson",
          "r2_dropout30", "r2_nested30", "r2_nested50", "r2_droptop20", "r2_dropvar20",
          "r2_dropimp20", "unit_importance_top_share", "r2_gain30", "sens_tangent_fraction",
          "sens_unit_top_share")


def load_rows(directories):
    rows, seen = [], set()
    for directory in directories:
        for path in sorted(Path(directory).rglob("results*.json")):
            if path.name not in ("results.json", "results_so_far.json"):
                continue
            if path.name == "results_so_far.json" and (path.parent / "results.json").exists():
                continue
            session = path.parent.name.split("_")[0]
            config = path.parent / "run_config.json"
            if config.exists():
                session = Path(json.loads(config.read_text())["data_path"]).stem
            for row in json.loads(path.read_text()):
                key = (str(path.parent), row["model"], row["seed"], row.get("epsilon"),
                       row.get("gamma"), tuple(row.get("k_range", ())), row.get("epsilon_unit"))
                if key in seen:
                    continue
                seen.add(key)
                unit = "w" if row.get("epsilon_unit") == "window" else ""
                group = (row["model"] if row["model"] == "clean" else
                         f"{row['model']}@{row.get('epsilon_nominal', row['epsilon']):g}{unit}")
                if row.get("gamma", 0.9) != 0.9 and row["model"].startswith("svd"):
                    group += f"/g{row['gamma']:g}"
                if row.get("k_range", [1, 8]) != [1, 8] and row["model"].startswith("svd"):
                    group += "/k{}-{}".format(*row["k_range"])
                row["group"], row["session"] = group, session
                rows.append(row)
    return rows


def _cell(values):
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return "-"
    std = values.std(ddof=1) if values.size > 1 else 0.0
    return f"{values.mean():.4f} ± {std:.4f}"


def radius_columns(rows):
    """PGD results at the extra evaluation radii of the runner (--eval-radii)."""
    return sorted({key for row in rows for key in row
                   if key.startswith("r2_pgd_eps") and not key.endswith("_per_label")})


def sign_test(diffs):
    """Two-sided exact sign test of positive against negative differences (ties dropped)."""
    wins, losses = int((diffs > 0).sum()), int((diffs < 0).sum())
    n = wins + losses
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, i) for i in range(min(wins, losses) + 1)) / 2**n
    return min(1.0, 2 * tail)


def _paired_table(groups, baseline, metrics, unit):
    """Differences to the baseline per (session, seed) pair or per session."""
    def key(row):
        return row["session"] if unit == "session" else (row["session"], row["seed"])

    def means(items, metric):
        values = {}
        for row in items:
            if metric in row:
                values.setdefault(key(row), []).append(row[metric])
        return {name: float(np.mean(v)) for name, v in values.items()}

    lines = ["| arm | " + " | ".join(f"Δ {m}" for m in metrics) + " |",
             "|" + "---|" * (len(metrics) + 1)]
    for group in sorted(groups):
        if group == baseline:
            continue
        cells = []
        for metric in metrics:
            base, mine = means(groups[baseline], metric), means(groups[group], metric)
            diffs = np.array([mine[name] - base[name] for name in mine if name in base])
            if diffs.size == 0:
                cells.append("-")
                continue
            std = diffs.std(ddof=1) if diffs.size > 1 else 0.0
            cells.append(f"{diffs.mean():+.4f} ± {std:.4f} ({int((diffs > 0).sum())}/{diffs.size}, "
                         f"p={sign_test(diffs):.2g})")
        lines.append(f"| {group} | " + " | ".join(cells) + " |")
    return lines


def summarize(rows, baseline):
    metrics = METRICS[:2] + tuple(radius_columns(rows)) + METRICS[2:]
    paired = PAIRED[:2] + tuple(radius_columns(rows)) + PAIRED[2:]
    groups = {}
    for row in rows:
        groups.setdefault(row["group"], []).append(row)
    lines = ["| arm | n | " + " | ".join(metrics) + " |", "|" + "---|" * (len(metrics) + 2)]
    for group in sorted(groups):
        items = groups[group]
        cells = [_cell([row[m] for row in items if m in row]) for m in metrics]
        lines.append(f"| {group} | {len(items)} | " + " | ".join(cells) + " |")

    if baseline not in groups:
        return "\n".join(lines + ["", f"Baseline {baseline} not found."])
    lines += ["", f"Paired difference to {baseline}, matched on (session, seed): "
              "mean ± std (wins/pairs, sign-test p)", ""]
    lines += _paired_table(groups, baseline, paired, "pair")
    if len({row["session"] for row in rows}) > 1:
        lines += ["", f"Session-level difference to {baseline} (seed mean per session): "
                  "mean ± std (wins/sessions, sign-test p)", ""]
        lines += _paired_table(groups, baseline, paired, "session")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("directories", nargs="+")
    parser.add_argument("--baseline", default="pgd@3")
    args = parser.parse_args()
    rows = load_rows(args.directories)
    if not rows:
        raise SystemExit("No results found.")
    print(summarize(rows, args.baseline))


if __name__ == "__main__":
    main()
