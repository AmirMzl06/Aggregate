#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Tests for the spectral-gap subspace attack and its solver integration."""

import dataclasses

import numpy as np
import pytest
import torch

import cebra
import cebra.data
import cebra.models
import cebra.solver
from cebra.solver import spectral_gap as sg


def _windows(batch=16, neurons=12, time=10, rank=3, noise=0.3, seed=0,
             dtype=torch.float64):
    """Low-rank windows plus noise, so the top singular modes are separated."""
    gen = torch.Generator().manual_seed(seed)
    left = torch.randn(batch, neurons, rank, generator=gen, dtype=dtype)
    right = torch.randn(batch, rank, time, generator=gen, dtype=dtype)
    scale = torch.tensor([6.0, 3.0, 1.5][:rank], dtype=dtype)
    signal = left @ (scale[:, None] * right)
    return signal + noise * torch.randn(
        batch, neurons, time, generator=gen, dtype=dtype)


def _config(**kwargs):
    defaults = dict(epsilon=10.0, alpha=2.0, steps=5, norm="l2", mode="gap")
    defaults.update(kwargs)
    return sg.AttackConfig(**defaults)


def _top(windows, k, center=True):
    matrix = windows - windows.mean(-1, keepdim=True) if center else windows
    u, s, vh = torch.linalg.svd(matrix, full_matrices=False)
    return u[..., :k], s[..., :k], vh.mT[..., :k]


def _projector_distance(a, b):
    return (a @ a.mT - b @ b.mT).norm()


@pytest.mark.parametrize("kwargs", [
    dict(norm="l1"),
    dict(mode="svd"),
    dict(mode="gap", norm="linf"),
    dict(gamma=0.0),
    dict(gamma=1.0),
    dict(k_min=0),
    dict(k_min=3, k_max=2),
    dict(epsilon=-1.0),
    dict(epsilon=float("nan")),
    dict(steps=-1),
    dict(steps=True),
    dict(center=1),
    dict(mode="gap_budget", preserve_mean=True),
    dict(mode="tangent", preserve_mean=True),
    dict(mode="tangent", norm="linf"),
    dict(mode="split", preserve_mean=True),
    dict(mode="split", norm="linf"),
    dict(mode="subspace_cert", certify="always"),
    dict(mode="split", split_complement=1.5),
    dict(mode="split", certify="collapse"),
    dict(mode="none", energy_match=True),
    dict(energy_match=1),
])
def test_invalid_configs(kwargs):
    with pytest.raises(ValueError):
        _config(**kwargs)


def test_projection_is_orthogonal_projector():
    windows = _windows()
    frame = sg.spectral_frame(windows, _config())
    g, h = torch.randn_like(windows), torch.randn_like(windows)
    pg = sg.project(g, frame)
    assert torch.allclose(sg.project(pg, frame), pg, atol=1e-12)
    # Self-adjoint: <P g, h> == <g, P h>.
    assert torch.allclose((pg * h).sum(), (g * sg.project(h, frame)).sum())
    assert (frame.left.mT @ pg).abs().max() < 1e-12
    assert (pg @ frame.right).abs().max() < 1e-12


@pytest.mark.parametrize("center", [True, False])
@pytest.mark.parametrize("shape", [(12, 10), (5, 14)])
def test_gap_budget_keeps_top_k_triplets_exactly(center, shape):
    windows = _windows(neurons=shape[0], time=shape[1], seed=1)
    config = _config(center=center, gamma=0.99)
    frame = sg.spectral_frame(windows, config)
    assert (frame.epsilon > 0).all()
    # Worst case inside the budget: a projected direction with norm eps_i.
    delta = sg.project(torch.randn_like(windows), frame)
    norm = delta.flatten(1).norm(dim=1)
    delta = delta * (frame.epsilon / norm)[:, None, None]
    for i in range(len(windows)):
        k = int(frame.k[i])
        u0, s0, v0 = _top(windows[i], k, center)
        u1, s1, v1 = _top(windows[i] + delta[i], k, center)
        assert torch.allclose(s0, s1, rtol=0, atol=1e-10 * float(s0[0]))
        assert _projector_distance(u0, u1) < 1e-9
        assert _projector_distance(v0, v1) < 1e-9

    # Control: an unprojected perturbation of the same size changes them.
    free = torch.randn_like(windows)
    free = free * (frame.epsilon / free.flatten(1).norm(dim=1))[:, None, None]
    changes = [(_top(windows[i] + free[i], int(frame.k[i]), center)[1] -
                _top(windows[i], int(frame.k[i]), center)[1]).abs().max()
               for i in range(len(windows))]
    assert max(changes) > 1e-3


def test_tangent_and_complement_split_the_space():
    windows = _windows(seed=8)
    frame = sg.spectral_frame(windows, _config(mode="tangent"))
    g = torch.randn_like(windows)
    tangent, complement = sg.project_tangent(g, frame), sg.project(g, frame)
    assert torch.allclose(tangent + complement, g)
    assert (tangent * complement).sum((-1, -2)).abs().max() < 1e-10
    assert torch.allclose(sg.project_tangent(tangent, frame), tangent, atol=1e-12)


@pytest.mark.parametrize("center", [True, False])
def test_tangent_budget_prevents_collapse(center):
    windows = _windows(seed=9)
    config = _config(mode="tangent", gamma=0.99, center=center)
    frame = sg.spectral_frame(windows, config)
    assert torch.allclose(frame.epsilon,
                          torch.clamp(0.99 * frame.gap / 2, max=config.epsilon))
    # Worst case: tangent directions with the full budget, both signs.
    delta = sg.project_tangent(torch.randn_like(windows), frame)
    delta = delta * (frame.epsilon / delta.flatten(1).norm(dim=1))[:, None, None]
    for sign in (1, -1):
        for i in range(len(windows)):
            k = int(frame.k[i])
            matrix = windows[i] + sign * delta[i]
            matrix = matrix - matrix.mean(-1, keepdim=True) if center else matrix
            values = torch.linalg.svdvals(matrix)
            assert values[k - 1] - values[k] >= 0.005 * frame.gap[i] - 1e-9
    # The dominant structure does change (unlike the complement mode).
    k = int(frame.k[0])
    assert (_top(windows[0] + delta[0], k, center)[1] -
            _top(windows[0], k, center)[1]).abs().max() > 1e-3


def test_tangent_attack_stays_on_manifold():
    windows = _windows(seed=10)
    config = _config(mode="tangent", epsilon=5.0, alpha=1.0, steps=8)
    frame = sg.spectral_frame(windows, config)
    attacked = sg.attack(windows, _quadratic_loss(windows), config, frame)
    delta = attacked - windows
    assert torch.allclose(sg.project_tangent(delta, frame), delta, atol=1e-10)
    assert torch.all(delta.flatten(1).norm(dim=1) <= frame.epsilon * (1 + 1e-9))
    diagnostics = sg.spectral_diagnostics(windows, attacked, config, frame)
    assert diagnostics["gap_kept_min"] > 0
    assert diagnostics["sv_err_max"] > 1e-6


def test_gap_is_the_collapse_radius():
    """Proposition 2: just above the gap, a complement direction collapses top-k."""
    windows = _windows(seed=11)
    frame = sg.spectral_frame(windows, _config())
    centred = windows - windows.mean(-1, keepdim=True)
    u, s, vh = torch.linalg.svd(centred, full_matrices=False)
    for i in range(len(windows)):
        k = int(frame.k[i])
        gap = float(s[i, k - 1] - s[i, k])
        direction = torch.outer(u[i, :, k], vh[i, k])
        for scale, collapses in ((0.99 * gap, False), (1.01 * gap, True)):
            delta = scale * direction
            assert torch.allclose(sg.project(delta[None], sg.SpectralFrame(
                frame.left[i:i + 1], frame.right[i:i + 1], frame.k[i:i + 1],
                frame.gap[i:i + 1], frame.epsilon[i:i + 1], frame.values[i:i + 1]))[0],
                                  delta, atol=1e-10)
            top = torch.linalg.svdvals(centred[i] + delta)[:k]
            assert (not torch.allclose(top, s[i, :k], atol=1e-8)) == collapses


def _single(frame, i):
    return sg.SpectralFrame(frame.left[i:i + 1], frame.right[i:i + 1], frame.k[i:i + 1],
                            frame.gap[i:i + 1], frame.epsilon[i:i + 1],
                            frame.values[i:i + 1])


def test_collapse_diagnostic_detects_mode_exchange():
    windows = _windows(seed=12)
    config = _config()
    clean = sg.spectral_diagnostics(windows, windows.clone(), config)
    assert clean["gap_kept_min"] == pytest.approx(1, abs=1e-8)
    assert clean["collapse_fraction"] == 0 and clean["mode_exchange_fraction"] == 0
    frame = sg.spectral_frame(windows, config)
    centred = windows - windows.mean(-1, keepdim=True)
    u, s, vh = torch.linalg.svd(centred, full_matrices=False)
    k = frame.k
    rows = torch.arange(len(windows))
    direction = u[rows, :, k][..., None] * vh[rows, k][:, None, :]  # u_{k+1} v_{k+1}^T
    gap = (s[rows, k - 1] - s[rows, k])[:, None, None]
    below = sg.spectral_diagnostics(windows, windows + 0.5 * gap * direction, config)
    assert below["collapse_fraction"] == 0
    assert below["gap_kept_min"] == pytest.approx(0.5, abs=1e-6)
    above = sg.spectral_diagnostics(windows, windows + 1.5 * gap * direction, config)
    assert above["collapse_fraction"] == 1
    assert above["gap_kept_mean"] == pytest.approx(-0.5, abs=1e-6)
    assert above["mode_exchange_fraction"] == 1


def test_split_attack_respects_both_budgets_and_the_joint_certificate():
    windows = _windows(seed=13)
    config = _config(mode="split", epsilon=3.0, alpha=0.6, steps=8)
    frame = sg.spectral_frame(windows, config)
    assert torch.allclose(frame.tangent_epsilon,
                          torch.clamp(config.gamma * frame.gap / 2, max=3.0))
    assert torch.allclose(frame.epsilon**2 + frame.tangent_epsilon**2,
                          torch.full_like(frame.epsilon, 9.0))
    attacked = sg.attack(windows, _quadratic_loss(windows), config, frame)
    delta = attacked - windows
    assert torch.all(delta.flatten(1).norm(dim=1) <= 3.0 * (1 + 1e-9))
    delta_s = sg.project(delta, frame)
    delta_t = delta - delta_s
    assert torch.all(delta_s.flatten(1).norm(dim=1) <= frame.epsilon * (1 + 1e-9) + 1e-9)
    assert torch.all(delta_t.flatten(1).norm(dim=1) <= frame.tangent_epsilon * (1 + 1e-9))
    norm_s, norm_t = sg.spectral_norm(delta_s), sg.spectral_norm(delta_t)
    assert torch.all(norm_s + 2 * norm_t <= frame.gap * (1 - 1e-6))
    assert delta_t.flatten(1).norm(dim=1).max() > 0 and delta_s.flatten(1).norm(dim=1).max() > 0
    for i in range(len(windows)):
        k = int(frame.k[i])
        values = torch.linalg.svdvals(attacked[i] - attacked[i].mean(-1, keepdim=True))
        assert values[k - 1] - values[k] > 0
    diagnostics = sg.spectral_diagnostics(windows, attacked, config, frame)
    assert diagnostics["collapse_fraction"] == 0 and diagnostics["gap_kept_min"] > 0


def test_certify_split_shrinks_worst_cases():
    windows = _windows(seed=14)
    frame = sg.spectral_frame(windows, _config(mode="split"))
    centred = windows - windows.mean(-1, keepdim=True)
    u, s, vh = torch.linalg.svd(centred, full_matrices=False)
    rows, k = torch.arange(len(windows)), frame.k
    gap = frame.gap[:, None, None]
    # Rank-one worst cases: raise the (k+1)-th value and lower the k-th one.
    delta_s = 2 * gap * u[rows, :, k][..., None] * vh[rows, k][:, None, :]
    delta_t = -2 * gap * u[rows, :, k - 1][..., None] * vh[rows, k - 1][:, None, :]
    assert torch.allclose(sg.project(delta_s, frame), delta_s, atol=1e-10)
    assert torch.allclose(sg.project_tangent(delta_t, frame), delta_t, atol=1e-10)
    safe_s, safe_t = sg.certify_split(delta_s, delta_t, frame, gamma=0.9)
    assert torch.all(sg.spectral_norm(safe_s) + 2 * sg.spectral_norm(safe_t) < frame.gap)
    for i in range(len(windows)):
        values = torch.linalg.svdvals(centred[i] + safe_s[i] + safe_t[i])
        assert values[int(k[i]) - 1] - values[int(k[i])] > 0
        unsafe = torch.linalg.svdvals(centred[i] + delta_s[i] + delta_t[i])
        top = _top(windows[i], int(k[i]))[1]
        assert not torch.allclose(unsafe[:int(k[i])], top, atol=1e-6)


def test_spectral_ball_projection_is_exact():
    gen = torch.Generator().manual_seed(18)
    y = torch.randn(32, 12, 10, generator=gen, dtype=torch.float64) * 2
    tau = torch.rand(32, generator=gen, dtype=torch.float64) * 3 + 0.5
    eps = torch.rand(32, generator=gen, dtype=torch.float64) * 6 + 1
    proj, active, top = sg.project_spectral_ball(y, tau, eps)
    values = torch.linalg.svdvals(proj)
    assert torch.all(values[:, 0] <= tau * (1 + 1e-9))
    assert torch.all(proj.flatten(1).norm(dim=1) <= eps * (1 + 1e-9))
    assert torch.all(top >= values[:, 0] * (1 - 1e-9))  # an upper bound, exact where binding
    assert torch.allclose(top[active], values[active, 0])
    # Idempotent, unchanged when already feasible.
    again, binding_again, _ = sg.project_spectral_ball(proj, tau, eps)
    assert torch.allclose(again, proj, atol=1e-9) and not binding_again.any()
    # The operator-norm bound is active exactly where Frobenius scaling alone is not enough.
    scaled = y * (eps / y.flatten(1).norm(dim=1)).clamp(max=1)[:, None, None]
    assert torch.equal(active, torch.linalg.svdvals(scaled)[:, 0] > tau * (1 + 1e-9))
    # Nearest point: closer than radial shrinking and random feasible points.
    distance = (y - proj).flatten(1).norm(dim=1)
    radial = y * torch.minimum(tau / torch.linalg.svdvals(y)[:, 0],
                               eps / y.flatten(1).norm(dim=1)).clamp(max=1)[:, None, None]
    assert torch.all(distance <= (y - radial).flatten(1).norm(dim=1) + 1e-9)
    for _ in range(20):
        z = proj + 0.3 * torch.randn(y.shape, generator=gen, dtype=torch.float64)
        z, _, _ = sg.project_spectral_ball(z, tau, eps)
        assert torch.all(distance <= (y - z).flatten(1).norm(dim=1) + 1e-9)


@pytest.mark.parametrize("certify", ["final", "every"])
def test_certified_subspace_keeps_the_budget_and_the_guarantee(certify):
    windows = _windows(seed=16, noise=1.0)
    plain = _config(mode="subspace", epsilon=25.0, alpha=5.0, steps=8)
    certified = dataclasses.replace(plain, mode="subspace_cert", certify=certify)
    frame = sg.spectral_frame(windows, certified)
    torch.manual_seed(5)
    free = sg.attack(windows, _quadratic_loss(windows), plain, frame) - windows
    torch.manual_seed(5)
    delta = sg.attack(windows, _quadratic_loss(windows), certified, frame) - windows
    assert torch.allclose(sg.project(delta, frame), delta, atol=1e-9)
    assert torch.all(sg.spectral_norm(delta) <= certified.gamma * frame.gap * (1 + 1e-9))
    assert torch.all(delta.flatten(1).norm(dim=1) <= 25.0 * (1 + 1e-9))
    summary = sg.attack_summary(windows, windows + delta, certified, frame)
    assert 0 < summary["adv_cert_active"] <= 1 and 0 < summary["adv_cert_retained"] <= 1
    if certify == "final":
        inside = sg.spectral_norm(free) <= certified.gamma * frame.gap
        assert inside.any() and (~inside).any()
        assert torch.allclose(delta[inside], free[inside])
        # Clipping keeps more of the attack than shrinking it as a whole.
        radial = free * (certified.gamma * frame.gap / sg.spectral_norm(free)).clamp(
            max=1)[:, None, None]
        assert torch.all(delta.flatten(1).norm(dim=1) >= radial.flatten(1).norm(dim=1) - 1e-9)
        assert (delta.flatten(1).norm(dim=1) > radial.flatten(1).norm(dim=1) + 1e-6).any()
    for i in range(len(windows)):
        k = int(frame.k[i])
        assert torch.allclose(_top(windows[i], k)[1], _top(windows[i] + delta[i], k)[1],
                              atol=1e-9)


def test_every_step_certification_uses_more_of_the_budget():
    windows = _windows(seed=19, noise=1.0)
    final = _config(mode="subspace_cert", epsilon=25.0, alpha=5.0, steps=10)
    every = dataclasses.replace(final, certify="every")
    frame = sg.spectral_frame(windows, final)
    norms = {}
    for config in (final, every):
        torch.manual_seed(6)
        delta = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
        norms[config.certify] = delta.flatten(1).norm(dim=1)
        assert torch.all(sg.spectral_norm(delta) <= config.gamma * frame.gap * (1 + 1e-9))
    assert norms["every"].mean() > norms["final"].mean()


def test_radial_certificate_matches_the_earlier_shrinking():
    windows = _windows(seed=23, noise=1.0)
    config = _config(mode="subspace_cert", certify="radial")
    frame = sg.spectral_frame(windows, config)
    gen = torch.Generator().manual_seed(24)
    delta = sg.project(torch.randn(windows.shape, generator=gen, dtype=windows.dtype), frame)
    delta = delta * (8 * torch.rand(len(delta), generator=gen, dtype=delta.dtype))[:, None, None]
    # The certificate of earlier versions, written out.
    allowed = config.gamma * frame.gap.to(delta.dtype)
    norm = sg.spectral_norm(delta)
    assert (norm > allowed).any() and (norm <= allowed).any()
    scale = torch.where(norm > allowed, allowed / norm.clamp_min(1e-12), torch.ones_like(norm))
    radial = sg.certify_complement(delta, frame, config.gamma, radial=True)
    assert torch.equal(radial, delta * scale[:, None, None])
    assert torch.equal(frame.stats["cert_active"], (norm > allowed).float().mean())
    # The exact projection is closer to every perturbation and keeps more of it.
    exact = sg.certify_complement(delta, frame, config.gamma)
    distance = lambda x: (delta - x).flatten(1).norm(dim=1)
    assert torch.all(distance(exact) <= distance(radial) + 1e-9)
    assert torch.all(exact.flatten(1).norm(dim=1) >= radial.flatten(1).norm(dim=1) - 1e-9)
    # In the attack, the radial certificate scales the uncertified attack.
    plain = _config(mode="subspace", epsilon=25.0, alpha=5.0, steps=8)
    torch.manual_seed(5)
    free = sg.attack(windows, _quadratic_loss(windows), plain, frame) - windows
    torch.manual_seed(5)
    attacked = sg.attack(windows, _quadratic_loss(windows),
                         dataclasses.replace(plain, mode="subspace_cert", certify="radial"), frame)
    scale = (allowed / sg.spectral_norm(free)).clamp(max=1)
    assert torch.allclose(attacked - windows, free * scale[:, None, None], atol=1e-9)


def test_radial_split_certificate_keeps_the_joint_bound():
    windows = _windows(seed=25, noise=1.0)
    config = _config(mode="split", epsilon=6.0, alpha=1.2, steps=6, certify="radial")
    frame = sg.spectral_frame(windows, config)
    delta = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
    delta_s = sg.project(delta, frame)
    norm = sg.spectral_norm(delta_s) + 2 * sg.spectral_norm(delta - delta_s)
    assert torch.all(norm < frame.gap)
    # With a Frobenius bound as well, the smaller of the two scales applies.
    frobenius_scale = torch.tensor([0.3, 0.7], dtype=delta.dtype).repeat(len(delta) // 2)
    tau = 0.5 * sg.spectral_norm(delta)
    shrunk, binding, top = sg.shrink_spectral_ball(
        delta, tau, frobenius_scale * delta.flatten(1).norm(dim=1))
    assert torch.allclose(shrunk, delta * frobenius_scale.clamp(max=0.5)[:, None, None])
    assert torch.equal(binding, frobenius_scale > 0.5)
    assert torch.allclose(top, sg.spectral_norm(shrunk))


def _centred(x):
    return x - x.mean(-1, keepdim=True)


def test_collapse_certificate_is_exact_and_reaches_beyond_weyl():
    windows = _windows(seed=26, noise=1.0)
    config = _config(mode="subspace_cert", certify="collapse")
    frame = sg.spectral_frame(windows, config)
    gen = torch.Generator().manual_seed(27)
    delta = sg.project(torch.randn(windows.shape, generator=gen, dtype=windows.dtype), frame)
    delta = delta * (10 * torch.rand(len(delta), generator=gen, dtype=delta.dtype))[:, None, None]
    certified = sg.certify_collapse(delta, windows, frame, config.gamma)
    # The direction is kept; the scale lies between the Weyl factor and 1.
    t = certified.flatten(1).norm(dim=1) / delta.flatten(1).norm(dim=1)
    assert torch.allclose(certified, delta * t[:, None, None], atol=1e-12)
    weyl = (config.gamma * frame.gap / sg.spectral_norm(_centred(delta))).clamp(max=1)
    assert torch.all(t >= weyl * (1 - 1e-9)) and torch.all(t <= 1)
    assert (t > 1.05 * weyl).any()
    assert frame.stats["cert_weyl_gain"] >= 1
    # Exact condition with the gamma margin, and close to the exact radius where it binds.
    residual = sg.project(_centred(windows), frame)
    assert torch.allclose(sg.spectral_norm(residual),
                          frame.values.gather(1, frame.k[:, None])[:, 0])
    threshold = frame.values.gather(1, frame.k[:, None])[:, 0] + config.gamma * frame.gap
    assert torch.all(sg.spectral_norm(residual + _centred(certified)) <= threshold * (1 + 1e-9))
    binding = t < 1
    assert binding.any() and (~binding).any()
    beyond = sg.spectral_norm(residual + 1.02 * _centred(certified))
    assert torch.all(beyond[binding] > threshold[binding])
    # Every window keeps its top-k singular triplets and the margin of the gap.
    for i in range(len(windows)):
        k = int(frame.k[i])
        u0, s0, v0 = _top(windows[i], k)
        u1, s1, v1 = _top(windows[i] + certified[i], k)
        assert torch.allclose(s0, s1, atol=1e-9)
        assert _projector_distance(u0, u1) < 1e-7 and _projector_distance(v0, v1) < 1e-7
    diagnostics = sg.spectral_diagnostics(windows, windows + certified, config, frame)
    assert diagnostics["gap_kept_min"] >= 1 - config.gamma - 1e-9


def test_collapse_attack_keeps_the_structure_and_the_radial_budget():
    windows = _windows(seed=28, noise=1.0)
    # Mean-free perturbations: a per-neuron mean shift is invisible to the centred SVD,
    # so only the radial certificate (on the raw perturbation) would limit it.
    radial = _config(mode="subspace_cert", certify="radial", epsilon=80.0, alpha=16.0, steps=8,
                     preserve_mean=True)
    collapse = dataclasses.replace(radial, certify="collapse")
    frame = sg.spectral_frame(windows, radial)
    deltas = {}
    for config in (radial, collapse):
        torch.manual_seed(5)
        deltas[config.certify] = sg.attack(windows, _quadratic_loss(windows), config,
                                           frame) - windows
    norms = {name: delta.flatten(1).norm(dim=1) for name, delta in deltas.items()}
    assert torch.all(norms["collapse"] >= norms["radial"] * (1 - 1e-9))
    assert norms["collapse"].mean() > norms["radial"].mean()
    summary = sg.attack_summary(windows, windows + deltas["collapse"], collapse, frame)
    assert summary["adv_cert_weyl_gain"] >= 1 and 0 < summary["adv_cert_active"] <= 1
    for i in range(len(windows)):
        k = int(frame.k[i])
        assert torch.allclose(_top(windows[i], k)[1], _top(windows[i] + deltas["collapse"][i], k)[1],
                              atol=1e-9)


@pytest.mark.parametrize("mode,certify", [("split", "final"), ("subspace_cert", "radial")])
def test_energy_matched_pgd_uses_the_spectral_norms(mode, certify):
    windows = _windows(seed=29, noise=1.0)
    config = _config(mode=mode, certify=certify, epsilon=6.0, alpha=1.2, steps=6)
    frame = sg.spectral_frame(windows, config)
    budgets = frame.epsilon.clone()
    torch.manual_seed(7)
    spectral = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
    torch.manual_seed(7)
    matched = sg.attack(windows, _quadratic_loss(windows),
                        dataclasses.replace(config, energy_match=True), frame) - windows
    reference = spectral.flatten(1).norm(dim=1)
    norm = matched.flatten(1).norm(dim=1)
    assert torch.all(norm <= reference * (1 + 1e-9))
    assert norm.mean() > 0.9 * reference.mean()
    assert torch.equal(frame.epsilon, budgets)  # the caller's frame is not changed
    # Same energy, unrestricted direction: it leaves the spectral subspaces.
    if mode == "split":
        assert not torch.allclose(matched, spectral, atol=1e-6)
    else:
        outside = (matched - sg.project(matched, frame)).flatten(1).norm(dim=1)
        assert (outside > 1e-3 * norm).all()


def test_attack_summary_reports_energy_on_the_most_active_units():
    windows = _windows(seed=30).abs()
    config = _config(mode="none")
    count = round(sg.TOP_UNIT_FRACTION * windows.shape[1])
    active = windows.mean(dim=(0, 2)).topk(count).indices
    delta = torch.zeros_like(windows)
    delta[:, active] = 0.5
    summary = sg.attack_summary(windows, windows + delta, config, None)
    assert summary["adv_top_unit_energy"] == pytest.approx(1.0)
    summary = sg.attack_summary(windows, windows + torch.ones_like(windows), config, None)
    assert summary["adv_top_unit_energy"] == pytest.approx(count / windows.shape[1])
    assert 0 < summary["adv_top_unit_signal"] < 1


def test_every_step_retained_norm_is_relative_to_the_frobenius_ball():
    windows = _windows(seed=31)
    frame = sg.spectral_frame(windows, _config(mode="subspace_cert"))
    gen = torch.Generator().manual_seed(32)
    delta = sg.project(torch.randn(windows.shape, generator=gen, dtype=windows.dtype), frame)
    # Spread perturbations: the Frobenius ball binds, the operator-norm bound does not.
    epsilon = 0.5 * delta.flatten(1).norm(dim=1)
    tau = 10 * sg.spectral_norm(delta)
    frame = dataclasses.replace(frame, gap=tau / 0.9, stats={})
    certified = sg.certify_complement(delta, frame, 0.9, epsilon[:, None, None])
    assert torch.allclose(certified.flatten(1).norm(dim=1), epsilon)
    assert frame.stats["cert_active"] == 0
    assert frame.stats["cert_retained"] == pytest.approx(1.0)


@pytest.mark.parametrize("fraction", [0.0, 0.5])
def test_split_complement_fraction(fraction):
    windows = _windows(seed=20, noise=1.0)
    config = _config(mode="split", epsilon=3.0, alpha=0.6, steps=6, split_complement=fraction)
    frame = sg.spectral_frame(windows, config)
    full = sg.spectral_frame(windows, dataclasses.replace(config, split_complement=1.0))
    assert torch.allclose(frame.epsilon, fraction * full.epsilon)
    delta = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
    complement = sg.project(delta, frame)
    assert torch.all(complement.flatten(1).norm(dim=1) <= frame.epsilon * (1 + 1e-9) + 1e-9)
    if fraction == 0:
        assert complement.abs().max() < 1e-9


def test_split_every_step_keeps_the_joint_certificate():
    windows = _windows(seed=21, noise=1.0)
    config = _config(mode="split", epsilon=6.0, alpha=1.2, steps=6, certify="every")
    frame = sg.spectral_frame(windows, config)
    delta = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
    delta_s = sg.project(delta, frame)
    norm = sg.spectral_norm(delta_s) + 2 * sg.spectral_norm(delta - delta_s)
    assert torch.all(norm < frame.gap)


def test_tangent_fixed_uses_the_full_budget_in_the_tangent_space():
    windows = _windows(seed=22)
    config = _config(mode="tangent_fixed", epsilon=2.0, alpha=0.4, steps=5)
    frame = sg.spectral_frame(windows, config)
    assert torch.all(frame.epsilon == 2.0)
    delta = sg.attack(windows, _quadratic_loss(windows), config, frame) - windows
    assert torch.allclose(sg.project_tangent(delta, frame), delta, atol=1e-10)
    assert delta.flatten(1).norm(dim=1).max() > 1.9


def test_tangent_energy_fraction_diagnostic():
    windows = _windows(seed=17)
    for mode, low, high in (("subspace", 0.0, 1e-9), ("tangent", 1 - 1e-9, 1 + 1e-9)):
        config = _config(mode=mode, epsilon=2.0, alpha=0.4, steps=4)
        attacked = sg.attack(windows, _quadratic_loss(windows), config)
        fraction = sg.spectral_diagnostics(windows, attacked, config)["tangent_energy_fraction"]
        assert low <= fraction <= high
    noise = windows + 0.1 * torch.randn_like(windows)
    diagnostics = sg.spectral_diagnostics(windows, noise, _config())
    assert diagnostics["tangent_energy_fraction"] == pytest.approx(
        diagnostics["tangent_chance_fraction"], rel=0.25)


def test_tangent_budget_is_the_unprojected_control():
    windows = _windows(seed=15)
    config = _config(mode="tangent_budget", epsilon=3.0, alpha=0.6, steps=5)
    frame = sg.spectral_frame(windows, config)
    reference = sg.spectral_frame(windows, _config(mode="tangent", epsilon=3.0))
    assert torch.allclose(frame.epsilon, reference.epsilon)
    attacked = sg.attack(windows, _quadratic_loss(windows), config, frame)
    delta = attacked - windows
    assert torch.all(delta.flatten(1).norm(dim=1) <= frame.epsilon * (1 + 1e-9))
    # Unrestricted directions: the perturbation leaves the tangent space.
    assert (delta - sg.project_tangent(delta, frame)).flatten(1).norm(dim=1).max() > 1e-3


def test_budget_and_k_follow_the_largest_gap():
    windows = _windows(seed=2)
    config = _config(epsilon=1.5, gamma=0.5, k_min=1, k_max=4)
    frame = sg.spectral_frame(windows, config)
    centred = windows - windows.mean(-1, keepdim=True)
    values = torch.linalg.svdvals(centred)
    gaps = values[:, :4] - values[:, 1:5]
    assert torch.equal(frame.k, gaps.argmax(-1) + 1)
    assert torch.allclose(frame.gap, gaps.max(-1).values)
    assert torch.allclose(frame.epsilon,
                          torch.clamp(0.5 * gaps.max(-1).values, max=1.5))
    fixed = sg.spectral_frame(windows, dataclasses.replace(config,
                                                           mode="subspace"))
    assert torch.all(fixed.epsilon == 1.5)
    assert torch.equal(fixed.k, frame.k)


def test_fixed_k():
    frame = sg.spectral_frame(_windows(), _config(k_min=2, k_max=2))
    assert torch.all(frame.k == 2)
    assert torch.all(frame.left[..., 2:] == 0) and frame.left.shape[-1] == 2


def test_preserve_mean_keeps_neuron_means():
    windows = _windows(seed=3)
    for center in (True, False):
        frame = sg.spectral_frame(
            windows, _config(preserve_mean=True, center=center))
        delta = sg.project(torch.randn_like(windows), frame)
        assert delta.mean(-1).abs().max() < 1e-12
        assert (frame.left.mT @ delta).abs().max() < 1e-12


def _quadratic_loss(windows):
    weight = torch.linspace(-1, 1, windows[0].numel(),
                            dtype=windows.dtype).reshape(windows.shape[1:])

    def loss_fn(reference):
        return ((reference * weight).sum((-1, -2))**2).mean() + (
            reference**3).mean()

    return loss_fn


@pytest.mark.parametrize("mode", ["gap", "subspace", "gap_budget"])
def test_attack_stays_in_the_allowed_set(mode):
    windows = _windows(seed=4)
    config = _config(mode=mode, epsilon=2.0, alpha=0.5, steps=8)
    frame = sg.spectral_frame(windows, config)
    attacked = sg.attack(windows, _quadratic_loss(windows), config, frame)
    delta = attacked - windows
    norm = delta.flatten(1).norm(dim=1)
    assert torch.all(norm <= frame.epsilon * (1 + 1e-9) + 1e-12)
    assert norm.max() > 0
    if config.projected:
        assert torch.allclose(sg.project(delta, frame), delta, atol=1e-10)
    if mode == "gap":
        for i in range(len(windows)):
            k = int(frame.k[i])
            assert torch.allclose(_top(windows[i], k)[1],
                                  _top(attacked[i], k)[1],
                                  atol=1e-9)
    summary = sg.attack_summary(windows, attacked, config, frame)
    assert summary["adv_delta_norm"] == pytest.approx(float(norm.mean()),
                                                      rel=1e-5)
    assert summary["adv_eps_mean"] == pytest.approx(
        float(frame.epsilon.mean()), rel=1e-5)


def test_attack_increases_the_loss():
    windows = _windows(seed=5)
    loss_fn = _quadratic_loss(windows)
    torch.manual_seed(0)
    attacked = sg.attack(windows, loss_fn, _config(steps=10))
    assert loss_fn(attacked) > loss_fn(windows)


def test_degenerate_windows_are_finite_and_not_attacked():
    windows = torch.poisson(torch.full((6, 12, 10), 0.4, dtype=torch.float64))
    windows[0] = 0  # silent
    windows[1] = 0
    windows[1, 3, 4] = 1  # one spike
    windows[2] = 3.0  # constant, zero after centring
    config = _config(epsilon=2.0)
    frame = sg.spectral_frame(windows, config)
    for value in (frame.left, frame.right, frame.gap, frame.epsilon):
        assert torch.isfinite(value).all()
    assert frame.epsilon[0] == 0 and frame.epsilon[2] == 0
    attacked = sg.attack(windows, _quadratic_loss(windows), config, frame)
    assert torch.isfinite(attacked).all()
    assert torch.equal(attacked[0], windows[0])
    assert torch.equal(attacked[2], windows[2])


def test_windows_too_short_for_spectral_modes():
    with pytest.raises(ValueError, match="longer receptive field"):
        sg.spectral_frame(torch.rand(4, 10, 1), _config())


def _legacy_l2(reference, loss_fn, eps, alpha, steps):
    """Copy of the previous project's L2 PGD loop (CEBRA-main solver)."""

    def l2n(t, e=1e-12):
        flat = t.reshape(t.size(0), -1)
        norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=e)
        return t / norm.view(-1, *([1] * (t.dim() - 1)))

    x_adv = reference.clone().detach()
    noise = l2n(torch.randn_like(x_adv))
    noise *= torch.rand([x_adv.size(0)] + [1] * (x_adv.dim() - 1),
                        device=x_adv.device) * eps
    x_adv = (reference + noise).clone().detach().requires_grad_(True)
    for _ in range(steps):
        grad_x, = torch.autograd.grad(loss_fn(x_adv), x_adv)
        with torch.no_grad():
            x_adv += alpha * l2n(grad_x)
            delta = x_adv - reference
            flat = delta.reshape(delta.size(0), -1)
            norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
            factor = torch.where(norm > eps, norm / eps, torch.ones_like(norm))
            x_adv = reference + delta / factor.view(-1, 1, 1)
            x_adv.requires_grad = True
    return x_adv.detach()


def _legacy_linf(reference, loss_fn, eps, alpha, steps):
    """Copy of the previous project's Linf PGD loop (CEBRA-main solver)."""
    perturb = torch.empty_like(reference).uniform_(-eps, eps)
    x_adv = (reference + perturb).clone()
    x_adv.requires_grad = True
    for _ in range(steps):
        grad_x, = torch.autograd.grad(loss_fn(x_adv), x_adv)
        with torch.no_grad():
            x_adv = x_adv + alpha * grad_x.sign()
            x_adv = torch.max(torch.min(x_adv, reference + eps),
                              reference - eps)
            x_adv.requires_grad = True
    return x_adv.detach()


@pytest.mark.parametrize("norm", ["l2", "linf"])
def test_plain_pgd_is_the_previous_implementation(norm):
    windows = _windows(dtype=torch.float32, seed=6)
    loss_fn = _quadratic_loss(windows)
    legacy = _legacy_l2 if norm == "l2" else _legacy_linf
    torch.manual_seed(3)
    expected = legacy(windows, loss_fn, 1.5, 0.3, 7)
    torch.manual_seed(3)
    config = sg.AttackConfig(epsilon=1.5, alpha=0.3, steps=7, norm=norm)
    assert torch.equal(sg.attack(windows, loss_fn, config), expected)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_cuda_svd_with_degenerate_windows_matches_cpu():
    windows = torch.poisson(torch.full((1100, 40, 36), 0.3))
    windows[5] = 0
    windows[700] = 0
    windows[700, 2, 3] = 1  # a single spike: many repeated zero singular values
    u, s, v = sg.window_svd(windows.cuda(), rank=4)
    u0, s0, v0 = sg.window_svd(windows.double(), rank=4)
    assert torch.allclose(s.cpu().double(), s0, atol=1e-4)
    good = (s0[:, 3] - s0[:, 4]) > 1e-2
    for a, b in ((u, u0), (v, v0)):
        a = a.cpu().double()[good]
        distance = (a @ a.mT - b[good] @ b[good].mT).norm(dim=(-1, -2))
        assert distance.max() < 1e-3


@pytest.mark.parametrize("mode", ["none", "gap"])
def test_diagnostics_separate_plain_pgd_from_gap(mode):
    windows = _windows(seed=7)
    config = _config(mode=mode, epsilon=3.0, alpha=0.6, steps=6)
    attacked = sg.attack(windows, _quadratic_loss(windows), config)
    diagnostics = sg.spectral_diagnostics(windows, attacked, config)
    if mode == "gap":
        assert diagnostics["sv_err_max"] < 1e-9
        assert diagnostics["left_subspace_err_max"] < 1e-6
        assert diagnostics["delta_over_gap_max"] <= config.gamma + 1e-9
        assert diagnostics["gap_kept_min"] >= 1 - config.gamma - 1e-9
        assert diagnostics["collapse_fraction"] == 0
    else:
        assert diagnostics["sv_err_max"] > 1e-3


# ---------------------------------------------------------------- solver level


def _solver(mode="gap", norm="l2", eval_mode=False, neurons=10, **kwargs):
    torch.manual_seed(0)
    model = cebra.models.init("offset10-model",
                              num_neurons=neurons,
                              num_units=16,
                              num_output=4)
    criterion = cebra.models.FixedCosineInfoNCE(temperature=1.0)
    optimizer = torch.optim.Adam(list(model.parameters()) +
                                 list(criterion.parameters()),
                                 lr=1e-3)
    settings = dict(training_mode="adversarial",
                    adv_epsilon=2.0,
                    adv_alpha=0.4,
                    adv_steps=3,
                    attack_norm=norm,
                    adv_spectral_mode=mode,
                    adv_attack_eval_mode=eval_mode)
    settings.update(kwargs)
    return cebra.solver.init("single-session",
                             model=model,
                             criterion=criterion,
                             optimizer=optimizer,
                             tqdm_on=False,
                             **settings)


def _batch(neurons=10, batch=32, seed=0):
    gen = torch.Generator().manual_seed(seed)
    return cebra.data.Batch(*(torch.poisson(torch.full(
        (batch, neurons, 10), 0.8), generator=gen) for _ in range(3)))


@pytest.mark.parametrize("eval_mode", [False, True])
def test_solver_step_logs_and_restores_modes(eval_mode):
    solver = _solver(eval_mode=eval_mode, adv_diagnostics_every=2)
    solver.model.train()
    solver.model.net[1].eval()  # A deliberately frozen submodule stays frozen.
    for seed in range(3):
        stats = solver.step(_batch(seed=seed))
    assert solver.model.training and not solver.model.net[1].training
    for key in ("adv_loss", "adv_delta_norm", "adv_eps_mean", "adv_k_mean",
                "total"):
        assert key in stats and len(solver.log[key]) == 3
    assert [d["step"] for d in solver.log["adv_diagnostics"]] == [1, 3]
    assert solver.log["adv_diagnostics"][0]["sv_err_max"] < 1e-4


@pytest.mark.parametrize("settings", [
    dict(mode="subspace_cert", adv_spectral_certify="collapse"),
    dict(mode="split", adv_spectral_energy_match=True),
])
def test_solver_runs_collapse_and_energy_matched_arms(settings):
    solver = _solver(adv_diagnostics_every=1, **settings)
    for seed in range(2):
        stats = solver.step(_batch(seed=seed))
    for key in ("adv_delta_norm", "adv_top_unit_energy", "adv_top_unit_signal",
                "adv_cert_active"):
        assert key in stats and len(solver.log[key]) == 2
    if settings.get("adv_spectral_energy_match"):
        assert solver.log["adv_diagnostics"][-1]["sv_err_max"] > 1e-6
    else:
        assert solver.log["adv_diagnostics"][-1]["sv_err_max"] < 1e-4


def test_eval_mode_reuses_embeddings_without_changing_the_loss():
    solver = _solver(eval_mode=True)
    batch = _batch()
    solver.model.eval()
    reference = batch.reference + 0.5
    cached = solver._attack_loss_fn(batch)(reference)
    full = cebra.solver.base.Solver._attack_loss_fn(solver, batch)(reference)
    assert torch.allclose(cached, full)


def test_adversarial_training_rejects_unsupported_batches():
    solver = _solver()
    with pytest.raises(ValueError, match="single-session"):
        solver.step([_batch()])


def test_invalid_solver_settings():
    with pytest.raises(ValueError, match="training_mode"):
        _solver(training_mode="adversial")
    with pytest.raises(ValueError, match="attack_norm"):
        _solver(norm="linf")  # spectral mode needs l2
    with pytest.raises(ValueError, match="adv_diagnostics_every"):
        _solver(adv_diagnostics_every=-1)


def test_solver_state_dict_keeps_attack_settings():
    solver = _solver(adv_spectral_gamma=0.7, adv_spectral_k_max=3)
    solver.step(_batch())
    state = solver.state_dict()
    other = _solver(mode="none")
    other.load_state_dict(state)
    assert other.adv_spectral_mode == "gap"
    assert other.adv_spectral_gamma == 0.7 and other.adv_spectral_k_max == 3
    del state["attack_settings"]  # Checkpoints of the previous project.
    _solver(mode="none").load_state_dict(state)


def test_sklearn_forwards_parameters_and_roundtrips(tmp_path):
    rng = np.random.default_rng(0)
    X = rng.poisson(0.5, size=(300, 12)).astype("float32")
    y = rng.random((300, 2)).astype("float32")
    params = dict(adv_spectral_mode="gap",
                  adv_spectral_gamma=0.8,
                  adv_spectral_k_min=1,
                  adv_spectral_k_max=3,
                  adv_spectral_center=True,
                  adv_spectral_preserve_mean=True,
                  adv_attack_eval_mode=True,
                  adv_diagnostics_every=2)
    model = cebra.CEBRA(model_architecture="offset10-model",
                        batch_size=32,
                        max_iterations=3,
                        output_dimension=3,
                        training_mode="adversarial",
                        attack_norm="l2",
                        adv_epsilon=1.0,
                        adv_alpha=0.2,
                        device="cpu",
                        **params)
    import sklearn.base
    assert sklearn.base.clone(model).get_params()["adv_spectral_gamma"] == 0.8
    model.fit(X, y)
    for name, value in params.items():
        assert getattr(model.solver_, name) == value
    assert len(model.solver_.log["adv_eps_mean"]) == 3
    path = tmp_path / "model.pt"
    model.save(path)
    loaded = cebra.CEBRA.load(path, weights_only=False)
    assert loaded.get_params()["adv_spectral_mode"] == "gap"
    assert loaded.solver_.adv_spectral_gamma == 0.8
    np.testing.assert_allclose(loaded.transform(X), model.transform(X),
                               rtol=1e-5,
                               atol=1e-6)


def test_sklearn_forwards_the_energy_match_control():
    rng = np.random.default_rng(2)
    X = rng.poisson(0.5, size=(300, 12)).astype("float32")
    model = cebra.CEBRA(model_architecture="offset10-model",
                        batch_size=32,
                        max_iterations=2,
                        output_dimension=3,
                        training_mode="adversarial",
                        attack_norm="l2",
                        adv_spectral_mode="subspace_cert",
                        adv_spectral_certify="collapse",
                        adv_spectral_energy_match=True,
                        adv_epsilon=1.0,
                        adv_alpha=0.2,
                        device="cpu")
    model.fit(X)
    assert model.solver_.adv_spectral_energy_match is True
    assert model.solver_.adv_spectral_certify == "collapse"
    assert len(model.solver_.log["adv_top_unit_energy"]) == 2


def test_hybrid_adversarial_training_with_gap_attack():
    rng = np.random.default_rng(1)
    X = rng.poisson(0.5, size=(300, 12)).astype("float32")
    y = rng.random((300, 2)).astype("float32")
    model = cebra.CEBRA(model_architecture="offset10-model",
                        batch_size=32,
                        max_iterations=2,
                        output_dimension=4,
                        hybrid=True,
                        training_mode="adversarial",
                        attack_norm="l2",
                        adv_spectral_mode="gap",
                        adv_epsilon=1.0,
                        adv_alpha=0.2,
                        device="cpu")
    model.fit(X, y)
    assert len(model.solver_.log["adv_loss"]) == 2
