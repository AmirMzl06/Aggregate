#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Spectral-gap subspace attacks on reference windows.

Every reference window ``X`` (neurons x time) is optionally centred over time
and decomposed as ``Xc = U diag(s) V^T`` with ``s`` sorted in descending order.
For a window-specific ``k`` the attack only uses perturbations in

    S_k = {D : U_k^T D = 0 and D V_k = 0},

the orthogonal complement of the top-k left *and* right singular subspaces.
Then ``Xc + D = U_k diag(s_1..s_k) V_k^T + (R + D)`` where ``R + D`` is
orthogonal to both subspaces, so the top-k singular values *and* singular
vectors of ``Xc + D`` are exactly those of ``Xc`` whenever
``||D||_2 < s_k - s_{k+1}`` (Weyl). Since ``||D||_2 <= ||D||_F``, the per-window
L2 budget

    eps_i = min(epsilon, gamma * (s_k - s_{k+1})),   0 < gamma < 1,

is the largest radius at which the top-k structure provably cannot collapse.
``k`` is chosen per window as the position of the largest gap in
``[k_min, k_max]``, i.e. the split that admits the largest such radius.

Modes:
    ``none``: plain PGD on the reference, identical to the previous project
        (L2 or Linf, fixed ``epsilon``).
    ``gap``: complement projection and gap budget (the full formulation).
    ``subspace``: complement projection with the fixed budget ``epsilon``
        (ablation; exact only where ``epsilon < s_k - s_{k+1}``).
    ``gap_budget``: gap budget without the projection (ablation; no guarantee).

The spectral modes need ``norm="l2"``: the budget is a Frobenius radius.
"""

import concurrent.futures
import contextlib
import dataclasses
import math
import os
from typing import Callable, Dict, Optional, Tuple, Union

import torch

__all__ = [
    "ATTACK_MODES", "AttackConfig", "SpectralFrame", "window_svd",
    "spectral_frame", "project", "attack", "attack_summary",
    "spectral_diagnostics"
]

ATTACK_MODES = ("none", "gap", "subspace", "gap_budget")

# Batched SVDs of small windows are slow with the default CUDA driver, and the
# fast cuSOLVER driver (gesvda) fails on degenerate windows such as silent bins.
# Instead, the eigendecomposition of the small Gram matrix is computed in float64
# on the CPU, split over a few single-threaded workers. This is exact to float64
# precision for the leading modes and takes ~40 ms for 2048 windows of 100 x 36.
_WORKERS = 8
_executor = None


def _thread_pool():
    global _executor
    if _executor is None:
        _executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=min(_WORKERS, os.cpu_count() or 1))
    return _executor


def _is_number(value) -> bool:
    return (isinstance(value, (int, float)) and not isinstance(value, bool) and
            math.isfinite(value))


@dataclasses.dataclass(frozen=True)
class AttackConfig:
    """Settings of the reference attack.

    Attributes:
        epsilon: Maximum budget. For the gap modes, the cap on the per-window budget.
        alpha: Step size for ``epsilon``; per-window budgets use the same
            fraction ``alpha / epsilon`` of their own radius.
        steps: Number of PGD steps.
        norm: ``"l2"`` or ``"linf"``; the spectral modes need ``"l2"``.
        mode: One of :py:data:`ATTACK_MODES`.
        gamma: Fraction of the spectral gap used as budget, ``0 < gamma < 1``.
        k_min: Smallest number of protected singular modes.
        k_max: Largest number of protected singular modes.
        center: Remove each neuron's temporal mean before the SVD.
        preserve_mean: Also protect the constant time direction, so that the
            perturbation leaves every neuron's mean rate in the window unchanged.
    """

    epsilon: float = 0.05
    alpha: float = 0.01
    steps: int = 10
    norm: str = "linf"
    mode: str = "none"
    gamma: float = 0.9
    k_min: int = 1
    k_max: int = 8
    center: bool = True
    preserve_mean: bool = False

    def __post_init__(self):
        if self.norm not in ("l2", "linf"):
            raise ValueError(
                f"attack_norm must be 'l2' or 'linf', got {self.norm!r}.")
        if self.mode not in ATTACK_MODES:
            raise ValueError(f"adv_spectral_mode must be one of {ATTACK_MODES}, "
                             f"got {self.mode!r}.")
        if self.spectral and self.norm != "l2":
            raise ValueError("Spectral attacks use a Frobenius (L2) budget; set "
                             "attack_norm='l2'.")
        for name in ("epsilon", "alpha"):
            value = getattr(self, name)
            if not _is_number(value) or value < 0:
                raise ValueError(f"adv_{name} must be finite and nonnegative, "
                                 f"got {value!r}.")
        if not isinstance(self.steps, int) or isinstance(self.steps,
                                                          bool) or self.steps < 0:
            raise ValueError(
                f"adv_steps must be a nonnegative integer, got {self.steps!r}.")
        if not _is_number(self.gamma) or not 0 < self.gamma < 1:
            raise ValueError("adv_spectral_gamma must be in (0, 1), got "
                             f"{self.gamma!r}.")
        for name in ("k_min", "k_max"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"adv_spectral_{name} must be a positive integer, "
                                 f"got {value!r}.")
        if self.k_max < self.k_min:
            raise ValueError("adv_spectral_k_max must be >= adv_spectral_k_min.")
        for name in ("center", "preserve_mean"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"adv_spectral_{name} must be a bool.")
        if self.preserve_mean and not self.projected:
            raise ValueError("adv_spectral_preserve_mean needs a projected mode "
                             "('gap' or 'subspace').")

    @property
    def spectral(self) -> bool:
        """Whether the attack needs the singular structure of the windows."""
        return self.mode != "none"

    @property
    def projected(self) -> bool:
        """Whether perturbations are restricted to the complement subspace."""
        return self.mode in ("gap", "subspace")

    @property
    def gap_limited(self) -> bool:
        """Whether the per-window budget is capped by the spectral gap."""
        return self.mode in ("gap", "gap_budget")


@dataclasses.dataclass
class SpectralFrame:
    """Protected subspaces and budgets of one batch of windows.

    Attributes:
        left: ``(B, N, q)`` protected left singular vectors, zero beyond ``k``.
        right: ``(B, T, q)`` protected right singular vectors, zero beyond ``k``;
            one extra column for the constant direction if ``preserve_mean``.
        k: ``(B,)`` number of protected singular modes.
        gap: ``(B,)`` spectral gap ``s_k - s_{k+1}``.
        epsilon: ``(B,)`` per-window L2 budget.
        values: ``(B, r)`` singular values of the clean windows.
    """

    left: torch.Tensor
    right: torch.Tensor
    k: torch.Tensor
    gap: torch.Tensor
    epsilon: torch.Tensor
    values: torch.Tensor


def _matrices(windows: torch.Tensor, center: bool) -> torch.Tensor:
    matrix = windows if windows.dtype == torch.float64 else windows.float()
    if center:
        matrix = matrix - matrix.mean(dim=-1, keepdim=True)
    return matrix


@contextlib.contextmanager
def _one_intraop_thread():
    """Avoid oversubscription: each worker's small LAPACK call runs single-threaded."""
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        yield
    finally:
        torch.set_num_threads(previous)


def _eigh_cpu(gram: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Batched symmetric eigendecomposition on the CPU, eigenvalues descending."""
    chunks = gram.chunk(min(len(gram), _WORKERS)) if len(gram) else [gram]
    with _one_intraop_thread():
        parts = list(_thread_pool().map(torch.linalg.eigh, chunks))
    values = torch.cat([part.eigenvalues for part in parts]).flip(-1)
    vectors = torch.cat([part.eigenvectors for part in parts]).flip(-1)
    return values, vectors


def window_svd(
        windows: torch.Tensor,
        center: bool = True,
        rank: Optional[int] = None
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Singular values and leading singular vectors of each window.

    Computed from the float64 eigendecomposition of the smaller Gram matrix:
    ``X^T X = V diag(s^2) V^T`` and ``U = X V / s`` (or the transposed form when
    there are fewer neurons than time bins). Singular vectors of numerically
    zero singular values are returned as zero columns.

    Args:
        windows: ``(B, N, T)`` batch of ``neurons x time`` windows.
        center: Remove each neuron's temporal mean first.
        rank: Number of leading singular vectors to return (all by default).

    Returns:
        ``u`` of shape ``(B, N, q)``, ``s`` of shape ``(B, min(N, T))`` in
        descending order and ``v`` of shape ``(B, T, q)``, in float32 (float64
        for float64 inputs).
    """
    with torch.autocast(device_type=windows.device.type, enabled=False):
        matrix = _matrices(windows.detach(), center)
        full = min(matrix.shape[-2:])
        rank = full if rank is None else min(rank, full)
        tall = matrix.shape[-2] >= matrix.shape[-1]
        m64 = matrix.double()
        gram = m64.mT @ m64 if tall else m64 @ m64.mT
        eigenvalues, vectors = _eigh_cpu(gram.cpu())
        values = eigenvalues.clamp_min(0).sqrt().to(matrix.device)
        vectors = vectors[..., :rank].to(matrix.device)
        other = (m64 @ vectors) if tall else (m64.mT @ vectors)
        scale = values[:, None, :rank]
        tolerance = values[:, None, :1] * max(matrix.shape[-2:]) * 1e-12
        other = torch.where(scale > tolerance, other / scale.clamp_min(1e-300),
                            torch.zeros_like(other))
        u, v = (other, vectors) if tall else (vectors, other)
        dtype = matrix.dtype
        return u.to(dtype), values.to(dtype), v.to(dtype)


def _top_structure(windows: torch.Tensor, config: AttackConfig):
    """Leading singular vectors, values, the chosen ``k`` and the gap per window."""
    neurons, time = windows.shape[-2:]
    if min(neurons, time) < config.k_min + 1:
        raise ValueError(
            f"Spectral attacks need windows with at least {config.k_min + 1} "
            f"neurons and time bins, got {neurons} x {time}. Use a model with a "
            "longer receptive field (e.g. offset10-model) or lower k_min.")
    k_high = min(config.k_max, min(neurons, time) - 1)
    u, s, v = window_svd(windows, config.center, rank=k_high)
    candidates = torch.arange(config.k_min, k_high + 1, device=s.device)
    gaps = s[:, candidates - 1] - s[:, candidates]
    gap, best = gaps.max(dim=-1)
    k = candidates[best]
    # Numerically zero singular values carry no structure to protect.
    tolerance = s[:, :1] * max(neurons, time) * torch.finfo(torch.float32).eps
    columns = torch.arange(k_high, device=s.device)
    keep = (columns[None] < k[:, None]) & (s[:, :k_high] > tolerance)
    return u, s, v, k, gap, keep


def _constant_direction(right: torch.Tensor) -> torch.Tensor:
    batch, time = right.shape[:2]
    ones = torch.full((batch, time, 1),
                      time**-0.5,
                      dtype=right.dtype,
                      device=right.device)
    ones = ones - right @ (right.mT @ ones)
    length = ones.norm(dim=-2, keepdim=True)
    return torch.where(length > 1e-6, ones / length.clamp_min(1e-12),
                       torch.zeros_like(ones))


def spectral_frame(windows: torch.Tensor, config: AttackConfig) -> SpectralFrame:
    """Compute protected subspaces and per-window budgets of a clean batch."""
    u, s, v, k, gap, keep = _top_structure(windows, config)
    dtype = torch.float64 if windows.dtype == torch.float64 else torch.float32
    mask = keep[:, None, :].to(dtype)
    left, right = u.to(dtype) * mask, v.to(dtype) * mask
    if config.preserve_mean:
        right = torch.cat([right, _constant_direction(right)], dim=-1)
    if config.gap_limited:
        epsilon = (config.gamma * gap).clamp(max=config.epsilon)
    else:
        epsilon = torch.full_like(gap, config.epsilon)
    epsilon = torch.where(torch.isfinite(epsilon), epsilon,
                          torch.zeros_like(epsilon)).clamp_min(0).to(dtype)
    return SpectralFrame(left, right, k, gap, epsilon, s)


def project(values: torch.Tensor, frame: SpectralFrame) -> torch.Tensor:
    """Orthogonal projection ``(I - L L^T) X (I - R R^T)`` onto the complement."""
    values = values - frame.left @ (frame.left.mT @ values)
    return values - (values @ frame.right) @ frame.right.mT


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor) -> torch.Tensor:
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…)."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _shrink_to_ball(delta: torch.Tensor,
                    epsilon: Union[float, torch.Tensor]) -> torch.Tensor:
    """Scale each sample of ``delta`` into the closed L2 ball of radius ``epsilon``."""
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    if isinstance(epsilon, torch.Tensor):
        epsilon = epsilon.reshape(-1, 1)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    return delta / factor.view(-1, *([1] * (delta.dim() - 1)))


def _attack_linf(original: torch.Tensor, loss_fn: Callable,
                 config: AttackConfig) -> torch.Tensor:
    epsilon, alpha = config.epsilon, config.alpha
    perturb = torch.empty_like(original).uniform_(-epsilon, epsilon)
    adversarial = (original + perturb).clone()
    adversarial.requires_grad = True
    for _ in range(config.steps):
        with torch.enable_grad():
            loss = loss_fn(adversarial)
        gradient, = torch.autograd.grad(loss, adversarial)
        with torch.no_grad():
            adversarial = adversarial + alpha * gradient.sign()
            adversarial = torch.max(torch.min(adversarial, original + epsilon),
                                    original - epsilon)
        adversarial.requires_grad = True
    return adversarial.detach()


def _attack_l2(original: torch.Tensor, loss_fn: Callable, config: AttackConfig,
               frame: Optional[SpectralFrame]) -> torch.Tensor:
    projected = frame is not None and config.projected
    if frame is None:
        epsilon, alpha = config.epsilon, config.alpha
    else:
        shape = (-1,) + (1,) * (original.dim() - 1)
        epsilon = frame.epsilon.to(original.dtype)
        fraction = config.alpha / config.epsilon if config.epsilon > 0 else 0.
        alpha = (epsilon * fraction).reshape(shape)
        epsilon = epsilon.reshape(shape)

    noise = torch.randn_like(original)
    if projected:
        noise = project(noise, frame)
    noise = _l2_normalize(noise)
    noise *= _rand_radius_like(original) * epsilon
    adversarial = (original + noise).clone().detach().requires_grad_(True)
    for _ in range(config.steps):
        with torch.enable_grad():
            loss = loss_fn(adversarial)
        gradient, = torch.autograd.grad(loss, adversarial)
        with torch.no_grad():
            if projected:
                gradient = project(gradient, frame)
            adversarial = adversarial + alpha * _l2_normalize(gradient)
            delta = adversarial - original
            if projected:
                delta = project(delta, frame)
            adversarial = original + _shrink_to_ball(delta, epsilon)
        adversarial.requires_grad = True
    return adversarial.detach()


def attack(reference: torch.Tensor,
           loss_fn: Callable[[torch.Tensor], torch.Tensor],
           config: AttackConfig,
           frame: Optional[SpectralFrame] = None) -> torch.Tensor:
    """Maximise ``loss_fn`` over perturbations of the reference windows.

    For ``mode="none"`` this is the previous project's PGD, with identical random
    calls, update and projection order. The spectral modes start from a random
    point of the allowed set and keep every iterate in it.

    Args:
        reference: ``(B, N, T)`` clean reference windows.
        loss_fn: Maps a reference batch to the scalar loss to maximise.
        config: Attack settings.
        frame: Precomputed :py:func:`spectral_frame` of ``reference``.

    Returns:
        The detached adversarial reference windows.
    """
    original = reference.detach()
    if config.norm == "linf":
        return _attack_linf(original, loss_fn, config)
    if config.spectral and frame is None:
        frame = spectral_frame(original, config)
    return _attack_l2(original, loss_fn, config,
                      frame if config.spectral else None)


@torch.no_grad()
def attack_summary(original: torch.Tensor, attacked: torch.Tensor,
                   config: AttackConfig,
                   frame: Optional[SpectralFrame]) -> Dict[str, float]:
    """Cheap per-step statistics of an attack, with one device synchronisation."""
    delta = (attacked - original).flatten(1)
    norm = delta.norm(dim=1) if config.norm == "l2" else delta.abs().amax(dim=1)
    names = ["adv_delta_norm"]
    values = [norm.float().mean()]
    if frame is not None:
        epsilon = frame.epsilon.float()
        names += [
            "adv_eps_mean", "adv_eps_min", "adv_gap_limited", "adv_k_mean",
            "adv_gap_mean"
        ]
        values += [
            epsilon.mean(),
            epsilon.min(),
            (config.gamma * frame.gap < config.epsilon).float().mean()
            if config.gap_limited else torch.zeros((), device=epsilon.device),
            frame.k.float().mean(),
            frame.gap.float().mean(),
        ]
    return dict(zip(names, torch.stack(values).tolist()))


@torch.no_grad()
def spectral_diagnostics(original: torch.Tensor,
                         attacked: torch.Tensor,
                         config: AttackConfig,
                         frame: Optional[SpectralFrame] = None) -> Dict[str, float]:
    """Measure how much an attack changed the top-k singular structure.

    Uses the same centring and choice of ``k`` as the spectral modes, also for
    plain PGD, so all modes are comparable. Subspace errors are normalised
    projector distances in ``[0, 1]``.

    Returns:
        Means and maxima over windows of the relative top-k singular-value
        change (``sv_err``), the left/right top-k subspace distances, the
        relative change of the whole spectrum (``spectral_drift``) and the ratio
        of the perturbation norm to the gap (``delta_over_gap``).
    """
    u, s, v, k, gap, keep = _top_structure(original, config)
    k_high = u.shape[-1]
    u2, s2, v2 = window_svd(attacked, config.center, rank=k_high)
    mask = keep.to(s.dtype)
    count = mask.sum(-1)
    scale = s[:, :1].clamp_min(1e-12)
    sv_err = ((s2[:, :k_high] - s[:, :k_high]).abs() * mask).amax(-1) / scale[:, 0]

    def subspace(a, b):
        overlap = ((a * mask[:, None]).mT @ (b * mask[:, None])).square().sum(
            (-1, -2))
        return (1 - overlap / count.clamp_min(1)).clamp_min(0).sqrt()

    valid = count > 0
    left, right = subspace(u, u2)[valid], subspace(v, v2)[valid]
    drift = (s2 - s).norm(dim=-1) / s.norm(dim=-1).clamp_min(1e-12)
    delta = (attacked - original).flatten(1).norm(dim=1).to(s.dtype)
    ratio = (delta / gap.clamp_min(1e-12))[gap > 0]

    def stats(name, values):
        if values.numel() == 0:
            return {f"{name}_mean": float("nan"), f"{name}_max": float("nan")}
        return {f"{name}_mean": values.mean(), f"{name}_max": values.max()}

    result = {}
    for name, values in (("sv_err", sv_err[valid]), ("left_subspace_err", left),
                         ("right_subspace_err", right), ("spectral_drift", drift),
                         ("delta_over_gap", ratio)):
        result.update(stats(name, values))
    result["k_mean"] = k.float().mean()
    result["gap_mean"] = gap.mean()
    return {
        name: float(value) if isinstance(value, torch.Tensor) else value
        for name, value in result.items()
    }
