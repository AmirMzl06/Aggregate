#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Spectral-gap subspace attacks on reference windows.

Every reference window ``X`` (neurons x time) is optionally centred over time
and decomposed as ``Xc = U diag(s) V^T`` with ``s`` sorted in descending order.
For a window-specific ``k`` the attack only uses perturbations in

    S_k = {D : U_k^T D = 0 and D V_k = 0},

the orthogonal complement of the top-k left *and* right singular subspaces.
Then ``Xc + D = U_k diag(s_1..s_k) V_k^T + (R + D)`` where ``R + D`` is
orthogonal to both subspaces, so the top-k singular values *and* singular
vectors of ``Xc + D`` are exactly those of ``Xc`` whenever
``||D||_2 < s_k - s_{k+1}`` (Weyl). Since ``||D||_2 <= ||D||_F``, the per-window
L2 budget

    eps_i = min(epsilon, gamma * (s_k - s_{k+1})),   0 < gamma < 1,

is the largest radius at which the top-k structure provably cannot collapse.
``k`` is chosen per window as the position of the largest gap in
``[k_min, k_max]``, i.e. the split that admits the largest such radius.

The orthogonal complement of ``S_k`` is the tangent space of the rank-k
matrices at the dominant structure, ``T_k = {U_k A + B V_k^T}``: the directions
along the top singular vectors (on-manifold). Perturbations in ``T_k`` change
the dominant structure. With ``||D||_F <= gamma * (s_k - s_{k+1}) / 2`` every
singular value moves by less than half the gap (Weyl), so ``s_k`` and
``s_{k+1}`` cannot cross: the top-k structure is perturbed but cannot collapse
into the rest of the spectrum.

``split`` perturbs both geometries at once, ``D = D_S + D_T`` with
``D_S`` in ``S_k`` and ``D_T`` in ``T_k``, each with its own budget. Its final
perturbation is certified with operator norms: ``||D_S||_2 <= gamma * gap / 2``
and ``||D_T||_2 <= gamma * (gap - ||D_S||_2) / 2``, so that
``||D_S||_2 + 2 ||D_T||_2 < gap`` and the k-th and (k+1)-th singular values
cannot cross (see THEORY.md, Proposition 5).

Modes:
    ``none``: plain PGD on the reference, identical to the previous project
        (L2 or Linf, fixed ``epsilon``).
    ``gap``: complement projection and gap budget (the full formulation,
        off-manifold).
    ``tangent``: tangent-space projection and half-gap budget (on-manifold).
    ``split``: both geometries with separate budgets (tangent half-gap, the
        complement the rest of ``epsilon`` so that ``||D||_F <= epsilon``) and a
        joint operator-norm certificate.
    ``subspace``: complement projection with the fixed budget ``epsilon``
        (exact only where ``||D||_2 < s_k - s_{k+1}``).
    ``subspace_cert``: ``subspace`` whose final perturbation is shrunk, where
        needed, to ``||D||_2 <= gamma * gap`` (exact operator norm): the full
        Frobenius budget with the guarantee of Proposition 1.
    ``gap_budget``: gap budget without the projection (ablation; no guarantee).
    ``tangent_budget``: half-gap budget without the projection (ablation:
        the budget of ``tangent``, unrestricted directions).
    ``tangent_fixed``: tangent projection with the fixed budget ``epsilon``
        and no certificate (equal-radius comparison of directions).

``subspace_cert`` and ``split`` enforce their operator-norm certificates by the
exact Euclidean projection onto the certified set: singular values of the
perturbation are clipped (and rescaled to the Frobenius budget), which keeps
more of the attack than shrinking the whole perturbation. ``certify="final"``
applies it to the final perturbation; ``certify="every"`` after every PGD step,
so that the attack optimises inside the certified set.

The spectral modes need ``norm="l2"``: the budget is a Frobenius radius.
"""

import concurrent.futures
import contextlib
import dataclasses
import math
import os
from typing import Callable, Dict, Optional, Tuple, Union

import torch

__all__ = [
    "ATTACK_MODES", "AttackConfig", "SpectralFrame", "window_svd",
    "spectral_frame", "project", "project_tangent", "spectral_norm",
    "project_spectral_ball", "shrink_spectral_ball", "certify_complement", "certify_collapse",
    "certify_split", "attack",
    "attack_summary", "spectral_diagnostics"
]

ATTACK_MODES = ("none", "gap", "tangent", "split", "subspace", "subspace_cert",
                "gap_budget", "tangent_budget", "tangent_fixed", "gap_share", "norm_share")
# Unrestricted attacks with per-window budgets, which may be reassigned (``allocation``).
BUDGET_MODES = ("gap_budget", "tangent_budget", "gap_share", "norm_share")
# "window": the budgets as computed; "shuffle": the same budgets, randomly permuted
# over the windows of the batch; "mean": every window gets the batch mean.
ALLOCATIONS = ("window", "shuffle", "mean")
# "final" and "every": exact projection of the final / every PGD iterate onto the
# certified set; "radial": scale the final perturbation as a whole (earlier versions);
# "collapse": scale it to the exact collapse radius along its direction (Proposition 7).
CERTIFY_WHEN = ("final", "every", "radial", "collapse")
# Share of the units, ranked by mean activity in the batch, whose perturbation
# energy attack_summary reports.
TOP_UNIT_FRACTION = 0.2

# Batched SVDs of small windows are slow with the default CUDA driver, and the
# fast cuSOLVER driver (gesvda) fails on degenerate windows such as silent bins.
# Instead, the eigendecomposition of the small Gram matrix is computed in float64
# on the CPU, split over a few single-threaded workers. This is exact to float64
# precision for the leading modes and takes ~40 ms for 2048 windows of 100 x 36.
_WORKERS = 8
_executor = None


def _thread_pool():
    global _executor
    if _executor is None:
        _executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=min(_WORKERS, os.cpu_count() or 1))
    return _executor


def _is_number(value) -> bool:
    return (isinstance(value, (int, float)) and not isinstance(value, bool) and
            math.isfinite(value))


@dataclasses.dataclass(frozen=True)
class AttackConfig:
    """Settings of the reference attack.

    Attributes:
        epsilon: Maximum budget. For the gap modes, the cap on the per-window budget.
        alpha: Step size for ``epsilon``; per-window budgets use the same
            fraction ``alpha / epsilon`` of their own radius.
        steps: Number of PGD steps.
        norm: ``"l2"`` or ``"linf"``; the spectral modes need ``"l2"``.
        mode: One of :py:data:`ATTACK_MODES`.
        gamma: Fraction of the spectral gap used as budget, ``0 < gamma < 1``.
        k_min: Smallest number of protected singular modes.
        k_max: Largest number of protected singular modes.
        center: Remove each neuron's temporal mean before the SVD.
        preserve_mean: Also protect the constant time direction, so that the
            perturbation leaves every neuron's mean rate in the window unchanged.
        certify: How ``subspace_cert`` and ``split`` enforce their operator-norm
            certificate, one of :py:data:`CERTIFY_WHEN`.
        split_complement: Fraction of the remaining budget given to the complement
            part in ``split``, in ``[0, 1]``.
        energy_match: Control arm. Run the configured spectral attack only to
            measure each window's perturbation norm, then train on unrestricted
            PGD with exactly that per-window L2 budget.
        allocation: How the per-window budgets of :py:data:`BUDGET_MODES` and of
            ``energy_match`` are assigned, one of :py:data:`ALLOCATIONS`.
    """

    epsilon: float = 0.05
    alpha: float = 0.01
    steps: int = 10
    norm: str = "linf"
    mode: str = "none"
    gamma: float = 0.9
    k_min: int = 1
    k_max: int = 8
    center: bool = True
    preserve_mean: bool = False
    certify: str = "final"
    split_complement: float = 1.0
    energy_match: bool = False
    allocation: str = "window"

    def __post_init__(self):
        if self.norm not in ("l2", "linf"):
            raise ValueError(
                f"attack_norm must be 'l2' or 'linf', got {self.norm!r}.")
        if self.mode not in ATTACK_MODES:
            raise ValueError(f"adv_spectral_mode must be one of {ATTACK_MODES}, "
                             f"got {self.mode!r}.")
        if self.spectral and self.norm != "l2":
            raise ValueError("Spectral attacks use a Frobenius (L2) budget; set "
                             "attack_norm='l2'.")
        for name in ("epsilon", "alpha"):
            value = getattr(self, name)
            if not _is_number(value) or value < 0:
                raise ValueError(f"adv_{name} must be finite and nonnegative, "
                                 f"got {value!r}.")
        if not isinstance(self.steps, int) or isinstance(self.steps,
                                                          bool) or self.steps < 0:
            raise ValueError(
                f"adv_steps must be a nonnegative integer, got {self.steps!r}.")
        if not _is_number(self.gamma) or not 0 < self.gamma < 1:
            raise ValueError("adv_spectral_gamma must be in (0, 1), got "
                             f"{self.gamma!r}.")
        for name in ("k_min", "k_max"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"adv_spectral_{name} must be a positive integer, "
                                 f"got {value!r}.")
        if self.k_max < self.k_min:
            raise ValueError("adv_spectral_k_max must be >= adv_spectral_k_min.")
        for name in ("center", "preserve_mean"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"adv_spectral_{name} must be a bool.")
        if self.certify not in CERTIFY_WHEN:
            raise ValueError(f"adv_spectral_certify must be one of {CERTIFY_WHEN}, "
                             f"got {self.certify!r}.")
        if not _is_number(self.split_complement) or not 0 <= self.split_complement <= 1:
            raise ValueError("adv_spectral_split_complement must be in [0, 1], got "
                             f"{self.split_complement!r}.")
        if self.preserve_mean and not self.projected:
            raise ValueError("adv_spectral_preserve_mean needs a complement mode "
                             "('gap', 'subspace' or 'subspace_cert').")
        if self.certify == "collapse" and self.split:
            raise ValueError("adv_spectral_certify='collapse' is defined for 'subspace_cert'; "
                             "'split' uses 'final', 'every' or 'radial'.")
        if not isinstance(self.energy_match, bool):
            raise ValueError("adv_spectral_energy_match must be a bool.")
        if self.energy_match and not self.spectral:
            raise ValueError("adv_spectral_energy_match needs a spectral mode, whose "
                             "perturbation norms set the PGD budgets.")
        if self.allocation not in ALLOCATIONS:
            raise ValueError(f"adv_spectral_allocation must be one of {ALLOCATIONS}, "
                             f"got {self.allocation!r}.")
        if (self.allocation != "window" and not self.energy_match and
                self.mode not in BUDGET_MODES):
            raise ValueError("adv_spectral_allocation reassigns the per-window budgets of "
                             f"unrestricted attacks: use it with {BUDGET_MODES} or "
                             "adv_spectral_energy_match.")

    @property
    def spectral(self) -> bool:
        """Whether the attack needs the singular structure of the windows."""
        return self.mode != "none"

    @property
    def projected(self) -> bool:
        """Whether perturbations are restricted to the complement subspace."""
        return self.mode in ("gap", "subspace", "subspace_cert")

    @property
    def tangent(self) -> bool:
        """Whether perturbations are restricted to the tangent space (on-manifold)."""
        return self.mode in ("tangent", "tangent_fixed")

    @property
    def split(self) -> bool:
        """Whether complement and tangent components are attacked jointly."""
        return self.mode == "split"

    @property
    def gap_limited(self) -> bool:
        """Whether the per-window budget is capped by the spectral gap."""
        return self.mode in ("gap", "gap_budget", "tangent", "tangent_budget")

    @property
    def gap_factor(self) -> float:
        """Fraction of ``gamma * gap`` used as budget: half in the tangent space."""
        return 0.5 if self.mode in ("tangent", "tangent_budget") else 1.0


@dataclasses.dataclass
class SpectralFrame:
    """Protected subspaces and budgets of one batch of windows.

    Attributes:
        left: ``(B, N, q)`` protected left singular vectors, zero beyond ``k``.
        right: ``(B, T, q)`` protected right singular vectors, zero beyond ``k``;
            one extra column for the constant direction if ``preserve_mean``.
        k: ``(B,)`` number of protected singular modes.
        gap: ``(B,)`` spectral gap ``s_k - s_{k+1}``.
        epsilon: ``(B,)`` per-window L2 budget (of the complement part in ``split``).
        values: ``(B, r)`` singular values of the clean windows.
        tangent_epsilon: ``(B,)`` L2 budget of the tangent part (``split`` only).
    """

    left: torch.Tensor
    right: torch.Tensor
    k: torch.Tensor
    gap: torch.Tensor
    epsilon: torch.Tensor
    values: torch.Tensor
    tangent_epsilon: Optional[torch.Tensor] = None
    stats: Dict[str, torch.Tensor] = dataclasses.field(default_factory=dict)


def _matrices(windows: torch.Tensor, center: bool) -> torch.Tensor:
    matrix = windows if windows.dtype == torch.float64 else windows.float()
    if center:
        matrix = matrix - matrix.mean(dim=-1, keepdim=True)
    return matrix


@contextlib.contextmanager
def _one_intraop_thread():
    """Avoid oversubscription: each worker's small LAPACK call runs single-threaded."""
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        yield
    finally:
        torch.set_num_threads(previous)


def _eigvalsh_cpu(gram: torch.Tensor) -> torch.Tensor:
    """Batched symmetric eigenvalues on the CPU, ascending."""
    chunks = gram.chunk(min(len(gram), _WORKERS)) if len(gram) else [gram]
    with _one_intraop_thread():
        parts = list(_thread_pool().map(torch.linalg.eigvalsh, chunks))
    return torch.cat(parts)


def spectral_norm(matrices: torch.Tensor) -> torch.Tensor:
    """Largest singular value of each ``(B, N, T)`` matrix, from float64 Gram eigenvalues."""
    m64 = matrices.detach().double()
    gram = m64.mT @ m64 if m64.shape[-2] >= m64.shape[-1] else m64 @ m64.mT
    values = _eigvalsh_cpu(gram.cpu())[..., -1]
    return values.clamp_min(0).sqrt().to(device=matrices.device, dtype=matrices.dtype)


def _eigh_cpu(gram: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Batched symmetric eigendecomposition on the CPU, eigenvalues descending."""
    chunks = gram.chunk(min(len(gram), _WORKERS)) if len(gram) else [gram]
    with _one_intraop_thread():
        parts = list(_thread_pool().map(torch.linalg.eigh, chunks))
    values = torch.cat([part.eigenvalues for part in parts]).flip(-1)
    vectors = torch.cat([part.eigenvectors for part in parts]).flip(-1)
    return values, vectors


def window_svd(
        windows: torch.Tensor,
        center: bool = True,
        rank: Optional[int] = None
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Singular values and leading singular vectors of each window.

    Computed from the float64 eigendecomposition of the smaller Gram matrix:
    ``X^T X = V diag(s^2) V^T`` and ``U = X V / s`` (or the transposed form when
    there are fewer neurons than time bins). Singular vectors of numerically
    zero singular values are returned as zero columns.

    Args:
        windows: ``(B, N, T)`` batch of ``neurons x time`` windows.
        center: Remove each neuron's temporal mean first.
        rank: Number of leading singular vectors to return (all by default).

    Returns:
        ``u`` of shape ``(B, N, q)``, ``s`` of shape ``(B, min(N, T))`` in
        descending order and ``v`` of shape ``(B, T, q)``, in float32 (float64
        for float64 inputs).
    """
    with torch.autocast(device_type=windows.device.type, enabled=False):
        matrix = _matrices(windows.detach(), center)
        full = min(matrix.shape[-2:])
        rank = full if rank is None else min(rank, full)
        tall = matrix.shape[-2] >= matrix.shape[-1]
        m64 = matrix.double()
        gram = m64.mT @ m64 if tall else m64 @ m64.mT
        eigenvalues, vectors = _eigh_cpu(gram.cpu())
        values = eigenvalues.clamp_min(0).sqrt().to(matrix.device)
        vectors = vectors[..., :rank].to(matrix.device)
        other = (m64 @ vectors) if tall else (m64.mT @ vectors)
        scale = values[:, None, :rank]
        tolerance = values[:, None, :1] * max(matrix.shape[-2:]) * 1e-12
        other = torch.where(scale > tolerance, other / scale.clamp_min(1e-300),
                            torch.zeros_like(other))
        u, v = (other, vectors) if tall else (vectors, other)
        dtype = matrix.dtype
        return u.to(dtype), values.to(dtype), v.to(dtype)


def _top_structure(windows: torch.Tensor, config: AttackConfig):
    """Leading singular vectors, values, the chosen ``k`` and the gap per window."""
    neurons, time = windows.shape[-2:]
    if min(neurons, time) < config.k_min + 1:
        raise ValueError(
            f"Spectral attacks need windows with at least {config.k_min + 1} "
            f"neurons and time bins, got {neurons} x {time}. Use a model with a "
            "longer receptive field (e.g. offset10-model) or lower k_min.")
    k_high = min(config.k_max, min(neurons, time) - 1)
    u, s, v = window_svd(windows, config.center, rank=k_high)
    candidates = torch.arange(config.k_min, k_high + 1, device=s.device)
    gaps = s[:, candidates - 1] - s[:, candidates]
    gap, best = gaps.max(dim=-1)
    k = candidates[best]
    # Numerically zero singular values carry no structure to protect.
    tolerance = s[:, :1] * max(neurons, time) * torch.finfo(torch.float32).eps
    columns = torch.arange(k_high, device=s.device)
    keep = (columns[None] < k[:, None]) & (s[:, :k_high] > tolerance)
    return u, s, v, k, gap, keep


def _constant_direction(right: torch.Tensor) -> torch.Tensor:
    batch, time = right.shape[:2]
    ones = torch.full((batch, time, 1),
                      time**-0.5,
                      dtype=right.dtype,
                      device=right.device)
    ones = ones - right @ (right.mT @ ones)
    length = ones.norm(dim=-2, keepdim=True)
    return torch.where(length > 1e-6, ones / length.clamp_min(1e-12),
                       torch.zeros_like(ones))


def spectral_frame(windows: torch.Tensor, config: AttackConfig) -> SpectralFrame:
    """Compute protected subspaces and per-window budgets of a clean batch."""
    u, s, v, k, gap, keep = _top_structure(windows, config)
    dtype = torch.float64 if windows.dtype == torch.float64 else torch.float32
    mask = keep[:, None, :].to(dtype)
    left, right = u.to(dtype) * mask, v.to(dtype) * mask
    if config.preserve_mean:
        right = torch.cat([right, _constant_direction(right)], dim=-1)
    def finite(budget):
        return torch.where(torch.isfinite(budget), budget,
                           torch.zeros_like(budget)).clamp_min(0).to(dtype)

    if config.gap_limited:
        epsilon = (config.gamma * config.gap_factor * gap).clamp(max=config.epsilon)
    elif config.mode == "gap_share":
        # Every window at the same fraction of its collapse radius, mean budget epsilon.
        epsilon = config.epsilon * gap / gap.mean().clamp_min(1e-12)
    elif config.mode == "norm_share":
        # Control of gap_share: the same fraction of every window's norm instead.
        norm = s.norm(dim=-1)
        epsilon = config.epsilon * norm / norm.mean().clamp_min(1e-12)
    else:
        epsilon = torch.full_like(gap, config.epsilon)
    if config.mode in BUDGET_MODES:
        epsilon = _allocate(epsilon, config.allocation)
    tangent_epsilon = None
    if config.split:
        # Orthogonal components: ||D||_F^2 = ||D_S||_F^2 + ||D_T||_F^2 <= epsilon^2.
        tangent_epsilon = finite((config.gamma * gap / 2).clamp(max=config.epsilon))
        epsilon = (config.epsilon**2 - tangent_epsilon.double()**2).clamp_min(0).sqrt()
        epsilon = config.split_complement * epsilon
    return SpectralFrame(left, right, k, gap, finite(epsilon), s, tangent_epsilon)


def _allocate(budget: torch.Tensor, allocation: str) -> torch.Tensor:
    """Per-window budgets as computed, randomly permuted, or all equal to their mean."""
    if allocation == "shuffle":
        return budget[torch.randperm(len(budget), device=budget.device)]
    if allocation == "mean":
        return budget.mean().expand(len(budget)).clone()
    return budget


def project(values: torch.Tensor, frame: SpectralFrame) -> torch.Tensor:
    """Orthogonal projection ``(I - L L^T) X (I - R R^T)`` onto the complement."""
    values = values - frame.left @ (frame.left.mT @ values)
    return values - (values @ frame.right) @ frame.right.mT


def project_tangent(values: torch.Tensor, frame: SpectralFrame) -> torch.Tensor:
    """Orthogonal projection onto the tangent space ``{L A + B R^T}``."""
    return values - project(values, frame)


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor) -> torch.Tensor:
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…)."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _shrink_to_ball(delta: torch.Tensor,
                    epsilon: Union[float, torch.Tensor]) -> torch.Tensor:
    """Scale each sample of ``delta`` into the closed L2 ball of radius ``epsilon``."""
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    if isinstance(epsilon, torch.Tensor):
        epsilon = epsilon.reshape(-1, 1)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    return delta / factor.view(-1, *([1] * (delta.dim() - 1)))


def _attack_linf(original: torch.Tensor, loss_fn: Callable,
                 config: AttackConfig) -> torch.Tensor:
    epsilon, alpha = config.epsilon, config.alpha
    perturb = torch.empty_like(original).uniform_(-epsilon, epsilon)
    adversarial = (original + perturb).clone()
    adversarial.requires_grad = True
    for _ in range(config.steps):
        with torch.enable_grad():
            loss = loss_fn(adversarial)
        gradient, = torch.autograd.grad(loss, adversarial)
        with torch.no_grad():
            adversarial = adversarial + alpha * gradient.sign()
            adversarial = torch.max(torch.min(adversarial, original + epsilon),
                                    original - epsilon)
        adversarial.requires_grad = True
    return adversarial.detach()


def _attack_l2(original: torch.Tensor, loss_fn: Callable, config: AttackConfig,
               frame: Optional[SpectralFrame]) -> torch.Tensor:
    restrict = None
    if frame is not None and config.projected:
        restrict = project
    elif frame is not None and config.tangent:
        restrict = project_tangent
    every_step = config.mode == "subspace_cert" and config.certify == "every"
    if frame is None:
        epsilon, alpha = config.epsilon, config.alpha
    else:
        shape = (-1,) + (1,) * (original.dim() - 1)
        epsilon = frame.epsilon.to(original.dtype)
        fraction = config.alpha / config.epsilon if config.epsilon > 0 else 0.
        alpha = (epsilon * fraction).reshape(shape)
        epsilon = epsilon.reshape(shape)

    noise = torch.randn_like(original)
    if restrict is not None:
        noise = restrict(noise, frame)
    noise = _l2_normalize(noise)
    noise *= _rand_radius_like(original) * epsilon
    if every_step:
        with torch.no_grad():
            noise = certify_complement(noise, frame, config.gamma, epsilon)
    adversarial = (original + noise).clone().detach().requires_grad_(True)
    for _ in range(config.steps):
        with torch.enable_grad():
            loss = loss_fn(adversarial)
        gradient, = torch.autograd.grad(loss, adversarial)
        with torch.no_grad():
            if restrict is not None:
                gradient = restrict(gradient, frame)
            adversarial = adversarial + alpha * _l2_normalize(gradient)
            delta = adversarial - original
            if restrict is not None:
                delta = restrict(delta, frame)
            if every_step:
                # Exact projection onto the certified set (Frobenius and operator norm).
                delta = certify_complement(delta, frame, config.gamma, epsilon)
            else:
                delta = _shrink_to_ball(delta, epsilon)
            adversarial = original + delta
        adversarial.requires_grad = True
    if config.mode == "subspace_cert" and not every_step:
        with torch.no_grad():
            delta = adversarial - original
            if config.certify == "collapse":
                delta = certify_collapse(delta, original, frame, config.gamma, config.center)
            else:
                delta = certify_complement(delta, frame, config.gamma,
                                           radial=config.certify == "radial")
            return (original + delta).detach()
    return adversarial.detach()


def _project_spectral_ball_svd(delta: torch.Tensor, tau: torch.Tensor,
                               epsilon: Optional[torch.Tensor]):
    """Exact projection through the SVD; also returns the singular values before it."""
    u, s, v = window_svd(delta, center=False)
    s = s.to(delta.dtype)
    tau = tau.reshape(-1, 1)
    clipped = torch.minimum(s, tau)
    if epsilon is not None:
        eps = epsilon.reshape(-1)
        over = clipped.norm(dim=1) > eps
        if over.any():
            low = torch.zeros_like(eps)
            high = (s.norm(dim=1) / eps.clamp_min(1e-12)).clamp_min(1.0)
            for _ in range(60):
                mid = (low + high) / 2
                fits = torch.minimum(s / (1 + mid[:, None]), tau).norm(dim=1) <= eps
                high = torch.where(fits, mid, high)
                low = torch.where(fits, low, mid)
            scaled = torch.minimum(s / (1 + high[:, None]), tau)
            clipped = torch.where(over[:, None], scaled, clipped)
    return (u * clipped[:, None, :]) @ v.mT, s, clipped[:, 0]


def project_spectral_ball(delta: torch.Tensor, tau: torch.Tensor,
                          epsilon: Optional[torch.Tensor] = None):
    """Euclidean projection onto ``{||D||_2 <= tau, ||D||_F <= epsilon}`` per matrix.

    Both constraints are unitarily invariant, so the projection keeps the singular
    vectors and maps the singular values to ``min(tau, s / (1 + mu))`` with the
    smallest ``mu >= 0`` for which the Frobenius bound holds (THEORY.md,
    Proposition 6). Scaling into the Frobenius ball is the projection whenever
    the scaled matrix already satisfies the operator-norm bound. Since
    ``||D||_2 <= ||D||_F``, only matrices whose scaled Frobenius norm exceeds
    ``tau`` can need more, and only those go through an SVD.

    Returns:
        The projected matrices; the mask of matrices where the operator-norm bound
        is active (needed beyond the Frobenius scaling); and an upper bound on their
        largest singular value after the projection (exact where an SVD was taken).
    """
    shape = (-1,) + (1,) * (delta.dim() - 1)
    tau = tau.to(delta.dtype).reshape(-1)
    norm = delta.flatten(1).norm(dim=1)
    scale = torch.ones_like(norm)
    if epsilon is not None:
        eps = epsilon.to(delta.dtype).reshape(-1)
        scale = torch.where(norm > eps, eps / norm.clamp_min(1e-12), scale)
    projected = torch.where(scale.reshape(shape) < 1, delta * scale.reshape(shape), delta)
    top = scale * norm
    binding = torch.zeros_like(norm, dtype=torch.bool)
    candidate = top > tau * (1 + 1e-9)
    if candidate.any():
        index = candidate.nonzero()[:, 0]
        rebuilt, values, top_index = _project_spectral_ball_svd(
            delta[index], tau[index], None if epsilon is None else eps[index])
        active = values[:, 0] * scale[index] > tau[index] * (1 + 1e-9)
        projected, top, binding = projected.clone(), top.clone(), binding.clone()
        projected[index] = torch.where(active.reshape(shape), rebuilt, projected[index])
        top[index] = torch.where(active, top_index, values[:, 0] * scale[index])
        binding[index] = active
    return projected, binding, top


def shrink_spectral_ball(delta: torch.Tensor, tau: torch.Tensor,
                         epsilon: Optional[torch.Tensor] = None):
    """Scale each matrix as a whole into ``{||D||_2 <= tau, ||D||_F <= epsilon}``.

    The radial certificate of earlier versions, kept as an ablation of
    :py:func:`project_spectral_ball`. It returns the same triple, with the exact
    largest singular value after scaling.
    """
    shape = (-1,) + (1,) * (delta.dim() - 1)
    tau = tau.to(delta.dtype).reshape(-1)
    norm = spectral_norm(delta)
    scale = torch.where(norm > tau, tau / norm.clamp_min(1e-12), torch.ones_like(norm))
    binding = norm > tau
    if epsilon is not None:
        eps = epsilon.to(delta.dtype).reshape(-1)
        frobenius = delta.flatten(1).norm(dim=1)
        ball = torch.where(frobenius > eps, eps / frobenius.clamp_min(1e-12),
                           torch.ones_like(frobenius))
        binding = binding & (scale <= ball)
        scale = torch.minimum(scale, ball)
    return delta * scale.reshape(shape), binding, norm * scale


def _feasible(delta: torch.Tensor, epsilon: Optional[torch.Tensor]) -> torch.Tensor:
    """``delta`` scaled into its Frobenius ball, the reference for the retained norm."""
    return delta if epsilon is None else _shrink_to_ball(delta, epsilon)


def _record(frame: SpectralFrame, before: torch.Tensor, after: torch.Tensor,
            binding: torch.Tensor):
    """Store the share of windows where the operator-norm bound is active, and the norm kept."""
    retained = after.flatten(1).norm(dim=1) / before.flatten(1).norm(dim=1).clamp_min(1e-12)
    frame.stats["cert_active"] = binding.float().mean()
    frame.stats["cert_retained"] = torch.where(before.flatten(1).norm(dim=1) > 0, retained,
                                               torch.ones_like(retained)).mean()


def certify_complement(delta: torch.Tensor, frame: SpectralFrame, gamma: float,
                       epsilon: Optional[torch.Tensor] = None,
                       radial: bool = False) -> torch.Tensor:
    """Project complement perturbations onto ``||D||_2 <= gamma * gap`` (Proposition 1).

    With ``radial``, shrink each perturbation as a whole instead (earlier versions).
    """
    if radial:
        certified, active, _ = shrink_spectral_ball(delta, gamma * frame.gap.to(delta.dtype),
                                                    epsilon)
    else:
        certified, active, _ = project_spectral_ball(delta, gamma * frame.gap, epsilon)
    _record(frame, _feasible(delta, epsilon), certified, active)
    return certified


def certify_collapse(delta: torch.Tensor, original: torch.Tensor, frame: SpectralFrame,
                     gamma: float, center: bool = True, iterations: int = 4) -> torch.Tensor:
    """Scale complement perturbations to the exact collapse radius along their direction.

    With ``R`` the clean complement part of the window and ``E`` the centred
    perturbation, the top-k singular triplets are unchanged exactly when
    ``||R + E||_2 < s_k`` (THEORY.md, Proposition 7); ``||E||_2 < gap`` (Weyl) is
    only sufficient. Each perturbation keeps its direction and is scaled by the
    largest ``t <= 1`` with ``||R + t E||_2 <= s_{k+1} + gamma * gap``, which keeps
    the same margin as the Weyl certificate and is at least its radial factor
    ``gamma * gap / ||E||_2``. ``f(t) = ||R + t E||_2`` is convex, so the chord
    between a feasible and an infeasible point crosses the threshold at a feasible
    point; ``t`` comes from a chord, a few bisection steps and a final chord.
    """
    shape = (-1,) + (1,) * (delta.dim() - 1)
    dtype = frame.left.dtype
    residual = project(_matrices(original, center).to(dtype), frame)
    moved = _matrices(delta, center).to(dtype)
    below = frame.values.gather(1, frame.k[:, None].long())[:, 0].double()  # s_{k+1}
    threshold = below + gamma * frame.gap.double()
    full = spectral_norm(residual + moved).double()
    scale = torch.ones_like(threshold)
    need = full > threshold
    if need.any():
        index = need.nonzero()[:, 0]
        theta, base, step = threshold[index], residual[index], moved[index]

        def value(t):
            return spectral_norm(base + t.to(dtype).reshape(shape) * step).double()

        lo, f_lo = torch.zeros_like(theta), below[index]
        hi, f_hi = torch.ones_like(theta), full[index]

        def chord():
            return lo + (theta - f_lo) * (hi - lo) / (f_hi - f_lo).clamp_min(1e-30)

        for trial in range(iterations + 1):
            t = chord() if trial == 0 else (lo + hi) / 2
            f = value(t)
            ok = f <= theta
            lo, f_lo = torch.where(ok, t, lo), torch.where(ok, f, f_lo)
            hi, f_hi = torch.where(ok, hi, t), torch.where(ok, f_hi, f)
        scale[index] = torch.maximum(chord(), lo).clamp(0, 1)
        weyl = (gamma * frame.gap[index].double() /
                spectral_norm(step).double().clamp_min(1e-30)).clamp(max=1)
        if (weyl > 0).any():  # how much further than the Weyl radius the exact radius reaches
            frame.stats["cert_weyl_gain"] = (scale[index] / weyl)[weyl > 0].mean()
    certified = delta * scale.to(delta.dtype).reshape(shape)
    _record(frame, delta, certified, need)
    return certified


def certify_split(delta_s: torch.Tensor,
                  delta_t: torch.Tensor,
                  frame: SpectralFrame,
                  gamma: float,
                  eps_s: Optional[torch.Tensor] = None,
                  eps_t: Optional[torch.Tensor] = None,
                  radial: bool = False) -> Tuple[torch.Tensor, torch.Tensor]:
    """Project the two components so that the k-th and (k+1)-th values cannot cross.

    Enforces ``||D_S||_2 <= gamma * gap / 2`` and then
    ``||D_T||_2 <= gamma * (gap - ||D_S||_2) / 2`` with exact operator norms, which
    implies ``||D_S||_2 + 2 ||D_T||_2 < gap`` (THEORY.md, Proposition 5). With
    ``radial``, each component is shrunk as a whole instead (earlier versions).
    """
    ball = shrink_spectral_ball if radial else project_spectral_ball
    gap = frame.gap.to(delta_s.dtype)
    certified_s, active_s, top_s = ball(delta_s, gamma * gap / 2, eps_s)
    allowed_t = gamma * (gap - top_s).clamp_min(0) / 2
    certified_t, active_t, _ = ball(delta_t, allowed_t, eps_t)
    _record(frame, _feasible(delta_s, eps_s) + _feasible(delta_t, eps_t),
            certified_s + certified_t, active_s | active_t)
    return certified_s, certified_t


def _attack_split(original: torch.Tensor, loss_fn: Callable, config: AttackConfig,
                  frame: SpectralFrame) -> torch.Tensor:
    """Block PGD over complement and tangent components with separate budgets."""
    shape = (-1,) + (1,) * (original.dim() - 1)
    fraction = config.alpha / config.epsilon if config.epsilon > 0 else 0.
    eps_s = frame.epsilon.to(original.dtype).reshape(shape)
    eps_t = frame.tangent_epsilon.to(original.dtype).reshape(shape)
    noise = torch.randn_like(original)
    radius = _rand_radius_like(original)
    noise_s = project(noise, frame)
    delta_s = _l2_normalize(noise_s) * radius * eps_s
    delta_t = _l2_normalize(noise - noise_s) * radius * eps_t
    adversarial = (original + delta_s + delta_t).detach().requires_grad_(True)
    for _ in range(config.steps):
        with torch.enable_grad():
            loss = loss_fn(adversarial)
        gradient, = torch.autograd.grad(loss, adversarial)
        with torch.no_grad():
            gradient_s = project(gradient, frame)
            gradient_t = gradient - gradient_s
            delta_s = project(delta_s + eps_s * fraction * _l2_normalize(gradient_s), frame)
            delta_t = project_tangent(
                delta_t + eps_t * fraction * _l2_normalize(gradient_t), frame)
            if config.certify == "every":
                delta_s, delta_t = certify_split(delta_s, delta_t, frame, config.gamma,
                                                 eps_s, eps_t)
            else:
                delta_s = _shrink_to_ball(delta_s, eps_s)
                delta_t = _shrink_to_ball(delta_t, eps_t)
            adversarial = original + delta_s + delta_t
        adversarial.requires_grad = True
    with torch.no_grad():
        if config.certify != "every":
            delta_s, delta_t = certify_split(delta_s, delta_t, frame, config.gamma,
                                             radial=config.certify == "radial")
        return (original + delta_s + delta_t).detach()


def attack(reference: torch.Tensor,
           loss_fn: Callable[[torch.Tensor], torch.Tensor],
           config: AttackConfig,
           frame: Optional[SpectralFrame] = None) -> torch.Tensor:
    """Maximise ``loss_fn`` over perturbations of the reference windows.

    For ``mode="none"`` this is the previous project's PGD, with identical random
    calls, update and projection order. The spectral modes start from a random
    point of the allowed set and keep every iterate in it.

    Args:
        reference: ``(B, N, T)`` clean reference windows.
        loss_fn: Maps a reference batch to the scalar loss to maximise.
        config: Attack settings.
        frame: Precomputed :py:func:`spectral_frame` of ``reference``.

    Returns:
        The detached adversarial reference windows.
    """
    original = reference.detach()
    if config.norm == "linf":
        return _attack_linf(original, loss_fn, config)
    if config.spectral and frame is None:
        frame = spectral_frame(original, config)
    if config.energy_match:
        # Same per-window energy as the spectral attack, no restriction of direction.
        spectral = attack(original, loss_fn,
                          dataclasses.replace(config, energy_match=False, allocation="window"),
                          frame)
        budget = _allocate((spectral - original).flatten(1).norm(dim=1), config.allocation)
        unrestricted = dataclasses.replace(config, mode="gap_budget", preserve_mean=False,
                                           certify="final", energy_match=False,
                                           allocation="window")
        matched = dataclasses.replace(frame, epsilon=budget.to(frame.epsilon.dtype))
        return _attack_l2(original, loss_fn, unrestricted, matched)
    if config.split:
        return _attack_split(original, loss_fn, config, frame)
    return _attack_l2(original, loss_fn, config,
                      frame if config.spectral else None)


@torch.no_grad()
def attack_summary(original: torch.Tensor, attacked: torch.Tensor,
                   config: AttackConfig,
                   frame: Optional[SpectralFrame]) -> Dict[str, float]:
    """Cheap per-step statistics of an attack, with one device synchronisation."""
    delta = (attacked - original).flatten(1)
    norm = delta.norm(dim=1) if config.norm == "l2" else delta.abs().amax(dim=1)
    quantiles = torch.quantile(norm.float(), torch.tensor([0.1, 0.5, 0.9], device=norm.device))
    names = ["adv_delta_norm", "adv_delta_norm_p10", "adv_delta_norm_p50", "adv_delta_norm_p90"]
    values = [norm.float().mean(), *quantiles]
    # Share of the perturbation energy, and of the clean centred signal, on the most
    # active units of the batch (uniform spread: TOP_UNIT_FRACTION).
    count = max(1, round(TOP_UNIT_FRACTION * original.shape[1]))
    top = original.float().mean(dim=(0, 2)).topk(count).indices
    energy = (attacked - original).float().square().sum(dim=(0, 2))
    signal = (original - original.mean(dim=-1, keepdim=True)).float().square().sum(dim=(0, 2))
    names += ["adv_top_unit_energy", "adv_top_unit_signal"]
    values += [energy[top].sum() / energy.sum().clamp_min(1e-30),
               signal[top].sum() / signal.sum().clamp_min(1e-30)]
    if frame is not None:
        epsilon = frame.epsilon.float()
        limited = torch.zeros((), device=epsilon.device)
        if config.gap_limited:
            limited = (config.gamma * config.gap_factor * frame.gap < config.epsilon).float().mean()
        elif config.split:
            limited = (config.gamma * frame.gap / 2 < config.epsilon).float().mean()
        tangent = project_tangent((attacked - original).to(frame.left.dtype), frame)
        complement = (attacked - original).to(frame.left.dtype) - tangent
        names += [
            "adv_eps_mean", "adv_eps_min", "adv_eps_max", "adv_gap_limited", "adv_k_mean",
            "adv_gap_mean", "adv_tangent_norm", "adv_complement_norm"
        ]
        values += [
            epsilon.mean(),
            epsilon.min(),
            epsilon.max(),
            limited,
            frame.k.float().mean(),
            frame.gap.float().mean(),
            tangent.flatten(1).norm(dim=1).float().mean(),
            complement.flatten(1).norm(dim=1).float().mean(),
        ]
        if frame.tangent_epsilon is not None:
            names.append("adv_tangent_eps_mean")
            values.append(frame.tangent_epsilon.float().mean())
        for key in ("cert_active", "cert_retained", "cert_weyl_gain"):
            if key in frame.stats:
                names.append(f"adv_{key}")
                values.append(frame.stats[key].float())
    return dict(zip(names, torch.stack(values).tolist()))


@torch.no_grad()
def spectral_diagnostics(original: torch.Tensor,
                         attacked: torch.Tensor,
                         config: AttackConfig,
                         frame: Optional[SpectralFrame] = None) -> Dict[str, float]:
    """Measure how much an attack changed the top-k singular structure.

    Uses the same centring and choice of ``k`` as the spectral modes, also for
    plain PGD, so all modes are comparable. Subspace errors are normalised
    projector distances in ``[0, 1]``.

    Returns:
        Means and maxima over windows of the relative top-k singular-value
        change (``sv_err``), the left/right top-k subspace distances, the
        relative change of the whole spectrum (``spectral_drift``) and the ratio
        of the perturbation norm to the gap (``delta_over_gap``). Collapse is
        measured by mode identity on the attacked window: ``gap_kept`` is
        ``(s_min(U_k^T X' V_k) - ||P_S(X')||_2) / gap``, the margin of the weakest
        clean dominant direction over the strongest complement direction (1 for
        the clean window, ``<= 0`` when a complement direction overtakes);
        ``collapse_fraction`` is the fraction of windows with ``gap_kept <= 0``;
        ``mode_exchange_fraction`` the fraction whose top-k left or right
        subspace turned by more than 45 degrees. ``tangent_energy_fraction`` is
        the share of the perturbation energy along the dominant structure
        (tangent space), next to the share of a random direction
        (``tangent_chance_fraction``). ``norm_cv`` is the coefficient of
        variation of the per-window perturbation norms and ``norm_gap_corr``
        their correlation with the spectral gap (NaN when all norms are equal).
    """
    u, s, v, k, gap, keep = _top_structure(original, config)
    k_high = u.shape[-1]
    u2, s2, v2 = window_svd(attacked, config.center, rank=k_high)
    mask = keep.to(s.dtype)
    count = mask.sum(-1)
    scale = s[:, :1].clamp_min(1e-12)
    sv_err = ((s2[:, :k_high] - s[:, :k_high]).abs() * mask).amax(-1) / scale[:, 0]

    def subspace(a, b):
        overlap = ((a * mask[:, None]).mT @ (b * mask[:, None])).square().sum(
            (-1, -2))
        return (1 - overlap / count.clamp_min(1)).clamp_min(0).sqrt()

    valid = count > 0
    left, right = subspace(u, u2)[valid], subspace(v, v2)[valid]
    drift = (s2 - s).norm(dim=-1) / s.norm(dim=-1).clamp_min(1e-12)
    delta = (attacked - original).flatten(1).norm(dim=1).to(s.dtype)
    ratio = (delta / gap.clamp_min(1e-12))[gap > 0]
    # How strongly the realised per-window energy follows the spectral gap.
    spread = delta.std() / delta.mean().clamp_min(1e-12) if len(delta) > 1 else delta.new_zeros(())
    norm_gap_corr = float("nan")
    if (gap > 0).sum() > 2 and spread > 1e-3:
        a, b = delta[gap > 0], gap[gap > 0].to(delta.dtype)
        a, b = a - a.mean(), b - b.mean()
        norm_gap_corr = (a * b).sum() / (a.norm() * b.norm()).clamp_min(1e-30)

    # Mode identity. Consecutive gaps of sorted singular values are never
    # negative, so a collapse is measured on the attacked window by comparing
    # the weakest clean dominant direction with the strongest direction of the
    # clean complement: inner = s_min(U_k^T X' V_k), outer = ||P_S(X')||_2.
    index = (k - 1).long()[:, None]
    attacked_c = _matrices(attacked, config.center).to(u.dtype)
    left_k, right_k = u * mask[:, None], v * mask[:, None]
    inner = torch.linalg.svdvals(left_k.mT @ attacked_c @ right_k).gather(1, index)[:, 0]
    def complement(x):
        x = x - left_k @ (left_k.mT @ x)
        return x - (x @ right_k) @ right_k.mT

    outer = spectral_norm(complement(attacked_c))
    structured = (gap > 0) & (count == k)
    kept = ((inner - outer) / gap.clamp_min(1e-12))[structured]

    # Share of the (centred) perturbation energy along the dominant structure,
    # against the share of a random direction, k (N + T' - k) / (N T').
    delta_c = attacked_c - _matrices(original, config.center).to(u.dtype)
    energy = delta_c.flatten(1).square().sum(1)
    along = (delta_c - complement(delta_c)).flatten(1).square().sum(1)
    moved = structured & (energy > 0)
    tangent_fraction = (along / energy.clamp_min(1e-30))[moved]
    neurons, time = original.shape[-2:]
    time = time - 1 if config.center else time
    chance = (k * (neurons + time - k) / (neurons * time)).to(u.dtype)[moved]

    def cos_largest_angle(a, b):
        product = (a * mask[:, None]).mT @ (b * mask[:, None])
        return torch.linalg.svdvals(product).gather(1, index)[:, 0]

    turned = ((cos_largest_angle(u, u2) < 2**-0.5) |
              (cos_largest_angle(v, v2) < 2**-0.5))[structured]

    def stats(name, values):
        if values.numel() == 0:
            return {f"{name}_mean": float("nan"), f"{name}_max": float("nan")}
        return {f"{name}_mean": values.mean(), f"{name}_max": values.max()}

    result = {}
    for name, values in (("sv_err", sv_err[valid]), ("left_subspace_err", left),
                         ("right_subspace_err", right), ("spectral_drift", drift),
                         ("delta_over_gap", ratio)):
        result.update(stats(name, values))
    result["gap_kept_min"] = kept.min() if kept.numel() else float("nan")
    result["gap_kept_mean"] = kept.mean() if kept.numel() else float("nan")
    result["collapse_fraction"] = (kept <= 0).float().mean() if kept.numel() else float("nan")
    result["mode_exchange_fraction"] = turned.float().mean() if turned.numel() else float("nan")
    result["tangent_energy_fraction"] = (tangent_fraction.mean()
                                         if tangent_fraction.numel() else float("nan"))
    result["tangent_chance_fraction"] = chance.mean() if chance.numel() else float("nan")
    result["norm_cv"] = spread
    result["norm_gap_corr"] = norm_gap_corr
    result["k_mean"] = k.float().mean()
    result["gap_mean"] = gap.mean()
    return {
        name: float(value) if isinstance(value, torch.Tensor) else value
        for name, value in result.items()
    }
