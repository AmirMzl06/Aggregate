"""Where do recording corruptions live relative to each window's dominant structure?

Usage: python analyze_corruption_geometry.py --data /path/to/C-CO12.npz [--windows 4096]

For every validation window X (neurons x 36 bins), the perturbation of each
corruption, D = X_corrupted - X, is split into the tangent space T_k of the
window's top-k singular structure (on-manifold) and its complement S_k
(off-manifold), with k chosen by the largest spectral gap as in training. The
script prints the fraction of the perturbation energy in T_k, next to the
fraction a random direction would have, k (N + T - k) / (N T).

No model is trained; this only describes the geometry of the corruptions.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from cebra.solver import spectral_gap  # noqa: E402

WINDOW = 36


def corruptions(x, rng):
    yield "poisson", rng.poisson(np.clip(x, 0, None)).astype(np.float32)
    for fraction in (0.1, 0.3):
        keep = np.ones(x.shape[1], dtype=np.float32)
        keep[rng.choice(x.shape[1], int(round(fraction * x.shape[1])), replace=False)] = 0
        yield f"dropout{int(fraction * 100)}", x * keep
    yield "gain30", x * np.exp(rng.normal(0, 0.3, x.shape[1])).astype(np.float32)
    yield "gaussian", x + rng.normal(0, 1, x.shape).astype(np.float32)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--windows", type=int, default=4096)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    x = np.load(args.data)["valid_data"].astype(np.float32)
    rng = np.random.default_rng(args.seed)
    starts = rng.choice(len(x) - WINDOW + 1, min(args.windows, len(x) - WINDOW + 1), replace=False)
    config = spectral_gap.AttackConfig(epsilon=3.0, alpha=0.6, norm="l2", mode="gap")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    def windows(series):
        stacked = np.stack([series[s:s + WINDOW].T for s in starts])
        return torch.as_tensor(stacked, device=device)

    clean = windows(x)
    frame = spectral_frame = spectral_gap.spectral_frame(clean, config)
    k = spectral_frame.k.float()
    neurons, time = clean.shape[1:]
    chance = (k * (neurons + time - k) / (neurons * time)).mean().item()
    print(f"windows={len(starts)} k_mean={k.mean():.2f} "
          f"random-direction tangent fraction={chance:.3f}")
    print(f"{'corruption':10s} {'|D|_F mean':>10s} {'tangent energy fraction':>24s}")
    for name, corrupted in corruptions(x, rng):
        delta = windows(corrupted) - clean
        delta = delta - delta.mean(-1, keepdim=True)  # the structure is defined on centred windows
        tangent = spectral_gap.project_tangent(delta, frame)
        energy = delta.flatten(1).square().sum(1).clamp_min(1e-12)
        fraction = tangent.flatten(1).square().sum(1) / energy
        print(f"{name:10s} {energy.sqrt().mean().item():10.2f} "
              f"{fraction.mean().item():12.3f} ± {fraction.std().item():.3f}")


if __name__ == "__main__":
    main()
