# Spectral-gap attacks: statements and proofs

These notes support the method section. Notation follows `cebra/solver/spectral_gap.py`.

## Setup

A reference window is `X ∈ R^{N×T}` (neurons × time bins). Let
`C = I_T − (1/T) 1 1ᵀ` be the temporal centring, and let `Xc = X C` have the thin
SVD `Xc = Σ_j s_j u_j v_jᵀ` with `s_1 ≥ s_2 ≥ … ≥ 0`. For a chosen `k`, let
`U_k = [u_1 … u_k]`, `V_k = [v_1 … v_k]`, `P_U = U_k U_kᵀ` and `P_V = V_k V_kᵀ`. The
spectral gap is `g_k = s_k − s_{k+1}`. Two complementary linear subspaces of
`R^{N×T}` are used:

```
complement (off-manifold)  S_k = { D : P_U D = 0, D P_V = 0 },     Π_S(D) = (I − P_U) D (I − P_V)
tangent    (on-manifold)   T_k = { U_k A + B V_kᵀ } = S_k^⊥,       Π_T(D) = D − Π_S(D)
```

`T_k` is the tangent space at `U_k diag(s_1..s_k) V_kᵀ` of the manifold of rank-k
matrices. `Π_S` and `Π_T` are orthogonal projectors with `Π_S + Π_T = I`.

**Lemma 1 (centring commutes).** If `s_k > 0`, then `Π_S(D) C = Π_S(D C)` and
`Π_T(D) C = Π_T(D C)` for every `D`.

*Proof.* Each `v_j` with `s_j > 0` lies in the row space of `Xc`, which is
orthogonal to `1` because `Xc 1 = 0`. Hence `P_V C = C P_V = P_V`, and
`(I − P_U) D (I − P_V) C = (I − P_U) D C (I − P_V)`. The claim for `Π_T` follows
from `Π_T = I − Π_S`. ∎

Lemma 1 lets the attack perturb the raw window `X` while the guarantees hold
for the centred window that defines the structure. Perturbations of the
constant direction (changes of per-neuron means in the window) are allowed
unless `preserve_mean` adds `1/√T` to the protected right vectors.

## Off-manifold attack (`gap`)

**Proposition 1 (exact preservation).** Let `D ∈ S_k` with `‖D‖_2 < g_k`; in
particular, any `D ∈ S_k` with `‖D‖_F ≤ γ g_k` and `0 < γ < 1`. Then the `k` largest
singular values of `(X + D) C` are `s_1, …, s_k`, and its top-k left and right
singular subspaces are `span(U_k)` and `span(V_k)`.

*Proof.* By Lemma 1, `E := D C ∈ S_k`, and `‖E‖_2 ≤ ‖D‖_2` because `‖C‖_2 = 1`.
Write `Xc = U_k Σ_k V_kᵀ + R` with `R = Π_S(Xc)` and `‖R‖_2 = s_{k+1}`. Then
`Xc + E = U_k Σ_k V_kᵀ + (R + E)`, where `R + E ∈ S_k`. In orthonormal bases
`[U_k, U_⊥]` and `[V_k, V_⊥]` this matrix is block diagonal,
`diag(Σ_k, U_⊥ᵀ (R + E) V_⊥)`. Its singular values are therefore
`{s_1, …, s_k} ∪ σ(R + E)`, and `σ_max(R + E) ≤ s_{k+1} + ‖E‖_2 < s_k`. ∎

**Proposition 2 (the gap is the collapse radius).** The bound is tight. For
every `η > 0`, the perturbation `D = (g_k + η) u_{k+1} v_{k+1}ᵀ ∈ S_k` has
`‖D‖_F = g_k + η`. It raises the (k+1)-th singular value to `s_k + η`, so the
(k+1)-th mode overtakes the k-th and the top-k structure changes.

Proposition 1 needs only the operator norm. `subspace_cert` keeps the full
Frobenius budget `ε` and shrinks the final perturbation radially wherever
`‖D‖_2 > γ g_k`, using exact operator norms. Spread-out complement perturbations
have `‖D‖_2 ≪ ‖D‖_F`, so this rarely binds.

Hence `ε_i = min(ε, γ g_k)` is, up to the factor `γ`, the largest Frobenius
radius at which no perturbation in `S_k` can change the top-k structure. This
is the precise sense of "epsilon grows until the SVD collapses". Choosing
`k = argmax_{k_min ≤ k ≤ k_max} g_k` maximises this certified radius.

## On-manifold attack (`tangent`)

**Proposition 3 (no collapse).** Let `D ∈ T_k` with `‖D‖_2 < g_k / 2`; in
particular, any `D ∈ T_k` with `‖D‖_F ≤ γ g_k / 2`. Then, for `X' = (X + D) C`:

1. every singular value moves by at most `‖D‖_2`;
2. `s_k(X') − s_{k+1}(X') ≥ g_k − 2 ‖D‖_2 > 0`, so the k-th and (k+1)-th modes do not cross;
3. the top-k left and right singular subspaces rotate by at most `‖D‖_2 / (g_k − ‖D‖_2) ≤ γ / (2 − γ)` in the `sin Θ` distance.

*Proof.* (1) is Weyl's inequality for `X' = Xc + D C`, with `‖D C‖_2 ≤ ‖D‖_2`.
Applying (1) to `s_k` and `s_{k+1}` gives (2). For (3), Wedin's `sin Θ` theorem
bounds the rotation by `‖D C‖_2 / δ`, where `δ = s_k(X') − s_{k+1}(Xc) ≥ g_k − ‖D‖_2`. ∎

**Remark.** In `T_k` the worst-case collapse radius is at most `g_k`. For
example, `D = −(g_k + η) u_k v_kᵀ` shrinks `s_k` below `s_{k+1}`. The certified
radius `g_k / 2` is therefore within a factor two of the worst case.

## Both geometries (`split`)

**Proposition 5 (joint no-collapse).** Let `D = D_S + D_T` with `D_S ∈ S_k`,
`D_T ∈ T_k` and `‖D_S‖_2 + 2 ‖D_T‖_2 < g_k`. Then, for `X' = (X + D) C`:

- `s_k(X') − s_{k+1}(X') ≥ g_k − ‖D_S‖_2 − 2 ‖D_T‖_2 > 0`;
- the top-k singular values move by at most `‖D_T‖_2`.

*Proof.* By Lemma 1, `D_S C ∈ S_k` and `D_T C ∈ T_k`, with operator norms at most
those of `D_S` and `D_T`. Since `‖D_S‖_2 < g_k`, Proposition 1 applies to
`X_1 = Xc + D_S C`: its top-k singular triplets are `(U_k, s_{1..k}, V_k)` and
`s_{k+1}(X_1) ≤ s_{k+1} + ‖D_S‖_2`, so its gap is at least `g_k − ‖D_S‖_2`.
Because `X_1` has the same top-k singular vectors, `T_k` is also the tangent
space at its dominant structure. Weyl's inequality for
`X' = X_1 + D_T C` then moves every singular value by at most `‖D_T‖_2`. ∎

`certify_split` enforces `‖D_S‖_2 ≤ γ g_k / 2` and then
`‖D_T‖_2 ≤ γ (g_k − ‖D_S‖_2) / 2`, using exact operator norms. Then
`‖D_S‖_2 + 2 ‖D_T‖_2 ≤ γ g_k + (1 − γ) ‖D_S‖_2 < g_k`. The operator norm is much
smaller than the Frobenius norm for spread-out perturbations, so the
complement part keeps its full Frobenius budget `ε` in most windows.

## Collapse diagnostic

Consecutive gaps of sorted singular values are never negative, so they cannot
reveal an exchange of modes. The diagnostic therefore tracks mode identity on
the attacked window `X'`:

```
inner = s_min(U_kᵀ X' V_k)      weakest clean dominant direction
outer = ‖Π_S(X')‖_2              strongest direction of the clean complement
gap_kept = (inner − outer) / g_k
```

`gap_kept = 1` for the clean window. It is at least `1 − γ` under the `gap`
budget (Proposition 1) and positive under the `tangent` and `split`
certificates. `gap_kept ≤ 0` means a complement direction carries more energy
than a clean dominant one, which is a collapse. The diagnostics also report the
fraction of windows whose top-k left or right subspace turned by more than
45°, i.e. whose largest principal angle exceeds 45°.

## Projected PGD

**Proposition 4 (exact projection).** Let `M ∈ {S_k, T_k}` and
`B_ε = { ‖D‖_F ≤ ε }`. The Euclidean projection onto `M ∩ B_ε` is
`Y ↦ Π_B(Π_M(Y))`, with `Π_B(Z) = Z · min(1, ε / ‖Z‖_F)`.

*Proof.* For `Z ∈ M`, Pythagoras gives `‖Y − Z‖² = ‖Y − Π_M Y‖² + ‖Π_M Y − Z‖²`.
Minimising over `Z ∈ M ∩ B_ε` therefore projects `Π_M Y ∈ M` onto `B_ε`. The
radial scaling stays in `M` and is the nearest point of `B_ε`. ∎

The attack takes normalised steps along `Π_M ∇`, with step `α_i = ε_i α / ε`,
and applies Proposition 4 after every step. Every iterate, including the
random start `Π_M(noise)`, therefore lies in `M ∩ B_{ε_i}`, and the guarantees of
Propositions 1 and 3 hold for every training perturbation, not only the last.

## Separability of the contrastive attack

With positives and negatives fixed, CEBRA's InfoNCE loss is
`L = (1/n) Σ_i ℓ_i(f(x_i))`. Here `ℓ_i` depends on the reference `x_i` only
through its own row of the similarity matrix; the row-wise stabilising shift
cancels. In eval mode (no batch-coupled layers), maximising `L` over a product
of per-window sets `Π_i (M_i ∩ B_{ε_i})` therefore decouples into independent
per-window problems. The batched attack is exactly a set of per-window attacks
solved in parallel.
