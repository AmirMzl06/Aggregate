#!/usr/bin/env python3
"""Fixed noise-aware d-prime eps=1/3 extensions for Exp15.

Imports the unchanged multi-session runner and its unchanged DprimeBridge;
patches only the fixed epsilon branch for the two new arms in this process.
No prior checkpoints, result directories, or repository files are overwritten.
"""
import run_multi_transfer as base
from multi_dprime_bridge import DprimeBridge

EXTRA = {'SPDIFF_D1': 1.0, 'SPDIFF_D3': 3.0}
if 'SPDIFF_D8' not in base.ARMS or 'SPDIFF_D8' not in base.DPRIME_ARMS:
    raise RuntimeError('Expected existing noise-aware D8 arm is missing')

_original_fit = DprimeBridge.fit

def fixed_fit(self, key, x, y, arm, mode, standardized=False):
    if arm not in EXTRA:
        return _original_fit(self, key, x, y, arm, mode, standardized)
    # Fit precisely the same difference-residual noise geometry as SPDIFF_D8.
    ctx = _original_fit(self, key, x, y, 'SPDIFF_D8', mode, standardized)
    assert self.contexts[key] is ctx
    eps = EXTRA[arm]
    # The PGD attack uses ctx['budget_dprime'], NOT train_kwargs.adv_eps.
    ctx['arm'] = arm
    ctx['budget_dprime'] = eps
    ctx['calibration'] = {
        'formula': 'fixed epsilon in noise-whitened coordinates',
        'fixed_eps': eps,
        'geometry_reference': 'SPDIFF_D8',
    }
    return ctx

DprimeBridge.fit = fixed_fit
base.ARMS = base.ARMS + tuple(EXTRA)
base.DPRIME_ARMS = base.DPRIME_ARMS.union(EXTRA)

if __name__ == '__main__':
    base.main()
