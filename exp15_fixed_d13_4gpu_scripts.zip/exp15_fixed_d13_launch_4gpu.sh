#!/usr/bin/env bash
set -euo pipefail

ROOT=/home/mirzaei/sam/result/Aggregate
PROJECT="$ROOT/Acorn-multi/acorn-main"
PY=/home/mirzaei/lm-cebra/.venv/bin/python
DATA=/data/hossein/mm_project/perich_data_valid_final_raw
FORK="$ROOT/Acorn-dprime"
DEST=/data/hossein/mm_project/exp15_fixed_d13_4gpu
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"

[[ -x "$PY" ]] || { echo "Python venv not found: $PY"; exit 2; }
[[ -f "$PROJECT/run_multi_transfer_fixed_d13.py" ]] || { echo 'Fixed-D13 wrapper missing'; exit 2; }
[[ -f "$PROJECT/run_multi_transfer.py" && -f "$PROJECT/multi_dprime_bridge.py" ]] || { echo 'Original scripts missing'; exit 2; }
[[ -f "$FORK/cebra/dprime/noise.py" && -f "$FORK/cebra/dprime/calibration.py" ]] || { echo 'Noise fork missing'; exit 2; }
[[ -f "$DATA/C-CO0.npz" && -f "$DATA/C-CO52.npz" ]] || { echo 'Dataset files missing'; exit 2; }
if [[ $(nvidia-smi --list-gpus | grep -c '^GPU ') -lt 4 ]]; then echo 'Need 4 visible GPUs'; exit 2; fi
cd "$PROJECT"
mkdir -p "$DEST"
echo '===== FIXED NOISE-AWARE EPS 1/3 (RAW + ZSCORE) ====='
echo '4 GPUs | 2 seeds | 52 targets | 416 target runs + 8 source runs'
echo "DEST=$DEST"

run_one() {
  local gpu="$1" arm="$2" seed="$3" preprocessing out
  local -a args
  for preprocessing in raw zscore; do
    out="$DEST/$preprocessing/$arm/seed$seed"
    mkdir -p "$out"
    args=(--data-dir "$DATA" --fork-dir "$FORK" --out "$out"
          --source C-CO0 --mode supervised --arms "$arm" --seeds "$seed"
          --source-steps 3000 --adapter-steps 1000 --decoder-steps 2500
          --batch-size 512 --attack-steps 10 --device auto --resume)
    if [[ "$preprocessing" == zscore ]]; then args+=(--standardize); fi
    echo "START gpu=$gpu prep=$preprocessing arm=$arm seed=$seed"
    CUDA_VISIBLE_DEVICES="$gpu" "$PY" -B -u "$PROJECT/run_multi_transfer_fixed_d13.py" "${args[@]}" 2>&1 \
      | tee -a "$out/worker.log" \
      | awk -v p="[GPU $gpu $preprocessing $arm seed=$seed] " \
          '/^(SUCCESS:|TRAINED source:|RESUMED source:|COMPLETE:|Traceback)/ || /Error:/ {print p $0; fflush()}'
    echo "FINISHED gpu=$gpu prep=$preprocessing arm=$arm seed=$seed"
  done
}

run_one 0 SPDIFF_D1 42 & p0=$!
run_one 1 SPDIFF_D1 43 & p1=$!
run_one 2 SPDIFF_D3 42 & p2=$!
run_one 3 SPDIFF_D3 43 & p3=$!

failed=0
for pid in "$p0" "$p1" "$p2" "$p3"; do
  wait "$pid" || failed=1
done
if [[ "$failed" -ne 0 ]]; then
  echo 'Some workers failed; successful records are preserved. Resubmit same job command to resume.'
  exit 1
fi

"$PY" -B - "$DEST" <<'PY'
import csv, json, math, sys
from pathlib import Path
root = Path(sys.argv[1])
rows = []
expected = set()
for prep in ('raw', 'zscore'):
    for arm in ('SPDIFF_D1', 'SPDIFF_D3'):
        eps = 1.0 if arm == 'SPDIFF_D1' else 3.0
        for seed in (42, 43):
            folder = root / prep / arm / f'seed{seed}'
            manifest = json.loads((folder / 'manifest.json').read_text())
            assert manifest['standardize'] == (prep == 'zscore'), (prep, arm, seed)
            assert manifest['selected_source'] == 'C-CO0'
            assert set(manifest['selected_targets']) == {f'C-CO{i}' for i in range(1,53)}
            latest = {}
            for line in (folder / 'records.jsonl').read_text().splitlines():
                try: rec = json.loads(line)
                except ValueError: continue
                if rec.get('status') == 'success':
                    latest[(rec['arm'],rec['seed'],rec['session'])] = rec
            for session in (['C-CO0'] + [f'C-CO{i}' for i in range(1,53)]):
                expected.add((prep, arm, seed, session))
            for rec in latest.values():
                assert rec['arm'] == arm and rec['seed'] == seed
                assert math.isfinite(float(rec['r2_holdout']))
                assert abs(float(rec['train_dprime_epsilon']) - eps) < 1e-6, rec
                rows.append({'preprocessing':prep, **rec})
actual = {(r['preprocessing'], r['arm'], r['seed'], r['session']) for r in rows}
missing = expected - actual
assert len(rows) == len(actual) == len(expected) == 424, (len(rows), len(actual), len(expected))
assert not missing, missing
fields = ['preprocessing','arm','seed','session','phase','status',
          'r2_train','r2_holdout','n_neurons','n_train','n_test',
          'train_dprime_epsilon','error']
output = root / 'summary_ALL_fixed_d13.csv'
with output.open('w',newline='') as f:
    writer = csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
    writer.writeheader()
    writer.writerows(sorted(rows,key=lambda r:(r['preprocessing'],r['arm'],r['seed'],int(r['session'].split('CO')[-1]))))
for prep in ('raw', 'zscore'):
    for arm in ('SPDIFF_D1', 'SPDIFF_D3'):
        group = [r for r in rows if r['preprocessing']==prep and r['arm']==arm and r['session']!='C-CO0']
        mean = sum(float(r['r2_holdout']) for r in group)/len(group)
        print(f'{prep:7s} {arm:10s}: {len(group)}/104 TARGETS, mean R2={mean:.5f}',flush=True)
print('VERIFIED: 416/416 TARGETS + 8/8 SOURCES = 424/424 SUCCESS',flush=True)
print('CONSOLIDATED CSV:',output,flush=True)
PY
