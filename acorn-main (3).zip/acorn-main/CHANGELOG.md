# Changelog

All notable changes to Acorn are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Optional language-model rescoring after a sequence export (`acorn.lm`,
  `rescore_export`, `export_all_sessions(..., use_lm=True)`). Docker sidecars;
  no host `[lm]` extra. Guide: [Language-model rescoring](docs/language_model.md).

- `device` policy string (`auto|cpu|cuda`) on both configs; resolved in runners.
- `list_datasets()` is the sorted union of time-bin and sequence keys.
- Sequence-format (B2T) recipe `offset36_ctc`: joint CTC + InfoNCE on unaligned
  transcripts, Dryad download with size warning, four datasets (`nlp21`,
  `nlp10`, `speech24`, `speech45`), greedy CER, and an LM-adapter export
  (`acorn.ctc_export.v1.1`).
- `SequenceTrainConfig` (including `recipe`, default `offset36_ctc`) +
  `acorn.train_model(cfg)` dispatch on config class. The two family runners
  never import each other. In-training CER via `periodic_eval_every=50` (not
  the single-dataset trainer.py 150) to match 4-session
  `multi_trainer_task_based.py`.
- Getting-started guide (`docs/getting_started.md`) and NLP21 notebooks
  (`examples/notebooks/demo_nlp21.ipynb`, `examples/notebooks/demo_nlp21_lm.ipynb`).
- `docs/adding_a_b2t_dataset.md`.
- Durable `history.jsonl` training curves (one row per encoder step and decoder
  epoch) and per-dataset decoder checkpoints (`decoder_<dataset>_best.pt`);
  encoder best-checkpoint moved from `/tmp` into the run directory as
  `encoder_best.pt`.
- Vendored Python-only XDS (`xds/xds_python/`) in git; no nested clone, no MATLAB.
- Apache-2.0 `cebra/LICENSE.md` + `NOTICE`, XDS license status, and [THIRD_PARTY.md](THIRD_PARTY.md).
- Declare `h5py` (XDS `.mat` v7.3 loader).
- Declare `py7zr` (dataset Drive archives are 7z).

### Changed

- Data root defaults to `./data` under the current working directory
  (`ACORN_DATA_DIR` still overrides).
- Family boundary is **label format** (`time_bin_aligned` vs `sequence`), not
  task type. `list_recipes()` reports both.
- `DatasetSpec.n_neurons` renamed to advisory `expected_n_neurons`; runners
  infer channel count from loaded data (same 96 for the four time-bin datasets).
- Optional `task_key` on `MultiSessionModel.add_session` (defaults to
  `session_key`).
- `AdvDecEncoderTrainer` is the encoder trainer bundled with
  `offset36_gru_advdec`.
- Public specs (`TrainConfig`, `AdvConfig`, `DatasetSpec`, `RecipeSpec`) are Pydantic models.
- CI installs into a uv virtualenv instead of `--system` (no distro Python 3.11 on GitHub runners).
- Vendored CEBRA uses `packaging.version` instead of `pkg_resources` (missing in modern setuptools/uv envs).
- Declare `joblib` (hard import in vendored CEBRA I/O) and guard optional `cebra.integrations.sklearn`.

### Removed

- Training CLI. 0.1.0 shipped a demo CLI; training is Python-only
  (`TrainConfig` / `SequenceTrainConfig` / `train_model`).
- Lab comparison note from `docs/`.
- Cluster-specific launcher scripts.
- Optional MLflow tracking extra. Run outputs (`metrics.json` + `history.jsonl`)
  are the system of record.
- `acorn.utils.xds_path.ensure_xds_on_path`. `import xds` is the vendored
  package (`xds/__init__.py`); `import acorn` still puts the repo root on
  `sys.path` for CEBRA.

## [0.1.0] — 2026-08-21

### Added

- Initial public snapshot of **Acorn**: multi-session CEBRA encoder + per-session GRU decoder.
- Recipe registry with two sibling variants:
  - `offset36_gru` (default)
  - `offset36_gru_advdec` (adversarial decoder + Adam/LinearLR trainer)
- Dataset registry (`jango`, `mihili_co`, `mihili_rt`, `pop`)
- Demo CLI and Python API (`TrainConfig`, `train_model`)
- Optional MLflow tracking extra, ruff/mypy/pytest CI, and CPU unit tests

[0.1.0]: #010
