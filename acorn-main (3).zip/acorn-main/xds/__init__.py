"""Acorn import shim for the vendored XDS Python loader.

Upstream code lives in ``xds_python/`` and uses top-level imports
(``xds_utils``, ``load_intan_rhd_format``). This package exists so
``from xds import lab_data`` resolves here instead of a PEP 420 namespace
over the license/NOTICE wrapper directory.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

_XDS_PYTHON = Path(__file__).resolve().parent / "xds_python"
_XDS_PY = _XDS_PYTHON / "xds.py"
_python_path = str(_XDS_PYTHON)
if _python_path not in sys.path:
    sys.path.insert(0, _python_path)

_spec = importlib.util.spec_from_file_location("_acorn_xds_impl", _XDS_PY)
if _spec is None or _spec.loader is None:
    raise ImportError(f"vendored XDS implementation missing: {_XDS_PY}")
_impl = importlib.util.module_from_spec(_spec)
sys.modules.setdefault("_acorn_xds_impl", _impl)
_spec.loader.exec_module(_impl)

lab_data = _impl.lab_data

__all__ = ["lab_data"]
