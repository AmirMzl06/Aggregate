# Vendored XDS (Python)

Python loader for `.mat` files stored as XDS / CDS lab recordings.

This directory is a Python-only snapshot of [limblab/xds](https://github.com/limblab/xds)
(via [alijabbari00/xds](https://github.com/alijabbari00/xds)). MATLAB sources are
omitted. Upstream code is under `xds_python/`. `__init__.py` is an Acorn shim so
`from xds import lab_data` imports this package rather than a namespace over
LICENSE/NOTICE.

```
xds/
  __init__.py     Acorn import shim (`lab_data`)
  NOTICE          origin, modifications, license status
  LICENSE.md      this tree is not under Acorn MIT
  README.md       this file
  xds_python/     upstream Python package (no MATLAB)
```

See [NOTICE](NOTICE) and [LICENSE.md](LICENSE.md) for origin and license status.
Upstream Python API notes: [`xds_python/readme.md`](xds_python/readme.md).
