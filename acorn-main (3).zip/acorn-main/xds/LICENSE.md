# License status — vendored XDS

The original project is [limblab/xds](https://github.com/limblab/xds)
("xds (cross-platform data structure), as a wrap for `cds` to be used in Python").

**That repository does not publish a license file.** Unlicensed source is not
public domain. This directory is therefore **not** licensed under the MIT
`LICENSE` at the Acorn repository root.

Acorn includes this Python-only snapshot of the XDS Python loader. MATLAB
sources are not included.

See [NOTICE](NOTICE) for origin URLs, omitted files, and Acorn-specific
modifications.

If you need a redistributable license for this tree (for example a public
PyPI release), obtain written permission from the original authors and record
it here.
