# Acorn

Brain-computer interfaces decode movement or language from neural activity.
Day-to-day shift in those recordings forces recalibration. ACORN learns
session-invariant embeddings with an adversarial contrastive objective, so a
decoder can run zero-shot on unseen sessions: language error down, motor R² up.

This repository is private until it is made public. Clone it with GitHub
access.

1. [See a result now](/examples/notebooks/demo_nlp21_lm.ipynb) — saved NLP21
   language-model scores; seconds; no GPU.
2. [Understand why ACORN exists](docs/learn/why-acorn.md) — BCI basics, session
   drift, and what the model does.
3. [Train from Python](docs/start/index.md) — pick a demo, then a full GPU run.

Install, then `pytest -q` (no datasets, no GPU):

```bash
uv pip install -e ".[dev]"
```

Walkthroughs: [Get started](docs/start/index.md). Demo index:
[Demos](docs/demos/index.md).

## Training from Python

Each `train_model` call starts a **full** training run (hours on a GPU; it
downloads data), not a quick sample. These snippets use library defaults
(`recipe="offset36_gru"` for Jango; `recipe="offset36_ctc"` for nlp21).
Macaque motor with recipe `offset36_gru_advdec` is
[`examples/offset36_gru_advdec.py`](examples/offset36_gru_advdec.py).

```python
from acorn import TrainConfig, train_model

cfg = TrainConfig(dataset_keys=["jango"])
result = train_model(cfg)
```

```python
from acorn import SequenceTrainConfig, train_model

seq = SequenceTrainConfig(dataset_keys=["nlp21"])
result = train_model(seq)
```

API walkthrough: [Train from the Python API](docs/getting_started.md). After a sequence
run, optional language-model rescoring:
[Language-model rescoring](docs/language_model.md).
Training scripts: [Examples catalog](examples/README.md).

## Extending

- Time-bin dataset: [Adding a dataset](docs/adding_a_dataset.md)
- B2T / sequence dataset: [Adding a B2T dataset](docs/adding_a_b2t_dataset.md)
- Recipe: [Adding a recipe](docs/adding_a_recipe.md)
- Where data comes from: [Datasets](docs/data.md)

## Vendored dependencies

CEBRA and XDS are third-party trees in this repository (not PyPI deps).
`import acorn` puts the repo root on `sys.path` via `acorn.utils.vendor_path`
so `import cebra` and `from xds import lab_data` resolve here.
Inventory, licenses, and modifications: [THIRD_PARTY.md](THIRD_PARTY.md).

The MIT `LICENSE` at the repo root covers **only** first-party Acorn code.
`cebra/` and `xds/` keep their own terms.
