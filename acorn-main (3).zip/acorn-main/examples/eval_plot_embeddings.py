"""Plot-ready embedding payload from a TrainResult (no core disk writes).

Does not train. After ``train_model``, call
``plot_payload(result, x_by_key, y_by_key)`` with a ``TrainResult``.

# HYPERS source=embeddings_plot.py
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import help_parser
from examples.eval_embeddings import embeddings_from_result


def plot_payload(result: TrainResult, x_by_key: dict, y_by_key: dict) -> dict:
    embs = embeddings_from_result(result, x_by_key)
    return {"embeddings": embs, "labels": y_by_key}


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
