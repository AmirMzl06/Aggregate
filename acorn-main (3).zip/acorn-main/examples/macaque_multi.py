"""Macaque multi-session (jango, mihili_co, mihili_rt, pop).

# HYPERS recipe=offset36_gru_advdec source=monkey_gru mgd14
# all four train keys, n_batch 30000, window 256, batch 1024, Adam 0.02, style=bin eps=0.5
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import MACAQUE_KEYS, maybe_save, output_dir_parser

RECIPE = "offset36_gru_advdec"


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=MACAQUE_KEYS,
        recipe=RECIPE,
        enc_lr=0.02,
        batch_size=1024,
        n_batch=30000,
        window=256,
        adv=AdvConfig(enabled=True, eps=0.5, style="bin"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
