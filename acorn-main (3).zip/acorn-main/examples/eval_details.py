"""Per-session details from a Perich TrainResult.

Does not train. After ``train_model``, call ``session_details(result)`` with a
``TrainResult``.

# HYPERS source=save_details.py
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import help_parser


def session_details(result: TrainResult) -> dict:
    return dict(result.metrics.get("per_dataset") or {})


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
