"""Score a trained encoder under Gaussian noise.

Does not train. After ``train_model``, call
``score_result_noise(result, x_by_key, y_by_key, grid)`` with a ``TrainResult``.
Use ``PERICH_NOISE_GRID`` or ``HIPPO_NOISE_GRID`` from ``examples._common``.

# HYPERS source=single_under_noise.py / single_under_noise_hippo.py
# Perich grid 0.0–1.0 step 0.1 plus 0.75; Hippo 0.0–0.5 step 0.05
"""

from __future__ import annotations

from acorn import TrainResult
from acorn.eval.noise import score_under_gaussian_noise
from examples._common import help_parser


def score_result_noise(
    result: TrainResult, x_by_key: dict, y_by_key: dict, stds, *, n_repeats: int = 1
) -> dict:
    """Score each session under iid Gaussian noise."""
    decoder0 = next(iter(result.decoders.values()))
    device = next(decoder0.parameters()).device
    out = {}
    for key, decoder in result.decoders.items():
        out[key] = {}
        for std in stds:
            scores = [
                score_under_gaussian_noise(
                    result.model,
                    decoder,
                    x_by_key[key],
                    y_by_key[key],
                    std,
                    session_key=key,
                    device=device,
                    seed=i * int(std * 10 + 0.1),
                )
                for i in range(n_repeats)
            ]
            out[key][std] = float(sum(scores) / max(len(scores), 1))
    return out


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.add_argument("--grid", choices=("perich", "hippo"), default="perich")
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
