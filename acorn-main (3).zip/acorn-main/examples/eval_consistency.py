"""Session consistency on per-session embedding lists (never vstack).

Does not train. Score with ``consistency_from_result(embeddings, labels, points=3000)``
from a ``TrainResult`` (Hippo uses ``y[:, 0]``). ``consistency_from_pickles`` only
loads POYOP/S5/LFADS overlay pickles; it does not score.

# HYPERS source=consistency_calculator.py --points 3000
"""

from __future__ import annotations

import pickle
from pathlib import Path

from acorn import TrainResult
from acorn.eval.consistency import session_consistency_score
from examples._common import help_parser

__all__ = ["TrainResult", "consistency_from_pickles", "consistency_from_result"]


def consistency_from_result(embeddings: list, labels: list, *, points: int = 3000, ids=None):
    label0 = [lab[:, 0] if hasattr(lab, "ndim") and lab.ndim > 1 else lab for lab in labels]
    return session_consistency_score(embeddings, label0, dataset_ids=ids, points=points)


def consistency_from_pickles(paths: dict[str, str], *, points: int = 3000):
    """Overlay precomputed embeddings (POYOP / S5 / LFADS pickles)."""
    loaded = {name: pickle.loads(Path(path).read_bytes()) for name, path in paths.items()}
    return loaded, points


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.add_argument("--points", type=int, default=3000)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
