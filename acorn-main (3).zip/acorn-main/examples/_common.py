"""Shared example key lists and optional ``--output-dir`` / ``--seed`` handling."""

from __future__ import annotations

import argparse

from acorn.data.groups.hippo import HIPPO_SPECS
from acorn.data.groups.perich import PERICH_SPECS

PERICH_KEYS = list(PERICH_SPECS)
HIPPO_KEYS = list(HIPPO_SPECS)
MACAQUE_KEYS = ["jango", "mihili_co", "mihili_rt", "pop"]
SEQUENCE_KEYS = ["speech24", "nlp10", "nlp21", "speech45"]
SEQUENCE_PAPER_NAMES = {
    "speech24": "Speech24",
    "nlp10": "NLP10",
    "nlp21": "NLP21",
    "speech45": "Speech45",
}

PERICH_NOISE_GRID = [i / 10 for i in range(11)] + [0.75]
HIPPO_NOISE_GRID = [i / 20 for i in range(11)]


def _user_facing_description(description: str) -> str:
    """Argparse text: first paragraph(s), not the ``# HYPERS`` comment block."""
    text = description or ""
    marker = "# HYPERS"
    if marker in text:
        text = text.split(marker, 1)[0]
    return text.strip()


def help_parser(description: str) -> argparse.ArgumentParser:
    """Bare parser for eval helpers (no ``--output-dir``)."""
    return argparse.ArgumentParser(description=_user_facing_description(description))


def output_dir_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--output-dir",
        default=None,
        help="If set, save the TrainResult via examples/save_run.py.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="RNG seed passed into TrainConfig / SequenceTrainConfig (TrainConfig.seed default is 42).",
    )
    return parser


def maybe_save(result, output_dir) -> None:
    if output_dir:
        from examples.save_run import save_run

        save_run(result, output_dir)


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
