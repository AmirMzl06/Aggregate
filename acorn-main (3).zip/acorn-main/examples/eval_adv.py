"""Score a trained encoder under a 10-step L2 attack.

Does not train. After ``train_model``, call
``score_result_adv(result, x_by_key, y_by_key, epsilon=0.5)`` with a ``TrainResult``.

# HYPERS source=multi_under_adv.py 10-step
"""

from __future__ import annotations

from acorn import TrainResult
from acorn.eval.adv import l2_attack_eval
from examples._common import help_parser


def score_result_adv(
    result: TrainResult, x_by_key: dict, y_by_key: dict, epsilon: float = 0.5
) -> dict:
    decoder0 = next(iter(result.decoders.values()))
    device = next(decoder0.parameters()).device
    out = {}
    for key, decoder in result.decoders.items():
        x = x_by_key[key].to(device)
        y = y_by_key[key].to(device)
        x_adv = l2_attack_eval(x, y, result.model, decoder, key, epsilon=epsilon, device=device)
        emb = result.model.transform(x_adv, key)
        out[key] = float(decoder.score(emb, y, device))
    return out


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
