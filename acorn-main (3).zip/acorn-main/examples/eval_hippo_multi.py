"""Hippo multi eval wrapping noise + 10-step adv attacks.

Does not train. After ``train_model``, call
``eval_hippo_multi(result, x_by_key, y_by_key)`` with a ``TrainResult``.

# HYPERS source=multi_hippo_script.py
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import HIPPO_NOISE_GRID, help_parser
from examples.eval_adv import score_result_adv
from examples.eval_noise import score_result_noise


def eval_hippo_multi(result: TrainResult, x_by_key, y_by_key) -> dict:
    return {
        "noise": score_result_noise(result, x_by_key, y_by_key, HIPPO_NOISE_GRID),
        "adv": score_result_adv(result, x_by_key, y_by_key, epsilon=0.5),
    }


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
