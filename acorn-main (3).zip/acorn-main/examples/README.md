# Examples

Jupyter demos live in [`notebooks/`](notebooks/). Start there if you
want a walkthrough rather than a script. Indexed table:
[Demos](../docs/demos/index.md).

Run a training command with `python examples/<file>.py`. There is
no `examples/run.py` selector.

Library `TrainConfig` defaults stay `offset36_gru` / AdamW `3e-5` /
`batch_size=256` / `window=256`. Values in these files are overlays, not
library defaults.

Four training recipes appear here: `offset36_gru` (Perich/Hippo Offset36_multi),
`offset36_gru_advdec` (macaque motor), `offset36_cebra` (sklearn `CEBRA.fit`
singles), and `offset36_ctc` (sequence). One dataset versus all four Dryad
corpora uses the same `offset36_ctc` recipe; Multi is NLP10, NLP21, Speech24,
and Speech45 together.

Eval modules (`eval_*.py`) are helpers: import and call them with a
`TrainResult`, or pass `--help` (`python examples/eval_perich.py --help`).
Running `python examples/eval_*.py` does not train.

Training scripts accept optional `--output-dir`, which writes via
[`save_run.py`](save_run.py).

Family/recipe catalog (same tables): [Scripts](../docs/demos/scripts.md).

## Reaching (Perich)

| Script | Recipe |
| --- | --- |
| `perich_cebra_adv.py` | `offset36_cebra` |
| `perich_cebra_adv_nozscore.py` | `offset36_cebra` |
| `perich_cebra_time_adv.py` | `offset36_cebra` |
| `perich_cebra.py` | `offset36_cebra` |
| `perich_cebra_time.py` | `offset36_cebra` |
| `perich_multi_oneshot.py` | `offset36_gru` |
| `perich_multi.py` | `offset36_gru` |
| `perich_multi_nozscore.py` | `offset36_gru` |
| `perich_multi_time.py` | `offset36_gru` |
| `perich_supervised.py` | `offset36_gru` |

`perich_multi.py` uses `style="cluster_pgd"` on the adversarial config.

## Hippocampus

| Script | Recipe |
| --- | --- |
| `hippo_multi.py` | `offset36_gru` |
| `hippo_multi_time.py` | `offset36_gru` |
| `hippo_multi_nozscore.py` | `offset36_gru` |
| `hippo_multi_time_nozscore.py` | `offset36_gru` |
| `hippo_all.py` | `offset36_gru` |
| `hippo_all_time.py` | `offset36_gru` |
| `hippo_cebra.py` | `offset36_cebra` |
| `hippo_cebra_adv.py` | `offset36_cebra` |
| `hippo_cebra_adv_nozscore.py` | `offset36_cebra` |
| `hippo_cebra_adv_time.py` | `offset36_cebra` |
| `hippo_cebra_time_mlp.py` | `offset36_cebra` |
| `hippo_embedding.py` | `offset36_cebra` |

## Macaque

Paper names: IW-J, CO-M, RT-M, PG-P. Keys: `jango`, `mihili_co`,
`mihili_rt`, `pop`.

| Script | Recipe |
| --- | --- |
| `demo_time_bin.py` | `offset36_gru` |
| `offset36_gru_advdec.py` | `offset36_gru_advdec` |
| `macaque_n1_jango.py` | `offset36_gru_advdec` |
| `macaque_n1_mihili_co.py` | `offset36_gru_advdec` |
| `macaque_n1_mihili_rt.py` | `offset36_gru_advdec` |
| `macaque_n1_pop.py` | `offset36_gru_advdec` |
| `macaque_multi.py` | `offset36_gru_advdec` |

## Brain-to-text

| Script | Recipe |
| --- | --- |
| `sequence_nlp10.py` | `offset36_ctc` |
| `sequence_nlp21.py` | `offset36_ctc` |
| `sequence_speech24.py` | `offset36_ctc` |
| `sequence_speech45.py` | `offset36_ctc` |
| `sequence_nlp10_baseline.py` | `offset36_ctc` |
| `sequence_nlp21_baseline.py` | `offset36_ctc` |
| `sequence_speech24_baseline.py` | `offset36_ctc` |
| `sequence_speech45_baseline.py` | `offset36_ctc` |
| `sequence_multi.py` | `offset36_ctc` |
| `sequence_multi_baseline.py` | `offset36_ctc` |

## Eval helpers

| Script | Recipe |
| --- | --- |
| `eval_hippo.py` | helper |
| `eval_perich.py` | helper |
| `eval_perich_multi.py` | helper |
| `eval_hippo_multi.py` | helper |
| `eval_details.py` | helper |
| `eval_details_hippo.py` | helper |
| `eval_embeddings_hippo_multi.py` | helper |
| `eval_consistency.py` | helper |
| `eval_plot_embeddings.py` | helper |
| `eval_sequence.py` | helper |
| `eval_sequence_lm.py` | helper |
| `eval_noise.py` | helper |
| `eval_adv.py` | helper |
| `eval_embeddings.py` | helper |

`fair.py` is data prep (not listed here).
