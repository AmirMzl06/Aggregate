"""Hippo-all: train=valid from raw full_* then independent std+1e-3.

# HYPERS recipe=offset36_gru source=macorn_perich_old_hippo_all.py (multi_runai_final_hippo_all.py)
# int(1.0*T), train=valid=full, 20000, 64/64/1, cluster_pgd, decoder_adv=pgd
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import HIPPO_KEYS, maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=HIPPO_KEYS,
        recipe="offset36_gru",
        enc_lr=1e-4,
        batch_size=2048,
        n_batch=20000,
        n_decoder_batches=2500,
        ceb_hidden=64,
        ceb_out=64,
        offset=1,
        time_offset=1,
        window=512,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional="time_delta",
        decoder_adv="pgd",
        full_session=True,
        adv=AdvConfig(enabled=True, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
