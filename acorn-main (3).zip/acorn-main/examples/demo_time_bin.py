"""Time-bin train on Jango using library defaults.

The Drive corpus is several GB; this script does not skip the y/N prompt.
Non-interactive: ACORN_DOWNLOAD_YES=1.

Pass ``--output-dir PATH`` to write run artifacts via ``examples/save_run.py``.
"""

from __future__ import annotations

import argparse

from acorn import TrainConfig, train_model
from acorn.data.download import DownloadDeclined, DryadDownloadError
from examples.save_run import save_run


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default=None,
        help="If set, save the TrainResult under this directory.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="RNG seed passed into TrainConfig / SequenceTrainConfig (TrainConfig.seed default is 42).",
    )
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=["jango"],
        device="auto",
        seed=args.seed,
    )
    try:
        result = train_model(cfg)
    except (DownloadDeclined, DryadDownloadError) as exc:
        print(exc)
        raise SystemExit(1) from None
    if args.output_dir:
        save_run(result, args.output_dir)


if __name__ == "__main__":
    main()
