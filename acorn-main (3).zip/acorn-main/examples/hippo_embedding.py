"""Hippo embeddings from sklearn CEBRA.fit (notes hippo_embedding.py).

# HYPERS recipe=offset36_cebra source=hippo_train.py / notes hippo_embedding.py
# runai_hippo_single_emb.py is missing in cluster; this freezes the notes row.
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=["hippo_achilles"],
        recipe="offset36_cebra",
        enc_lr=3e-4,
        batch_size=2048,
        n_batch=5000,
        ceb_hidden=64,
        ceb_out=64,
        offset=1,
        time_offset=1,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional="time_delta",
        mlp_decoder=True,
        zscore=False,
        adv=AdvConfig(enabled=False, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)
    return result


if __name__ == "__main__":
    main()
