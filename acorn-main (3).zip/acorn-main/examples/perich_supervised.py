"""Perich supervised Offset36_multi (not in the notes file).

# HYPERS recipe=offset36_gru source=macorn_cluster supervised overlay
# hidden 256, cluster_pgd if adv, decoder_adv=off
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import PERICH_KEYS, maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=PERICH_KEYS,
        recipe="offset36_gru",
        enc_lr=1e-4,
        batch_size=2048,
        n_batch=40000,
        n_decoder_batches=2500,
        ceb_hidden=256,
        ceb_out=64,
        offset=4,
        time_offset=4,
        window=512,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional="time_delta",
        decoder_adv="off",
        adv=AdvConfig(enabled=True, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
