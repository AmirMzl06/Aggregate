"""Greedy CER from a sequence TrainResult.

Does not train. After ``train_model``, call ``evaluate(result)`` with a
``TrainResult``. Returns ``per_dataset`` and ``cer_mean`` from
``result.metrics``.

# HYPERS source=evaluate_sequence_sessions
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import help_parser


def evaluate(result: TrainResult) -> dict:
    """Greedy CER already stored on ``result.metrics``."""
    metrics = result.metrics or {}
    return {
        "per_dataset": dict(metrics.get("per_dataset") or {}),
        "cer_mean": metrics.get("cer_mean"),
    }


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
