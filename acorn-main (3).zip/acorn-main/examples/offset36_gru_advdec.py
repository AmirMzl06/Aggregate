"""Run the offset36_gru_advdec recipe through the Python interface.

This is the intended path for composing a full recipe in code: pick the
registered name, set the matching hyperparameters, call ``train_model``.

# HYPERS recipe=offset36_gru_advdec source=monkey_gru mgd14
# n_batch 30000, window 256, batch 1024, Adam 0.02, LinearLR, style=bin eps=0.5

Example::

    python examples/offset36_gru_advdec.py
"""

from __future__ import annotations

import argparse

from acorn import AdvConfig, TrainConfig, train_model
from examples.save_run import save_run

RECIPE = "offset36_gru_advdec"


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default=None,
        help="If set, save the TrainResult under this directory.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="RNG seed passed into TrainConfig / SequenceTrainConfig (TrainConfig.seed default is 42).",
    )
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=["jango"],
        recipe=RECIPE,
        enc_lr=0.02,
        batch_size=1024,
        adv=AdvConfig(enabled=True, eps=0.5, style="bin"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    if args.output_dir:
        save_run(result, args.output_dir)


if __name__ == "__main__":
    main()
