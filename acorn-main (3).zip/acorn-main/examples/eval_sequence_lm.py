"""Optional language-model rescoring of a saved sequence export.

Does not train. After ``examples/save_run.py``, call ``rescore(export_dir)``.
Needs Docker; see docs/language_model.md.

# HYPERS source=rescore_export
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from acorn.lm import rescore_export
from examples._common import help_parser


def rescore(
    export_dir: str | Path,
    *,
    assume_yes: bool = False,
    session_key: str | None = None,
    host_ram_bytes: int | None = None,
) -> dict[str, Any]:
    """Wrap ``acorn.lm.rescore_export``."""
    return rescore_export(
        export_dir,
        assume_yes=assume_yes,
        session_key=session_key,
        host_ram_bytes=host_ram_bytes,
    )


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
