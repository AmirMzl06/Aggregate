"""Hippo multi-session embeddings from a TrainResult.

Does not train. After ``train_model``, call
``embeddings_from_result(result, x_by_key)`` with a ``TrainResult``.

# HYPERS source=multi_embedding_script.py
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import help_parser
from examples.eval_embeddings import embeddings_from_result

__all__ = ["TrainResult", "embeddings_from_result"]


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
