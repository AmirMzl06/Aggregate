"""Perich Offset36_multi time-only cluster_pgd.

# HYPERS recipe=offset36_gru source=macorn_perich_time_time_based_no_noise.py
# (multi_runai_final_no_noise.py) hidden 64, offset 1, conditional=time, cluster_pgd
# decoder_adv=pgd, is_cont=False
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import PERICH_KEYS, maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=PERICH_KEYS,
        recipe="offset36_gru",
        enc_lr=1e-4,
        batch_size=2048,
        n_batch=40000,
        n_decoder_batches=2500,
        ceb_hidden=64,
        ceb_out=64,
        offset=1,
        time_offset=1,
        window=512,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional="time",
        decoder_adv="pgd",
        adv=AdvConfig(enabled=True, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
