"""Perich eval matrix on a TrainResult.

Does not train. After ``train_model``, call
``eval_perich(result, x_by_key, y_by_key, mlp=...)`` with a ``TrainResult``.
Perich clean-time eval hypers are 16/8/1.

# HYPERS source=perich_script.py
# time × not-time × encoder-adv × clean × (noise eval, adv eval)
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import PERICH_NOISE_GRID, help_parser
from examples.eval_adv import score_result_adv
from examples.eval_noise import score_result_noise

PERICH_CLEAN_TIME = {"ceb_hidden": 16, "ceb_out": 8, "offset": 1}


def eval_perich(result: TrainResult, x_by_key, y_by_key, *, mlp: bool = False) -> dict:
    """Run noise + adv eval. MLP when that notes row used --mlp."""
    return {
        "mlp": mlp,
        "noise": score_result_noise(result, x_by_key, y_by_key, PERICH_NOISE_GRID),
        "adv": score_result_adv(result, x_by_key, y_by_key, epsilon=0.5),
        "clean_time_hypers": PERICH_CLEAN_TIME,
    }


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
