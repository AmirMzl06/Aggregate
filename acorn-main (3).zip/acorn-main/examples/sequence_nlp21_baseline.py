"""NLP21 brain-to-text without adversarial training, offset36_ctc.

# HYPERS recipe=offset36_ctc
# n_batch 20000, batch 16, hidden 1024, layers 5, bidir True, offset 4
# kernel 32, stride 4, cont_batch 1024, enc_lr 0.02, style=bin eps=0.8 enabled=False
"""

from __future__ import annotations

from acorn import AdvConfig, SequenceTrainConfig, TrainResult, train_model
from examples._common import maybe_save, output_dir_parser


def train(args) -> TrainResult:
    cfg = SequenceTrainConfig(
        dataset_keys=["nlp21"],
        recipe="offset36_ctc",
        n_batch=20000,
        batch_size=16,
        hidden=1024,
        layers=5,
        bidir=True,
        offset=4,
        kernel=32,
        stride=4,
        cont_batch=1024,
        enc_lr=0.02,
        adv=AdvConfig(enabled=False, eps=0.8, style="bin"),
        device="auto",
        seed=args.seed,
    )
    return train_model(cfg)


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    result = train(args)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
