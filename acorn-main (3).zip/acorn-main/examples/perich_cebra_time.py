"""Perich sklearn CEBRA.fit time-only, clean encoder.

# HYPERS recipe=offset36_cebra source=acorn_single_one_run_time_no_noise_time.py
# (runai_perich_cebra_time.py) 512/64/4, mlp, fit(data,), omits conditional, batch 2048
# training_mode=clean adv_alternate=False
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=["perich_c_co_1"],
        recipe="offset36_cebra",
        enc_lr=3e-4,
        batch_size=2048,
        n_batch=5000,
        n_decoder_batches=2500,
        ceb_hidden=512,
        ceb_out=64,
        offset=4,
        time_offset=4,
        window=512,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional=None,
        decoder_adv="off",
        mlp_decoder=True,
        zscore=False,
        adv=AdvConfig(enabled=False, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
