"""Hippo eval matrix on a TrainResult.

Does not train. After ``train_model``, call
``eval_hippo(result, x_by_key, y_by_key, mlp=...)`` with a ``TrainResult``.
MLP when that notes row used ``--mlp``. Hippo clean-time eval hidden 32.

# HYPERS source=hippo_script.py
# time × not-time × encoder-adv × clean × (noise eval, adv eval)
"""

from __future__ import annotations

from acorn import TrainResult
from examples._common import HIPPO_NOISE_GRID, help_parser
from examples.eval_adv import score_result_adv
from examples.eval_noise import score_result_noise

HIPPO_CLEAN_TIME = {"ceb_hidden": 32, "ceb_out": 64, "offset": 1}


def eval_hippo(result: TrainResult, x_by_key, y_by_key, *, mlp: bool = False) -> dict:
    return {
        "mlp": mlp,
        "noise": score_result_noise(result, x_by_key, y_by_key, HIPPO_NOISE_GRID),
        "adv": score_result_adv(result, x_by_key, y_by_key, epsilon=0.5),
        "clean_time_hypers": HIPPO_CLEAN_TIME,
    }


def main(argv: list[str] | None = None) -> None:
    parser = help_parser(__doc__)
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
