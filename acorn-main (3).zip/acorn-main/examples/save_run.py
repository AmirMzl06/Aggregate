"""Write ``TrainResult`` artifacts under a run directory.

Examples only — not part of the installed ``acorn`` package. Core training
returns RAM artifacts and never writes run files.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch

from acorn.train.result import TrainResult
from acorn.utils.history import append_history

PLOT_DATA_DIRNAME = "plot_data"


def save_day_npz(path: Path, payload: dict[str, Any]) -> None:
    """Write one day's plot payload as a compressed ``.npz``."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **payload)


def save_run(result: TrainResult, out_dir: str | Path) -> Path:
    """Save checkpoint, metrics, history, decoders, plots, and sequence export."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    metrics = dict(result.metrics)
    torch.save(
        {
            "mode": metrics.get("mode"),
            "recipe": metrics.get("recipe"),
            "model": result.model.state_dict(),
            "datasets": metrics.get("datasets"),
        },
        out_dir / "checkpoint.pt",
    )
    (out_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2, default=str), encoding="utf-8"
    )
    for record in result.history:
        append_history(out_dir, record)
    for key, decoder in result.decoders.items():
        torch.save(decoder.state_dict(), out_dir / f"decoder_{key}_best.pt")
    plots = result.plots or {}
    export = plots.get("export")
    if export is not None:
        _save_sequence_export(out_dir, export)
        lm = export.get("lm")
        if isinstance(lm, dict):
            (out_dir / "lm_metrics.json").write_text(
                json.dumps(lm, indent=2, default=str), encoding="utf-8"
            )
    for key, payload in plots.items():
        if key == "export":
            continue
        _save_plot_payload(out_dir / key / PLOT_DATA_DIRNAME, payload)
    return out_dir


def _save_plot_payload(plot_dir: Path, payload: dict[str, Any]) -> None:
    plot_dir.mkdir(parents=True, exist_ok=True)
    manifest = payload.get("manifest")
    if manifest is not None:
        (plot_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2, default=str), encoding="utf-8"
        )
    for tag in ("day0", "dayk"):
        day = payload.get(tag)
        if day is not None:
            save_day_npz(plot_dir / f"{tag}.npz", day)


def _save_sequence_export(out_dir: Path, export: dict[str, Any]) -> None:
    sessions = export.get("sessions") or {}
    entries = []
    for entry in export.get("datasets") or []:
        key = entry["session_key"]
        bundle = sessions.get(key)
        written = dict(entry)
        if bundle is not None:
            dest = out_dir / f"{key}_logits.pt"
            torch.save(bundle, dest)
            written["path"] = dest.name
        entries.append(written)
    manifest = {"schema": export.get("schema"), "datasets": entries}
    (out_dir / "ctc_export_manifest.json").write_text(
        json.dumps(manifest, indent=2, default=str), encoding="utf-8"
    )


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Unused on the CLI; call save_run(result, path) from a training example.",
    )
    parser.parse_args(argv)
    parser.print_help()


if __name__ == "__main__":
    main()
