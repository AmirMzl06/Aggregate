"""Perich Offset36_multi cluster_pgd encoder + PGD decoder.

# HYPERS recipe=offset36_gru source=macorn_perich_old_time.py
# flags from multi_runai_final.py, attack from macorn_perich_old_time.py
# AdamW 1e-4, 512/64/4, cluster_pgd eps=0.5, decoder_adv=pgd, 40000, batch 2048, window 512
"""

from __future__ import annotations

from acorn import AdvConfig, TrainConfig, train_model
from examples._common import PERICH_KEYS, maybe_save, output_dir_parser


def main(argv: list[str] | None = None) -> None:
    parser = output_dir_parser(__doc__)
    args = parser.parse_args(argv)
    cfg = TrainConfig(
        dataset_keys=PERICH_KEYS,
        recipe="offset36_gru",
        enc_lr=1e-4,
        batch_size=2048,
        n_batch=40000,
        n_decoder_batches=2500,
        ceb_hidden=512,
        ceb_out=64,
        offset=4,
        time_offset=4,
        window=512,
        encoder_val_checkpoint=False,
        decoder_val_checkpoint=False,
        conditional="time_delta",
        decoder_adv="pgd",
        adv=AdvConfig(enabled=True, eps=0.5, style="cluster_pgd"),
        device="auto",
        seed=args.seed,
    )
    result = train_model(cfg)
    maybe_save(result, args.output_dir)


if __name__ == "__main__":
    main()
