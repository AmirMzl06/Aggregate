"""Helpers for the newcomer Jupyter demos in this folder.

Training still goes through ``TrainConfig`` / ``train_model``. This module only
handles repo-root discovery, optional save/load of a finished run, paper display
names, and matplotlib bar/trajectory plots.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import numpy as np

PAPER_NAMES = {
    "jango": "IW-J",
    "mihili_co": "CO-M",
    "mihili_rt": "RT-M",
    "pop": "PG-P",
}

DAY0_LABEL = "Day-0"
DAYK_LABEL = "Day-K"
NO_ADV_LABEL = "without adversarial training"
REACH_N_SHOW = 8


def paper_label(key: str) -> str:
    """Paper name for a registry key (IW-J, CO-M, RT-M, PG-P)."""
    return PAPER_NAMES.get(str(key), str(key))


def chdir_repo_root(start: str | Path | None = None) -> Path:
    """``os.chdir`` to the directory that contains ``pyproject.toml``."""
    here = Path(start or Path.cwd()).resolve()
    for candidate in [here, *here.parents]:
        if (candidate / "pyproject.toml").is_file():
            os.chdir(candidate)
            return candidate
    msg = (
        "Acorn is not on this machine yet. Clone the repository with GitHub "
        "access, or upload a zip of the repo to this VM, then open the notebook "
        "from that tree. Do not paste a token into the notebook."
    )
    raise FileNotFoundError(msg)


def try_load_run(resume_dir: str | Path | None) -> dict[str, Any] | None:
    """Load ``metrics.json`` and plot payloads written by ``examples.save_run``.

    Returns ``None`` when ``resume_dir`` is unset or has no metrics file, so the
    notebook can call ``train_model`` instead.
    """
    if not resume_dir:
        return None
    run_dir = Path(resume_dir)
    metrics_file = run_dir / "metrics.json"
    if not metrics_file.is_file():
        return None
    metrics = json.loads(metrics_file.read_text(encoding="utf-8"))
    plots: dict[str, Any] = {}
    for child in sorted(run_dir.iterdir()):
        plot_dir = child / "plot_data"
        if child.is_dir() and plot_dir.is_dir():
            plots[child.name] = _load_plot_payload(plot_dir)
    return {"metrics": metrics, "plots": plots}


def maybe_save_run(result: Any, save_dir: str | Path | None) -> None:
    """Write a ``TrainResult`` with ``examples.save_run.save_run`` when asked."""
    if result is None or not save_dir:
        return
    from examples.save_run import save_run

    save_run(result, save_dir)


def per_dataset_rows(metrics: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Per-session metric dicts from a ``TrainResult.metrics`` payload."""
    nested = metrics.get("per_dataset")
    if isinstance(nested, dict):
        return nested
    if "r2_holdout" in metrics:
        return {"_": metrics}
    return {}


def macaque_day_scores(metrics: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Paper name → Day-0 holdout R² and mean Day-K R²."""
    out: dict[str, dict[str, float]] = {}
    for key, row in per_dataset_rows(metrics).items():
        out[paper_label(key)] = {
            DAY0_LABEL: float(row["r2_holdout"]),
            DAYK_LABEL: float(row["r2_mean_other_days"]),
        }
    return out


def load_eval_xy(
    dataset_keys: list[str], *, assume_yes: bool = True
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Holdout neural bins and labels for the public noise/attack helpers."""
    import torch

    from acorn.data.registry import DATASET_REGISTRY

    x_by_key: dict[str, Any] = {}
    y_by_key: dict[str, Any] = {}
    for key in dataset_keys:
        spec = DATASET_REGISTRY[key]
        if spec.dataset_group == "perich":
            from acorn.data.groups.perich.load import load_perich_session

            arrays = load_perich_session(spec, assume_yes=assume_yes)
        elif spec.dataset_group == "hippo":
            from acorn.data.groups.hippo.load import load_hippo_session

            arrays = load_hippo_session(spec, assume_yes=assume_yes)
        else:
            raise ValueError(f"No holdout loader for dataset group {spec.dataset_group!r}")
        x_by_key[key] = torch.as_tensor(arrays["test_x"])
        y_by_key[key] = torch.as_tensor(arrays["test_y"])
    return x_by_key, y_by_key


def score_clean_noise_adv(
    result: Any,
    x_by_key: dict[str, Any],
    y_by_key: dict[str, Any],
    *,
    noise_std: float,
    attack_eps: float,
) -> dict[str, dict[str, float]]:
    """Clean holdout R² plus Gaussian-noise and 10-step L2-attack R²."""
    from examples.eval_adv import score_result_adv
    from examples.eval_noise import score_result_noise

    clean = {key: float(row["r2_holdout"]) for key, row in per_dataset_rows(result.metrics).items()}
    noise_raw = score_result_noise(result, x_by_key, y_by_key, [noise_std])
    noise = {key: float(values[noise_std]) for key, values in noise_raw.items()}
    adv_raw = score_result_adv(result, x_by_key, y_by_key, epsilon=attack_eps)
    adv = {key: float(value) for key, value in adv_raw.items()}
    return {"clean": clean, "noise": noise, "adv": adv}


_MISSING_DEMO_EVAL_MSG = (
    "Noise and attack bars need this notebook's saved eval or a live "
    "TrainResult; this folder only has clean holdout R²."
)

_CONDITION_LABELS = {"clean": "clean", "noise": "Gaussian noise", "adv": "L2 attack"}
_CONDITION_ORDER = ("clean", "noise", "adv")


def holdout_as_eval(metrics: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Clean-only eval dict from ``r2_holdout`` (noise/attack omitted)."""
    clean: dict[str, float] = {}
    for key, row in per_dataset_rows(metrics).items():
        if "r2_holdout" in row:
            clean[str(key)] = float(row["r2_holdout"])
    return {"clean": clean}


def eval_scores_from_loaded(loaded: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Return ``demo_eval`` when this notebook saved it, else clean holdout.

    A generic ``examples.save_run`` folder has ``r2_holdout`` but no
    ``demo_eval``. Prints one line so a newcomer knows why noise/attack bars
    are missing.
    """
    metrics = loaded.get("metrics") if isinstance(loaded, dict) else None
    if not isinstance(metrics, dict):
        metrics = {}
    demo = metrics.get("demo_eval")
    if isinstance(demo, dict) and any(isinstance(row, dict) and row for row in demo.values()):
        return demo
    print(_MISSING_DEMO_EVAL_MSG)
    return holdout_as_eval(metrics)


def scores_for_key(eval_scores: dict[str, dict[str, float]], key: str) -> dict[str, float]:
    """One session's present conditions (omit missing noise/attack)."""
    out: dict[str, float] = {}
    for cond in _CONDITION_ORDER:
        by_key = eval_scores.get(cond)
        if isinstance(by_key, dict) and key in by_key and _finite(by_key[key]):
            out[cond] = float(by_key[key])
    return out


def mean_condition_scores(eval_scores: dict[str, dict[str, float]]) -> dict[str, float]:
    """Mean R² per present condition across sessions."""
    out: dict[str, float] = {}
    for cond in _CONDITION_ORDER:
        by_key = eval_scores.get(cond)
        if isinstance(by_key, dict) and by_key:
            values = [float(v) for v in by_key.values() if _finite(v)]
            if values:
                out[cond] = float(sum(values) / len(values))
    return out


def mean_eval_by_perich_task(
    eval_scores: dict[str, dict[str, float]],
) -> dict[str, dict[str, float]]:
    """Average session scores into paper tasks (C-CO, C-RT, …)."""
    from collections import defaultdict

    from acorn.data.groups.perich import PERICH_DAYS, parse_perich_key

    grouped: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for cond, by_key in eval_scores.items():
        if not isinstance(by_key, dict):
            continue
        for key, value in by_key.items():
            if not _finite(value):
                continue
            task, _day = parse_perich_key(str(key))
            grouped[cond][task].append(float(value))
    tasks = [task for task in PERICH_DAYS if any(task in grouped[cond] for cond in grouped)]
    return {
        cond: {
            task: float(sum(grouped[cond][task]) / len(grouped[cond][task]))
            for task in tasks
            if task in grouped[cond]
        }
        for cond in _CONDITION_ORDER
        if cond in grouped
    }


def _pyplot():
    try:
        from matplotlib import pyplot as plt
    except ImportError as exc:
        raise ImportError(
            "Plotting these demos needs matplotlib in the same environment as Acorn."
        ) from exc
    return plt


def _show_figure(fig) -> None:
    """Embed ``fig`` as notebook image data, then close it.

    ``plt.show()`` does not store PNG for a ``list[Figure]`` cell result.
    IPython ``display(fig)`` writes ``image/png``; returning ``None`` avoids a
    Figure-repr ``execute_result``. When IPython is missing, ``plt.show()``
    still lets a PNG land on backends that capture it. Do not call both.
    Import as ``ipython_display`` so EMG channel names can keep the local
    name ``display``.
    """
    plt = _pyplot()
    try:
        from IPython.display import display as ipython_display
    except ImportError:
        ipython_display = None
    if ipython_display is not None:
        ipython_display(fig)
    else:
        plt.show()
    plt.close(fig)


def _finite(value: Any) -> bool:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return False
    return number == number


def plot_grouped_bars(
    groups: dict[str, dict[str, float]],
    *,
    title: str,
    ylabel: str = "R²",
    group_order: list[str] | None = None,
    series_order: list[str] | None = None,
):
    """Grouped matplotlib bars. ``groups`` maps an x-tick to series → height."""
    plt = _pyplot()

    ticks = group_order or list(groups)
    series = series_order or _union_series(groups)
    series = [name for name in series if any(name in (groups.get(tick) or {}) for tick in ticks)]
    n_groups = max(len(ticks), 1)
    n_series = max(len(series), 1)
    x = np.arange(n_groups, dtype=float)
    width = min(0.8 / n_series, 0.35)
    fig, ax = plt.subplots(figsize=(max(6.0, 1.4 * n_groups), 4.0))
    for i, name in enumerate(series):
        heights = [float(groups.get(tick, {}).get(name, float("nan"))) for tick in ticks]
        ax.bar(x + (i - (n_series - 1) / 2) * width, heights, width, label=name)
    ax.set_xticks(x)
    ax.set_xticklabels(
        ticks, rotation=30 if n_groups > 4 else 0, ha="right" if n_groups > 4 else "center"
    )
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    ax.axhline(0.0, color="black", linewidth=0.6)
    fig.tight_layout()
    _show_figure(fig)


def plot_condition_bars(
    methods: dict[str, dict[str, float]],
    *,
    title: str,
    conditions: tuple[str, ...] = _CONDITION_ORDER,
):
    """One group per method; skip missing noise/attack (plot clean only)."""
    present = [
        cond
        for cond in conditions
        if any(cond in scores and _finite(scores.get(cond)) for scores in methods.values())
    ]
    groups = {
        method: {
            _CONDITION_LABELS[cond]: float(scores[cond])
            for cond in present
            if cond in scores and _finite(scores[cond])
        }
        for method, scores in methods.items()
    }
    return plot_grouped_bars(
        groups,
        title=title,
        series_order=[_CONDITION_LABELS[cond] for cond in present],
    )


def plot_session_condition_bars(
    eval_scores: dict[str, dict[str, float]],
    *,
    title: str,
    label_fn=None,
):
    """One group per session; skip missing noise/attack (plot clean only)."""
    rename = label_fn or (lambda key: str(key))
    present = [cond for cond in _CONDITION_ORDER if isinstance(eval_scores.get(cond), dict)]
    keys: list[str] = []
    for cond in present:
        for key in eval_scores[cond]:
            if key not in keys:
                keys.append(key)
    groups: dict[str, dict[str, float]] = {}
    for key in keys:
        row: dict[str, float] = {}
        for cond in present:
            by_key = eval_scores.get(cond) or {}
            if key in by_key and _finite(by_key[key]):
                row[_CONDITION_LABELS[cond]] = float(by_key[key])
        if row:
            groups[rename(key)] = row
    return plot_grouped_bars(
        groups,
        title=title,
        series_order=[_CONDITION_LABELS[cond] for cond in present],
    )


def plot_macaque_day_bars(metrics: dict[str, Any], *, title: str):
    """Day-0 holdout vs mean Day-K R² for each paper dataset."""
    scores = macaque_day_scores(metrics)
    return plot_grouped_bars(
        scores,
        title=title,
        series_order=[DAY0_LABEL, DAYK_LABEL],
    )


def plot_acorn_vs_no_adv(
    metrics_acorn: dict[str, Any],
    metrics_other: dict[str, Any] | None,
    *,
    title: str,
):
    """Grouped ACORN vs without-adversarial bars for Day-0 and Day-K.

    When ``metrics_other`` is missing, this run is plotted alone.
    """
    acorn = macaque_day_scores(metrics_acorn)
    other = macaque_day_scores(metrics_other) if metrics_other else {}
    groups: dict[str, dict[str, float]] = {}
    for name in acorn:
        row = {
            f"ACORN {DAY0_LABEL}": acorn[name][DAY0_LABEL],
            f"ACORN {DAYK_LABEL}": acorn[name][DAYK_LABEL],
        }
        if name in other:
            row[f"{NO_ADV_LABEL} {DAY0_LABEL}"] = other[name][DAY0_LABEL]
            row[f"{NO_ADV_LABEL} {DAYK_LABEL}"] = other[name][DAYK_LABEL]
        groups[name] = row
    return plot_grouped_bars(groups, title=title)


def plot_behavior_traces(plots: dict[str, Any] | None, *, title_prefix: str = ""):
    """Day-0 / Day-K EMG or reach traces from ``TrainResult.plots``."""
    plt = _pyplot()

    if not plots:
        print("No behavior traces on this run (nothing to plot).")
        return None
    n = 0
    for key, payload in plots.items():
        if key == "export" or not isinstance(payload, dict):
            continue
        if "day0" not in payload and "manifest" not in payload:
            continue
        _plot_one_behavior(payload, paper_label(key), title_prefix, plt)
        n += 1
    if not n:
        print("No behavior traces on this run (nothing to plot).")
    return None


def _union_series(groups: dict[str, dict[str, float]]) -> list[str]:
    seen: list[str] = []
    for row in groups.values():
        for name in row:
            if name not in seen:
                seen.append(name)
    return seen


def _load_plot_payload(plot_dir: Path) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    manifest_path = plot_dir / "manifest.json"
    if manifest_path.is_file():
        payload["manifest"] = json.loads(manifest_path.read_text(encoding="utf-8"))
    for tag in ("day0", "dayk"):
        npz_path = plot_dir / f"{tag}.npz"
        if npz_path.is_file():
            payload[tag] = _npz_mapping(npz_path)
    return payload


def _npz_mapping(path: Path) -> dict[str, Any]:
    loaded = np.load(path, allow_pickle=True)
    return {name: loaded[name] for name in loaded.files}


def _trial_list(day: dict[str, Any], field: str) -> list[Any]:
    raw = day.get(field)
    if raw is None:
        return []
    if isinstance(raw, np.ndarray) and raw.dtype == object:
        return [raw[i] for i in range(raw.shape[0])]
    if isinstance(raw, np.ndarray) and raw.ndim >= 2:
        return [raw[i] for i in range(raw.shape[0])]
    if isinstance(raw, (list, tuple)):
        return list(raw)
    return []


def _plot_one_behavior(payload: dict[str, Any], name: str, title_prefix: str, plt):
    manifest = payload.get("manifest") or {}
    plot_type = str(manifest.get("plot_type") or "")
    heading = f"{title_prefix}{name}".strip()
    if plot_type == "emg":
        return _plot_emg_days(payload, manifest, heading, plt)
    return _plot_reach_days(payload, manifest, heading, plt)


def _plot_emg_days(payload: dict[str, Any], manifest: dict[str, Any], heading: str, plt):
    channels = list(manifest.get("plot_channel_indices") or [0])
    display = list(manifest.get("plot_channel_display") or [str(i) for i in channels])
    showcase_len = int(manifest.get("showcase_len") or 40)
    fig, axes = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    for ax, tag, subtitle in (
        (axes[0], "day0", DAY0_LABEL),
        (axes[1], "dayk", DAYK_LABEL),
    ):
        day = payload.get(tag) or {}
        actuals = _trial_list(day, "actual_trials")
        preds = _trial_list(day, "pred_trials")
        if not actuals:
            ax.set_title(f"{heading} — {subtitle} (no trials)")
            continue
        trial_idx = int(day.get("showcase_trial_idx", manifest.get("example_trial_idx") or 0))
        start = int(day.get("showcase_start", manifest.get("example_start_bin") or 0))
        trial_idx = min(max(trial_idx, 0), len(actuals) - 1)
        actual = np.asarray(actuals[trial_idx])
        pred = np.asarray(preds[trial_idx]) if trial_idx < len(preds) else None
        end = min(start + showcase_len, actual.shape[0])
        start = min(start, max(end - 1, 0))
        t = np.arange(end - start) * float(manifest.get("bin_size") or 0.05)
        for i, ch in enumerate(channels):
            if ch >= actual.shape[1]:
                continue
            label = display[i] if i < len(display) else str(ch)
            ax.plot(t, actual[start:end, ch], label=f"{label} actual", linewidth=1.2)
            if pred is not None and ch < pred.shape[1]:
                ax.plot(
                    t,
                    pred[start:end, ch],
                    label=f"{label} predicted",
                    linewidth=1.0,
                    linestyle="--",
                )
        ax.set_ylabel("EMG")
        bin_size = float(manifest.get("bin_size") or 0.05)
        sec = int(manifest.get("showcase_len") or 40) * bin_size
        ax.set_title(f"{heading} — {subtitle} ({sec:g} s showcase)")
        ax.legend(fontsize=8, ncol=2)
    axes[-1].set_xlabel("time (s)")
    fig.tight_layout()
    _show_figure(fig)


def _target_dir_array(day: dict[str, Any], using_all: bool):
    raw = day.get("all_target_dirs") if using_all else day.get("target_dirs")
    if raw is None:
        return None
    arr = np.asarray(raw, dtype=float).reshape(-1)
    return arr if arr.size else None


def _rtm_plot_indices(day: dict[str, Any], actuals: list[Any], tag: str):
    from acorn.eval.plot_config import RTM_TRIAL_INDICES

    raw = day.get("plot_trial_indices")
    if raw is None:
        raw = RTM_TRIAL_INDICES.get(tag, ())
    indices = [int(i) for i in np.asarray(raw).reshape(-1).tolist()]
    return [i for i in indices if 0 <= i < len(actuals)]


def _plot_reach_days(payload: dict[str, Any], manifest: dict[str, Any], heading: str, plt):
    from acorn.eval.plot_config import COM_N_SHOW

    dims = list(manifest.get("pos_dims") or [0, 1])
    dataset_key = str(manifest.get("dataset_key") or "")
    is_com = dataset_key == "mihili_co"
    is_rtm = dataset_key == "mihili_rt"
    cmap = plt.get_cmap("hsv")
    fig, axes = plt.subplots(1, 2, figsize=(8, 4), sharex=True, sharey=True)
    for ax, tag, subtitle in (
        (axes[0], "day0", DAY0_LABEL),
        (axes[1], "dayk", DAYK_LABEL),
    ):
        day = payload.get(tag) or {}
        using_all = day.get("all_actual_trials") is not None
        if is_rtm:
            actuals = _trial_list(day, "actual_trials") or _trial_list(day, "all_actual_trials")
            preds = _trial_list(day, "pred_trials") or _trial_list(day, "all_pred_trials")
            show_idx = _rtm_plot_indices(day, actuals, tag)
        else:
            actuals = _trial_list(day, "all_actual_trials") or _trial_list(day, "actual_trials")
            preds = _trial_list(day, "all_pred_trials") or _trial_list(day, "pred_trials")
            cap = COM_N_SHOW if is_com else REACH_N_SHOW
            show_idx = list(range(min(cap, len(actuals))))
        dirs = _target_dir_array(day, using_all) if is_com else None
        n_show = len(show_idx)
        for i in show_idx:
            actual = np.asarray(actuals[i])
            if actual.ndim != 2 or actual.shape[1] <= max(dims):
                continue
            if is_com:
                if dirs is not None and i < dirs.size and np.isfinite(dirs[i]):
                    color = cmap((float(dirs[i]) % 360.0) / 360.0)
                else:
                    color = cmap(i / max(n_show, 1))
                actual_color, pred_color = color, color
            else:
                actual_color, pred_color = "black", "tab:blue"
            ax.plot(
                actual[:, dims[0]],
                actual[:, dims[1]],
                color=actual_color,
                alpha=0.35,
                linewidth=0.8,
            )
            if i < len(preds):
                pred = np.asarray(preds[i])
                if pred.ndim == 2 and pred.shape[1] > max(dims):
                    ax.plot(
                        pred[:, dims[0]],
                        pred[:, dims[1]],
                        color=pred_color,
                        alpha=0.6,
                        linewidth=0.8,
                    )
        ax.set_title(f"{heading} — {subtitle}")
        ax.set_xlabel("x")
        ax.set_aspect("equal", adjustable="box")
    axes[0].set_ylabel("y")
    fig.tight_layout()
    _show_figure(fig)
