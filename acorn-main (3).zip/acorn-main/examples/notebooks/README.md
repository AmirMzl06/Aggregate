# Demo notebooks

Jupyter walkthroughs that use the Python API
(`TrainConfig` / `SequenceTrainConfig` / `train_model`). Install and pick a
row: [Get started](../../docs/start/index.md). The indexed table (Notebook |
Time | Data | GPU) is [Demos](../../docs/demos/index.md).

Full training is the default. Time-bin runs take hours on a GPU and download
public data. Set `RESUME_DIR` to a folder written by `examples/save_run.py` to
skip training and plot saved metrics. A generic `save_run` folder is enough
for clean holdout R². Noise and attack comparison needs the eval this
notebook writes (or a live `TrainResult`); otherwise the plots show clean
holdout only. Set `SAVE_DIR` to write a new run.

Bar and trace plots need matplotlib in the same environment as Acorn.

Dryad notebooks include a cell for `DRYAD_CLIENT_ID` / `DRYAD_CLIENT_SECRET`
(leave empty to use the same names from the environment). How to create
those keys: [docs/data.md](../../docs/data.md) (Dryad section). Do not
commit secrets.

There is no language-model step in the motor notebooks. Brain-to-text
rescoring is optional and lives in the NLP21 LM notebook. Single-dataset
NLP10 / NLP21 / Speech24 / Speech45 scripts (and their no-adversarial
comparisons) live in the [examples catalog](../README.md); this folder has
the four-corpus Multi walkthrough plus the existing NLP21 demos.

Per-family "what you get" pages: [Reaching](../../docs/demos/reaching.md),
[Hippocampus](../../docs/demos/hippocampus.md),
[Macaque](../../docs/demos/macaque.md),
[Handwriting](../../docs/demos/handwriting.md),
[Multi-session](../../docs/demos/multi-session.md).

Notebooks in this folder: `demo_perich_single.ipynb`,
`demo_perich_multi.ipynb`, `demo_hippo_single.ipynb`,
`demo_hippo_multi.ipynb`, `demo_macaque_multi.ipynb`,
`demo_macaque_multi_baseline.ipynb`, `demo_macaque_iwj.ipynb`,
`demo_nlp21.ipynb`, `demo_sequence_multi.ipynb`, `demo_nlp21_lm.ipynb`.

Script examples (same hyperparameters, no Jupyter) stay in the
[examples catalog](../README.md).
