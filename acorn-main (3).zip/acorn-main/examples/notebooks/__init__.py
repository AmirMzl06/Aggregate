"""Newcomer Jupyter demos. See README.md in this folder."""
