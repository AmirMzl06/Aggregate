"""Append-only JSONL training history for a run directory."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

HISTORY_FILENAME = "history.jsonl"


def append_history(out_dir: str | Path, record: dict[str, Any]) -> None:
    """Append one JSON object as a line to ``out_dir/history.jsonl``.

    Opens, writes, flushes, and ``fsync``s so a crash leaves prior lines intact.
    """
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    dest = path / HISTORY_FILENAME
    line = json.dumps(record, default=str, ensure_ascii=False) + "\n"
    with dest.open("a", encoding="utf-8") as fh:
        fh.write(line)
        fh.flush()
        os.fsync(fh.fileno())
