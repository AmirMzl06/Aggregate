"""Shared AMP (bf16 autocast) helpers used by train and eval."""

from __future__ import annotations

import torch


def amp_ctx(device: torch.device):
    """Autocast context: bfloat16 on CUDA, a no-op elsewhere."""
    use_cuda = device.type == "cuda"
    return torch.autocast(
        "cuda" if use_cuda else "cpu",
        dtype=torch.bfloat16,
        enabled=use_cuda,
    )
