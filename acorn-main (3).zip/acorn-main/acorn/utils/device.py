"""Resolve Acorn device policy strings to torch.device."""

from __future__ import annotations

import torch

_NO_CUDA = (
    "device='cuda' was requested but torch.cuda.is_available() is False. "
    "Use device='cpu' or device='auto'."
)
_POLICY = "Use 'auto', 'cpu', or 'cuda'."


def _unsupported(spec: object) -> ValueError:
    return ValueError(f"Unsupported device {spec!r}. {_POLICY} Acorn does not support mps.")


def _reject_multi_gpu(spec: object) -> ValueError:
    return ValueError(f"Unsupported device {spec!r}. Acorn uses a single GPU. {_POLICY}")


def _require_cuda() -> None:
    if not torch.cuda.is_available():
        raise ValueError(_NO_CUDA)


def _cuda0() -> torch.device:
    _require_cuda()
    return torch.device("cuda:0")


def resolve_device(spec: str | torch.device = "auto") -> torch.device:
    """Map ``auto|cpu|cuda`` (or ``cuda:0`` / a ``torch.device``) to a ``torch.device``."""
    if isinstance(spec, torch.device):
        if spec.type == "cpu":
            return torch.device("cpu")
        if spec.type == "cuda":
            if spec.index in (None, 0):
                return _cuda0()
            raise _reject_multi_gpu(spec)
        raise _unsupported(spec)

    if not isinstance(spec, str):
        raise _unsupported(spec)

    folded = spec.casefold()
    if folded == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda:0")
        return torch.device("cpu")
    if folded == "cpu":
        return torch.device("cpu")
    if folded in {"cuda", "cuda:0"}:
        return _cuda0()
    if folded.startswith("cuda:"):
        raise _reject_multi_gpu(spec)
    raise _unsupported(spec)


def cebra_sklearn_device(device: torch.device) -> str | torch.device:
    """Adapter for vendored ``HasDevice``: keep GPU index as a string."""
    if not isinstance(device, torch.device):
        raise TypeError("cebra_sklearn_device requires a torch.device, not str")
    if device.index is not None:
        return f"cuda:{device.index}"
    return device


def activate_torch_device(device: torch.device) -> None:
    """Call ``torch.cuda.set_device`` only for an indexed CUDA device."""
    if device.type == "cuda" and device.index is not None:
        torch.cuda.set_device(device.index)
