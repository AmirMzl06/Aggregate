"""Put vendored third-party trees on ``sys.path``.

``cebra/`` and ``xds/`` live at the repo root (not PyPI deps). ``import acorn``
runs this so a non-repo cwd still resolves ``import cebra`` and
``from xds import lab_data``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# acorn/utils/vendor_path.py → repo root is parents[2]
_REPO_ROOT = Path(__file__).resolve().parents[2]


def ensure_vendored_on_path() -> Path:
    """Prepend the repository root to ``sys.path`` if needed.

    Returns the repository root.
    """
    path = str(_REPO_ROOT)
    if path not in sys.path:
        sys.path.insert(0, path)
    return _REPO_ROOT
