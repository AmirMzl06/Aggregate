"""Shared validation-split and early-stopping settings."""

from __future__ import annotations

import torch

VAL_FRAC = 0.2
MIN_EPOCHS = 10000
PATIENCE = 2000


def split_time_aware(x: torch.Tensor, y: torch.Tensor, frac: float = VAL_FRAC):
    """Hold out the last ``frac`` of the timeline for validation."""
    n = x.shape[0]
    v = max(1, int(frac * n))
    if n <= v + 1:
        v = max(1, n // 5)
    if n - v < 1:
        return x, y, x[-1:], y[-1:]
    return x[:-v], y[:-v], x[-v:], y[-v:]
