"""Shared path constants."""

from __future__ import annotations

import os
from pathlib import Path

# Canonical data root used by DatasetLoader and runners.
# Override with ACORN_DATA_DIR for machines that store data elsewhere.
_DEFAULT_DATA_DIR = Path("./data")
DATA_DIR = Path(os.environ.get("ACORN_DATA_DIR", str(_DEFAULT_DATA_DIR)))
