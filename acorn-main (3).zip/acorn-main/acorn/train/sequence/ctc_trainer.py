"""Joint CTC+InfoNCE trainer. Round-robin over registered sessions."""

from __future__ import annotations

import copy
from typing import TYPE_CHECKING

import torch
from torch.utils.data import DataLoader
from tqdm import trange

from acorn.data.sequence.collate import TrialDataset, collate_fn
from acorn.eval.sequence.ctc_probe import evaluate_split
from acorn.log import get_logger
from acorn.train.sequence.adversarial_ctc import l2_adv_ctc
from acorn.train.sequence.get_batch import get_batch
from acorn.utils.amp import amp_ctx

if TYPE_CHECKING:
    from acorn.train.sequence.config import SequenceTrainConfig

LR_END = 0.002
WEIGHT_DECAY = 1e-5
ADAM_EPS = 0.1
GRAD_CLIP_NORM = 5.0
logger = get_logger(__name__)


def _contrastive_criterion(temperature: float, device: torch.device):
    from acorn.utils.vendor_path import ensure_vendored_on_path

    ensure_vendored_on_path()
    import cebra

    return cebra.models.FixedCosineInfoNCE(temperature).to(device)


def _cycle(loader: DataLoader):
    iterator = iter(loader)
    while True:
        try:
            yield next(iterator)
        except StopIteration:
            iterator = iter(loader)


class CtcTrainer:
    def __init__(self, model, sessions: dict, device: torch.device, config: SequenceTrainConfig):
        self.model = model
        self.sessions = sessions
        self.device = device
        self.config = config

    def build_optimizer(self):
        return torch.optim.Adam(
            self.model.parameters(),
            lr=self.config.enc_lr,
            betas=(0.9, 0.999),
            eps=ADAM_EPS,
            weight_decay=WEIGHT_DECAY,
        )

    def build_scheduler(self, optimizer, n_batches: int):
        enc_lr = self.config.enc_lr
        if enc_lr <= 0:
            raise ValueError("enc_lr must be > 0 for LinearLR")
        return torch.optim.lr_scheduler.LinearLR(
            optimizer,
            start_factor=1.0,
            end_factor=LR_END / enc_lr,
            total_iters=max(n_batches, 1),
        )

    def _clean_step(
        self,
        x,
        y,
        x_len,
        y_len,
        session_key,
        optimizer,
        ctc_criterion,
        infonce_criterion,
    ):
        with amp_ctx(self.device):
            pred, lengths = self.model(x, x_len, session_key)
            embeddings, emb_lengths = self.model.get_cebra_embs()
            ctc_loss = ctc_criterion(pred.log_softmax(2).permute(1, 0, 2), y, lengths, y_len)
            triples = get_batch(embeddings, emb_lengths, self.config.cont_batch, self.config.offset)
            reference, positive, negative = triples[0], triples[1], triples[2]
            infonce_loss, _, _ = infonce_criterion(reference, positive, negative)
            loss = ctc_loss + infonce_loss
        optimizer.zero_grad(set_to_none=True)
        if torch.isfinite(loss):
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), GRAD_CLIP_NORM)
            optimizer.step()
        index_triples = triples[3:]
        return loss.detach(), ctc_loss.detach(), infonce_loss.detach(), index_triples

    def _adversarial_step(
        self,
        x,
        y,
        x_len,
        y_len,
        session_key,
        optimizer,
        ctc_criterion,
        infonce_criterion,
        triples,
    ):
        adv = self.config.adv
        if not adv.enabled:
            return None
        eps = float(adv.eps)
        return l2_adv_ctc(
            self.model,
            optimizer,
            x,
            y,
            x_len,
            y_len,
            session_key,
            ctc_criterion,
            infonce_criterion,
            triples,
            adv_eps=eps,
            adv_steps=adv.steps,
            alpha=adv.alpha,
        )

    def _log_step(self, history: list[dict], step: int, losses: dict, cers: dict | None) -> None:
        record = {
            "phase": "ctc_step",
            "step": step,
            "losses": {k: float(v) for k, v in losses.items()},
        }
        if cers is not None:
            record["cer"] = {k: float(v) for k, v in cers.items()}
        history.append(record)

    def run(self) -> dict:
        model = self.model
        device = self.device
        config = self.config
        n_batches = config.n_batch
        history: list[dict] = []

        ctc_criterion = torch.nn.CTCLoss(blank=0, reduction="mean", zero_infinity=True)
        infonce_criterion = _contrastive_criterion(config.temperature, device)
        optimizer = self.build_optimizer()
        scheduler = self.build_scheduler(optimizer, n_batches)

        session_keys = list(self.sessions.keys())
        loaders = []
        for key in session_keys:
            session = self.sessions[key]
            loader = DataLoader(
                TrialDataset(session.train),
                batch_size=config.batch_size,
                shuffle=True,
                collate_fn=collate_fn,
            )
            loaders.append(_cycle(loader))

        last_losses = {k: 0.0 for k in session_keys}
        last_cers: dict[str, float] | None = None
        best_cer = float("inf")
        best_state = None

        for step in trange(n_batches, desc="[Sequence] CTC+InfoNCE"):
            model.train()
            for i, key in enumerate(session_keys):
                x, y, x_len, y_len = next(loaders[i])
                x = x.to(device)
                y = y.to(device)
                x_len = x_len.to(device)
                y_len = y_len.to(device)
                loss, _ctc, _nce, triples = self._clean_step(
                    x, y, x_len, y_len, key, optimizer, ctc_criterion, infonce_criterion
                )
                last_losses[key] = float(loss.item())
                self._adversarial_step(
                    x, y, x_len, y_len, key, optimizer, ctc_criterion, infonce_criterion, triples
                )
            scheduler.step()

            do_eval = step % config.periodic_eval_every == 0
            if do_eval:
                last_cers = {}
                for key in session_keys:
                    session = self.sessions[key]
                    result = evaluate_split(
                        model,
                        key,
                        session.periodic_eval,
                        device,
                        batch_size=config.batch_size,
                        blank=session.blank_index,
                    )
                    last_cers[key] = result["cer"]
                    logger.info(
                        "[ctc %5d/%s] %s cer=%.4f",
                        step,
                        n_batches,
                        key,
                        result["cer"],
                    )
                mean_cer = sum(last_cers.values()) / max(len(last_cers), 1)
                if mean_cer < best_cer:
                    best_cer = mean_cer
                    best_state = copy.deepcopy(model.state_dict())
                    history.append(
                        {"phase": "ctc_best", "step": step, "cer": float(best_cer)},
                    )
                model.train()

            self._log_step(history, step, last_losses, last_cers if do_eval else None)

        if best_state is not None:
            model.load_state_dict(best_state)

        return {
            "n_batch": n_batches,
            "best_cer": best_cer if best_cer < float("inf") else float("nan"),
            "last_losses": last_losses,
            "history": history,
        }
