"""InfoNCE triple sampling from already-encoded embeddings.

Faithful port with ``single_sequence=False``, ``random_offset=True``,
``random_dir=True``, ``all_ref=False`` (bidirectional Uniform{1..offset}).
No config flags for ``random_dir`` / ``random_offset``.
"""

from __future__ import annotations

import torch


def get_batch(
    x: torch.Tensor,
    x_len: torch.Tensor,
    batch_size: int = 1024,
    offset: int = 4,
) -> tuple[torch.Tensor, ...]:
    bsz, _t, _f = x.shape
    device = x.device
    ref_batch_idx = torch.randint(0, bsz, (batch_size,), device=device)
    max_times = torch.clamp(x_len[ref_batch_idx] - offset - 1, min=1)
    ref_time_idx = torch.randint(offset, torch.max(max_times).item(), (batch_size,), device=device)
    ref_time_idx = torch.min(ref_time_idx, max_times - 1)

    add_offset = torch.randint(
        1, offset + 1, (len(ref_batch_idx),), device=device, dtype=torch.long
    )
    dir_val = torch.randint(0, 2, add_offset.shape, device=device) * 2 - 1
    add_offset = add_offset * dir_val

    pos_time_idx = torch.clamp(
        ref_time_idx + add_offset,
        min=torch.zeros_like(x_len[ref_batch_idx] - 1),
        max=x_len[ref_batch_idx] - 1,
    )

    neg_batch_idx = torch.randint(0, bsz, (len(ref_batch_idx),), device=device)
    neg_max_times = x_len[neg_batch_idx]
    neg_time_idx = torch.randint(
        0, torch.max(neg_max_times).item(), (len(ref_batch_idx),), device=device
    )
    neg_time_idx = torch.min(neg_time_idx, neg_max_times - 1)

    reference = x[ref_batch_idx, ref_time_idx]
    positive = x[ref_batch_idx, pos_time_idx]
    negative = x[neg_batch_idx, neg_time_idx]
    return (
        reference,
        positive,
        negative,
        ref_batch_idx,
        ref_time_idx,
        pos_time_idx,
        neg_batch_idx,
        neg_time_idx,
    )
