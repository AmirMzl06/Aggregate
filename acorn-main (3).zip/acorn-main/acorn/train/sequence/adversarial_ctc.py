"""Combined CTC+InfoNCE L2 PGD on whole padded trials.

Reuses ``init_adv_noise`` / ``pgd_step`` from :mod:`acorn.train.adversarial`.
Alpha default is ``eps / 5.0`` — not ``default_adv_alpha`` (``2·eps/steps``).
"""

from __future__ import annotations

import torch

from acorn.train.adversarial import init_adv_noise, pgd_step
from acorn.utils.amp import amp_ctx


def ctc_adv_alpha(eps: float) -> float:
    return eps / 5.0


def l2_adv_ctc(
    model,
    optimizer,
    x: torch.Tensor,
    y: torch.Tensor,
    x_len: torch.Tensor,
    y_len: torch.Tensor,
    session_key: str,
    ctc_criterion,
    infonce_criterion,
    triples: tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor],
    adv_eps: float,
    adv_steps: int,
    alpha: float | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Bin-style PGD on raw padded input, then a second optimizer step.

    Returns ``(loss_adv, x_adv)``.
    """
    device = x.device
    step_alpha = ctc_adv_alpha(adv_eps) if alpha is None else alpha
    ref_batch_idx, ref_time_idx, pos_time_idx, neg_batch_idx, neg_time_idx = triples
    x_adv = init_adv_noise(x, adv_eps, "bin", device)
    x_adv.requires_grad_(True)

    for _ in range(adv_steps):
        with amp_ctx(device):
            pred_adv, lengths = model(x_adv, x_len, session_key)
            embeddings_adv, _emb_lengths = model.get_cebra_embs()
            ctc_loss_adv = ctc_criterion(
                pred_adv.log_softmax(2).permute(1, 0, 2),
                y,
                lengths,
                y_len,
            )
            reference = embeddings_adv[ref_batch_idx, ref_time_idx]
            positive = embeddings_adv[ref_batch_idx, pos_time_idx].detach()
            negative = embeddings_adv[neg_batch_idx, neg_time_idx].detach()
            loss_contrastive_adv, _, _ = infonce_criterion(reference, positive, negative)
            loss_adv = loss_contrastive_adv + ctc_loss_adv
        (grad_x,) = torch.autograd.grad(loss_adv, x_adv, retain_graph=False, create_graph=False)
        x_adv = pgd_step(x_adv, grad_x, x, adv_eps, step_alpha, "bin")
        x_adv.requires_grad_(True)

    x_adv.requires_grad_(False)
    optimizer.zero_grad(set_to_none=True)
    with amp_ctx(device):
        pred_adv, lengths = model(x_adv, x_len, session_key)
        embeddings_adv, _emb_lengths = model.get_cebra_embs()
        ctc_loss_adv = ctc_criterion(
            pred_adv.log_softmax(2).permute(1, 0, 2),
            y,
            lengths,
            y_len,
        )
        reference = embeddings_adv[ref_batch_idx, ref_time_idx]
        positive = embeddings_adv[ref_batch_idx, pos_time_idx]
        negative = embeddings_adv[neg_batch_idx, neg_time_idx]
        loss_contrastive_adv, _, _ = infonce_criterion(reference, positive, negative)
        loss_adv = loss_contrastive_adv + ctc_loss_adv
    if torch.isfinite(loss_adv):
        loss_adv.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
    return loss_adv.detach(), x_adv.detach()
