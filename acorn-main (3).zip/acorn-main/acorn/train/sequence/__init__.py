"""Sequence-format training package."""
