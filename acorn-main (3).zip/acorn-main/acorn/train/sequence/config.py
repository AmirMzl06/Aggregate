"""Sequence-format training hyperparameters."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator

from acorn.data.dataset_keys import validate_dataset_keys
from acorn.models.registry import DEFAULT_SEQUENCE_RECIPE
from acorn.train.config import AdvConfig


class SequenceTrainConfig(BaseModel):
    """Hyperparameters for sequence (brain-to-text) training.

    Transcripts are shorter than the neural timeline.
    :func:`acorn.runners.dispatch.train_model` trains encoder and CTC
    decoder together. Default recipe is ``offset36_ctc``. ``dataset_keys``
    is required; field descriptions document the rest.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    dataset_keys: list[str] = Field(description="Sequence dataset registry keys for this run.")
    output_dir: str | None = Field(
        default=None,
        description="Ignored by core training (no run-directory writes). Examples may pass a path to save.",
    )
    recipe: str = Field(
        default=DEFAULT_SEQUENCE_RECIPE,
        description="Registered sequence recipe name.",
    )
    seed: int = Field(default=42, description="RNG seed for Python, NumPy, and Torch.")
    device: str = Field(
        default="auto",
        pattern=r"^(auto|cpu|cuda)$",
        description="Device policy: auto, cpu, or cuda.",
    )
    enc_lr: float = Field(default=0.02, description="Joint CTC+InfoNCE Adam learning rate.")
    n_batch: int = Field(default=20000, description="Training steps (paper default 20000).")
    batch_size: int = Field(default=16, description="Trial minibatch size.")
    kernel: int = Field(default=32, description="Unfolder kernel width.")
    stride: int = Field(default=4, description="Unfolder stride.")
    ceb_hidden: int = Field(default=256, description="CEBRA hidden width.")
    ceb_out: int = Field(default=64, description="CEBRA embedding dimension.")
    hidden: int = Field(default=1024, description="CTC GRU hidden size.")
    layers: int = Field(default=5, description="CTC GRU layer count.")
    dropout: float = Field(default=0.4, description="CTC GRU dropout.")
    bidir: bool = Field(default=True, description="Bidirectional CTC GRU.")
    offset: int = Field(default=4, description="InfoNCE positive time offset.")
    cont_batch: int = Field(default=1024, description="InfoNCE triple count per step.")
    temperature: float = Field(default=0.4, description="InfoNCE temperature.")
    adv: AdvConfig = Field(
        default_factory=AdvConfig, description="Encoder adversarial PGD settings."
    )
    # multi_trainer_task_based.py (Tier A source of truth) uses batch % 50 == 0.
    # The single-dataset trainer.py uses 150; source-wins for the 4-session recipe.
    periodic_eval_every: int = Field(
        default=50,
        description="Run greedy CER every N steps.",
    )
    assume_yes: bool = Field(
        default=False,
        description="Skip Dryad download confirmation prompts.",
    )

    @field_validator("device", mode="before")
    @classmethod
    def _fold_device(cls, v: object) -> object:
        if not isinstance(v, str):
            return v
        folded = v.casefold()
        if folded == "cuda:0":
            return "cuda"
        return folded

    @field_validator("dataset_keys")
    @classmethod
    def _validate_dataset_keys(cls, v: list[str]) -> list[str]:
        return validate_dataset_keys(v, family="sequence")
