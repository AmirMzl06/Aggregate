"""L2 adversarial utilities and CEBRA-window PGD training step."""

from __future__ import annotations

from collections.abc import Callable

import numpy as np
import torch
from scipy.spatial import cKDTree

from acorn.log import get_logger
from acorn.utils.amp import amp_ctx

logger = get_logger(__name__)


def l2_normalize(t: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def rand_radius_like(t: torch.Tensor) -> torch.Tensor:
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float) -> torch.Tensor:
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta


def min_l2_distance_data(x: torch.Tensor, max_samples: int = 10_000) -> float:
    arr = x.float().cpu().numpy()
    if arr.shape[0] > max_samples:
        idx = np.random.choice(arr.shape[0], max_samples, replace=False)
        arr = arr[idx]
    arr = np.unique(arr, axis=0)
    if len(arr) < 2:
        return 1.0
    tree = cKDTree(arr)
    dists, _ = tree.query(arr, k=2, workers=-1)
    return float(np.min(dists[:, 1]))


def init_adv_noise(reference: torch.Tensor, adv_eps: float, adv_style: str, device: torch.device):
    """Initialize an L2 perturbation. ``oneshot`` / ``cluster_pgd`` permute (B,C,T)→(B,T,C)."""
    if adv_style == "oneshot":
        x_adv = reference.clone().detach().permute(0, 2, 1)
        noise = torch.randn_like(x_adv)
        noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
        noise = noise / noise_norm
        x_adv = x_adv + adv_eps * noise
        return x_adv.permute(0, 2, 1).detach()
    if adv_style == "cluster_pgd":
        x_adv = reference.clone().detach().permute(0, 2, 1)
        noise = torch.randn_like(x_adv)
        noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
        noise_normalized = noise / noise_norm
        noise_normalized *= torch.rand((noise.shape[0], noise.shape[1], 1), device=device) * adv_eps
        x_adv = x_adv + noise_normalized
        return x_adv.permute(0, 2, 1).detach()
    if adv_style == "bin":
        noise = torch.randn_like(reference)
        noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
        noise = noise / noise_norm
        noise *= torch.rand(reference.shape[0], reference.shape[1], 1, device=device) * adv_eps
        return (reference + noise).detach()
    noise = l2_normalize(torch.randn_like(reference))
    return (reference + noise * rand_radius_like(reference) * adv_eps).clone().detach()


def pgd_step(x_adv, grad, reference, adv_eps, alpha, adv_style):
    with torch.no_grad():
        if adv_style == "cluster_pgd":
            grad = grad.permute(0, 2, 1)
            x_adv = x_adv.permute(0, 2, 1)
            grad_norm = grad.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            x_adv = (x_adv + alpha * (grad / grad_norm)).detach()
            delta = x_adv - reference.permute(0, 2, 1)
            delta_norm = delta.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            scale = torch.clamp(adv_eps / delta_norm, max=1.0)
            delta = delta * scale
            return (reference + delta.permute(0, 2, 1)).detach()
        if adv_style == "bin":
            grad_norm = grad.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            x_adv = (x_adv + alpha * grad / grad_norm).detach()
            delta = x_adv - reference
            delta_norm = delta.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            return (reference + delta * torch.clamp(adv_eps / delta_norm, max=1.0)).detach()
        x_adv = x_adv + alpha * l2_normalize(grad)
        return proj_l2_ball(x_adv, reference, adv_eps)


def default_adv_alpha(adv_eps: float, adv_steps: int, adv_style: str) -> float:
    if adv_style == "bin":
        return 2.0 * adv_eps / adv_steps
    return adv_eps / 5.0


def l2_adv_cebra(
    model,
    optimizer,
    batch,
    session_name,
    criterion,
    adv_eps,
    adv_steps,
    adv_style: str = "global",
    adv_alpha: float | None = None,
    clip_grad_fn: Callable[[], None] | None = None,
):
    """L2 attack on CEBRA windows, then a second optimizer step.

    ``oneshot`` is a fixed-radius perturbation with no inner PGD loop.
    ``cluster_pgd`` is per-bin L2 over neurons after ``(B,C,T)→(B,T,C)``.
    ``bin`` / ``global`` keep the macaque geometries.
    """
    alpha = adv_alpha if adv_alpha is not None else default_adv_alpha(adv_eps, adv_steps, adv_style)
    device = batch.reference.device
    x_adv = init_adv_noise(batch.reference, adv_eps, adv_style, device)
    if adv_style != "oneshot":
        x_adv.requires_grad_(True)
        for _ in range(adv_steps):
            with amp_ctx(device):
                r_adv = model.encode_cebra_windows(x_adv, session_name)
                p = model.encode_cebra_windows(batch.positive, session_name)
                n = model.encode_cebra_windows(batch.negative, session_name)
                adv_loss, _, _ = criterion(r_adv, p, n)
            (grad_x,) = torch.autograd.grad(adv_loss, x_adv, retain_graph=False, create_graph=False)
            x_adv = pgd_step(x_adv, grad_x, batch.reference, adv_eps, alpha, adv_style)
            x_adv.requires_grad_(True)
        x_adv.requires_grad_(False)

    optimizer.zero_grad(set_to_none=True)
    with amp_ctx(device):
        r_adv = model.encode_cebra_windows(x_adv, session_name)
        p = model.encode_cebra_windows(batch.positive, session_name)
        n = model.encode_cebra_windows(batch.negative, session_name)
        adv_loss, _, _ = criterion(r_adv, p, n)
    if torch.isfinite(adv_loss):
        adv_loss.backward()
        if clip_grad_fn is not None:
            clip_grad_fn()
        optimizer.step()
    return adv_loss


def resolve_session_adv_eps(bundles, adv_eps, adv_eps_mode):
    """Return per-session L2 eps. ``min_dist_half`` uses 0.5 * nearest-neighbor L2 on day-0 train bins."""
    session_eps = {}
    for key, bundle in bundles.items():
        if adv_eps_mode == "min_dist_half":
            d = min_l2_distance_data(bundle["train_x"])
            session_eps[key] = 0.5 * d
            logger.info(
                "[AdvEps] %s: min_l2=%.4f → eps=%.4f (min_dist_half)",
                key,
                d,
                session_eps[key],
            )
        else:
            session_eps[key] = float(adv_eps)
    return session_eps
