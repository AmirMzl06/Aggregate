"""Training: adversarial PGD, CEBRA contrastive, encoder trainers.

``TrainConfig``, ``AdvConfig``, ``set_seed``, and ``SequenceTrainConfig``
are re-exported here.
"""

from typing import TYPE_CHECKING, Any

from acorn.train.encoder_trainer import EncoderTrainer, train_encoder_phase
from acorn.train.result import TrainResult

if TYPE_CHECKING:
    from acorn.train.config import AdvConfig, TrainConfig, set_seed
    from acorn.train.sequence.config import SequenceTrainConfig

__all__ = [
    "AdvConfig",
    "EncoderTrainer",
    "SequenceTrainConfig",
    "TrainConfig",
    "TrainResult",
    "set_seed",
    "train_encoder_phase",
]


def __getattr__(name: str) -> Any:
    if name in ("AdvConfig", "TrainConfig", "set_seed"):
        from acorn.train.config import AdvConfig, TrainConfig, set_seed

        mapping = {"AdvConfig": AdvConfig, "TrainConfig": TrainConfig, "set_seed": set_seed}
        globals().update(mapping)
        return mapping[name]
    if name == "SequenceTrainConfig":
        from acorn.train.sequence.config import SequenceTrainConfig

        globals()["SequenceTrainConfig"] = SequenceTrainConfig
        return SequenceTrainConfig
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
