"""Train hyperparameters (single source of truth for time-bin defaults)."""

from __future__ import annotations

import random
from typing import Any

import numpy as np
import torch
from pydantic import BaseModel, ConfigDict, Field, field_validator

from acorn.data.dataset_keys import validate_dataset_keys
from acorn.data.registry import DATASETS
from acorn.models.registry import DEFAULT_RECIPE

DEFAULT_DATASETS = ",".join(DATASETS)
N_BATCHES = 30000
N_DECODER_BATCHES = 30000


def set_seed(seed: int) -> None:
    """Seed Python, NumPy, and Torch (including CUDA when available).

    Parameters
    ----------
    seed : int
        RNG seed forwarded to ``random``, ``numpy.random``, and ``torch``.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class AdvConfig(BaseModel):
    """Adversarial PGD settings for encoder contrastive training.

    Nested on :class:`TrainConfig` and :class:`SequenceTrainConfig` as
    ``adv``. Field ``description`` values are the source of truth for each
    hyperparameter (including ``style`` values ``bin``, ``global``,
    ``oneshot``, and ``cluster_pgd``).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    enabled: bool = Field(
        default=True, description="Run encoder L2 PGD during contrastive training."
    )
    eps: float = Field(default=0.8, description="PGD radius.")
    eps_mode: str = Field(
        default="fixed",
        description="fixed: use eps; min_dist_half: per-session 0.5 * nearest-neighbor L2 on day-0 train bins.",
    )
    norm: str = Field(default="l2", description="PGD ball norm.")
    style: str = Field(
        default="bin",
        description=(
            "L2 PGD geometry: bin (macaque per-window), global (per-sample), "
            "oneshot (fixed-radius), or cluster_pgd (per-bin over neurons)."
        ),
    )
    alpha: float | None = Field(
        default=None,
        description="PGD step size. None selects the family default (eps/5 global, 2*eps/steps bin).",
    )
    steps: int = Field(default=10, description="PGD inner steps.")

    @field_validator("style")
    @classmethod
    def _validate_style(cls, v: str) -> str:
        if v in {"bin", "global", "oneshot", "cluster_pgd"}:
            return v
        raise ValueError("style must be 'bin', 'global', 'oneshot', or 'cluster_pgd'")


class TrainConfig(BaseModel):
    """Hyperparameters for time-bin (movement / EMG / position) training.

    One label vector per neural bin. :func:`acorn.runners.dispatch.train_model`
    runs a shared encoder, then per-session decoders. Defaults are the
    library values, not example-script overlays. ``dataset_keys`` is
    required; field descriptions document the rest.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    dataset_keys: list[str] = Field(description="Time-bin dataset registry keys for this run.")
    output_dir: str | None = Field(
        default=None,
        description="Ignored by core training (no run-directory writes). Examples may pass a path to save.",
    )
    seed: int = Field(default=42, description="RNG seed for Python, NumPy, and Torch.")
    device: str = Field(
        default="auto",
        pattern=r"^(auto|cpu|cuda)$",
        description="Device policy: auto, cpu, or cuda.",
    )
    offset: int = Field(default=4, description="Contrastive positive time offset.")
    batch_size: int = Field(default=256, description="CEBRA loader batch size.")
    n_batch: int = Field(
        default=N_BATCHES, description="Encoder training steps (paper default 30000)."
    )
    n_decoder_batches: int = Field(
        default=N_DECODER_BATCHES,
        description="Decoder training steps (paper default 30000).",
    )
    ceb_out: int = Field(default=64, description="CEBRA embedding dimension.")
    ceb_hidden: int = Field(default=256, description="CEBRA hidden width.")
    temperature: float = Field(default=0.4, description="InfoNCE temperature.")
    enc_lr: float = Field(default=3e-5, description="Encoder AdamW learning rate.")
    window: int = Field(default=256, description="Decoder embedding window length in bins.")
    time_offset: int = Field(
        default=4,
        description="CEBRA time_delta offset for behavior-guided contrastive sampling.",
    )
    encoder_val_checkpoint: bool = Field(
        default=True,
        description="Early-stop / best-checkpoint the encoder on validation InfoNCE.",
    )
    decoder_val_checkpoint: bool = Field(
        default=True,
        description="Early-stop / best-checkpoint each decoder on validation R².",
    )
    recipe: str = Field(default=DEFAULT_RECIPE, description="Registered time-bin recipe name.")
    adv: AdvConfig = Field(
        default_factory=AdvConfig, description="Encoder adversarial PGD settings."
    )
    conditional: str | None = Field(
        default="time_delta",
        description=(
            "CEBRA loader conditional. time_delta uses behavior; time uses time "
            "contrastive. None omits the kwarg on sklearn CEBRA (Perich time)."
        ),
    )
    decoder_adv: str = Field(
        default="off",
        description="Post-hoc decoder attack: off, oneshot, or pgd (cluster per-bin).",
    )
    mlp_decoder: bool = Field(
        default=False,
        description="Fit TwoLayerMLP on frozen embeddings instead of the GRU probe.",
    )
    full_session: bool = Field(
        default=False,
        description="Hippo-all: train and valid are the raw full trajectory, then independent z-score.",
    )
    assume_yes: bool = Field(
        default=False,
        description="Skip download confirmation prompts (Drive / Dryad).",
    )
    zscore: bool = Field(
        default=True,
        description="Z-score neuron spike rates per time bin.",
    )

    @field_validator("device", mode="before")
    @classmethod
    def _fold_device(cls, v: object) -> object:
        if not isinstance(v, str):
            return v
        folded = v.casefold()
        if folded == "cuda:0":
            return "cuda"
        return folded

    @field_validator("dataset_keys")
    @classmethod
    def _validate_dataset_keys(cls, v: list[str]) -> list[str]:
        return validate_dataset_keys(v, family="time_bin_aligned")

    @field_validator("conditional")
    @classmethod
    def _validate_conditional(cls, v: str | None) -> str | None:
        if v is None or v in {"time_delta", "time"}:
            return v
        raise ValueError("conditional must be 'time_delta', 'time', or None")

    @field_validator("decoder_adv")
    @classmethod
    def _validate_decoder_adv(cls, v: str) -> str:
        if v in {"off", "oneshot", "pgd"}:
            return v
        raise ValueError("decoder_adv must be 'off', 'oneshot', or 'pgd'")

    def to_legacy_dict(self) -> dict[str, Any]:
        """Dict shape expected by the runner / encoder trainer (legacy key names)."""
        return {
            "dataset_keys": list(self.dataset_keys),
            "output_dir": self.output_dir,
            "offset": self.offset,
            "batchSize": self.batch_size,
            "nBatch": self.n_batch,
            "n_decoder_batches": self.n_decoder_batches,
            "ceb_out": self.ceb_out,
            "ceb_hidden": self.ceb_hidden,
            "temperature": self.temperature,
            "enc_lr": self.enc_lr,
            "adv": self.adv.enabled,
            "adv_eps": self.adv.eps,
            "adv_eps_mode": self.adv.eps_mode,
            "adv_norm": self.adv.norm,
            "adv_style": self.adv.style,
            "adv_alpha": self.adv.alpha,
            "adv_steps": self.adv.steps,
            "window": self.window,
            "seed": self.seed,
            "device": self.device,
            "time_offset": self.time_offset,
            "encoder_val_checkpoint": self.encoder_val_checkpoint,
            "decoder_val_checkpoint": self.decoder_val_checkpoint,
            "recipe": self.recipe,
            "conditional": self.conditional,
            "decoder_adv": self.decoder_adv,
            "mlp_decoder": self.mlp_decoder,
            "full_session": self.full_session,
            "assume_yes": self.assume_yes,
            "zscore": self.zscore,
        }


def config_as_dict(config: TrainConfig) -> dict[str, Any]:
    """Serialize for debugging (includes nested adv)."""
    return config.model_dump()
