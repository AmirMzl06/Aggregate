"""sklearn CEBRA.fit trainer for the offset36_cebra recipe."""

from __future__ import annotations

import numpy as np
import torch

from acorn.utils.device import cebra_sklearn_device


def _numpy(x):
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().numpy()
    return np.asarray(x)


def _sklearn_device_str(device: torch.device) -> str:
    adapted = cebra_sklearn_device(device)
    if isinstance(adapted, torch.device):
        return "cpu" if adapted.type == "cpu" else f"cuda:{adapted.index or 0}"
    return str(adapted)


class CebraFitTrainer:
    """Call sklearn ``CEBRA(...).fit`` / ``.transform`` (N=1)."""

    def __init__(self, model, bundles, device, args: dict):
        self.model = model
        self.bundles = bundles
        self.device = device
        self.args = args

    def _cebra_kwargs(self, adv: bool) -> dict:
        from acorn.utils.vendor_path import ensure_vendored_on_path

        ensure_vendored_on_path()
        adv_eps = float(self.args.get("adv_eps", 0.5))
        kwargs = dict(
            model_architecture="offset36-model-more-dropout",
            batch_size=self.args.get("batchSize", 2048),
            temperature=self.args.get("temperature", 0.4),
            time_offsets=self.args.get("time_offset", self.args.get("offset", 4)),
            num_hidden_units=self.args.get("ceb_hidden", 256),
            max_iterations=self.args.get("nBatch", 5000),
            output_dimension=self.args.get("ceb_out", 64),
            learning_rate=3e-4,
            device=_sklearn_device_str(self.device),
            verbose=True,
            training_mode="adversarial" if adv else "clean",
            attack_norm="l2",
            adv_alternate=False,
            adv_epsilon=adv_eps,
            adv_alpha=self.args["adv_alpha"]
            if self.args.get("adv_alpha") is not None
            else adv_eps / 5.0,
            adv_steps=self.args.get("adv_steps", 10),
        )
        conditional = self.args.get("conditional")
        if conditional is not None:
            kwargs["conditional"] = conditional
        return kwargs

    def run(self) -> dict:
        from acorn.utils.vendor_path import ensure_vendored_on_path

        ensure_vendored_on_path()
        from cebra import CEBRA

        if len(self.bundles) != 1:
            raise ValueError("offset36_cebra fits a single session (N=1).")
        key, bundle = next(iter(self.bundles.items()))
        adv = bool(self.args.get("adv", False))
        data = _numpy(bundle["train_x"]).astype(np.float32)
        labels = _numpy(bundle["train_y"]).astype(np.float32)
        estimator = CEBRA(**self._cebra_kwargs(adv))
        conditional = self.args.get("conditional")
        if conditional in (None, "time"):
            estimator.fit(data)
        else:
            estimator.fit(data, labels)
        self.model.attach_estimator(estimator)
        return {
            "encoder_best_step": self.args.get("nBatch", 5000),
            "encoder_best_val_loss": float("nan"),
            "encoder_val_checkpoint": False,
            "session_adv_eps": {key: float(self.args.get("adv_eps", 0.5))} if adv else {},
            "enc_lr": 3e-4,
            "history": [],
            "sklearn_training_mode": "adversarial" if adv else "clean",
            "sklearn_adv_alternate": False,
            "sklearn_attack_norm": "l2",
        }
