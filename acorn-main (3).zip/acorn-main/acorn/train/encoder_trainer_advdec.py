"""Adversarial-decoder encoder trainer: Adam + LinearLR + grad clip.

Subclasses :class:`EncoderTrainer` directly so removing the default recipe
does not affect this file.
"""

from __future__ import annotations

import torch

from acorn.train.encoder_trainer import EncoderTrainer

LR_END = 0.002
WEIGHT_DECAY = 1e-5
ADAM_EPS = 0.1
GRAD_CLIP_NORM = 5.0


class AdvDecEncoderTrainer(EncoderTrainer):
    """Adam, linear decay from ``enc_lr`` to 0.002, clip-norm 5.0."""

    def build_optimizer(self, params):
        enc_lr = self.args.get("enc_lr", 3e-5)
        return torch.optim.Adam(params, lr=enc_lr, weight_decay=WEIGHT_DECAY, eps=ADAM_EPS)

    def build_scheduler(self, optimizer, n_batches):
        enc_lr = self.args.get("enc_lr", 3e-5)
        if enc_lr <= 0:
            raise ValueError("enc_lr must be > 0 for LinearLR")
        return torch.optim.lr_scheduler.LinearLR(
            optimizer,
            start_factor=1.0,
            end_factor=LR_END / enc_lr,
            total_iters=max(n_batches, 1),
        )

    def clip_grad(self, params) -> None:
        torch.nn.utils.clip_grad_norm_(params, GRAD_CLIP_NORM)
