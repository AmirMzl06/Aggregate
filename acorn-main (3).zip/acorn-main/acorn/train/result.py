"""In-memory artifacts returned by ``train_model`` (no run-directory writes)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TrainResult:
    """Live model plus RAM eval artifacts returned by ``train_model``.

    ``decoders`` holds fitted per-session decoder modules (time-bin).
    Sequence runs leave it empty; CTC heads live on ``model``. ``plots``
    holds plot payloads and/or sequence export tensors — never paths to
    files core wrote.
    """

    model: Any
    decoders: dict[str, Any] = field(default_factory=dict)
    metrics: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)
    plots: dict[str, Any] = field(default_factory=dict)
