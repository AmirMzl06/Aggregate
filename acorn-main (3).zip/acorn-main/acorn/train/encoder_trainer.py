"""CEBRA time_delta contrastive encoder training.

:class:`EncoderTrainer` is the default trainer: AdamW, no scheduler,
no grad clip. Recipe-specific trainers subclass it and override
``build_optimizer`` / ``build_scheduler`` / ``clip_grad``.
"""

from __future__ import annotations

import copy

import torch
from tqdm import trange

from acorn.log import get_logger
from acorn.train.adversarial import l2_adv_cebra, resolve_session_adv_eps
from acorn.train.cebra_contrastive import build_cebra_loader, build_cebra_train_dataset
from acorn.utils.amp import amp_ctx
from acorn.utils.validation import MIN_EPOCHS, PATIENCE

LOG_EVERY = 200
logger = get_logger(__name__)


def _contrastive_criterion(temperature: float, device: torch.device):
    from acorn.utils.vendor_path import ensure_vendored_on_path

    ensure_vendored_on_path()
    import cebra

    return cebra.models.FixedCosineInfoNCE(temperature).to(device)


def _eval_encoder_val_loss(
    model,
    val_datasets,
    session_names,
    criterion,
    device,
    batch_size,
    time_offset,
    conditional="time_delta",
    is_cont=None,
):
    model.eval()
    losses = []
    with torch.no_grad():
        for key, val_ds in zip(session_names, val_datasets, strict=True):
            loader = build_cebra_loader(
                val_ds,
                batch_size,
                1,
                time_offset,
                conditional=conditional,
                is_cont=is_cont,
            )
            batch = next(iter(loader))
            batch.to(device)
            with amp_ctx(device):
                r = model.encode_cebra_windows(batch.reference, key)
                p = model.encode_cebra_windows(batch.positive, key)
                n = model.encode_cebra_windows(batch.negative, key)
                loss, _, _ = criterion(r, p, n)
            if torch.isfinite(loss):
                losses.append(float(loss.item()))
    model.monkey_encoder.train(True)
    return sum(losses) / max(len(losses), 1)


class EncoderTrainer:
    """Default encoder training loop (offset36_gru)."""

    def __init__(self, model, bundles, device, args: dict):
        self.model = model
        self.bundles = bundles
        self.device = device
        self.args = args

    def build_optimizer(self, params):
        enc_lr = self.args.get("enc_lr", 3e-5)
        return torch.optim.AdamW(params, lr=enc_lr, weight_decay=0.01)

    def build_scheduler(self, optimizer, n_batches):
        return None

    def clip_grad(self, params) -> None:
        return None

    def run(self) -> dict:
        model = self.model
        bundles = self.bundles
        device = self.device
        args = self.args

        n_batches = args["nBatch"]
        batch_size = args.get("batchSize", 256)
        time_offset = args.get("time_offset", 4)
        temperature = args.get("temperature", 0.4)
        enc_lr = args.get("enc_lr", 3e-5)
        adv = args.get("adv", True)
        # Deferred: config imports the recipe registry, which imports this module.
        from acorn.train.config import AdvConfig

        adv_eps = args.get("adv_eps", AdvConfig().eps)
        adv_eps_mode = args.get("adv_eps_mode", "fixed")
        adv_norm = args.get("adv_norm", "l2")
        adv_steps = args.get("adv_steps", 10)
        adv_style = args.get("adv_style", "bin")
        adv_alpha = args.get("adv_alpha")
        use_val_checkpoint = args.get("encoder_val_checkpoint", True)
        min_epochs = args.get("encoder_min_epochs", MIN_EPOCHS)
        patience = args.get("encoder_patience", PATIENCE)
        conditional = args.get("conditional") or "time_delta"
        groups = {bundles[k].get("dataset_group") for k in bundles}
        # Perich Offset36_multi --time: cluster is_cont=not time (False) while labels stay.
        if conditional == "time" and groups == {"perich"}:
            loader_is_cont = False
        else:
            loader_is_cont = None

        criterion = _contrastive_criterion(temperature, device)
        enc_params = list(model.encoder_parameters())
        optimizer = self.build_optimizer(enc_params)
        scheduler = self.build_scheduler(optimizer, n_batches)

        model.freeze_decoder()
        model.unfreeze_encoder()
        model.encoder_train(True)
        model.decoder_train(False)

        offset_obj = model.get_offset()
        session_names = list(bundles.keys())
        session_adv_eps = resolve_session_adv_eps(bundles, adv_eps, adv_eps_mode) if adv else {}
        loaders = []
        val_datasets = []
        for key in session_names:
            train_x = bundles[key]["train_x"]
            train_y = bundles[key]["train_y"]
            train_dataset = build_cebra_train_dataset(train_x, train_y, offset_obj, device)
            if use_val_checkpoint:
                # Validate on the full day-0 train split (no held-out encoder val slice).
                val_datasets.append(train_dataset)
            loader = build_cebra_loader(
                train_dataset,
                batch_size,
                n_batches,
                time_offset,
                conditional=conditional,
                is_cont=loader_is_cont,
            )
            loaders.append(iter(loader))

        last_losses = {n: torch.tensor(0.0) for n in session_names}
        last_adv = torch.tensor(0.0)
        best_step = 0
        best_val_loss = float("inf")
        bad = 0
        best_state = None
        history: list[dict] = []

        for step in trange(n_batches, desc="[Phase 1] Encoder (CEBRA time_delta)"):
            model.monkey_encoder.train(True)
            session_idx = step % len(session_names)
            session_name = session_names[session_idx]

            optimizer.zero_grad(set_to_none=True)
            batch = next(loaders[session_idx])
            batch.to(device)

            with amp_ctx(device):
                r = model.encode_cebra_windows(batch.reference, session_name)
                p = model.encode_cebra_windows(batch.positive, session_name)
                n = model.encode_cebra_windows(batch.negative, session_name)
                loss, _, _ = criterion(r, p, n)
            last_losses[session_name] = loss.detach()

            if torch.isfinite(loss):
                loss.backward()
                self.clip_grad(enc_params)
                optimizer.step()

            if adv and adv_norm == "l2":
                last_adv = l2_adv_cebra(
                    model,
                    optimizer,
                    batch,
                    session_name,
                    criterion,
                    session_adv_eps[session_name],
                    adv_steps,
                    adv_style=adv_style,
                    adv_alpha=adv_alpha,
                    clip_grad_fn=lambda: self.clip_grad(enc_params),
                )

            if scheduler is not None:
                scheduler.step()

            if use_val_checkpoint:
                vloss = _eval_encoder_val_loss(
                    model,
                    val_datasets,
                    session_names,
                    criterion,
                    device,
                    batch_size,
                    time_offset,
                    conditional=conditional,
                    is_cont=loader_is_cont,
                )
                if vloss < best_val_loss:
                    best_val_loss = vloss
                    best_step = step + 1
                    bad = 0
                    best_state = copy.deepcopy(model.state_dict())
                    history.append(
                        {
                            "phase": "encoder_best",
                            "step": best_step,
                            "val_loss": float(best_val_loss),
                        }
                    )
                elif best_step == 0 and vloss < float("inf"):
                    best_val_loss = vloss
                    best_step = step + 1
                    best_state = copy.deepcopy(model.state_dict())
                    history.append(
                        {
                            "phase": "encoder_best",
                            "step": best_step,
                            "val_loss": float(best_val_loss),
                        }
                    )
                else:
                    if step >= min_epochs - patience:
                        bad += 1
                    if bad >= patience:
                        logger.info(
                            "[EncEarlyStop] step=%s, best_step=%s, best_val_loss=%.4f",
                            step + 1,
                            best_step,
                            best_val_loss,
                        )
                        break

            record = {
                "phase": "encoder_step",
                "step": step,
                "losses": {k: float(last_losses[k].item()) for k in session_names},
            }
            if adv:
                record["adv"] = float(last_adv.item())
            if use_val_checkpoint:
                record["val_loss"] = float(best_val_loss) if best_val_loss < float("inf") else None
            history.append(record)
            if step % LOG_EVERY == 0:
                parts = "  ".join(f"{k}={last_losses[k].item():.4f}" for k in session_names)
                adv_tag = f"  adv={last_adv.item():.4f}" if adv else ""
                val_tag = f"  val_loss={best_val_loss:.4f}" if use_val_checkpoint else ""
                logger.info("[enc %5d/%s]  %s%s%s", step, n_batches, parts, adv_tag, val_tag)

        if use_val_checkpoint and best_state is not None:
            model.load_state_dict(best_state)
            logger.info("[EncBestCheckpoint] step=%s, val_loss=%.4f", best_step, best_val_loss)
        elif use_val_checkpoint and best_step == 0:
            best_step = 1
            logger.info(
                "[EncBestCheckpoint] step=1 (no improvement tracked), val_loss=%.4f",
                best_val_loss,
            )

        return {
            "encoder_best_step": best_step if use_val_checkpoint else n_batches,
            "encoder_best_val_loss": best_val_loss if use_val_checkpoint else float("nan"),
            "encoder_val_checkpoint": use_val_checkpoint,
            "session_adv_eps": session_adv_eps,
            "enc_lr": enc_lr,
            "history": history,
        }


def train_encoder_phase(model, bundles, device, args: dict) -> dict:
    """Backward-compatible wrapper around :class:`EncoderTrainer`."""
    return EncoderTrainer(model, bundles, device, args).run()
