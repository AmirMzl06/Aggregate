"""CEBRA dataset/loader helpers for single-session time_delta contrastive training."""

from __future__ import annotations

from collections.abc import Iterable

import cebra
from acorn.utils.device import cebra_sklearn_device


def init_loader(
    is_cont: bool,
    is_disc: bool,
    is_full: bool,
    is_multi: bool,
    is_hybrid: bool,
    shared_kwargs: dict,
    extra_kwargs: dict,
):
    """Select a CEBRA loader for single-session continuous training."""
    incompatible_combinations = [
        (not is_cont, not is_disc, is_hybrid),
        (not is_cont, not is_disc, is_multi),
    ]
    if any(all(combination) for combination in incompatible_combinations):
        raise ValueError("Invalid index combination.")

    if "conditional" in extra_kwargs and extra_kwargs["conditional"] is None:
        del extra_kwargs["conditional"]

    if "time_offsets" in extra_kwargs:
        time_offsets = extra_kwargs["time_offsets"]
        if isinstance(time_offsets, Iterable) and not isinstance(time_offsets, str | bytes):
            offsets_list = list(time_offsets)
            if len(offsets_list) > 1:
                raise NotImplementedError(
                    "Support for multiple time offsets is not yet implemented."
                )
            (time_offsets,) = offsets_list
            extra_kwargs["time_offsets"] = time_offsets
            if not isinstance(extra_kwargs["time_offsets"], int):
                raise TypeError(f"Invalid type for time_offsets: {type(time_offsets)}")

    if is_multi:
        raise NotImplementedError("Multi-session loaders are not supported here.")

    if not is_cont and not is_disc:
        kwargs = dict(
            conditional="time",
            time_offset=extra_kwargs["time_offsets"],
            **shared_kwargs,
        )
        if is_full:
            if is_hybrid:
                raise NotImplementedError("Hybrid full-dataset loader not supported.")
            return cebra.data.FullDataLoader(**kwargs), "single-session-full"
        if is_hybrid:
            raise NotImplementedError("Hybrid time-only loader not supported.")
        return cebra.data.ContinuousDataLoader(**kwargs), "single-session"

    if is_cont and not is_disc:
        kwargs = dict(
            conditional=extra_kwargs.get("conditional", "time_delta"),
            time_offset=extra_kwargs["time_offsets"],
            delta=extra_kwargs.get("delta"),
            **shared_kwargs,
        )
        if is_full:
            if is_hybrid:
                raise NotImplementedError("Hybrid full-dataset loader not supported.")
            return cebra.data.FullDataLoader(**kwargs), "single-session-full"
        if is_hybrid:
            return cebra.data.HybridDataLoader(**kwargs), "single-session-hybrid"
        return cebra.data.ContinuousDataLoader(**kwargs), "single-session"

    raise RuntimeError(
        "Unsupported loader configuration. Expected single-session continuous or time-only training."
    )


def build_cebra_train_dataset(train_x, train_y, offset_obj, device):
    if hasattr(train_x, "cpu"):
        train_x = train_x.cpu().numpy()
    if hasattr(train_y, "cpu"):
        train_y = train_y.cpu().numpy()

    dataset = cebra.integrations.sklearn.dataset.SklearnDataset(
        train_x.astype(float), (train_y.astype(float),), device=cebra_sklearn_device(device)
    )
    dataset.offset = offset_obj
    dataset.trial_ids = None
    return dataset


def build_cebra_loader(
    train_dataset,
    batch_size: int,
    num_steps: int,
    time_offset: int = 4,
    conditional: str = "time_delta",
    is_cont: bool | None = None,
):
    """Build a single-session CEBRA loader.

    When ``is_cont`` is None, it follows whether the dataset has a continuous
    index. Perich Offset36_multi time-only passes ``is_cont=False`` while keeping
    labels on the dataset. Hippo time-only keeps labels and only sets
    ``conditional="time"``.
    """
    if is_cont is None:
        is_cont = train_dataset.continuous_index is not None
    loader, _ = init_loader(
        is_cont=is_cont,
        is_disc=train_dataset.discrete_index is not None,
        is_hybrid=False,
        is_full=False,
        is_multi=False,
        shared_kwargs=dict(
            dataset=train_dataset,
            batch_size=batch_size,
            num_steps=num_steps,
        ),
        extra_kwargs=dict(
            time_offsets=time_offset,
            conditional=conditional if conditional is not None else "time",
            delta=None,
        ),
    )
    return loader
