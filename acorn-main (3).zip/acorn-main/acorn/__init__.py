"""acorn: multi-session CEBRA encoder for monkey reach/EMG and sequence/B2T."""

from __future__ import annotations

# Vendored ``cebra/`` and ``xds/`` are in git next to this package, not PyPI
# deps. ``import acorn`` puts the repo root on ``sys.path``.
from acorn.utils.vendor_path import ensure_vendored_on_path

ensure_vendored_on_path()

try:
    from importlib.metadata import PackageNotFoundError, version

    try:
        __version__ = version("acorn")
    except PackageNotFoundError:
        __version__ = "0.1.0"
except ImportError:  # pragma: no cover
    __version__ = "0.1.0"

from acorn.data.registry import (
    DATASET_REGISTRY,
    DATASETS,
    DatasetSpec,
    get_dataset,
    list_datasets,
)
from acorn.data.sequence.registry import (
    SEQUENCE_DATASET_REGISTRY,
    SequenceDatasetSpec,
    get_sequence_dataset,
)
from acorn.log import get_logger, set_verbosity
from acorn.models.registry import (
    DEFAULT_RECIPE,
    DEFAULT_SEQUENCE_RECIPE,
    RECIPE_REGISTRY,
    SEQUENCE_RECIPE_REGISTRY,
    RecipeSpec,
    SequenceRecipeSpec,
    get_recipe,
    get_sequence_recipe,
    list_recipes,
    register_recipe,
    register_sequence_recipe,
)
from acorn.runners.dispatch import train_model
from acorn.train.config import AdvConfig, TrainConfig, set_seed
from acorn.train.result import TrainResult
from acorn.train.sequence.config import SequenceTrainConfig

__all__ = [
    "AdvConfig",
    "DATASET_REGISTRY",
    "DATASETS",
    "DEFAULT_RECIPE",
    "DEFAULT_SEQUENCE_RECIPE",
    "DatasetSpec",
    "RECIPE_REGISTRY",
    "SEQUENCE_DATASET_REGISTRY",
    "SEQUENCE_RECIPE_REGISTRY",
    "RecipeSpec",
    "SequenceDatasetSpec",
    "SequenceRecipeSpec",
    "SequenceTrainConfig",
    "TrainConfig",
    "TrainResult",
    "__version__",
    "get_dataset",
    "get_logger",
    "get_recipe",
    "get_sequence_dataset",
    "get_sequence_recipe",
    "list_datasets",
    "list_recipes",
    "register_recipe",
    "register_sequence_recipe",
    "set_seed",
    "set_verbosity",
    "train_model",
]
