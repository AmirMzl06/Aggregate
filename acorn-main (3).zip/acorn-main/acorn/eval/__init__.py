"""Evaluation: windowed R^2, decoder probes, plot export."""

from acorn.eval.adv import l2_attack_eval
from acorn.eval.consistency import session_consistency_score
from acorn.eval.decoder_probe import evaluate_embedding_decoders, train_session_decoder
from acorn.eval.noise import score_under_gaussian_noise
from acorn.eval.windowed import collect_stream_trial_predictions, evaluate_r2
from acorn.utils.amp import amp_ctx

__all__ = [
    "amp_ctx",
    "collect_stream_trial_predictions",
    "evaluate_embedding_decoders",
    "evaluate_r2",
    "l2_attack_eval",
    "score_under_gaussian_noise",
    "session_consistency_score",
    "train_session_decoder",
]
