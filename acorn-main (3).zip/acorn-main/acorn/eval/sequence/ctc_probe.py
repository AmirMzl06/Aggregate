"""Greedy CTC decode and corpus CER (global ratio, not mean of per-trial CERs)."""

from __future__ import annotations

import torch
from torch.utils.data import DataLoader

from acorn.data.sequence.collate import SequenceSplit, TrialDataset, collate_fn
from acorn.log import get_logger
from acorn.utils.amp import amp_ctx

logger = get_logger(__name__)


def greedy_decode(
    logits: torch.Tensor, input_lengths: torch.Tensor, blank: int = 0
) -> list[list[int]]:
    decoded: list[list[int]] = []
    for i in range(logits.shape[0]):
        length = int(input_lengths[i].item())
        seq = torch.argmax(logits[i, :length, :], dim=-1)
        seq = torch.unique_consecutive(seq)
        seq = seq[seq != blank]
        decoded.append(seq.detach().cpu().tolist())
    return decoded


def edit_distance(a: list[int], b: list[int]) -> int:
    n, m = len(a), len(b)
    dp = list(range(m + 1))
    for i in range(1, n + 1):
        prev = dp[0]
        dp[0] = i
        for j in range(1, m + 1):
            cur = dp[j]
            if a[i - 1] == b[j - 1]:
                dp[j] = prev
            else:
                dp[j] = 1 + min(prev, dp[j], dp[j - 1])
            prev = cur
    return dp[m]


def corpus_cer(hypotheses: list[list[int]], references: list[list[int]]) -> float:
    total_edit = 0
    total_len = 0
    for hyp, ref in zip(hypotheses, references, strict=True):
        total_edit += edit_distance(hyp, ref)
        total_len += len(ref)
    if total_len == 0:
        return 0.0
    return total_edit / total_len


def _true_seqs(y: torch.Tensor, y_len: torch.Tensor) -> list[list[int]]:
    out = []
    for i in range(y.shape[0]):
        length = int(y_len[i].item())
        out.append(y[i, :length].detach().cpu().tolist())
    return out


@torch.no_grad()
def evaluate_split(
    model,
    session_key: str,
    split: SequenceSplit,
    device: torch.device,
    batch_size: int = 16,
    blank: int = 0,
) -> dict[str, float]:
    loader = DataLoader(
        TrialDataset(split),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=collate_fn,
    )
    ctc_criterion = torch.nn.CTCLoss(blank=blank, reduction="mean", zero_infinity=True)
    hyps: list[list[int]] = []
    refs: list[list[int]] = []
    losses: list[float] = []
    model.eval()
    for x, y, x_len, y_len in loader:
        x = x.to(device)
        y = y.to(device)
        x_len = x_len.to(device)
        y_len = y_len.to(device)
        with amp_ctx(device):
            pred, lengths = model(x, x_len, session_key)
            loss = ctc_criterion(pred.log_softmax(2).permute(1, 0, 2), y, lengths, y_len)
        if torch.isfinite(loss):
            losses.append(float(loss.item()))
        hyps.extend(greedy_decode(pred, lengths, blank=blank))
        refs.extend(_true_seqs(y, y_len))
    cer = corpus_cer(hyps, refs)
    avg_loss = sum(losses) / max(len(losses), 1)
    return {"cer": cer, "ctc_loss": avg_loss, "n_trials": float(len(refs))}


def evaluate_sequence_sessions(
    model,
    sessions: dict,
    device: torch.device,
    batch_size: int = 16,
    use_final: bool = True,
) -> dict:
    """Per-session greedy CER.

    Parameters
    ----------
    model
        Sequence model with a CTC head.
    sessions : dict
        Mapping of dataset key to ``SequenceSession``.
    device : torch.device
        Torch device.
    batch_size : int, optional
        Eval minibatch size.
    use_final : bool, optional
        If True (default), use ``final_eval`` (ctc_probe / export). If
        False, use ``periodic_eval``.

    Returns
    -------
    dict
        Per-key ``cer``, ``ctc_loss``, ``n_trials``, and split name.
    """
    metrics = {}
    for key, session in sessions.items():
        split = session.final_eval if use_final else session.periodic_eval
        result = evaluate_split(
            model,
            session.session_key,
            split,
            device,
            batch_size=batch_size,
            blank=session.blank_index,
        )
        metrics[key] = {
            "dataset": key,
            "task_key": session.task_key,
            "cer": result["cer"],
            "ctc_loss": result["ctc_loss"],
            "n_trials": int(result["n_trials"]),
            "split": "final" if use_final else "periodic",
        }
        logger.info("--- %s (%s) ---", key, session.task_key)
        logger.info("  CER = %.4f  CTC = %.4f", result["cer"], result["ctc_loss"])
    return metrics
