"""LM-adapter export contract.

Acorn-native, self-describing schema — not CORP's folder-name sniffing.
Every field a reader needs is an explicit key.

Core returns in-memory payloads. Examples may write the on-disk layout::

    {
      "schema": "acorn.ctc_export.v1.1",
      "datasets": [
        {
          "dataset_key": "nlp21",
          "task_key": "nlp",
          "session_key": "nlp21",
          "vocab": ["<BLANK>", ">", ...],
          "blank_index": 0,
          "path": "nlp21_logits.pt",
          "has_transcripts": true
        }
      ]
    }

Each session bundle dict has:

- ``logits``: list of float tensors ``(T_i, C)`` (unpadded per trial)
- ``input_lengths``: 1-d long tensor
- ``label_ids``: list of long tensors (true CTC ids)
- ``transcripts`` (optional v1.1): list of English strings aligned to logits order
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from acorn.data.sequence.collate import TrialDataset, collate_fn
from acorn.data.sequence.loaders.nlp10 import collect_nlp10_final_transcripts
from acorn.data.sequence.loaders.nlp21 import collect_nlp21_final_transcripts
from acorn.data.sequence.loaders.speech24 import collect_speech24_final_transcripts
from acorn.data.sequence.loaders.speech45 import collect_speech45_final_transcripts
from acorn.utils.amp import amp_ctx
from acorn.utils.constants import DATA_DIR

SCHEMA = "acorn.ctc_export.v1.1"
SCHEMA_LEGACY = "acorn.ctc_export.v1"

TRANSCRIPT_COLLECTORS: dict[str, Callable[[Path], list[str]]] = {
    "nlp10": collect_nlp10_final_transcripts,
    "nlp21": collect_nlp21_final_transcripts,
    "speech24": collect_speech24_final_transcripts,
    "speech45": collect_speech45_final_transcripts,
}


def collect_final_eval_transcripts(
    session_key: str, data_dir: Path | None = None
) -> list[str] | None:
    collector = TRANSCRIPT_COLLECTORS.get(session_key)
    if collector is None:
        return None
    root = Path(data_dir) if data_dir is not None else DATA_DIR / session_key
    try:
        transcripts = collector(root)
    except (OSError, ValueError, KeyError):
        return None
    return transcripts


@torch.no_grad()
def export_session_logits(
    model,
    session,
    device: torch.device,
    batch_size: int = 16,
    transcripts: list[str] | None = None,
) -> dict:
    loader = DataLoader(
        TrialDataset(session.final_eval),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=collate_fn,
    )
    logits_list: list[torch.Tensor] = []
    lengths_list: list[int] = []
    labels_list: list[torch.Tensor] = []
    model.eval()
    for x, y, x_len, y_len in loader:
        x = x.to(device)
        x_len = x_len.to(device)
        with amp_ctx(device):
            pred, lengths = model(x, x_len, session.session_key)
        for i in range(pred.shape[0]):
            t = int(lengths[i].item())
            logits_list.append(pred[i, :t].detach().cpu().float())
            lengths_list.append(t)
            n_lab = int(y_len[i].item())
            labels_list.append(y[i, :n_lab].detach().cpu().long())
    if transcripts is not None and len(transcripts) != len(logits_list):
        raise ValueError(
            f"{session.session_key}: len(transcripts)={len(transcripts)} != "
            f"len(logits)={len(logits_list)}"
        )
    bundle = {
        "logits": logits_list,
        "input_lengths": torch.tensor(lengths_list, dtype=torch.long),
        "label_ids": labels_list,
        "dataset_key": session.session_key,
        "task_key": session.task_key,
        "session_key": session.session_key,
        "vocab": list(session.vocab),
        "blank_index": session.blank_index,
    }
    if transcripts is not None:
        bundle["transcripts"] = list(transcripts)
    return bundle


def _entry_from_bundle(bundle: dict) -> dict:
    return {
        "dataset_key": bundle["dataset_key"],
        "task_key": bundle["task_key"],
        "session_key": bundle["session_key"],
        "vocab": list(bundle["vocab"]),
        "blank_index": bundle["blank_index"],
        "has_transcripts": bundle.get("transcripts") is not None,
    }


def export_all_sessions(
    model,
    sessions: dict,
    device: torch.device,
    batch_size: int = 16,
    data_dir: Path | None = None,
    use_lm: bool = False,
    assume_yes: bool = False,
) -> dict:
    """Export logits for every session (``acorn.ctc_export.v1.1``).

    Parameters
    ----------
    model
        Sequence model with a CTC head.
    sessions : dict
        Mapping of dataset key to ``SequenceSession``.
    device : torch.device
        Torch device.
    batch_size : int, optional
        Export minibatch size.
    data_dir : pathlib.Path, optional
        Data root for collecting transcripts.
    use_lm : bool, optional
        If True, run optional language-model rescoring in this call.
    assume_yes : bool, optional
        Skip download confirmation when ``use_lm`` fetches graphs.

    Returns
    -------
    dict
        Schema, per-dataset entries, and session bundles. Includes ``lm``
        when ``use_lm`` is True.
    """
    if use_lm:
        from acorn.lm.runtime import require_lm_runtime

        require_lm_runtime(
            [session.task_key for session in sessions.values()],
            assume_yes=assume_yes,
        )
    entries = []
    bundles = {}
    for session in sessions.values():
        transcripts = collect_final_eval_transcripts(session.session_key, data_dir=data_dir)
        bundle = export_session_logits(
            model,
            session,
            device,
            batch_size=batch_size,
            transcripts=transcripts,
        )
        bundles[session.session_key] = bundle
        entries.append(_entry_from_bundle(bundle))
    payload = {"schema": SCHEMA, "datasets": entries, "sessions": bundles}
    if use_lm:
        from acorn.lm.runtime import rescore_session_exports
        from acorn.lm.schema import session_from_bundle

        report = rescore_session_exports(
            [session_from_bundle(bundle) for bundle in bundles.values()],
            assume_yes=assume_yes,
        )
        return {**payload, "lm": report}
    return payload
