"""Dataset metadata for plot_data export (derived from DATASET_REGISTRY)."""

from acorn.data.registry import (
    CURSOR_LABEL_NAMES,
    DATASET_REGISTRY,
    JANGO_LABEL_NAMES,
    POP_LABEL_NAMES,
)

# Re-export label-name constants for callers that imported them from here.
__all__ = [
    "BIN_SIZE",
    "CURSOR_LABEL_NAMES",
    "FIGURE2_DAY_K",
    "JANGO_LABEL_NAMES",
    "PLOT_DEFAULTS",
    "POP_LABEL_NAMES",
    "SHOWCASE_LEN",
    "SHOWCASE_SEC",
    "figure2_dayk_index",
    "label_names_for_dataset",
    "plot_channel_indices",
    "resolve_channel_indices",
    "showcase_len_for",
    "showcase_step_for",
    "RTM_TRIAL_INDICES",
    "COM_N_SHOW",
    "EMG_SHOWCASE",
]

PLOT_DEFAULTS = {}
for _key, _spec in DATASET_REGISTRY.items():
    if not _spec.train_enabled:
        continue
    _entry = {
        "plot_type": _spec.plot_type,
        "panel": _spec.panel,
        "title": _spec.title,
        "label_names": list(_spec.label_names),
    }
    if _spec.plot_channels is not None:
        _entry["plot_channels"] = list(_spec.plot_channels)
        _entry["plot_channel_display"] = list(_spec.plot_channel_display or _spec.plot_channels)
    if _spec.pos_dims is not None:
        _entry["pos_dims"] = list(_spec.pos_dims)  # type: ignore[arg-type]
    PLOT_DEFAULTS[_key] = _entry

FIGURE2_DAY_K = {
    key: spec.dayk_override
    for key, spec in DATASET_REGISTRY.items()
    if spec.train_enabled and spec.dayk_override is not None
}

BIN_SIZE = 0.05
SHOWCASE_SEC = 2.0
SHOWCASE_LEN = int(SHOWCASE_SEC / BIN_SIZE)
SHOWCASE_SEC_BY_DATASET = {"pop": 2.5}

RTM_TRIAL_INDICES = {
    "day0": (21, 10, 12, 26, 22),
    "dayk": (3, 20, 5, 26, 25),
}
COM_N_SHOW = 48
EMG_SHOWCASE = {
    "pop": {"day0": (2, 12), "dayk": (5, 7)},
    "jango": {"day0": (3, 0), "dayk": (3, 0)},
}


def showcase_len_for(dataset_key: str) -> int:
    seconds = SHOWCASE_SEC_BY_DATASET.get(dataset_key, SHOWCASE_SEC)
    return int(round(seconds / BIN_SIZE))


def showcase_step_for(dataset_key: str) -> int | None:
    if dataset_key in SHOWCASE_SEC_BY_DATASET:
        return 1
    return None


def figure2_dayk_index(dataset_key: str, num_days: int) -> int:
    spec = DATASET_REGISTRY.get(dataset_key)
    if spec is not None and spec.dayk_override is not None:
        return spec.dayk_override
    return FIGURE2_DAY_K.get(dataset_key, num_days - 1)


def label_names_for_dataset(dataset_key: str, n_labels: int) -> list[str]:
    names = PLOT_DEFAULTS.get(dataset_key, {}).get("label_names")
    if names and len(names) == n_labels:
        return list(names)
    return [f"dim_{i}" for i in range(n_labels)]


def resolve_channel_indices(label_names: list[str], channel_names: list[str]) -> list[int]:
    indices = []
    for name in channel_names:
        if name in label_names:
            indices.append(label_names.index(name))
            continue
        matches = [i for i, ln in enumerate(label_names) if name in ln or ln in name]
        if len(matches) == 1:
            indices.append(matches[0])
        elif name == "ECRI":
            for candidate in ("EMG_ECRl", "EMG_ECRb", "ECR"):
                if candidate in label_names:
                    indices.append(label_names.index(candidate))
                    break
            else:
                raise KeyError(f"Cannot resolve channel {name!r} in {label_names}")
        else:
            raise KeyError(f"Cannot resolve channel {name!r} in {label_names}")
    return indices


def plot_channel_indices(dataset_key: str, n_labels: int) -> tuple[list[int], list[str]]:
    cfg = PLOT_DEFAULTS[dataset_key]
    label_names = label_names_for_dataset(dataset_key, n_labels)
    if cfg["plot_type"] == "emg":
        indices = resolve_channel_indices(label_names, list(cfg["plot_channels"]))
        display = list(cfg.get("plot_channel_display", cfg["plot_channels"]))
        return indices, display
    return [int(x) for x in cfg["pos_dims"]], ["x", "y"]
