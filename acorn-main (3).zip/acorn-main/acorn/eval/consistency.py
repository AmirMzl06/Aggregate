"""Per-session embedding consistency. Never vstack session arrays."""

from __future__ import annotations

from acorn.utils.vendor_path import ensure_vendored_on_path


def session_consistency_score(
    embeddings: list,
    labels: list | None = None,
    *,
    dataset_ids: list[str] | None = None,
    points: int = 3000,
    between: str = "datasets",
):
    """Wrap sklearn CEBRA consistency on a list of per-session embeddings."""
    if not embeddings:
        raise ValueError("embeddings must be a non-empty per-session list")
    ensure_vendored_on_path()
    import cebra

    ids = dataset_ids if dataset_ids is not None else [str(i) for i in range(len(embeddings))]
    kwargs = dict(
        embeddings=list(embeddings),
        dataset_ids=list(ids),
        between=between,
        num_discretization_bins=points,
    )
    if labels is not None:
        kwargs["labels"] = list(labels)
    return cebra.sklearn.metrics.consistency_score(**kwargs)
