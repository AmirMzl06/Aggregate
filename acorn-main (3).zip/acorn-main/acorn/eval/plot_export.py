"""Export trial predictions as in-memory payloads (see plot/)."""

from __future__ import annotations

import os
from typing import Any

import numpy as np

from acorn.data.splits import TRAIN_FRAC, load_day_trials
from acorn.eval.plot_config import (
    BIN_SIZE,
    EMG_SHOWCASE,
    PLOT_DEFAULTS,
    RTM_TRIAL_INDICES,
    SHOWCASE_LEN,
    label_names_for_dataset,
    plot_channel_indices,
    showcase_len_for,
)
from acorn.eval.windowed import collect_stream_trial_predictions


def _load_trial_target_dirs(
    loader, dataset_name: str, day_idx: int
) -> tuple[np.ndarray, np.ndarray] | None:
    if dataset_name == "Pop_PG_2021":
        return None
    if "CO" not in dataset_name and "Chewie" not in dataset_name:
        return None

    from xds import lab_data

    day_path = loader.get_dataset_day_file_path(day_idx, dataset_name)
    base_path, file_name = os.path.split(day_path)
    xds_data = lab_data(base_path, file_name)
    trial_idx = np.where(np.asarray(xds_data.trial_result) == "R")[0]
    return np.asarray(xds_data.trial_target_dir)[trial_idx], trial_idx


def _align_target_dirs_with_test_trials(
    loader,
    dataset_name: str,
    day_idx: int,
    n_test_trials: int,
) -> np.ndarray | None:
    result = _load_trial_target_dirs(loader, dataset_name, day_idx)
    if result is None:
        return None

    all_dirs, _ = result
    x_list, _ = loader.load_dataset_day(day_idx, dataset_name, stack=False)
    split_time = int(TRAIN_FRAC * sum(x.shape[0] for x in x_list))

    test_dirs = []
    cum = 0
    for i, x in enumerate(x_list):
        t_end = cum + x.shape[0]
        if cum >= split_time or (cum < split_time < t_end):
            test_dirs.append(float(all_dirs[i]))
        cum = t_end

    if len(test_dirs) != n_test_trials:
        return np.full(n_test_trials, np.nan, dtype=np.float64)
    return np.asarray(test_dirs, dtype=np.float64)


def _align_target_dirs_all_trials(
    loader,
    dataset_name: str,
    day_idx: int,
    n_trials: int,
) -> np.ndarray | None:
    result = _load_trial_target_dirs(loader, dataset_name, day_idx)
    if result is None:
        return None
    all_dirs, _ = result
    if len(all_dirs) < n_trials:
        padded: np.ndarray = np.full(n_trials, np.nan, dtype=np.float64)
        padded[: len(all_dirs)] = np.asarray(all_dirs, dtype=np.float64)
        return padded
    return np.asarray(all_dirs[:n_trials], dtype=np.float64)


_RTM_DATASET_KEY = "mihili_rt"


def _day_npz_payload(
    actuals,
    preds,
    r2_overall,
    r2_per_dim,
    target_dirs,
    showcase_trial_idx,
    showcase_start,
    showcase_len: int = SHOWCASE_LEN,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "actual_trials": np.array(actuals, dtype=object),
        "pred_trials": np.array(preds, dtype=object),
        "r2_overall": np.float32(r2_overall),
        "r2_per_dim": r2_per_dim.astype(np.float32),
    }
    if target_dirs is not None:
        payload["target_dirs"] = target_dirs.astype(np.float64)
    if showcase_trial_idx is not None:
        payload["showcase_trial_idx"] = np.int32(showcase_trial_idx)
        payload["showcase_start"] = np.int32(showcase_start)
        payload["showcase_len"] = np.int32(showcase_len)
    return payload


def export_plot_data(
    encoder,
    decoder,
    loader,
    dataset_key: str,
    dataset_name: str,
    dayk_idx: int,
    device,
    xds_smooth: bool,
    train_day: int = 0,
    window_size: int = 256,
    zscore: bool = True,
) -> dict[str, Any]:
    """Build day-0 / day-k trial prediction payloads and a manifest dict."""
    cfg = PLOT_DEFAULTS[dataset_key]
    plot_type = cfg["plot_type"]

    train_trials_d0, test_trials_d0, *_ = load_day_trials(
        loader, dataset_name, train_day, xds_smooth=xds_smooth, zscore=zscore
    )
    train_trials_dk, test_trials_dk, *_ = load_day_trials(
        loader, dataset_name, dayk_idx, xds_smooth=xds_smooth, zscore=zscore
    )

    # Stream-windowed inference matches evaluate_r2 holdout scoring. Per-trial
    # forwards under-estimate R² on short-trial reach days (e.g. Chewie CO) and
    # also produce worse directional trajectories than stream-sliced preds.
    preds_d0, actuals_d0, r2_d0, r2_dim_d0 = collect_stream_trial_predictions(
        encoder, decoder, test_trials_d0, device, window_size=window_size
    )
    preds_dk, actuals_dk, r2_dk, r2_dim_dk = collect_stream_trial_predictions(
        encoder, decoder, test_trials_dk, device, window_size=window_size
    )

    all_actuals_d0 = all_preds_d0 = all_actuals_dk = all_preds_dk = None
    all_dirs_d0 = all_dirs_dk = None
    if plot_type in ("co_reach", "rt_reach"):
        # Train/test streams separately so windows never cross the split.
        tr_p0, tr_a0, _, _ = collect_stream_trial_predictions(
            encoder, decoder, list(train_trials_d0), device, window_size=window_size
        )
        tr_pk, tr_ak, _, _ = collect_stream_trial_predictions(
            encoder, decoder, list(train_trials_dk), device, window_size=window_size
        )
        all_preds_d0 = list(tr_p0) + list(preds_d0)
        all_actuals_d0 = list(tr_a0) + list(actuals_d0)
        all_preds_dk = list(tr_pk) + list(preds_dk)
        all_actuals_dk = list(tr_ak) + list(actuals_dk)
        all_dirs_d0 = _align_target_dirs_all_trials(
            loader, dataset_name, train_day, len(all_actuals_d0)
        )
        all_dirs_dk = _align_target_dirs_all_trials(
            loader, dataset_name, dayk_idx, len(all_actuals_dk)
        )

    n_labels = actuals_d0[0].shape[1] if actuals_d0 else test_trials_d0[0][1].shape[1]
    label_names = label_names_for_dataset(dataset_key, n_labels)
    ch_indices, ch_display = plot_channel_indices(dataset_key, n_labels)

    target_dirs_d0 = _align_target_dirs_with_test_trials(
        loader, dataset_name, train_day, len(actuals_d0)
    )
    target_dirs_dk = _align_target_dirs_with_test_trials(
        loader, dataset_name, dayk_idx, len(actuals_dk)
    )

    showcase_trial_idx = showcase_start = None
    used_showcase_len = SHOWCASE_LEN
    emg_sc = EMG_SHOWCASE.get(dataset_key) or {}
    if plot_type == "emg" and actuals_d0:
        used_showcase_len = showcase_len_for(dataset_key)
        if not any(np.asarray(trial).shape[0] >= used_showcase_len for trial in actuals_d0):
            used_showcase_len = SHOWCASE_LEN
        showcase_trial_idx, showcase_start = emg_sc.get("day0", (0, 0))

    plot_idx_d0 = plot_idx_dk = None
    if dataset_key == _RTM_DATASET_KEY:
        plot_idx_d0 = list(RTM_TRIAL_INDICES["day0"])
        plot_idx_dk = list(RTM_TRIAL_INDICES["dayk"])

    def _day_payload(
        actuals,
        preds,
        r2,
        r2_dim,
        dirs,
        all_a=None,
        all_p=None,
        all_d=None,
        plot_idx=None,
        sc_trial=None,
        sc_start=None,
    ):
        payload = _day_npz_payload(
            actuals,
            preds,
            r2,
            r2_dim,
            dirs,
            sc_trial if sc_trial is not None else showcase_trial_idx,
            sc_start if sc_start is not None else showcase_start,
            showcase_len=used_showcase_len,
        )
        if all_a is not None:
            payload["all_actual_trials"] = np.array(all_a, dtype=object)
            payload["all_pred_trials"] = np.array(all_p, dtype=object)
            if all_d is not None:
                payload["all_target_dirs"] = all_d.astype(np.float64)
        if plot_idx is not None:
            payload["plot_trial_indices"] = np.asarray(plot_idx, dtype=np.int32)
        return payload

    day0_sc = emg_sc.get("day0") if plot_type == "emg" else None
    dayk_sc = emg_sc.get("dayk") if plot_type == "emg" else None
    day0 = _day_payload(
        actuals_d0,
        preds_d0,
        r2_d0,
        r2_dim_d0,
        target_dirs_d0,
        all_actuals_d0,
        all_preds_d0,
        all_dirs_d0,
        plot_idx_d0,
        None if day0_sc is None else day0_sc[0],
        None if day0_sc is None else day0_sc[1],
    )
    dayk = _day_payload(
        actuals_dk,
        preds_dk,
        r2_dk,
        r2_dim_dk,
        target_dirs_dk,
        all_actuals_dk,
        all_preds_dk,
        all_dirs_dk,
        plot_idx_dk,
        None if dayk_sc is None else dayk_sc[0],
        None if dayk_sc is None else dayk_sc[1],
    )

    manifest = {
        "dataset_key": dataset_key,
        "dataset_name": dataset_name,
        "plot_type": plot_type,
        "panel": cfg["panel"],
        "title": cfg["title"],
        "train_day": train_day,
        "day0_idx": train_day,
        "dayk_idx": dayk_idx,
        "day0_label": loader.get_dataset_day_label(train_day, dataset_name),
        "dayk_label": loader.get_dataset_day_label(dayk_idx, dataset_name),
        "day0_filename": loader.get_dataset_day_filename(train_day, dataset_name),
        "dayk_filename": loader.get_dataset_day_filename(dayk_idx, dataset_name),
        "bin_size": BIN_SIZE,
        "label_names": label_names,
        "n_labels": n_labels,
        "plot_channel_indices": ch_indices,
        "plot_channel_display": ch_display,
        "pos_dims": cfg.get("pos_dims"),
        "r2_day0_overall": r2_d0,
        "r2_dayk_overall": r2_dk,
        "r2_day0_per_dim": r2_dim_d0.tolist() if r2_dim_d0.size else [],
        "r2_dayk_per_dim": r2_dim_dk.tolist() if r2_dim_dk.size else [],
        "example_trial_idx": showcase_trial_idx,
        "example_start_bin": showcase_start,
        "showcase_len": used_showcase_len,
    }
    return {"manifest": manifest, "day0": day0, "dayk": dayk}
