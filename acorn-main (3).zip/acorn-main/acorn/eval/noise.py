"""Generic i.i.d. Gaussian noise on neural bins. Grids live in examples."""

from __future__ import annotations

import numpy as np
import torch


def add_gaussian_noise(x, std: float, seed: int = 0):
    """Return ``x + N(0, std^2)`` with the same type as ``x``."""
    return_np = isinstance(x, np.ndarray)
    tensor = torch.as_tensor(x) if return_np else x
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))
    noise = torch.randn(tensor.shape, generator=generator, dtype=torch.float32) * float(std)
    if tensor.device.type != "cpu":
        noise = noise.to(tensor.device)
    noise_dtype = tensor.dtype if tensor.is_floating_point() else torch.float32
    perturbed = tensor.float() + noise.to(dtype=noise_dtype)
    if return_np:
        return perturbed.cpu().numpy()
    return perturbed


def score_under_gaussian_noise(
    model,
    decoder,
    x,
    y,
    std: float,
    *,
    session_key: str,
    device,
    seed: int = 0,
) -> float:
    """Decode ``model.transform`` of i.i.d. Gaussian-noised bins and return R²."""
    noisy = add_gaussian_noise(x, std, seed=seed)
    if hasattr(noisy, "to"):
        noisy = noisy.to(device)
    else:
        noisy = torch.as_tensor(noisy, device=device)
    was_training = model.training
    model.eval()
    with torch.no_grad():
        emb = model.transform(noisy, session_key)
    if was_training:
        model.train()
    return float(decoder.score(emb, y, device))
