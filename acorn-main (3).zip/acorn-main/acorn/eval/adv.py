"""Eval-time 10-step L2 attack from cluster ``multi_under_adv.py``."""

from __future__ import annotations

import torch
import torch.nn as nn


def l2_attack_eval(
    x: torch.Tensor,
    y: torch.Tensor,
    model,
    decoder,
    session: str,
    epsilon: float = 0.05,
    num_steps: int = 10,
    adv_norm: str = "l2",
    device=None,
):
    """10-step input-space attack using ``model.transform`` and ``decoder.forward_window``."""
    if epsilon <= 0:
        return x
    if device is None:
        device = x.device
    alpha = epsilon * 2 / num_steps
    model = model.to(device)
    decoder = decoder.to(device)
    model.eval()
    decoder.train()
    if hasattr(decoder, "gru") and decoder.gru is not None:
        decoder.gru.dropout = 0.0
    for p in model.parameters():
        p.requires_grad_(False)
    for p in decoder.parameters():
        p.requires_grad_(False)

    x_orig = x.detach().to(device)
    y = y.to(device)
    mse_loss = nn.MSELoss(reduction="mean")
    x_adv = x_orig.clone().detach().requires_grad_(True)
    view_shape = [x.size(0)] + [1] * (x.ndim - 1)

    for _ in range(num_steps):
        predictions = model.transform(x_adv, session)
        predictions, related_y = decoder.forward_window(predictions, y, device)
        loss = mse_loss(predictions, related_y)
        grad = torch.autograd.grad(loss, x_adv, retain_graph=False, create_graph=False)[0]
        with torch.no_grad():
            if adv_norm == "l2":
                grad_flat = grad.view(grad.size(0), -1)
                grad_norm = torch.norm(grad_flat, p=2, dim=1).clamp(min=1e-8)
                normalized_grad = grad / grad_norm.view(*view_shape)
                x_adv = x_adv + alpha * normalized_grad
                delta = x_adv - x_orig
                delta_flat = delta.view(delta.size(0), -1)
                delta_norm = torch.norm(delta_flat, p=2, dim=1)
                factor = torch.min(
                    torch.ones_like(delta_norm), epsilon / delta_norm.clamp(min=1e-8)
                )
                delta = delta * factor.view(*view_shape)
                x_adv = (x_orig + delta).detach().requires_grad_(True)
            elif adv_norm == "linf":
                x_adv = x_adv + alpha * grad.sign()
                delta = (x_adv - x_orig).clamp(min=-epsilon, max=epsilon)
                x_adv = (x_orig + delta).detach().requires_grad_(True)
            else:
                raise NotImplementedError(adv_norm)
    return x_adv
