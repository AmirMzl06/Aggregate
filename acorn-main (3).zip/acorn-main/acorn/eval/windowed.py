"""Windowed R^2 evaluation shared by the multi-session training and plot-export flows.

The encoder has a fixed receptive field (see ``MonkeyEncoder.get_offset``) and is applied
with replicate padding, so its output sequence length always matches its input sequence
length. Evaluation therefore slices neural/label windows of the same length, with no
truncation bookkeeping required.
"""

from __future__ import annotations

import numpy as np
import torch
from sklearn.metrics import r2_score

from acorn.utils.amp import amp_ctx


def evaluate_r2(
    encoder, decoder, x: torch.Tensor, y: torch.Tensor, device, window_size: int = 256
) -> float:
    """R² over non-overlapping windows spanning the full sequence.

    Parameters
    ----------
    encoder
        Session encoder with a ``forward`` that returns embeddings.
    decoder
        Fitted per-session decoder.
    x : torch.Tensor
        Neural bins, shape ``(T, n_neurons)``.
    y : torch.Tensor
        Labels, shape ``(T, n_labels)``.
    device
        Torch device for the forward pass.
    window_size : int, optional
        Window length in bins. Default 256.

    Returns
    -------
    float
        Uniform-average coefficient of determination, or NaN if no window
        fits or predictions are non-finite.
    """
    encoder.eval()
    decoder.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        T = x.shape[0]
        for start in range(0, T - window_size + 1, window_size):
            x_win = x[start : start + window_size].unsqueeze(0).to(device)
            lengths = torch.tensor([window_size], device=device, dtype=torch.long)
            with amp_ctx(device):
                embs, _ = encoder(x_win, lengths)
            pred = decoder(embs.float(), lengths)
            pred_np = pred.squeeze(0).float().cpu().numpy()
            y_sub = y[start : start + window_size].numpy()
            all_preds.append(pred_np)
            all_labels.append(y_sub)

    if not all_preds:
        return float("nan")

    preds = np.concatenate(all_preds, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    if not np.isfinite(preds).all():
        return float("nan")
    return float(r2_score(labels, preds, multioutput="uniform_average"))


def _predict_stream_windowed(
    encoder,
    decoder,
    x: torch.Tensor,
    y: torch.Tensor,
    device,
    window_size: int = 256,
) -> np.ndarray:
    """Dense predictions on a continuous stream using the same windows as ``evaluate_r2``.

    Non-overlapping windows match metrics; any uncovered tail is filled with one
    final window ending at T so every bin has a prediction for plotting.
    """
    encoder.eval()
    decoder.eval()
    T = int(x.shape[0])
    n_labels = int(y.shape[1])
    if T <= 0:
        return np.zeros((0, n_labels), dtype=np.float32)

    pred_stream: np.ndarray = np.full((T, n_labels), np.nan, dtype=np.float64)
    covered: np.ndarray = np.zeros(T, dtype=bool)

    def _run_window(start: int) -> None:
        if T >= window_size:
            x_win = x[start : start + window_size].unsqueeze(0).to(device)
            win_len = window_size
        else:
            x_win = x.unsqueeze(0).to(device)
            win_len = T
            start = 0
        lengths = torch.tensor([win_len], device=device, dtype=torch.long)
        with amp_ctx(device):
            embs, _ = encoder(x_win, lengths)
        pred = decoder(embs.float(), lengths)
        pred_np = pred.squeeze(0).float().cpu().numpy()
        end = min(start + win_len, T)
        pred_stream[start:end] = pred_np[: end - start]
        covered[start:end] = True

    with torch.no_grad():
        if T < window_size:
            _run_window(0)
        else:
            for start in range(0, T - window_size + 1, window_size):
                _run_window(start)
            if not covered.all():
                _run_window(T - window_size)

    if not np.isfinite(pred_stream).all():
        # Should not happen if coverage logic is correct; fall back to zeros.
        pred_stream = np.nan_to_num(pred_stream, nan=0.0)
    return pred_stream.astype(np.float32)


def collect_stream_trial_predictions(
    encoder,
    decoder,
    trials: list,
    device,
    window_size: int = 256,
):
    """Trial predictions via windowed stream inference (matches ``evaluate_r2``).

    Concatenates trials, runs a sliding-window forward pass, then splits predictions
    back per trial. This matches holdout R² for short-trial datasets where per-trial
    forwards would badly underestimate R^2.
    """
    if not trials:
        return [], [], float("nan"), np.array([])

    trial_lens = [int(tx.shape[0]) for tx, _ in trials]
    x = torch.cat([tx for tx, _ in trials], dim=0)
    y = torch.cat([ty for _, ty in trials], dim=0)

    pred_stream = _predict_stream_windowed(encoder, decoder, x, y, device, window_size=window_size)
    label_stream = y.numpy().astype(np.float32)

    preds_list, actuals_list = [], []
    offset = 0
    for L in trial_lens:
        preds_list.append(pred_stream[offset : offset + L])
        actuals_list.append(label_stream[offset : offset + L])
        offset += L

    # R² matches metrics: same windowed evaluate_r2 on the concatenated stream.
    r2_overall = evaluate_r2(encoder, decoder, x, y, device, window_size=window_size)
    r2_per_dim = r2_score(label_stream, pred_stream, multioutput="raw_values")
    return preds_list, actuals_list, float(r2_overall), np.asarray(r2_per_dim, dtype=np.float64)
