"""Post-hoc per-session decoder training on frozen full-trajectory embeddings."""

from __future__ import annotations

import numpy as np
import torch

from acorn.data.splits import load_day_split
from acorn.log import get_logger
from acorn.models.decoder_base import BaseGRUDecoder

TRAIN_DAY = 0
logger = get_logger(__name__)


def encode_full_trajectory(
    model, session_key: str, x: torch.Tensor, device: torch.device
) -> torch.Tensor:
    was_training = model.training
    model.eval()
    with torch.no_grad():
        out = model.transform(x.to(device), session_key).float()
    if was_training:
        model.train()
    return out


def resolve_probe_decoder(
    decoder_cls,
    decoder_adv: str = "off",
    mlp_decoder: bool = False,
):
    """Pick the probe class. ``decoder_adv`` is unused for AdversarialMonkeyDecoder recipes."""
    if mlp_decoder:
        from acorn.models.decoder_mlp import TwoLayerMLP

        return TwoLayerMLP, True
    if decoder_adv == "oneshot":
        from acorn.models.decoder_oneshot import OneshotMonkeyDecoder

        return OneshotMonkeyDecoder, False
    if decoder_adv == "pgd":
        from acorn.models.decoder_cluster_pgd import ClusterPgdMonkeyDecoder

        return ClusterPgdMonkeyDecoder, False
    return decoder_cls, False


def train_session_decoder(
    model,
    session_key: str,
    train_x: torch.Tensor,
    train_y: torch.Tensor,
    n_labels: int,
    device: torch.device,
    n_steps: int,
    seed: int = 42,
    use_val_checkpoint: bool = True,
    decoder_cls: type = BaseGRUDecoder,
    decoder_kwargs: dict | None = None,
    ceb_out: int = 64,
    window_size: int = 256,
    decoder_adv: str = "off",
    mlp_decoder: bool = False,
):
    train_emb = encode_full_trajectory(model, session_key, train_x, device)
    extra = dict(decoder_kwargs or {})
    probe_cls, is_mlp = resolve_probe_decoder(decoder_cls, decoder_adv, mlp_decoder)
    if is_mlp:
        decoder = probe_cls(
            ceb_out,
            64,
            n_labels,
            device=device,
            verbose=False,
            **{k: v for k, v in extra.items() if k not in {"window_size", "hidden", "adv_eps"}},
        )
    else:
        decoder = probe_cls(
            ceb_out=ceb_out,
            hidden=512,
            n_labels=n_labels,
            verbose=False,
            n_train_steps=n_steps,
            device=device,
            window_size=window_size,
            **extra,
        ).to(device)
    decoder.fit(
        train_emb,
        train_y.to(device),
        seed=seed,
        use_val_checkpoint=use_val_checkpoint,
        n_train_steps=n_steps,
    )
    return decoder


def evaluate_embedding_decoders(
    model,
    loader,
    bundles: dict,
    device: torch.device,
    n_decoder_steps: int,
    seed: int = 42,
    decoder_val_checkpoint: bool = True,
    decoder_cls: type = BaseGRUDecoder,
    decoder_kwargs: dict | None = None,
    ceb_out: int = 64,
    window_size: int = 256,
    decoder_adv: str = "off",
    mlp_decoder: bool = False,
) -> dict:
    """Fit per-session decoders on frozen embeddings and score R².

    Parameters
    ----------
    model
        Multi-session encoder container.
    loader
        Dataset loader used for extra days when present.
    bundles : dict
        Per-key arrays with ``train_x`` / ``train_y`` / ``test_x`` /
        ``test_y`` and metadata.
    device : torch.device
        Torch device.
    n_decoder_steps : int
        Decoder training steps.
    seed : int, optional
        RNG seed for decoder fitting.
    decoder_val_checkpoint : bool, optional
        Early-stop each decoder on validation R².
    decoder_cls, decoder_kwargs, ceb_out, window_size, decoder_adv, mlp_decoder
        Probe constructor and eval knobs. ``decoder_adv`` is ``off``,
        ``oneshot``, or ``pgd``.

    Returns
    -------
    dict
        Per-key metrics including ``r2_train``, ``r2_holdout``, and
        optional other-day scores.
    """
    metrics = {}
    for key, bundle in bundles.items():
        decoder = train_session_decoder(
            model,
            key,
            bundle["train_x"],
            bundle["train_y"],
            bundle["n_labels"],
            device,
            n_decoder_steps,
            seed=seed,
            use_val_checkpoint=decoder_val_checkpoint,
            decoder_cls=decoder_cls,
            decoder_kwargs=decoder_kwargs,
            ceb_out=ceb_out,
            window_size=window_size,
            decoder_adv=decoder_adv,
            mlp_decoder=mlp_decoder,
        )
        model.set_session_decoder(key, decoder)

        train_emb = encode_full_trajectory(model, key, bundle["train_x"], device)
        test_emb = encode_full_trajectory(model, key, bundle["test_x"], device)
        r2_train = decoder.score(train_emb, bundle["train_y"], device)
        r2_holdout = decoder.score(test_emb, bundle["test_y"], device)
        logger.info("--- %s (%s) ---", key, bundle["dataset_name"])
        logger.info(
            "  decoder fit  : best_epoch=%s  val_R^2=%.3f",
            decoder.best_epoch_,
            decoder.best_val_r2_,
        )
        logger.info("  day %2d (train)   : R^2 = %.3f", TRAIN_DAY, r2_train)
        logger.info("  day %2d (holdout) : R^2 = %.3f", TRAIN_DAY, r2_holdout)
        day_scores = {}
        if bundle["num_days"] > 1:
            for day_idx in range(bundle["num_days"]):
                if day_idx == TRAIN_DAY:
                    continue
                _, day_x, _, day_y = load_day_split(
                    loader,
                    bundle["dataset_name"],
                    day_idx,
                    xds_smooth=bundle["xds_smooth"],
                    zscore=bool(bundle.get("zscore", True)),
                )
                day_emb = encode_full_trajectory(model, key, day_x, device)
                r2 = decoder.score(day_emb, day_y, device)
                day_scores[day_idx] = r2
                logger.info("  day %2d           : R^2 = %.3f", day_idx, r2)
        mean_other = float(np.mean(list(day_scores.values()))) if day_scores else float("nan")
        all_days = [r2_holdout, *day_scores.values()]
        overall_all_days = float(np.mean(all_days)) if all_days else float("nan")
        if day_scores:
            logger.info("  mean over other days : R^2 = %.3f", mean_other)
        logger.info("  overall mean (all days): R^2 = %.3f", overall_all_days)
        metrics[key] = {
            "dataset": key,
            "dataset_name": bundle["dataset_name"],
            "use_smooth": bundle["use_smooth"],
            "xds_smooth": bundle["xds_smooth"],
            "n_labels": bundle["n_labels"],
            "decoder_best_epoch": decoder.best_epoch_,
            "decoder_best_val_r2": decoder.best_val_r2_,
            "r2_train": r2_train,
            "r2_holdout": r2_holdout,
            "r2_other_days": day_scores,
            "r2_mean_other_days": mean_other,
            "r2_overall_all_days": overall_all_days,
            "dayk_idx": bundle["dayk_idx"],
        }
    return metrics
