"""Default GRU decoder: clean MSE window steps, no embedding PGD."""

from acorn.models.decoder_base import BaseGRUDecoder


class MonkeyDecoder(BaseGRUDecoder):
    """offset36_gru recipe decoder. Shared loop lives on :class:`BaseGRUDecoder`."""

    pass
