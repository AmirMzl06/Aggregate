"""Structural Protocols for encoder / decoder variants.

These document the exact method surface consumed by runners and eval code.
Implementing a new recipe means satisfying these Protocols (and registering
the pair in :mod:`acorn.models.registry`).
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import torch


@runtime_checkable
class EncoderModel(Protocol):
    """Multi-session encoder surface used by training and evaluation."""

    def add_session(
        self, session_key: str, num_neurons: int, n_labels: int, use_smooth: bool = True
    ) -> None: ...

    def encode(
        self, x: torch.Tensor, lengths: torch.Tensor, session_key: str
    ) -> tuple[torch.Tensor, torch.Tensor]: ...

    def encode_cebra_windows(self, x: torch.Tensor, session_key: str) -> torch.Tensor: ...

    def transform(self, x: torch.Tensor, session_key: str) -> torch.Tensor: ...

    def get_offset(self): ...

    def set_session_decoder(self, session_key: str, decoder) -> None: ...

    def session_decoder(self, session_key: str): ...

    def session_encoder(self, session_key: str): ...

    def encoder_parameters(self): ...

    def freeze_decoder(self) -> None: ...

    def unfreeze_encoder(self) -> None: ...

    def encoder_train(self, mode: bool = True) -> None: ...

    def decoder_train(self, mode: bool = True) -> None: ...

    def to(self, device): ...

    def eval(self): ...


@runtime_checkable
class DecoderModel(Protocol):
    """Per-session decoder fitted on frozen embeddings."""

    best_epoch_: int
    best_val_r2_: float

    def fit(
        self,
        train_emb: torch.Tensor,
        train_y: torch.Tensor,
        seed: int = 42,
        use_val_checkpoint: bool = True,
    ): ...

    def score(self, emb: torch.Tensor, y, device) -> float: ...

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor: ...
