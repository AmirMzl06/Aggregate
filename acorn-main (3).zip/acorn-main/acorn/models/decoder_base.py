"""Neutral GRU decoder: sampling, fit loop, score, forward.

Owned by no recipe. Recipe classes subclass this and override
``_train_window_step`` when they need a different per-window update.
"""

from __future__ import annotations

import copy
import random

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import r2_score
from torch import optim

from acorn.log import get_logger
from acorn.utils.validation import MIN_EPOCHS, PATIENCE, VAL_FRAC, split_time_aware

DEC_WINDOW_SIZE = 256
logger = get_logger(__name__)
DEC_BATCH_SIZE = 32
DEC_LR = 1e-3
DEC_L2_DECAY = 1e-5


def _setup_seed(seed: int = 42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def sample_embedding_windows(x, y, batch_size, window_size, device):
    t = x.shape[0]
    max_start = max(1, t - window_size + 1)
    starts = torch.randint(0, max_start, (batch_size,))
    x_batch = torch.stack([x[s : s + window_size] for s in starts]).to(device)
    y_batch = torch.stack([y[s : s + window_size] for s in starts]).to(device)
    lengths = torch.full((batch_size,), window_size, device=device, dtype=torch.long)
    return x_batch, y_batch, lengths


class BaseGRUDecoder(nn.Module):
    def __init__(
        self,
        ceb_out=64,
        hidden=512,
        layers=2,
        dropout=0.4,
        bidir=False,
        n_labels=2,
        use_gru=True,
        n_train_steps=10_000,
        batch_size=DEC_BATCH_SIZE,
        window_size=DEC_WINDOW_SIZE,
        lr=DEC_LR,
        weight_decay=DEC_L2_DECAY,
        min_epochs=MIN_EPOCHS,
        patience=PATIENCE,
        val_frac=VAL_FRAC,
        device=None,
        verbose=False,
    ):
        super().__init__()
        self.use_gru = use_gru
        self.n_train_steps = n_train_steps
        self.batch_size = batch_size
        self.window_size = window_size
        self.lr = lr
        self.weight_decay = weight_decay
        self.min_epochs = min_epochs
        self.patience = patience
        self.val_frac = val_frac
        self.verbose = verbose
        self.device = device
        self.best_epoch_ = 0
        self.best_val_r2_ = float("nan")
        if use_gru:
            self.gru = nn.GRU(
                ceb_out,
                hidden,
                layers,
                batch_first=True,
                bidirectional=bidir,
                dropout=dropout if layers > 1 else 0.0,
            )
            self.linear = nn.Linear(hidden * (2 if bidir else 1), n_labels)
        else:
            self.gru = None
            self.linear = nn.Linear(ceb_out, n_labels)

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor:
        if not self.use_gru:
            return self.linear(embs)
        if lengths is not None:
            packed = nn.utils.rnn.pack_padded_sequence(
                embs,
                lengths.cpu(),
                batch_first=True,
                enforce_sorted=False,
            )
            out_packed, _ = self.gru(packed)
            out, _ = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)
        else:
            out, _ = self.gru(embs)
        return self.linear(out)

    @staticmethod
    def _split_time_aware(x: torch.Tensor, y: torch.Tensor, frac: float = VAL_FRAC):
        return split_time_aware(x, y, frac)

    def _fit_fixed_steps(
        self,
        train_x: torch.Tensor,
        train_y: torch.Tensor,
        device: torch.device,
        mse_fn: nn.Module,
        n_steps: int | None = None,
    ):
        """Train for a fixed number of steps with cosine LR schedule."""
        if n_steps is None:
            n_steps = self.n_train_steps
        window_size = min(self.window_size, train_x.shape[0])
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(n_steps, 1), eta_min=1e-5
        )
        for _ in range(n_steps):
            self._train_window_step(train_x, train_y, window_size, device, optimizer, mse_fn)
            scheduler.step()
        self.best_epoch_ = n_steps
        self.best_val_r2_ = float("nan")

    def fit(self, train_x: torch.Tensor, train_y: torch.Tensor, seed: int = 42, **kwargs):
        use_val_checkpoint = kwargs.get("use_val_checkpoint", True)
        n_train_steps = kwargs.get("n_train_steps", self.n_train_steps)
        device = self.device or train_x.device
        self.to(device)
        if self.verbose:
            logger.info(
                "Fitting MonkeyDecoder on embeddings %s -> labels %s",
                tuple(train_x.shape),
                tuple(train_y.shape),
            )
        _setup_seed(seed)
        train_x = train_x.to(device).float()
        train_y = train_y.to(device).float()
        mse_fn = nn.MSELoss()

        if not use_val_checkpoint:
            self._fit_fixed_steps(train_x, train_y, device, mse_fn, n_steps=n_train_steps)
            return self

        # Save initial weights so phase 2 can retrain from scratch on full data.
        init_state = copy.deepcopy(self.state_dict())

        # Phase 1: search on train split, monitor val to find best_epoch.
        tr_x, tr_y, val_x, val_y = self._split_time_aware(train_x, train_y, self.val_frac)
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        best_epoch, best_r2, bad = 0, -1e9, 0

        tr_window = min(self.window_size, tr_x.shape[0])
        for epoch in range(n_train_steps):
            self._train_window_step(tr_x, tr_y, tr_window, device, optimizer, mse_fn)
            self.eval()
            r2 = self.score(val_x, val_y, device)
            if r2 > best_r2:
                best_r2 = r2
                best_epoch = epoch + 1
                bad = 0
            else:
                if epoch >= self.min_epochs - self.patience:
                    bad += 1
                if bad >= self.patience:
                    if self.verbose:
                        logger.info(
                            "[EarlyStop] epoch=%s, best_epoch=%s, best_r2=%.3f",
                            epoch + 1,
                            best_epoch,
                            best_r2,
                        )
                    break

        if best_epoch == 0:
            best_epoch = 1

        if self.verbose:
            logger.info(
                "[Retrain] best_epoch=%s, val_r2=%.3f → retraining on full data",
                best_epoch,
                best_r2,
            )

        # Phase 2: reset to initial weights, train on full data for best_epoch steps.
        self.load_state_dict(init_state)
        _setup_seed(seed)
        self._fit_fixed_steps(train_x, train_y, device, mse_fn, n_steps=best_epoch)

        self.best_epoch_ = best_epoch
        self.best_val_r2_ = best_r2 if best_r2 > -1e9 else float("nan")

        return self

    def _train_window_step(
        self,
        train_x: torch.Tensor,
        train_y: torch.Tensor,
        window_size: int,
        device: torch.device,
        optimizer: optim.Optimizer,
        mse_fn: nn.Module,
    ) -> torch.Tensor | None:
        self.train()
        x_batch, y_batch, lengths = sample_embedding_windows(
            train_x, train_y, self.batch_size, window_size, device
        )
        pred = self.forward(x_batch, lengths)
        loss = mse_fn(pred, y_batch)
        if not torch.isfinite(loss):
            return None
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.parameters(), 1.0)
        optimizer.step()
        return loss

    def score(self, test_x, test_y, device) -> float:
        self.eval()
        test_x = test_x.float().to(device)
        test_y = test_y.float()
        window_size = min(self.window_size, test_x.shape[0])
        all_preds, all_labels = [], []

        with torch.no_grad():
            t = test_x.shape[0]
            for start in range(0, t - window_size + 1, window_size):
                x_win = test_x[start : start + window_size].unsqueeze(0)
                lengths = torch.tensor([window_size], device=device, dtype=torch.long)
                pred = self.forward(x_win, lengths).squeeze(0).cpu().numpy()
                y_sub = test_y[start : start + window_size].cpu().numpy()
                all_preds.append(pred)
                all_labels.append(y_sub)

        if not all_preds:
            return float("nan")

        preds = np.concatenate(all_preds, axis=0)
        labels = np.concatenate(all_labels, axis=0)
        if not np.isfinite(preds).all():
            return float("nan")
        return float(r2_score(labels, preds, multioutput="uniform_average"))

    def forward_window(self, test_x, test_y, device):
        """Windowed decode used by eval-time L2 attacks."""
        all_preds = []
        all_labels = []
        window_size = min(self.window_size, test_x.shape[0])
        t = test_x.shape[0]
        for start in range(0, t - window_size + 1, window_size):
            x_win = test_x[start : start + window_size].unsqueeze(0)
            lengths = torch.tensor([window_size], device=device, dtype=torch.long)
            pred = self.forward(x_win, lengths).squeeze(0)
            y_sub = test_y[start : start + window_size]
            all_preds.append(pred)
            all_labels.append(y_sub)
        preds = torch.cat(all_preds, axis=0)
        labels = torch.cat(all_labels, axis=0)
        return preds, labels
