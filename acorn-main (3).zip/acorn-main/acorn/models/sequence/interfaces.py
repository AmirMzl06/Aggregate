"""Structural Protocols for the sequence (CTC) label format.

Sibling of :mod:`acorn.models.interfaces`. Session keys are the public
lookup; task keys are resolved internally so callers never see them.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import torch


@runtime_checkable
class SequenceEncoderModel(Protocol):
    """Multi-session sequence encoder + task-keyed CTC heads."""

    def add_session(
        self,
        session_key: str,
        num_neurons: int,
        task_key: str,
        use_smooth: bool = True,
    ) -> None: ...

    def add_task_head(self, task_key: str, num_classes: int) -> None: ...

    def encode(
        self, x: torch.Tensor, lengths: torch.Tensor, session_key: str
    ) -> tuple[torch.Tensor, torch.Tensor]: ...

    def session_decoder(self, session_key: str): ...

    def get_offset(self): ...

    def encoder_parameters(self): ...

    def freeze_encoder(self) -> None: ...

    def unfreeze_encoder(self) -> None: ...

    def encoder_train(self, mode: bool = True) -> None: ...

    def decoder_train(self, mode: bool = True) -> None: ...


@runtime_checkable
class TaskHead(Protocol):
    """CTC classification head. ``lengths`` is accepted and ignored (no packing)."""

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor: ...
