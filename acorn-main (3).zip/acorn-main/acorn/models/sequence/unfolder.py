"""Unfolder: (B, T, F) → (B, T', F*kernel) plus the CTC length-formula quirk.

Tensor length after unfolding is ``floor((T - kernel) / stride) + 1``.
Lengths metadata fed to CTC is ``floor((L - kernel) / stride)`` — one less
than the tensor's own length. Reproduce both; they are not the same formula.
"""

from __future__ import annotations

import torch
from torch import nn


class Unfolder(nn.Module):
    def __init__(self, kernel: int = 32, stride: int = 4):
        super().__init__()
        self.unfolder = torch.nn.Unfold((kernel, 1), dilation=1, padding=0, stride=stride)
        self.kernel = kernel
        self.stride = stride

    def forward(self, x: torch.Tensor, lengths: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        x = torch.permute(
            self.unfolder(torch.unsqueeze(torch.permute(x, (0, 2, 1)), 3)),
            (0, 2, 1),
        )
        lengths = ((lengths - self.kernel) / self.stride).to(torch.int32)
        return x, lengths
