"""Sequence-format model package."""
