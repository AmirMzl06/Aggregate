"""Task-keyed multi-session sequence model (N>=1). One recipe, not two."""

from __future__ import annotations

import torch
import torch.nn as nn

from acorn.models.augmentation import GaussianSmoothing
from acorn.models.encoder import MonkeyEncoder
from acorn.models.offset36_multi import SMOOTH_KERNEL, SMOOTH_SIGMA
from acorn.models.sequence.task_head import CtcTaskHead
from acorn.models.sequence.unfolder import Unfolder


class SequenceMultiTaskModel(nn.Module):
    """Gauss → Unfold → Offset36_multi trunk → task-keyed CTC GRU head.

    Multiple sessions may share one task head (same module instance). Callers
    look up heads via ``session_decoder(session_key)``; the session→task map
    stays internal.
    """

    def __init__(
        self,
        ceb_hidden: int = 256,
        ceb_out: int = 64,
        kernel: int = 32,
        stride: int = 4,
        hidden: int = 1024,
        layers: int = 5,
        dropout: float = 0.4,
        bidir: bool = True,
    ):
        super().__init__()
        self.ceb_out = ceb_out
        self.kernel = kernel
        self.stride = stride
        self.hidden = hidden
        self.layers = layers
        self.dropout = dropout
        self.bidir = bidir
        self.unfolder = Unfolder(kernel=kernel, stride=stride)
        self.monkey_encoder = MonkeyEncoder(ceb_hidden=ceb_hidden, ceb_out=ceb_out)
        self.smoothers = nn.ModuleDict()
        self._task_heads = nn.ModuleDict()
        self._session_task_key: dict[str, str] = {}
        self.embeddings: torch.Tensor | None = None
        self.emb_lengths: torch.Tensor | None = None

    @property
    def encoder(self):
        return self.monkey_encoder.cebra

    @property
    def session_keys(self) -> list[str]:
        return self.monkey_encoder.session_keys

    def _safe_key(self, session_key: str) -> str:
        return MonkeyEncoder._safe_key(session_key)

    def add_session(
        self,
        session_key: str,
        num_neurons: int,
        task_key: str,
        use_smooth: bool = True,
    ) -> None:
        # Unfold happens before the trunk, so CEBRA in-channels are F * kernel.
        # Trunk smoothing is off: GaussianSmoothing is applied on raw (B, T, F).
        self.monkey_encoder.add_session(session_key, num_neurons * self.kernel, use_smooth=False)
        sk = self._safe_key(session_key)
        if use_smooth:
            self.smoothers[sk] = GaussianSmoothing(num_neurons, SMOOTH_KERNEL, SMOOTH_SIGMA, dim=1)
        else:
            self.smoothers[sk] = nn.Identity()
        self._session_task_key[session_key] = task_key

    def add_task_head(self, task_key: str, num_classes: int) -> None:
        if task_key in self._task_heads:
            existing = self._task_heads[task_key]
            if existing.num_classes != num_classes:
                raise ValueError(
                    f"task {task_key!r} already registered with "
                    f"num_classes={existing.num_classes}, got {num_classes}"
                )
            return
        self._task_heads[task_key] = CtcTaskHead(
            num_classes=num_classes,
            ceb_out=self.ceb_out,
            hidden=self.hidden,
            layers=self.layers,
            dropout=self.dropout,
            bidir=self.bidir,
        )

    def _task_key(self, session_key: str) -> str:
        if session_key not in self._session_task_key:
            raise KeyError(f"Unknown session {session_key!r}")
        return self._session_task_key[session_key]

    def session_decoder(self, session_key: str) -> CtcTaskHead:
        task_key = self._task_key(session_key)
        if task_key not in self._task_heads:
            raise RuntimeError(
                f"No CTC head for session {session_key!r} (task {task_key!r}); "
                "call add_task_head first."
            )
        return self._task_heads[task_key]

    def encode(
        self, x: torch.Tensor, lengths: torch.Tensor, session_key: str
    ) -> tuple[torch.Tensor, torch.Tensor]:
        sk = self._safe_key(session_key)
        x = self.smoothers[sk](x)
        x, lengths = self.unfolder(x, lengths)
        embs, _ = self.monkey_encoder.encode(x, lengths, session_key)
        self.embeddings = embs
        self.emb_lengths = lengths
        return embs, lengths

    def get_cebra_embs(self) -> tuple[torch.Tensor | None, torch.Tensor | None]:
        return self.embeddings, self.emb_lengths

    def decode(self, embs: torch.Tensor, lengths: torch.Tensor, session_key: str) -> torch.Tensor:
        return self.session_decoder(session_key)(embs, lengths)

    def forward(
        self, x: torch.Tensor, lengths: torch.Tensor, session_key: str
    ) -> tuple[torch.Tensor, torch.Tensor]:
        embs, out_lens = self.encode(x, lengths, session_key)
        logits = self.decode(embs, out_lens, session_key)
        return logits, out_lens

    def get_offset(self):
        return self.monkey_encoder.get_offset()

    def encoder_parameters(self):
        yield from self.monkey_encoder.parameters()
        yield from self.smoothers.parameters()
        yield from self.unfolder.parameters()

    def decoder_parameters(self):
        yield from self._task_heads.parameters()

    def freeze_encoder(self) -> None:
        for p in self.encoder_parameters():
            p.requires_grad_(False)

    def unfreeze_encoder(self) -> None:
        for p in self.encoder_parameters():
            p.requires_grad_(True)

    def encoder_train(self, mode: bool = True) -> None:
        self.monkey_encoder.train(mode)
        self.smoothers.train(mode)
        self.unfolder.train(mode)

    def decoder_train(self, mode: bool = True) -> None:
        self._task_heads.train(mode)
