"""CTC GRU+Linear task head. No packed sequences — padded trials go straight through."""

from __future__ import annotations

import torch
from torch import nn


class CtcTaskHead(nn.Module):
    def __init__(
        self,
        num_classes: int,
        ceb_out: int = 64,
        hidden: int = 1024,
        layers: int = 5,
        dropout: float = 0.4,
        bidir: bool = True,
    ):
        super().__init__()
        self.num_classes = num_classes
        self.gru = nn.GRU(
            ceb_out,
            hidden,
            layers,
            batch_first=True,
            bidirectional=bidir,
            dropout=dropout if layers > 1 else 0.0,
        )
        out_dim = hidden * (2 if bidir else 1)
        self.linear = nn.Linear(out_dim, num_classes)

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor:
        # lengths is unused: CTC head must not pack_padded_sequence (build spec §2.1 step 4).
        _ = lengths
        out, _ = self.gru(embs)
        return self.linear(out)
