"""Multi-session CEBRA encoder wrapping Offset36_multi."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from acorn.models.offset36_multi import Offset36_multi


class MonkeyEncoder(nn.Module):
    """Multi-session CEBRA encoder: a shared Offset36_multi backbone with per-session
    input/output heads, added via ``add_session``."""

    def __init__(self, ceb_hidden: int = 256, ceb_out: int = 64):
        super().__init__()
        self.ceb_out = ceb_out
        self.session_keys: list[str] = []
        self.cebra = Offset36_multi(ceb_hidden, ceb_out)

    @staticmethod
    def _safe_key(session_key: str) -> str:
        return f"ds_{session_key}"

    def add_session(self, session_key: str, num_neurons: int, use_smooth: bool = True):
        sk = self._safe_key(session_key)
        self.session_keys.append(session_key)
        self.cebra.add_session(sk, num_neurons, use_smooth=use_smooth)

    def encode(self, x: torch.Tensor, lengths: torch.Tensor, session_key: str):
        sk = self._safe_key(session_key)
        x = x.permute(0, 2, 1)
        x = F.pad(x, (18, 17), mode="replicate")
        x = self.cebra(x, sk)
        if x.dim() == 2:
            x = x.unsqueeze(-1)
        x = x.permute(0, 2, 1)
        return x, lengths

    def encode_cebra_windows(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        """Encode CEBRA contrastive windows (B, neurons, 36)."""
        sk = self._safe_key(session_key)
        out = self.cebra(x, sk)
        if out.dim() == 3:
            out = out.squeeze(-1)
        return out

    def transform(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        """Full-trajectory embeddings (T, ceb_out)."""
        sk = self._safe_key(session_key)
        return self.cebra.transform(x, sk)

    def get_offset(self):
        return self.cebra.get_offset()
