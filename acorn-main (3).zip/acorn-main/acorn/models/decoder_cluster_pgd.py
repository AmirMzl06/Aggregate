"""GRU decoder with per-bin 10-step L2 PGD on embedding windows."""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import optim

from acorn.models.decoder_base import BaseGRUDecoder, _setup_seed, sample_embedding_windows
from acorn.utils.amp import amp_ctx


class ClusterPgdMonkeyDecoder(BaseGRUDecoder):
    """Clean MSE step, then 10-step per-bin L2 PGD on the same window."""

    def __init__(self, *args, adv_eps: float = 0.1, adv_steps: int = 10, **kwargs):
        super().__init__(*args, **kwargs)
        self.adv_eps = float(adv_eps)
        self.adv_steps = int(adv_steps)
        self.adv_alpha = self.adv_eps * 2 / self.adv_steps

    def fit(self, train_x: torch.Tensor, train_y: torch.Tensor, seed: int = 42, **kwargs):
        n_train_steps = kwargs.get("n_train_steps", self.n_train_steps) // 2
        device = self.device or train_x.device
        self.to(device)
        _setup_seed(seed)
        train_x = train_x.to(device).float()
        train_y = train_y.to(device).float()
        mse_fn = nn.MSELoss()
        self._fit_fixed_steps(train_x, train_y, device, mse_fn, n_steps=n_train_steps)
        return self

    def _train_window_step(
        self,
        train_x: torch.Tensor,
        train_y: torch.Tensor,
        window_size: int,
        device: torch.device,
        optimizer: optim.Optimizer,
        mse_fn: nn.Module,
    ) -> torch.Tensor | None:
        self.train()
        x_batch, y_batch, lengths = sample_embedding_windows(
            train_x, train_y, self.batch_size, window_size, device
        )
        with amp_ctx(device):
            pred = self.forward(x_batch, lengths)
            loss = mse_fn(pred, y_batch)
        if not torch.isfinite(loss):
            return None
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.parameters(), 1.0)
        optimizer.step()

        with torch.no_grad():
            x_adv = x_batch.detach().clone()
            x_clean = x_batch.detach().clone()
            noise = torch.randn_like(x_adv)
            noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            noise_normalized = noise / noise_norm
            noise_normalized *= (
                torch.rand((noise.shape[0], noise.shape[1], 1), device=device) * self.adv_eps
            )
            x_adv = x_adv + noise_normalized

        for _ in range(self.adv_steps):
            x_adv.requires_grad_(True)
            with amp_ctx(device):
                pred = self.forward(x_adv, lengths)
                adv_loss = mse_fn(pred, y_batch)
            (grad,) = torch.autograd.grad(adv_loss, x_adv, only_inputs=True)
            with torch.no_grad():
                grad_norm = grad.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
                x_adv = (x_adv + self.adv_alpha * (grad / grad_norm)).detach()
                delta = x_adv - x_clean
                delta_norm = delta.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
                scale = torch.clamp(self.adv_eps / delta_norm, max=1.0)
                x_adv = (x_clean + delta * scale).detach()

        with amp_ctx(device):
            pred = self.forward(x_adv, lengths)
            adv_loss = mse_fn(pred, y_batch)
        optimizer.zero_grad(set_to_none=True)
        if torch.isfinite(adv_loss):
            adv_loss.backward()
            optimizer.step()
        return loss
