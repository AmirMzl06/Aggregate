"""Multi-session encoder+decoder container with per-session views."""

from __future__ import annotations

import torch
import torch.nn as nn

from acorn.models.decoder_base import BaseGRUDecoder
from acorn.models.encoder import MonkeyEncoder


class SessionEncoderView(nn.Module):
    """Thin wrapper so eval/plot code can call encode() per session."""

    def __init__(self, parent: MultiSessionModel, session_key: str):
        super().__init__()
        self.parent = parent
        self.session_key = session_key

    def forward(self, x: torch.Tensor, lengths: torch.Tensor):
        return self.parent.encode(x, lengths, self.session_key)


class SessionDecoderView(nn.Module):
    """Placeholder until a per-session decoder is fitted during evaluation."""

    def __init__(self, parent: MultiSessionModel, session_key: str):
        super().__init__()
        self.parent = parent
        self.session_key = session_key

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor:
        raise RuntimeError(
            f"No trained decoder for session {self.session_key!r}; "
            "run embedding-decoder evaluation first."
        )


class MultiSessionModel(nn.Module):
    """Multi-session: MonkeyEncoder (Offset36_multi) + per-session decoder eval."""

    def __init__(self, ceb_hidden: int = 256, ceb_out: int = 64):
        super().__init__()
        self.ceb_out = ceb_out
        self.monkey_encoder = MonkeyEncoder(ceb_hidden=ceb_hidden, ceb_out=ceb_out)
        self._session_decoders: dict[str, BaseGRUDecoder] = {}
        self._session_n_labels: dict[str, int] = {}
        self._session_task_key: dict[str, str] = {}
        self.embeddings = None
        self.emb_lengths = None

    @property
    def encoder(self):
        """Offset36_multi backbone (diag/weight-copy compatibility)."""
        return self.monkey_encoder.cebra

    @property
    def session_keys(self) -> list[str]:
        return self.monkey_encoder.session_keys

    def add_session(
        self,
        session_key: str,
        num_neurons: int,
        n_labels: int,
        use_smooth: bool = True,
        task_key: str | None = None,
    ):
        self.monkey_encoder.add_session(session_key, num_neurons, use_smooth=use_smooth)
        self._session_n_labels[session_key] = n_labels
        self._session_task_key[session_key] = task_key or session_key

    def _task_key(self, session_key: str) -> str:
        return self._session_task_key.get(session_key, session_key)

    def encode(self, x: torch.Tensor, lengths: torch.Tensor, session_key: str):
        embs, out_lens = self.monkey_encoder.encode(x, lengths, session_key)
        self.embeddings = embs
        self.emb_lengths = out_lens
        return embs, out_lens

    def encode_cebra_windows(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        return self.monkey_encoder.encode_cebra_windows(x, session_key)

    def transform(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        return self.monkey_encoder.transform(x, session_key)

    def get_offset(self):
        return self.monkey_encoder.get_offset()

    def get_cebra_embs(self):
        return self.embeddings, self.emb_lengths

    def set_session_decoder(self, session_key: str, decoder: BaseGRUDecoder) -> None:
        self._session_decoders[self._task_key(session_key)] = decoder

    def session_decoder(self, session_key: str) -> nn.Module:
        task_key = self._task_key(session_key)
        if task_key in self._session_decoders:
            return self._session_decoders[task_key]
        return SessionDecoderView(self, session_key)

    def decode(self, embs: torch.Tensor, lengths: torch.Tensor, session_key: str) -> torch.Tensor:
        decoder = self.session_decoder(session_key)
        if isinstance(decoder, SessionDecoderView):
            raise RuntimeError(
                f"No trained decoder for session {session_key!r}; "
                "run embedding-decoder evaluation first."
            )
        return decoder(embs, lengths)

    def forward(self, x: torch.Tensor, lengths: torch.Tensor, session_key: str):
        embs, out_lens = self.encode(x, lengths, session_key)
        pred = self.decode(embs, out_lens, session_key)
        return pred, out_lens

    def encoder_parameters(self):
        yield from self.monkey_encoder.parameters()

    def decoder_parameters(self):
        for decoder in self._session_decoders.values():
            yield from decoder.parameters()

    def freeze_encoder(self):
        for p in self.encoder_parameters():
            p.requires_grad_(False)

    def unfreeze_encoder(self):
        for p in self.encoder_parameters():
            p.requires_grad_(True)

    def freeze_decoder(self):
        for p in self.decoder_parameters():
            p.requires_grad_(False)

    def unfreeze_decoder(self):
        for p in self.decoder_parameters():
            p.requires_grad_(True)

    def session_encoder(self, session_key: str) -> SessionEncoderView:
        return SessionEncoderView(self, session_key)

    def encoder_train(self, mode: bool = True) -> None:
        self.monkey_encoder.train(mode)

    def decoder_train(self, mode: bool = True) -> None:
        for decoder in self._session_decoders.values():
            decoder.train(mode)

    def load_state_dict(self, state_dict, strict=True):
        remapped = {}
        for key, value in state_dict.items():
            if key.startswith("encoder."):
                remapped["monkey_encoder.cebra." + key[len("encoder.") :]] = value
            elif key.startswith("monkey_encoder."):
                remapped[key] = value
            elif key.startswith(("gru.", "heads.")):
                continue
            else:
                remapped[key] = value
        return super().load_state_dict(remapped, strict=False)
