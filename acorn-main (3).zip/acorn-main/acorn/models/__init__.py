"""Neural encoder and decoder models.

Recipe-specific decoder classes (``MonkeyDecoder``, ``AdversarialMonkeyDecoder``)
are intentionally *not* re-exported here: importing this package must not
require every recipe's file to exist. Import them from their own submodule
(``acorn.models.decoder`` / ``acorn.models.decoder_adversarial``), or
get the right one for a recipe via ``get_recipe(name).decoder_cls``.
"""

from acorn.models.decoder_base import BaseGRUDecoder
from acorn.models.encoder import MonkeyEncoder
from acorn.models.multi_session import (
    MultiSessionModel,
    SessionDecoderView,
    SessionEncoderView,
)
from acorn.models.registry import (
    DEFAULT_RECIPE,
    DEFAULT_SEQUENCE_RECIPE,
    RECIPE_REGISTRY,
    SEQUENCE_RECIPE_REGISTRY,
    RecipeSpec,
    SequenceRecipeSpec,
    get_recipe,
    get_sequence_recipe,
    list_recipes,
    register_recipe,
    register_sequence_recipe,
)

__all__ = [
    "DEFAULT_RECIPE",
    "DEFAULT_SEQUENCE_RECIPE",
    "RECIPE_REGISTRY",
    "SEQUENCE_RECIPE_REGISTRY",
    "BaseGRUDecoder",
    "MonkeyEncoder",
    "MultiSessionModel",
    "RecipeSpec",
    "SequenceRecipeSpec",
    "SessionDecoderView",
    "SessionEncoderView",
    "get_recipe",
    "get_sequence_recipe",
    "list_recipes",
    "register_recipe",
    "register_sequence_recipe",
]
