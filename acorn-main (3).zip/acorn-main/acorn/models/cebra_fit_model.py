"""N=1 sklearn CEBRA.fit adapter satisfying EncoderModel."""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from acorn.models.multi_session import SessionDecoderView, SessionEncoderView


class CebraFitModel(nn.Module):
    """Wraps a fitted sklearn ``CEBRA`` estimator as an ``EncoderModel``."""

    def __init__(self, ceb_hidden: int = 256, ceb_out: int = 64):
        super().__init__()
        self.ceb_hidden = ceb_hidden
        self.ceb_out = ceb_out
        self.estimator = None
        self._session_key: str | None = None
        self._n_neurons: int | None = None
        self._n_labels: dict[str, int] = {}
        self._session_decoders: dict = {}
        self._offset = None

    def add_session(
        self, session_key: str, num_neurons: int, n_labels: int, use_smooth: bool = True
    ) -> None:
        if self._session_key is not None and session_key != self._session_key:
            raise ValueError("offset36_cebra trains a single session (N=1).")
        self._session_key = session_key
        self._n_neurons = num_neurons
        self._n_labels[session_key] = n_labels

    def attach_estimator(self, estimator) -> None:
        self.estimator = estimator
        self._offset = getattr(estimator, "offset_", None)

    def _as_numpy(self, x):
        if hasattr(x, "detach"):
            return x.detach().cpu().numpy()
        return np.asarray(x)

    def encode(self, x: torch.Tensor, lengths: torch.Tensor, session_key: str):
        embs = []
        out_lens = []
        for i in range(x.shape[0]):
            t = int(lengths[i].item()) if lengths is not None else x.shape[1]
            emb = self.transform(x[i, :t], session_key)
            embs.append(emb)
            out_lens.append(emb.shape[0])
        max_t = max(out_lens)
        padded = x.new_zeros(x.shape[0], max_t, self.ceb_out)
        for i, emb in enumerate(embs):
            padded[i, : emb.shape[0]] = emb.to(padded.device)
        return padded, torch.tensor(out_lens, device=x.device, dtype=torch.long)

    def encode_cebra_windows(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        if self.estimator is None or not hasattr(self.estimator, "model_"):
            raise RuntimeError("sklearn CEBRA estimator is not fitted.")
        out = self.estimator.model_(x)
        if out.dim() == 3:
            out = out.squeeze(-1)
        return out

    def _transform_keep_grad(self, x: torch.Tensor) -> torch.Tensor:
        """Pad like sklearn ``CEBRA.transform``, then call ``model_`` without ``no_grad``.

        sklearn ``transform`` always numpy-copies under ``torch.no_grad``, which
        breaks eval-time L2 attacks (``l2_attack_eval``).
        """
        model = getattr(self.estimator, "model_", None)
        if model is None:
            raise RuntimeError("sklearn CEBRA estimator is not fitted.")
        offset = self.get_offset()
        if offset is None:
            raise RuntimeError("sklearn CEBRA estimator has no offset_.")
        # x: (T, neurons) -> (1, neurons, T), edge-pad time like np.pad mode="edge".
        x_in = x.transpose(0, 1).unsqueeze(0)
        x_in = F.pad(x_in, (int(offset.left), int(offset.right) - 1), mode="replicate")
        out = model(x_in)
        if out.dim() == 3:
            out = out.squeeze(0).transpose(0, 1)
        return out

    def transform(self, x: torch.Tensor, session_key: str) -> torch.Tensor:
        if self.estimator is None:
            raise RuntimeError("sklearn CEBRA estimator is not fitted.")
        if isinstance(x, torch.Tensor) and x.requires_grad:
            return self._transform_keep_grad(x)
        device = x.device if isinstance(x, torch.Tensor) else torch.device("cpu")
        arr = self._as_numpy(x)
        out = self.estimator.transform(arr)
        return torch.as_tensor(out, device=device, dtype=torch.float32)

    def get_offset(self):
        if self._offset is not None:
            return self._offset
        if self.estimator is not None and hasattr(self.estimator, "offset_"):
            return self.estimator.offset_
        return None

    def set_session_decoder(self, session_key: str, decoder) -> None:
        self._session_decoders[session_key] = decoder

    def session_decoder(self, session_key: str):
        if session_key in self._session_decoders:
            return self._session_decoders[session_key]
        return SessionDecoderView(self, session_key)

    def session_encoder(self, session_key: str):
        return SessionEncoderView(self, session_key)

    def encoder_parameters(self):
        if self.estimator is not None and hasattr(self.estimator, "model_"):
            yield from self.estimator.model_.parameters()

    def freeze_decoder(self) -> None:
        for decoder in self._session_decoders.values():
            for p in decoder.parameters():
                p.requires_grad_(False)

    def unfreeze_encoder(self) -> None:
        for p in self.encoder_parameters():
            p.requires_grad_(True)

    def encoder_train(self, mode: bool = True) -> None:
        if self.estimator is not None and hasattr(self.estimator, "model_"):
            self.estimator.model_.train(mode)

    def decoder_train(self, mode: bool = True) -> None:
        for decoder in self._session_decoders.values():
            decoder.train(mode)

    def to(self, device):
        super().to(device)
        if self.estimator is not None and hasattr(self.estimator, "to"):
            try:
                self.estimator.to(device)
            except Exception:
                pass
        return self

    def eval(self, *args, **kwargs):
        super().eval()
        if self.estimator is not None and hasattr(self.estimator, "model_"):
            self.estimator.model_.eval()
        return self
