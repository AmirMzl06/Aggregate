"""Recipe registry: encoder-container + decoder + encoder-trainer, bundled.

Register a new recipe with :func:`register_recipe`, then select it via
``TrainConfig.recipe``.

Each builtin recipe is registered independently (its own imports) so a missing
recipe file cannot prevent another recipe from loading. Deferred imports also
let this module be imported from ``train.config`` without a circular import.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from acorn.log import get_logger
from acorn.models.label_format import LabelFormat
from acorn.models.multi_session import MultiSessionModel

DEFAULT_RECIPE = "offset36_gru"
logger = get_logger(__name__)
DEFAULT_SEQUENCE_RECIPE = "offset36_ctc"


class RecipeSpec(BaseModel):
    """Registered time-bin encoder container, decoder, and encoder trainer.

    Select with :class:`~acorn.train.config.TrainConfig` ``recipe``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid", arbitrary_types_allowed=True)

    name: str
    display_name: str
    multi_cls: type[Any]
    decoder_cls: type[Any]
    # Optional constructor kwargs forwarded to multi_cls(...)
    multi_kwargs: dict[str, Any] | None = None
    decoder_kwargs: dict[str, Any] | None = None
    encoder_trainer_cls: type[Any] | None = None
    label_format: LabelFormat = "time_bin_aligned"

    def build_multi(self, *, ceb_hidden: int = 256, ceb_out: int = 64):
        kwargs = {"ceb_hidden": ceb_hidden, "ceb_out": ceb_out}
        if self.multi_kwargs:
            kwargs.update(self.multi_kwargs)
        return self.multi_cls(**kwargs)

    @property
    def trainer_cls(self) -> type[Any]:
        if self.encoder_trainer_cls is None:
            from acorn.train.encoder_trainer import EncoderTrainer

            return EncoderTrainer
        return self.encoder_trainer_cls


class SequenceRecipeSpec(BaseModel):
    """A registered sequence-format (CTC) recipe. Introspection only — not a dispatch key.

    ``trainer_cls`` is a class field (unlike :class:`RecipeSpec`, where
    ``trainer_cls`` is a property that returns the class). Call it as
    ``spec.trainer_cls(model, sessions, device, config)`` — do not add extra ``()``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid", arbitrary_types_allowed=True)

    name: str
    display_name: str
    multi_cls: type[Any]
    trainer_cls: type[Any]
    multi_kwargs: dict[str, Any] | None = None
    label_format: LabelFormat = "sequence"

    def build_multi(
        self,
        *,
        ceb_hidden: int = 256,
        ceb_out: int = 64,
        kernel: int = 32,
        stride: int = 4,
        hidden: int = 1024,
        layers: int = 5,
        dropout: float = 0.4,
        bidir: bool = True,
    ):
        kwargs = {
            "ceb_hidden": ceb_hidden,
            "ceb_out": ceb_out,
            "kernel": kernel,
            "stride": stride,
            "hidden": hidden,
            "layers": layers,
            "dropout": dropout,
            "bidir": bidir,
        }
        if self.multi_kwargs:
            kwargs.update(self.multi_kwargs)
        return self.multi_cls(**kwargs)


RECIPE_REGISTRY: dict[str, RecipeSpec] = {}
SEQUENCE_RECIPE_REGISTRY: dict[str, SequenceRecipeSpec] = {}


def register_recipe(spec: RecipeSpec) -> RecipeSpec:
    """Register a time-bin recipe. Names must be unique.

    Parameters
    ----------
    spec : RecipeSpec
        Bundle to add to :data:`RECIPE_REGISTRY`.

    Returns
    -------
    RecipeSpec
        The same ``spec``.

    Raises
    ------
    ValueError
        If ``spec.name`` is already registered.
    """
    if spec.name in RECIPE_REGISTRY:
        raise ValueError(f"Recipe {spec.name!r} is already registered.")
    RECIPE_REGISTRY[spec.name] = spec
    return spec


def register_sequence_recipe(spec: SequenceRecipeSpec) -> SequenceRecipeSpec:
    """Register a sequence recipe. Names must be unique.

    Parameters
    ----------
    spec : SequenceRecipeSpec
        Bundle to add to :data:`SEQUENCE_RECIPE_REGISTRY`.

    Returns
    -------
    SequenceRecipeSpec
        The same ``spec``.

    Raises
    ------
    ValueError
        If ``spec.name`` is already registered.
    """
    if spec.name in SEQUENCE_RECIPE_REGISTRY:
        raise ValueError(f"Sequence recipe {spec.name!r} is already registered.")
    SEQUENCE_RECIPE_REGISTRY[spec.name] = spec
    return spec


def get_recipe(name: str = DEFAULT_RECIPE) -> RecipeSpec:
    """Return a time-bin :class:`RecipeSpec`.

    Parameters
    ----------
    name : str, optional
        Recipe name. Default ``offset36_gru``.

    Returns
    -------
    RecipeSpec
        Registered bundle.

    Raises
    ------
    KeyError
        If ``name`` is unknown or is registered only for sequence training.
    """
    _register_builtin_recipes()
    if name in RECIPE_REGISTRY:
        return RECIPE_REGISTRY[name]
    if name in SEQUENCE_RECIPE_REGISTRY:
        raise KeyError(
            f"Recipe {name!r} is registered for sequence training. "
            "Use get_sequence_recipe, not get_recipe."
        )
    raise KeyError(f"Unknown recipe {name!r}. Registered: {sorted(RECIPE_REGISTRY)}")


def get_sequence_recipe(name: str = DEFAULT_SEQUENCE_RECIPE) -> SequenceRecipeSpec:
    """Return a sequence :class:`SequenceRecipeSpec`.

    Parameters
    ----------
    name : str, optional
        Recipe name. Default ``offset36_ctc``.

    Returns
    -------
    SequenceRecipeSpec
        Registered bundle.

    Raises
    ------
    KeyError
        If ``name`` is unknown or is registered only for time-bin training.
    """
    _register_builtin_recipes()
    if name in SEQUENCE_RECIPE_REGISTRY:
        return SEQUENCE_RECIPE_REGISTRY[name]
    if name in RECIPE_REGISTRY:
        raise KeyError(
            f"Recipe {name!r} is registered for time-bin training. "
            "Use get_recipe, not get_sequence_recipe."
        )
    raise KeyError(
        f"Unknown sequence recipe {name!r}. Registered: {sorted(SEQUENCE_RECIPE_REGISTRY)}"
    )


def list_recipes(*, label_format: LabelFormat | None = None) -> list[str]:
    """Sorted recipe names.

    Parameters
    ----------
    label_format : {None, 'time_bin_aligned', 'sequence'}, optional
        Restrict to one family. ``None`` returns the union.

    Returns
    -------
    list of str
        Sorted recipe names.
    """
    _register_builtin_recipes()
    if label_format == "sequence":
        return sorted(SEQUENCE_RECIPE_REGISTRY)
    if label_format == "time_bin_aligned":
        return sorted(RECIPE_REGISTRY)
    return sorted(set(RECIPE_REGISTRY) | set(SEQUENCE_RECIPE_REGISTRY))


def _register_builtin_recipes() -> None:
    _register_offset36_gru()
    _register_offset36_gru_advdec()
    _register_offset36_cebra()
    _register_offset36_ctc()


def _register_offset36_gru() -> None:
    if DEFAULT_RECIPE in RECIPE_REGISTRY:
        return
    try:
        from acorn.models.decoder import MonkeyDecoder
        from acorn.train.encoder_trainer import EncoderTrainer
    except ModuleNotFoundError as exc:
        logger.debug("[recipe] skipped %r: %s", DEFAULT_RECIPE, exc)
        return
    register_recipe(
        RecipeSpec(
            name=DEFAULT_RECIPE,
            display_name="Offset36_multi + MonkeyDecoder (GRU)",
            multi_cls=MultiSessionModel,
            decoder_cls=MonkeyDecoder,
            encoder_trainer_cls=EncoderTrainer,
        )
    )


def _register_offset36_gru_advdec() -> None:
    if "offset36_gru_advdec" in RECIPE_REGISTRY:
        return
    try:
        from acorn.models.decoder_adversarial import AdversarialMonkeyDecoder
        from acorn.train.encoder_trainer_advdec import AdvDecEncoderTrainer
    except ModuleNotFoundError as exc:
        logger.debug("[recipe] skipped 'offset36_gru_advdec': %s", exc)
        return
    register_recipe(
        RecipeSpec(
            name="offset36_gru_advdec",
            display_name="Offset36_multi + AdversarialMonkeyDecoder",
            multi_cls=MultiSessionModel,
            decoder_cls=AdversarialMonkeyDecoder,
            decoder_kwargs={"adv_eps": 0.1},
            encoder_trainer_cls=AdvDecEncoderTrainer,
        )
    )


def _register_offset36_cebra() -> None:
    if "offset36_cebra" in RECIPE_REGISTRY:
        return
    try:
        from acorn.models.cebra_fit_model import CebraFitModel
        from acorn.models.decoder import MonkeyDecoder
        from acorn.train.cebra_fit import CebraFitTrainer
    except ModuleNotFoundError as exc:
        logger.debug("[recipe] skipped 'offset36_cebra': %s", exc)
        return
    register_recipe(
        RecipeSpec(
            name="offset36_cebra",
            display_name="sklearn CEBRA.fit + MonkeyDecoder",
            multi_cls=CebraFitModel,
            decoder_cls=MonkeyDecoder,
            encoder_trainer_cls=CebraFitTrainer,
        )
    )


def _register_offset36_ctc() -> None:
    if DEFAULT_SEQUENCE_RECIPE in SEQUENCE_RECIPE_REGISTRY:
        return
    try:
        from acorn.models.sequence.multi_task_model import SequenceMultiTaskModel
        from acorn.train.sequence.ctc_trainer import CtcTrainer
    except ModuleNotFoundError as exc:
        logger.debug("[recipe] skipped %r: %s", DEFAULT_SEQUENCE_RECIPE, exc)
        return
    register_sequence_recipe(
        SequenceRecipeSpec(
            name=DEFAULT_SEQUENCE_RECIPE,
            display_name="Offset36_multi + CTC GRU (sequence / B2T)",
            multi_cls=SequenceMultiTaskModel,
            trainer_cls=CtcTrainer,
        )
    )


_register_builtin_recipes()
