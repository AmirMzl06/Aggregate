"""Label-format families: the axis that splits Acorn's training pipelines.

A family is defined by how labels line up with the neural time series, not by
task type (speech vs handwriting vs EMG). Plug-ins (dataset shape, sampler,
task head, training loop, eval metric) live per format; the encoder trunk,
InfoNCE criterion, PGD primitives, and run-directory conventions are shared.
"""

from __future__ import annotations

from typing import Literal

LabelFormat = Literal["time_bin_aligned", "sequence"]
