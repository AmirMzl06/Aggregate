"""Two-layer MLP probe fitted on frozen embeddings."""

from __future__ import annotations

from contextlib import nullcontext

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import r2_score
from torch import optim

from acorn.train.config import set_seed


class TwoLayerMLP(nn.Module):
    """Linear-ReLU-Linear decoder; full-batch MSE for ``max_iters`` steps."""

    def __init__(
        self,
        input_dim,
        hidden_dim=64,
        output_dim=2,
        lr=1e-3,
        weight_decay=2e-4,
        max_iters=10000,
        device=None,
        verbose=False,
        n_train_steps=None,
        **_ignored,
    ):
        super().__init__()
        self.device = device
        self.verbose = verbose
        self.max_iters = int(n_train_steps) if n_train_steps is not None else int(max_iters)
        self.lr = lr
        self.weight_decay = weight_decay
        self.best_epoch_ = 0
        self.best_val_r2_ = float("nan")
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )
        self._init_weights()
        if device is not None:
            self.to(device)

    def _init_weights(self):
        for module in self.net:
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                nn.init.constant_(module.bias, 0.0)

    def forward(self, embs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor:
        return self.net(embs)

    def forward_window(self, x, y, device):
        return self.forward(x), y

    def _autocast(self, device):
        if torch.cuda.is_available() and str(device).startswith("cuda"):
            return torch.autocast("cuda", dtype=torch.bfloat16)
        return nullcontext()

    def fit(self, train_emb: torch.Tensor, train_y: torch.Tensor, seed: int = 42, **_kwargs):
        device = self.device or train_emb.device
        self.device = device
        self.to(device)
        set_seed(seed)
        train_x = train_emb.to(device).float()
        train_y = train_y.to(device).float()
        criterion = nn.MSELoss()
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        for _ in range(self.max_iters):
            self.train()
            optimizer.zero_grad(set_to_none=True)
            with self._autocast(device):
                loss = criterion(self(train_x), train_y)
            loss.backward()
            optimizer.step()
        self.best_epoch_ = self.max_iters
        return self

    def score(self, emb: torch.Tensor, y, device) -> float:
        self.eval()
        with torch.no_grad():
            predictions = self(emb.float().to(device)).cpu().numpy()
            true_values = y.cpu().numpy() if hasattr(y, "cpu") else np.asarray(y)
        r2_scores = [
            r2_score(true_values[:, i], predictions[:, i]) for i in range(predictions.shape[1])
        ]
        return float(sum(r2_scores) / len(r2_scores))
