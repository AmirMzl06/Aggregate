"""GRU decoder with L2 PGD on embedding windows (offset36_gru_advdec recipe).

Subclasses :class:`BaseGRUDecoder` directly — never :class:`MonkeyDecoder` —
so removing the default recipe does not affect this file.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import optim

from acorn.models.decoder_base import BaseGRUDecoder, sample_embedding_windows
from acorn.train.adversarial import l2_normalize, proj_l2_ball, rand_radius_like


class AdversarialMonkeyDecoder(BaseGRUDecoder):
    """After each clean MSE step, run L2 PGD on the same embedding batch."""

    def __init__(
        self,
        *args,
        adv_eps: float = 0.1,
        adv_alpha: float | None = None,
        adv_steps: int = 10,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.adv_eps = float(adv_eps)
        self.adv_alpha = float(adv_alpha) if adv_alpha is not None else self.adv_eps / 5.0
        self.adv_steps = int(adv_steps)

    def _train_window_step(
        self,
        train_x: torch.Tensor,
        train_y: torch.Tensor,
        window_size: int,
        device: torch.device,
        optimizer: optim.Optimizer,
        mse_fn: nn.Module,
    ) -> torch.Tensor | None:
        self.train()
        x_batch, y_batch, lengths = sample_embedding_windows(
            train_x, train_y, self.batch_size, window_size, device
        )
        pred = self.forward(x_batch, lengths)
        loss = mse_fn(pred, y_batch)
        if not torch.isfinite(loss):
            return None
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.parameters(), 1.0)
        optimizer.step()

        eps = self.adv_eps
        alpha = self.adv_alpha
        steps = self.adv_steps
        x_adv = (
            x_batch + l2_normalize(torch.randn_like(x_batch)) * rand_radius_like(x_batch) * eps
        ).detach()
        x_adv.requires_grad_(True)
        for _ in range(steps):
            adv_loss = mse_fn(self.forward(x_adv, lengths), y_batch)
            (grad_x,) = torch.autograd.grad(adv_loss, x_adv, retain_graph=False, create_graph=False)
            with torch.no_grad():
                x_adv = proj_l2_ball(x_adv + alpha * l2_normalize(grad_x), x_batch, eps)
            x_adv.requires_grad_(True)
        x_adv.requires_grad_(False)
        optimizer.zero_grad(set_to_none=True)
        adv_loss = mse_fn(self.forward(x_adv, lengths), y_batch)
        if torch.isfinite(adv_loss):
            adv_loss.backward()
            nn.utils.clip_grad_norm_(self.parameters(), 1.0)
            optimizer.step()

        return loss
