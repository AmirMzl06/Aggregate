"""Fan-style English normalize used for ``char_cer`` / ``wer``.

Matches ``CORP/decoder_utils.py`` (replace ``>`` then ``~``, then whitespace
split).
"""

from __future__ import annotations


def normalize_nlp(text: str) -> str:
    return text.replace(">", " ").replace("~", ".").replace("#", "").strip()


def normalize_speech(text: str) -> str:
    return text.strip()


def normalize_text(text: str, task_key: str) -> str:
    if task_key == "nlp":
        return normalize_nlp(text)
    if task_key == "speech":
        return normalize_speech(text)
    raise ValueError(f"Unknown task_key {task_key!r}")


def words(text: str, task_key: str) -> list[str]:
    return normalize_text(text, task_key).split(" ")


def cleanup_nbest_text(text: str) -> str:
    """Hypothesis cleanup inside CORP ``gpt2_lm_decode`` before neural scoring."""
    hyp = text.strip()
    hyp = hyp.replace(">", "")
    hyp = hyp.replace("  ", " ")
    hyp = hyp.replace(" ,", ",")
    hyp = hyp.replace(" .", ".")
    hyp = hyp.replace(" ?", "?")
    return hyp
