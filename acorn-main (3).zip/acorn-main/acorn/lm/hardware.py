"""Fail-fast RAM and graph-dir probes. No Docker inspect."""

from __future__ import annotations

import math
import os
from pathlib import Path

from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.presets import DecodePreset

NLP_WORDS_PREFIX = ("<eps>", ">", ",", "?", ".", "'")


def available_ram_bytes() -> int:
    try:
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
    except (ValueError, OSError) as exc:
        raise LmPrerequisiteError(f"Cannot read physical RAM: {exc}") from exc


def effective_memory_gib(preset: DecodePreset, *, host_ram_bytes: int | None = None) -> int:
    """``min(preset, floor(0.9*host))`` in GiB — never omit at run time."""
    host = host_ram_bytes if host_ram_bytes is not None else available_ram_bytes()
    preset_gib = max(1, preset.ram_bytes // 1024**3)
    host_cap_gib = max(1, math.floor(0.9 * host / 1024**3))
    return min(preset_gib, host_cap_gib)


def memory_flag(preset: DecodePreset, *, host_ram_bytes: int | None = None) -> str:
    return f"{effective_memory_gib(preset, host_ram_bytes=host_ram_bytes)}g"


def require_ram(preset: DecodePreset, *, available: int | None = None) -> None:
    have = available if available is not None else available_ram_bytes()
    cap_gib = effective_memory_gib(preset, host_ram_bytes=have)
    preset_gib = max(1, preset.ram_bytes // 1024**3)
    if cap_gib < preset_gib:
        raise LmPrerequisiteError(
            f"Preset {preset.name} wants ~{preset_gib} GiB RAM; "
            f"min(preset, floor(0.9*host)) = {cap_gib} GiB "
            f"({have / 1024**3:.1f} GiB host reported). "
            "NLP decode is the 64 GiB path; speech 5-gram + G_no_prune is ~350 GiB."
        )


def _read_words_tokens(words_path: Path) -> list[str]:
    tokens: list[str] = []
    for line in words_path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        tokens.append(line.split()[0])
        if len(tokens) >= 6:
            break
    return tokens


def validate_words_txt(words_path: Path, task_key: str) -> None:
    tokens = _read_words_tokens(words_path)
    if task_key == "nlp":
        if tokens[:6] != list(NLP_WORDS_PREFIX):
            raise LmPrerequisiteError(
                f"NLP words.txt prefix mismatch in {words_path}: "
                f"expected {list(NLP_WORDS_PREFIX)}, got {tokens[:6]}"
            )
        return
    if task_key == "speech":
        if not tokens or tokens[0] != "<eps>":
            raise LmPrerequisiteError(f"Speech words.txt must start with <eps>, got {tokens[:1]}")
        if len(tokens) < 2 or tokens[1] == ">":
            raise LmPrerequisiteError(
                f"Speech words.txt second token must not be '>', got {tokens[1]!r}"
            )
        return
    raise ValueError(f"Unknown task_key {task_key!r}")


def require_tlg_dir(tlg_dir: Path, preset: DecodePreset) -> None:
    tlg_dir = Path(tlg_dir)
    tlg = tlg_dir / "TLG.fst"
    words = tlg_dir / "words.txt"
    missing = [str(p) for p in (tlg, words) if not p.is_file()]
    if missing:
        raise LmPrerequisiteError(
            "Kaldi graph dir is missing "
            + ", ".join(missing)
            + ". Download the Dryad language-model archive."
        )
    validate_words_txt(words, preset.task_key)
    if preset.lattice_rescore:
        for name in ("G.fst", "G_no_prune.fst"):
            path = tlg_dir / name
            if not path.is_file():
                raise LmPrerequisiteError(
                    f"Preset {preset.name} sets lattice_rescore but {path} is missing."
                )
