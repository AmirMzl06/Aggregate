"""Original CORP decode knobs. ``original_preset`` is the only True-path selector."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class DecodePreset:
    name: str
    task_key: str
    graph_tier: str
    nbest: int
    beam: float
    search_acoustic_scale: float
    mix_acoustic_scale: float
    blank_penalty: float
    lattice_rescore: bool
    neural_alpha: float
    neural_model: str
    neural_8bit: bool
    max_active: int = 7000
    min_active: int = 200
    lattice_beam: float = 8.0
    ctc_blank_skip_threshold: float = 1.0
    length_penalty: float = 0.0
    ram_bytes: int = 0
    tlg_bytes: int = 0
    extra_fst_bytes: int = 0


NLP_ORIGINAL = DecodePreset(
    name="nlp_original",
    task_key="nlp",
    graph_tier="nlp_3gram",
    nbest=10,
    beam=17.0,
    search_acoustic_scale=0.8,
    mix_acoustic_scale=0.5,
    blank_penalty=math.log(11.0),
    lattice_rescore=False,
    neural_alpha=1.0,
    neural_model="gpt2-xl",
    neural_8bit=False,
    ram_bytes=64 * 1024**3,
    tlg_bytes=9_917_672_962,
)

SPEECH_ORIGINAL = DecodePreset(
    name="speech_original",
    task_key="speech",
    graph_tier="speech_5gram",
    nbest=100,
    beam=18.0,
    search_acoustic_scale=0.5,
    mix_acoustic_scale=0.5,
    blank_penalty=math.log(7.0),
    lattice_rescore=True,
    neural_alpha=0.5,
    neural_model="facebook/opt-6.7b",
    neural_8bit=True,
    ram_bytes=350 * 1024**3,
    tlg_bytes=44_119_718_526,
    extra_fst_bytes=5_464_795_386 + 80_381_089_054,
)


def original_preset(task_key: str) -> DecodePreset:
    if task_key == "nlp":
        return NLP_ORIGINAL
    if task_key == "speech":
        return SPEECH_ORIGINAL
    raise ValueError(f"Unknown task_key {task_key!r}; expected 'nlp' or 'speech'")
