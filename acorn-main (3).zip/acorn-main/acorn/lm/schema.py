"""Load ``acorn.ctc_export.v1`` / ``v1.1`` session bundles."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch

SCHEMA_V1 = "acorn.ctc_export.v1"
SCHEMA_V1_1 = "acorn.ctc_export.v1.1"
SUPPORTED_SCHEMAS = {SCHEMA_V1, SCHEMA_V1_1}
MANIFEST_NAME = "ctc_export_manifest.json"


def _torch_load(path: Path) -> Any:
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


@dataclass(frozen=True)
class SessionExport:
    path: Path
    dataset_key: str
    task_key: str
    session_key: str
    vocab: list[str]
    blank_index: int
    logits: list[torch.Tensor]
    input_lengths: torch.Tensor
    label_ids: list[torch.Tensor]
    transcripts: list[str] | None = None

    @property
    def n_trials(self) -> int:
        return len(self.logits)

    @property
    def has_transcripts(self) -> bool:
        return self.transcripts is not None


@dataclass(frozen=True)
class ExportManifest:
    schema: str
    root: Path
    datasets: list[dict[str, Any]]

    def entry(self, session_key: str | None = None) -> dict[str, Any]:
        if not self.datasets:
            raise ValueError(f"No datasets in manifest at {self.root}")
        if session_key is None:
            if len(self.datasets) != 1:
                keys = [d.get("session_key") for d in self.datasets]
                raise ValueError(f"Pass session_key; manifest has {keys}")
            return self.datasets[0]
        for item in self.datasets:
            if item.get("session_key") == session_key:
                return item
        raise KeyError(f"session_key {session_key!r} not in {self.root}")


def load_manifest(export_dir: Path) -> ExportManifest:
    export_dir = Path(export_dir)
    raw = json.loads((export_dir / MANIFEST_NAME).read_text())
    schema = raw.get("schema")
    if schema not in SUPPORTED_SCHEMAS:
        raise ValueError(
            f"Unsupported schema {schema!r}; expected one of {sorted(SUPPORTED_SCHEMAS)}"
        )
    datasets = raw.get("datasets")
    if not isinstance(datasets, list) or not datasets:
        raise ValueError("Manifest 'datasets' must be a non-empty list")
    return ExportManifest(schema=schema, root=export_dir, datasets=datasets)


def list_session_keys(export_dir: Path) -> list[str]:
    manifest = load_manifest(export_dir)
    return [str(item["session_key"]) for item in manifest.datasets]


def load_session(export_dir: Path, session_key: str | None = None) -> SessionExport:
    manifest = load_manifest(export_dir)
    entry = manifest.entry(session_key)
    pt_path = manifest.root / entry["path"]
    bundle = _torch_load(pt_path)
    return session_from_bundle(bundle, path=pt_path, entry=entry)


def session_from_bundle(
    bundle: dict[str, Any],
    *,
    path: Path | None = None,
    entry: dict[str, Any] | None = None,
) -> SessionExport:
    """Build a ``SessionExport`` from an in-memory logits bundle (or a loaded ``.pt``)."""
    entry = entry or {}
    pt_path = Path(path) if path is not None else Path(".")
    logits = [t.detach().cpu().float() for t in bundle["logits"]]
    lengths = bundle["input_lengths"].detach().cpu().long()
    labels = [t.detach().cpu().long() for t in bundle["label_ids"]]
    if len(logits) != int(lengths.numel()) or len(logits) != len(labels):
        raise ValueError(
            f"{pt_path}: logits/input_lengths/label_ids length mismatch "
            f"({len(logits)}, {int(lengths.numel())}, {len(labels)})"
        )
    transcripts_raw = bundle.get("transcripts")
    transcripts: list[str] | None
    if transcripts_raw is None:
        transcripts = None
    else:
        transcripts = [str(x) for x in transcripts_raw]
        if len(transcripts) != len(logits):
            raise ValueError(
                f"{pt_path}: len(transcripts)={len(transcripts)} != len(logits)={len(logits)}"
            )
    for i, tensor in enumerate(logits):
        if tensor.ndim != 2:
            raise ValueError(f"{pt_path} trial {i}: expected (T, C), got {tuple(tensor.shape)}")
        if int(lengths[i]) != tensor.shape[0]:
            raise ValueError(
                f"{pt_path} trial {i}: input_lengths={int(lengths[i])} but T={tensor.shape[0]}"
            )
    blank = int(bundle.get("blank_index", entry.get("blank_index", 0)))
    return SessionExport(
        path=pt_path,
        dataset_key=str(bundle.get("dataset_key", entry.get("dataset_key", ""))),
        task_key=str(bundle.get("task_key", entry.get("task_key", ""))),
        session_key=str(bundle.get("session_key", entry.get("session_key", ""))),
        vocab=[str(x) for x in bundle.get("vocab", entry.get("vocab", []))],
        blank_index=blank,
        logits=logits,
        input_lengths=lengths,
        label_ids=labels,
        transcripts=transcripts,
    )
