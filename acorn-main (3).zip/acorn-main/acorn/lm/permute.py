"""Map Acorn-native CTC channels to Kaldi ``lm_decoder`` order.

``DecodeNumpy`` log-softmaxes then subtracts the blank penalty from column 0,
so blank must be channel 0 at the sidecar boundary.

NLP Acorn order already matches Kaldi
``[BLANK, >, comma, ?, ~, ', a–z]``. Do **not** apply CORP
``rearrange_handwriting_logits`` to Acorn logits.

Speech Acorn order is ``[BLANK, phones…, SIL]``. Kaldi wants
``[BLANK, SIL, phones…]``.
"""

from __future__ import annotations

import numpy as np
import torch

NLP_CLASSES = 32
SPEECH_CLASSES = 41


def permute_to_kaldi(logits: np.ndarray | torch.Tensor, task_key: str) -> np.ndarray:
    array = np.asarray(logits, dtype=np.float32)
    if array.ndim != 2:
        raise ValueError(f"Expected (T, C) logits, got {array.shape}")
    _, n_classes = array.shape
    if task_key == "nlp":
        if n_classes != NLP_CLASSES:
            raise ValueError(f"NLP logits must have C={NLP_CLASSES}, got {n_classes}")
        return np.ascontiguousarray(array)
    if task_key == "speech":
        if n_classes != SPEECH_CLASSES:
            raise ValueError(f"Speech logits must have C={SPEECH_CLASSES}, got {n_classes}")
        blank = array[:, :1]
        sil = array[:, -1:]
        phones = array[:, 1:-1]
        return np.ascontiguousarray(np.concatenate([blank, sil, phones], axis=-1))
    raise ValueError(f"Unknown task_key {task_key!r}; expected 'nlp' or 'speech'.")
