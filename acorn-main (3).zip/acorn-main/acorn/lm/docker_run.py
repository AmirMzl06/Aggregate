"""Build and run Kaldi (CPU) and neural (CUDA) sidecar images."""

# Neural HF wheels live only in the neural Docker image, never on the host.

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import warnings
from collections.abc import Iterator
from contextlib import contextmanager
from importlib.resources import files
from pathlib import Path

from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.hardware import effective_memory_gib, memory_flag
from acorn.lm.presets import DecodePreset

KALDI_IMAGE = "acorn-lm-kaldi:latest"
NEURAL_IMAGE = "acorn-lm-neural:latest"

_SIDECAR_FILES = {
    "kaldi": ("Dockerfile", "decode_worker.py"),
    "neural": ("Dockerfile", "worker.py"),
}


def require_docker() -> None:
    if shutil.which("docker") is None:
        raise LmPrerequisiteError(
            "docker is not on PATH. LM rescoring needs Docker "
            "(Kaldi CPU image and neural CUDA image)."
        )
    # Ping the daemon so a down daemon fails here, not later as `docker build`.
    _docker_info_text("{{.ServerVersion}}")


def _docker_subcommand(cmd: object) -> str:
    if isinstance(cmd, (list, tuple)) and len(cmd) >= 2:
        return str(cmd[1])
    if isinstance(cmd, str):
        parts = cmd.split()
        if len(parts) >= 2:
            return parts[1]
    return "command"


def _run_docker(cmd: list[str], **kwargs) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, **kwargs)
    except FileNotFoundError as exc:
        raise LmPrerequisiteError(
            "docker is not on PATH. LM rescoring needs Docker "
            "(Kaldi CPU image and neural CUDA image)."
        ) from exc
    except subprocess.CalledProcessError as exc:
        sub = _docker_subcommand(exc.cmd)
        if sub == "info":
            raise LmPrerequisiteError(
                "Cannot query Docker (`docker info` failed). "
                "If the daemon is not running, start Docker and retry."
            ) from exc
        raise LmPrerequisiteError(f"`docker {sub}` failed (exit {exc.returncode}).") from exc


def _docker_info_text(fmt: str) -> str:
    result = _run_docker(
        ["docker", "info", "--format", fmt],
        capture_output=True,
        text=True,
        check=True,
    )
    if result.returncode != 0:
        raise LmPrerequisiteError(
            "Cannot query Docker (`docker info` failed). "
            "If the daemon is not running, start Docker and retry."
        )
    return result.stdout or ""


def docker_has_nvidia_runtime() -> bool:
    require_docker()
    runtimes = _docker_info_text("{{json .Runtimes}}")
    if "nvidia" in runtimes.lower():
        return True
    return "nvidia" in _docker_info_text("{{.DefaultRuntime}}").lower()


def docker_image_exists(image: str) -> bool:
    require_docker()
    result = _run_docker(
        ["docker", "image", "inspect", image],
        capture_output=True,
        check=False,
    )
    return result.returncode == 0


@contextmanager
def _sidecar_build_context(kind: str) -> Iterator[Path]:
    names = _SIDECAR_FILES[kind]
    root = files("acorn.lm") / "sidecar" / kind
    with tempfile.TemporaryDirectory(prefix=f"acorn-lm-{kind}-ctx-") as tmp:
        ctx = Path(tmp)
        for name in names:
            dest = ctx / name
            dest.write_bytes((root / name).read_bytes())
        yield ctx


def build_kaldi_image(*, image: str = KALDI_IMAGE) -> None:
    require_docker()
    with _sidecar_build_context("kaldi") as ctx:
        _run_docker(
            ["docker", "build", "-f", str(ctx / "Dockerfile"), "-t", image, str(ctx)],
            check=True,
        )


def build_neural_image(*, image: str = NEURAL_IMAGE) -> None:
    require_docker()
    with _sidecar_build_context("neural") as ctx:
        _run_docker(
            ["docker", "build", "-f", str(ctx / "Dockerfile"), "-t", image, str(ctx)],
            check=True,
        )


def ensure_images(
    *,
    kaldi_image: str = KALDI_IMAGE,
    neural_image: str = NEURAL_IMAGE,
) -> None:
    if not docker_image_exists(kaldi_image):
        build_kaldi_image(image=kaldi_image)
    if not docker_image_exists(neural_image):
        build_neural_image(image=neural_image)


def hf_cache_dir() -> Path:
    env = os.environ.get("HF_HOME")
    if env:
        return Path(env).expanduser().resolve()
    return (Path.home() / ".cache" / "huggingface").expanduser().resolve()


def docker_kaldi_args(
    *,
    job_dir: Path,
    tlg_dir: Path,
    out_path: Path,
    preset: DecodePreset,
    image: str = KALDI_IMAGE,
    host_ram_bytes: int | None = None,
) -> list[str]:
    job_dir = Path(job_dir).resolve()
    tlg_dir = Path(tlg_dir).resolve()
    out_path = Path(out_path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    return [
        "docker",
        "run",
        "--rm",
        "--memory",
        memory_flag(preset, host_ram_bytes=host_ram_bytes),
        "-v",
        f"{job_dir}:/job:ro",
        "-v",
        f"{tlg_dir}:/tlg:ro",
        "-v",
        f"{out_path.parent}:/out",
        image,
        "--job",
        "/job",
        "--tlg",
        "/tlg",
        "--out",
        f"/out/{out_path.name}",
    ]


def docker_neural_args(
    *,
    nbest_path: Path,
    out_path: Path,
    preset: DecodePreset,
    gpus: bool,
    image: str = NEURAL_IMAGE,
    host_ram_bytes: int | None = None,
    hf_home: Path | None = None,
) -> list[str]:
    nbest_path = Path(nbest_path).resolve()
    out_path = Path(out_path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cache = Path(hf_home).expanduser().resolve() if hf_home is not None else hf_cache_dir()
    cache.mkdir(parents=True, exist_ok=True)
    cmd = [
        "docker",
        "run",
        "--rm",
        "--memory",
        memory_flag(preset, host_ram_bytes=host_ram_bytes),
    ]
    if gpus:
        cmd.extend(["--gpus", "all"])
    cmd.extend(
        [
            "-v",
            f"{nbest_path.parent}:/nbest:ro",
            "-v",
            f"{cache}:/hf",
            "-v",
            f"{out_path.parent}:/out",
            "-e",
            "HF_HOME=/hf",
            image,
            "--nbest",
            f"/nbest/{nbest_path.name}",
            "--out",
            f"/out/{out_path.name}",
            "--model",
            preset.neural_model,
            "--alpha",
            str(preset.neural_alpha),
            "--acoustic-scale",
            str(preset.mix_acoustic_scale),
        ]
    )
    if preset.neural_8bit:
        cmd.append("--load-in-8bit")
    return cmd


def run_kaldi_decode(
    job_dir: Path,
    tlg_dir: Path,
    out_path: Path,
    preset: DecodePreset,
    *,
    image: str = KALDI_IMAGE,
    host_ram_bytes: int | None = None,
) -> None:
    cmd = docker_kaldi_args(
        job_dir=job_dir,
        tlg_dir=tlg_dir,
        out_path=out_path,
        preset=preset,
        image=image,
        host_ram_bytes=host_ram_bytes,
    )
    _run_docker(cmd, check=True)


def run_neural_rescore(
    nbest_path: Path,
    out_path: Path,
    preset: DecodePreset,
    *,
    image: str = NEURAL_IMAGE,
    host_ram_bytes: int | None = None,
    hf_home: Path | None = None,
) -> None:
    has_nvidia = docker_has_nvidia_runtime()
    if preset.task_key == "speech" and not has_nvidia:
        raise LmPrerequisiteError(
            "Speech LM uses OPT-6.7B 8-bit and needs Docker's NVIDIA runtime."
        )
    if preset.task_key == "nlp" and not has_nvidia:
        warnings.warn(
            "Docker has no NVIDIA runtime; running GPT-2 XL neural rescore on CPU (slow).",
            stacklevel=2,
        )
    cmd = docker_neural_args(
        nbest_path=nbest_path,
        out_path=out_path,
        preset=preset,
        gpus=has_nvidia,
        image=image,
        host_ram_bytes=host_ram_bytes,
        hf_home=hf_home,
    )
    _run_docker(cmd, check=True)


# Re-export so tests can patch a single memory helper.
__all__ = [
    "KALDI_IMAGE",
    "NEURAL_IMAGE",
    "build_kaldi_image",
    "build_neural_image",
    "docker_has_nvidia_runtime",
    "docker_image_exists",
    "docker_kaldi_args",
    "docker_neural_args",
    "effective_memory_gib",
    "ensure_images",
    "hf_cache_dir",
    "memory_flag",
    "require_docker",
    "run_kaldi_decode",
    "run_neural_rescore",
]
