"""``acorn_lm.nbest.v1`` — word-level n-best from the Kaldi sidecar."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_V1 = "acorn_lm.nbest.v1"


@dataclass
class Hypothesis:
    text: str
    acoustic_score: float
    ngram_score: float


@dataclass
class NBest:
    session_key: str
    task_key: str
    trials: list[list[Hypothesis]] = field(default_factory=list)

    @property
    def n_trials(self) -> int:
        return len(self.trials)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA_V1,
            "session_key": self.session_key,
            "task_key": self.task_key,
            "trials": [
                {
                    "hypotheses": [
                        {
                            "text": hyp.text,
                            "acoustic_score": hyp.acoustic_score,
                            "ngram_score": hyp.ngram_score,
                        }
                        for hyp in trial
                    ]
                }
                for trial in self.trials
            ],
        }


def save_nbest(nbest: NBest, path: Path) -> None:
    path = Path(path)
    path.write_text(json.dumps(nbest.to_dict(), indent=2))


def load_nbest(path: Path) -> NBest:
    raw = json.loads(Path(path).read_text())
    schema = raw.get("schema")
    if schema != SCHEMA_V1:
        raise ValueError(f"Unsupported n-best schema {schema!r}; expected {SCHEMA_V1}")
    trials: list[list[Hypothesis]] = []
    for trial in raw["trials"]:
        hyps = [
            Hypothesis(
                text=str(h["text"]),
                acoustic_score=float(h["acoustic_score"]),
                ngram_score=float(h["ngram_score"]),
            )
            for h in trial["hypotheses"]
        ]
        trials.append(hyps)
    return NBest(
        session_key=str(raw["session_key"]),
        task_key=str(raw["task_key"]),
        trials=trials,
    )
