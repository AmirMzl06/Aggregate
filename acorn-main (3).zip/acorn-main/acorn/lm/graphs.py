"""LM graph cache paths under ``~/.cache/acorn/lm``."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from acorn.lm.presets import DecodePreset


def _lm_cache_root() -> Path:
    env = os.environ.get("ACORN_LM_CACHE")
    if env:
        return Path(env).expanduser().resolve()
    return (Path.home() / ".cache" / "acorn" / "lm").resolve()


ACORN_LM_CACHE = _lm_cache_root()


def graph_cache_dir(task_key: str) -> Path:
    if task_key == "nlp":
        return ACORN_LM_CACHE / "nlp" / "language_model"
    if task_key == "speech":
        return ACORN_LM_CACHE / "speech" / "5gram"
    raise ValueError(f"Unknown task_key {task_key!r}")


def resolve_graph_dir(preset: DecodePreset, *, graph_dir: Path | None = None) -> Path:
    if graph_dir is not None:
        return Path(graph_dir)
    return graph_cache_dir(preset.task_key)


def flatten_graph_artifacts(src_root: Path, dest: Path, names: tuple[str, ...]) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for name in names:
        matches = sorted(src_root.rglob(name))
        if len(matches) != 1:
            raise FileNotFoundError(
                f"Expected exactly one {name} under {src_root}, found {len(matches)}"
            )
        target = dest / name
        if target.exists():
            target.unlink()
        # G_no_prune.fst is ~80 GiB; never slurp the whole file into memory.
        shutil.move(str(matches[0]), str(target))
