"""Dryad REST v2 downloads for Kaldi graphs. NLP zip and speech 5-gram only."""

from __future__ import annotations

import hashlib
import json
import shutil
import tarfile
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from acorn.data.consent import DownloadDeclined, confirm_download
from acorn.lm.graphs import ACORN_LM_CACHE, flatten_graph_artifacts, graph_cache_dir

DRYAD_ROOT = "https://datadryad.org"


class DryadDownloadError(RuntimeError):
    """Dryad API/download failed."""


@dataclass(frozen=True)
class DryadArtifact:
    key: str
    version_number: int
    doi: str
    filename: str
    size_bytes: int
    sha256: str
    cache_subdir: str
    download_gb: float
    peak_disk_gb: float
    ram_gib: int
    extract_only: tuple[str, ...] | None = None
    tar_members: tuple[str, ...] | None = None
    skip_tar_prefixes: tuple[str, ...] = ()
    min_free_gb: float = 0.0


# Pins/sha256 copied from sibling acorn-lm/src/acorn_lm/download.py.
NLP_LM = DryadArtifact(
    key="nlp_lm",
    version_number=4,
    doi="10.5061/dryad.hqbzkh1p6",
    filename="CORP_data_release.zip",
    size_bytes=3_567_072_761,
    sha256="f768e7817befd84a6c5b065ce6bc694f9217907a824d896b1db5dc77dc52c09f",
    cache_subdir="nlp/language_model",
    download_gb=3.57,
    peak_disk_gb=13.0,
    ram_gib=64,
    extract_only=("language_model/",),
    min_free_gb=13.0,
)

SPEECH_5GRAM = DryadArtifact(
    key="speech_5gram",
    version_number=253293,
    doi="10.5061/dryad.x69p8czpq",
    filename="languageModel_5gram.tar.gz",
    size_bytes=38_245_502_441,
    sha256="bb2b15cc13d40e484359ffe0afe74580cdbad02440c27586074bfe2e51e7867e",
    cache_subdir="speech/5gram",
    download_gb=38.2,
    peak_disk_gb=160.0,
    ram_gib=350,
    tar_members=("TLG.fst", "G.fst", "G_no_prune.fst", "words.txt"),
    min_free_gb=160.0,
)


ARTIFACTS = {
    NLP_LM.key: NLP_LM,
    SPEECH_5GRAM.key: SPEECH_5GRAM,
}


def artifact_for_task(task_key: str) -> DryadArtifact:
    if task_key == "nlp":
        return NLP_LM
    if task_key == "speech":
        return SPEECH_5GRAM
    raise ValueError(f"Unknown task_key {task_key!r}")


def _urlified_doi(doi: str) -> str:
    return doi.replace("/", "%2F")


def _manual_hint(artifact: DryadArtifact, dest_dir: Path) -> str:
    return (
        f"Dryad blocked the programmatic download (403/captcha is common). "
        f"Download manually from https://datadryad.org/dataset/doi:{artifact.doi} "
        f"(file {artifact.filename}) and place artifacts under {dest_dir}. "
        f"Cache root: {ACORN_LM_CACHE}."
    )


def _get_json(url: str, artifact: DryadArtifact, dest_dir: Path) -> dict:
    try:
        with urllib.request.urlopen(url) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403}:
            raise DryadDownloadError(_manual_hint(artifact, dest_dir)) from exc
        raise DryadDownloadError(f"Dryad request failed ({exc.code}): {url}") from exc


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _disk_free_gb(path: Path) -> float:
    usage = shutil.disk_usage(path)
    return usage.free / 1024**3


def _prompt_yes(artifact: DryadArtifact, *, assume_yes: bool) -> None:
    confirm_download(
        message=(
            f"Download ~{artifact.download_gb:.1f} GB ({artifact.filename}), "
            f"peak disk ~{artifact.peak_disk_gb:.0f} GB, decode RAM ~{artifact.ram_gib} GiB. "
            f"DOI {artifact.doi}. Proceed?"
        ),
        assume_yes=assume_yes,
        declined=f"Download of {artifact.filename} declined.",
    )


def _version_files_url(artifact: DryadArtifact, dest_dir: Path) -> str:
    versions_url = f"{DRYAD_ROOT}/api/v2/datasets/doi:{_urlified_doi(artifact.doi)}/versions"
    versions_info = _get_json(versions_url, artifact, dest_dir)
    versions = versions_info["_embedded"]["stash:versions"]
    chosen = None
    for item in versions:
        if int(item.get("versionNumber", -1)) == artifact.version_number:
            chosen = item
            break
    if chosen is None:
        chosen = versions[-1]
    return f"{DRYAD_ROOT}{chosen['_links']['stash:files']['href']}"


def _download_stream(url: str, dest: Path, artifact: DryadArtifact, cache_dir: Path) -> None:
    part = dest.with_suffix(dest.suffix + ".part")
    headers = {"Accept": "*/*"}
    offset = part.stat().st_size if part.is_file() else 0
    if offset:
        headers["Range"] = f"bytes={offset}-"
    token = None
    try:
        from acorn.data.download import _USER_AGENT, _DropAuthOnForeignRedirect, _oauth_token

        token = _oauth_token()
        headers["Authorization"] = f"Bearer {token}"
        headers["User-Agent"] = _USER_AGENT
    except Exception:
        token = None
    request = urllib.request.Request(url, headers=headers)
    try:
        if token is not None:
            from acorn.data.download import _DropAuthOnForeignRedirect

            opener = urllib.request.build_opener(_DropAuthOnForeignRedirect)
            response_cm = opener.open(request, timeout=600)
        else:
            response_cm = urllib.request.urlopen(request)
        with response_cm as response:
            mode = "ab" if offset else "wb"
            with part.open(mode) as handle:
                while chunk := response.read(1024 * 1024):
                    handle.write(chunk)
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403}:
            raise DryadDownloadError(_manual_hint(artifact, cache_dir)) from exc
        raise DryadDownloadError(f"Failed to download {artifact.filename} ({exc.code})") from exc
    if part.stat().st_size != artifact.size_bytes:
        raise DryadDownloadError(
            f"{artifact.filename}: size {part.stat().st_size} != expected {artifact.size_bytes}"
        )
    digest = _sha256(part)
    if digest != artifact.sha256:
        part.unlink(missing_ok=True)
        raise DryadDownloadError(f"{artifact.filename}: sha256 mismatch (got {digest})")
    part.rename(dest)


def _matches_prefix(name: str, prefixes: tuple[str, ...]) -> bool:
    name = name.replace("\\", "/").lstrip("./")
    candidates = [name]
    if "/" in name:
        candidates.append(name.split("/", 1)[1])
    return any(c.startswith(p) for c in candidates for p in prefixes)


def _member_basename(name: str) -> str:
    return Path(name.replace("\\", "/")).name


def _extract_zip(archive: Path, dest_dir: Path, extract_only: tuple[str, ...] | None) -> None:
    with zipfile.ZipFile(archive, "r") as zf:
        members = zf.namelist()
        if extract_only:
            members = [m for m in members if _matches_prefix(m, extract_only)]
        zf.extractall(dest_dir, members=members)


def _tar_members_to_extract(tf: tarfile.TarFile, artifact: DryadArtifact) -> list[tarfile.TarInfo]:
    members: list[tarfile.TarInfo] = []
    wanted = set(artifact.tar_members or ())
    for member in tf.getmembers():
        base = _member_basename(member.name)
        if artifact.tar_members is not None and base not in wanted:
            continue
        if any(base.startswith(prefix) for prefix in artifact.skip_tar_prefixes):
            continue
        members.append(member)
    return members


def _extract_tar(archive: Path, dest_dir: Path, artifact: DryadArtifact) -> None:
    with tarfile.open(archive, "r:*") as tf:
        members = _tar_members_to_extract(tf, artifact)
        if artifact.min_free_gb:
            need = sum(m.size for m in members if m.isfile())
            free = shutil.disk_usage(dest_dir).free
            if free < need:
                raise DryadDownloadError(
                    f"Need {need / 1024**3:.1f} GB free to extract {artifact.filename}; "
                    f"only {free / 1024**3:.1f} GB available"
                )
        try:
            tf.extractall(dest_dir, members=members, filter="data")
        except TypeError:
            tf.extractall(dest_dir, members=members)


def _complete_marker(cache_dir: Path, artifact: DryadArtifact) -> Path:
    return cache_dir / f".{artifact.filename}.complete"


def _is_complete(cache_dir: Path, artifact: DryadArtifact) -> bool:
    marker = _complete_marker(cache_dir, artifact)
    if not marker.is_file():
        return False
    try:
        payload = json.loads(marker.read_text())
    except json.JSONDecodeError:
        return False
    return (
        payload.get("sha256") == artifact.sha256
        and int(payload.get("size_bytes", -1)) == artifact.size_bytes
    )


def _write_complete(cache_dir: Path, artifact: DryadArtifact) -> None:
    payload = {"sha256": artifact.sha256, "size_bytes": artifact.size_bytes}
    _complete_marker(cache_dir, artifact).write_text(json.dumps(payload))


def _post_extract_layout(staging: Path, cache_dir: Path, artifact: DryadArtifact) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    if artifact.key == "nlp_lm":
        flatten_graph_artifacts(staging, cache_dir, ("TLG.fst", "words.txt"))
        return
    if artifact.tar_members:
        flatten_graph_artifacts(staging, cache_dir, artifact.tar_members)


def ensure_graphs(
    task_key: str,
    *,
    assume_yes: bool = False,
    graph_dir: Path | None = None,
) -> Path:
    """Download/extract graphs when missing. Speech always uses the 5-gram archive."""
    from acorn.lm.hardware import require_tlg_dir
    from acorn.lm.presets import original_preset

    artifact = artifact_for_task(task_key)
    cache_dir = graph_dir or graph_cache_dir(task_key)
    if _is_complete(cache_dir, artifact):
        require_tlg_dir(cache_dir, original_preset(task_key))
        return cache_dir

    cache_dir.mkdir(parents=True, exist_ok=True)
    if artifact.min_free_gb and _disk_free_gb(cache_dir) < artifact.min_free_gb:
        raise DryadDownloadError(
            f"Need at least {artifact.min_free_gb:.0f} GB free under {cache_dir}; "
            f"have {_disk_free_gb(cache_dir):.1f} GB"
        )
    _prompt_yes(artifact, assume_yes=assume_yes)

    files_url = _version_files_url(artifact, cache_dir)
    files_info = _get_json(files_url, artifact, cache_dir)
    file_infos = files_info["_embedded"]["stash:files"]
    download_href = None
    for file_info in file_infos:
        path = file_info["path"]
        if path == "README.md" or path == "languageModel_readme.txt":
            continue
        if path != artifact.filename:
            continue
        download_href = file_info["_links"]["stash:download"]["href"]
        break
    if download_href is None:
        raise DryadDownloadError(f"No Dryad file matched {artifact.filename!r}")

    archive = cache_dir / artifact.filename
    _download_stream(f"{DRYAD_ROOT}{download_href}", archive, artifact, cache_dir)

    staging = cache_dir / ".extract_staging"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    if archive.name.lower().endswith(".zip"):
        _extract_zip(archive, staging, artifact.extract_only)
    else:
        _extract_tar(archive, staging, artifact)
    _post_extract_layout(staging, cache_dir, artifact)
    shutil.rmtree(staging, ignore_errors=True)
    archive.unlink(missing_ok=True)
    _write_complete(cache_dir, artifact)
    require_tlg_dir(cache_dir, original_preset(task_key))
    return cache_dir


__all__ = [
    "ARTIFACTS",
    "DownloadDeclined",
    "DryadArtifact",
    "DryadDownloadError",
    "NLP_LM",
    "SPEECH_5GRAM",
    "artifact_for_task",
    "ensure_graphs",
]
