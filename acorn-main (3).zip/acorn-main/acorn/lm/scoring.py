"""Host WER/CER on n-best / rescored strings. Mix formula matches CORP."""

from __future__ import annotations

import numpy as np

from acorn.lm.metrics import char_cer, wer
from acorn.lm.nbest import Hypothesis, NBest
from acorn.lm.normalize import cleanup_nbest_text, normalize_text, words
from acorn.lm.presets import DecodePreset


def first_best_text(trial: list[Hypothesis]) -> str:
    """1-best = decoder list order ``[0]``, not min acoustic."""
    if not trial:
        return ""
    return cleanup_nbest_text(trial[0].text)


def score_ngram_metrics(
    nbest: NBest,
    refs_raw: list[str],
    task_key: str,
) -> tuple[float, float]:
    hyps_norm = [normalize_text(first_best_text(trial), task_key) for trial in nbest.trials]
    refs_norm = [normalize_text(t, task_key) for t in refs_raw]
    ngram_char_cer = char_cer(hyps_norm, refs_norm)
    ngram_wer = wer(
        [words(t, task_key) for t in hyps_norm],
        [words(t, task_key) for t in refs_norm],
    )
    return ngram_wer, ngram_char_cer


def score_lm_metrics(
    decoded: list[str],
    refs_raw: list[str],
    task_key: str,
) -> tuple[float, float]:
    hyps_norm = [normalize_text(t, task_key) for t in decoded]
    refs_norm = [normalize_text(t, task_key) for t in refs_raw]
    lm_char_cer = char_cer(hyps_norm, refs_norm)
    lm_wer = wer(
        [words(t, task_key) for t in hyps_norm],
        [words(t, task_key) for t in refs_norm],
    )
    return lm_wer, lm_char_cer


def mix_scores(
    hypotheses: list[Hypothesis],
    neural_scores: list[float],
    *,
    alpha: float,
    acoustic_scale: float,
) -> tuple[str, float]:
    """Return (best_text, softmax-confidence of the winning mix)."""
    acoustic = np.array([h.acoustic_score for h in hypotheses], dtype=np.float64)
    ngram = np.array([h.ngram_score for h in hypotheses], dtype=np.float64)
    neural = np.array(neural_scores, dtype=np.float64)
    total = alpha * neural + (1.0 - alpha) * ngram + acoustic_scale * acoustic
    best = int(np.argmax(total))
    shifted = total - np.max(total)
    probs = np.exp(shifted)
    conf = float(probs[best] / np.sum(probs))
    return hypotheses[best].text, conf


def comparability_for(preset: DecodePreset, *, neural_ran: bool) -> tuple[bool, str]:
    if (
        neural_ran
        and preset.task_key == "speech"
        and preset.graph_tier == "speech_5gram"
        and preset.neural_model == "facebook/opt-6.7b"
        and preset.neural_8bit
        and preset.neural_alpha == 0.5
    ):
        return True, "fan_speech_lm_stack"
    if neural_ran and preset.task_key == "nlp":
        return False, "recipe_match_only"
    return False, "not_paper"
