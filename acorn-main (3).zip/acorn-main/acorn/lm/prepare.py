"""Write a Kaldi sidecar job: float32 npy in Kaldi channel order."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from acorn.lm.permute import permute_to_kaldi
from acorn.lm.presets import DecodePreset
from acorn.lm.schema import SessionExport

KALDI_JOB_SCHEMA = "acorn_lm.kaldi_job.v1"


def prepare_kaldi_job(session: SessionExport, out_dir: Path, preset: DecodePreset) -> Path:
    if session.task_key != preset.task_key:
        raise ValueError(
            f"Session task_key {session.task_key!r} does not match preset {preset.name} "
            f"({preset.task_key})"
        )
    out_dir = Path(out_dir)
    trial_dir = out_dir / "trials"
    trial_dir.mkdir(parents=True, exist_ok=True)
    for i, tensor in enumerate(session.logits):
        kaldi = permute_to_kaldi(tensor.numpy(), session.task_key)
        np.save(trial_dir / f"{i:06d}.npy", kaldi)
    config = {
        "schema": KALDI_JOB_SCHEMA,
        "session_key": session.session_key,
        "task_key": session.task_key,
        "dataset_key": session.dataset_key,
        "n_trials": session.n_trials,
        "nbest": preset.nbest,
        "max_active": preset.max_active,
        "min_active": preset.min_active,
        "beam": preset.beam,
        "lattice_beam": preset.lattice_beam,
        "acoustic_scale": preset.search_acoustic_scale,
        "ctc_blank_skip_threshold": preset.ctc_blank_skip_threshold,
        "length_penalty": preset.length_penalty,
        "blank_penalty": preset.blank_penalty,
        "rescore": preset.lattice_rescore,
        "preset": preset.name,
        "trial_dir": "trials",
    }
    dest = out_dir / "config.json"
    dest.write_text(json.dumps(config, indent=2))
    return dest
