#!/usr/bin/env python3
"""Neural rescore worker. transformers live here, not on the Acorn host.

Reads ``acorn_lm.nbest.v1`` and writes rescored texts. Host computes WER/CER.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


def cleanup(text):
    hyp = text.strip().replace(">", "").replace("  ", " ")
    return hyp.replace(" ,", ",").replace(" .", ".").replace(" ?", "?")


def mix_pick(hyps, neural, alpha, acoustic_scale):
    acoustic = np.array([h["acoustic_score"] for h in hyps], dtype=np.float64)
    ngram = np.array([h["ngram_score"] for h in hyps], dtype=np.float64)
    neural = np.array(neural, dtype=np.float64)
    total = alpha * neural + (1.0 - alpha) * ngram + acoustic_scale * acoustic
    best = int(np.argmax(total))
    return hyps[best]["text"]


def hf_load_kwargs(load_in_8bit, *, cuda_available=None):
    """8-bit OPT always uses device_map=auto; GPT-2 does when CUDA is present.

    Do not pass cache_dir: transformers then uses ``$HF_HOME/hub``. Passing
    HF_HOME itself would miss the ``hub/`` subdirectory.
    """
    kwargs = {}
    if load_in_8bit:
        kwargs["load_in_8bit"] = True
        kwargs["device_map"] = "auto"
        return kwargs
    if cuda_available is None:
        import torch

        cuda_available = bool(torch.cuda.is_available())
    if cuda_available:
        kwargs["device_map"] = "auto"
    return kwargs


def hf_scorer(model_name, load_in_8bit):
    if "opt" in model_name.lower():
        print(
            "facebook/opt-* uses Meta's OPT license (non-commercial research).",
            file=sys.stderr,
        )
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    kwargs = hf_load_kwargs(load_in_8bit)
    model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)
    tokenizer.padding_side = "right"
    tokenizer.pad_token = tokenizer.eos_token
    model.eval()

    def score_fn(texts):
        import torch

        inputs = tokenizer(texts, return_tensors="pt", padding=True)
        device = next(model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            logits = model(**inputs).logits
            log_probs = torch.nn.functional.log_softmax(logits.float(), dim=-1)
        scores = []
        for i in range(log_probs.shape[0]):
            n_tokens = int(inputs["attention_mask"][i].sum().item())
            total = 0.0
            for j in range(1, n_tokens):
                token_id = int(inputs["input_ids"][i, j].item())
                total += float(log_probs[i, j - 1, token_id].item())
            scores.append(total)
        return scores

    return score_fn


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--nbest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--alpha", type=float, required=True)
    parser.add_argument("--acoustic-scale", type=float, required=True)
    parser.add_argument("--load-in-8bit", action="store_true")
    args = parser.parse_args(argv)

    nbest = json.loads(args.nbest.read_text())
    if nbest.get("schema") != "acorn_lm.nbest.v1":
        raise SystemExit(f"unsupported nbest schema {nbest.get('schema')!r}")
    trials = nbest["trials"]
    score_fn = hf_scorer(args.model, args.load_in_8bit)
    decoded = []
    for trial in trials:
        raw = trial["hypotheses"]
        kept = []
        cleaned = []
        for hyp in raw:
            text = cleanup(hyp["text"])
            if not text:
                continue
            kept.append(
                {
                    "text": text,
                    "acoustic_score": hyp["acoustic_score"],
                    "ngram_score": hyp["ngram_score"],
                }
            )
            cleaned.append(text)
        if not kept:
            decoded.append("")
            continue
        decoded.append(mix_pick(kept, score_fn(cleaned), args.alpha, args.acoustic_scale))

    payload = {
        "schema": "acorn_lm.rescored.v1",
        "session_key": nbest.get("session_key"),
        "task_key": nbest.get("task_key"),
        "decoded": decoded,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2))
    print("wrote", args.out)


if __name__ == "__main__":
    main()
