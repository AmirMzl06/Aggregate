#!/usr/bin/env python3
"""Kaldi/WeNet n-best worker. Python 3.9 + lm_decoder + numpy. No Acorn import."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

NLP_WORDS_PREFIX = ("<eps>", ">", ",", "?", ".", "'")


def _ram_bytes():
    try:
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
    except (ValueError, OSError):
        return None


def _read_words_tokens(words_path: Path) -> list[str]:
    tokens: list[str] = []
    for line in words_path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        tokens.append(line.split()[0])
        if len(tokens) >= 6:
            break
    return tokens


def _validate_words_txt(words_path: Path, task_key: str) -> None:
    tokens = _read_words_tokens(words_path)
    if task_key == "nlp":
        if tokens[:6] != list(NLP_WORDS_PREFIX):
            raise SystemExit(
                f"NLP words.txt prefix mismatch: expected {list(NLP_WORDS_PREFIX)}, got {tokens[:6]}"
            )
        return
    if task_key == "speech":
        if not tokens or tokens[0] != "<eps>":
            raise SystemExit("Speech words.txt must start with <eps>")
        if len(tokens) < 2 or tokens[1] == ">":
            raise SystemExit("Speech words.txt second token must not be '>'")


def _build_decoder(tlg_dir, cfg):
    try:
        import lm_decoder
    except ImportError as exc:
        raise SystemExit(
            "lm_decoder is not importable. Build LanguageModelDecoder/runtime/server/x86 "
            "against torch 1.13.1 (see packaged sidecar/Dockerfile) or use the lab new_venv."
        ) from exc

    tlg_dir = Path(tlg_dir)
    tlg = tlg_dir / "TLG.fst"
    words = tlg_dir / "words.txt"
    if not tlg.is_file() or not words.is_file():
        raise SystemExit(f"Need TLG.fst and words.txt in {tlg_dir}")
    _validate_words_txt(words, str(cfg.get("task_key", "nlp")))

    g_path = ""
    rescore_g = ""
    if cfg.get("rescore"):
        g = tlg_dir / "G.fst"
        gp = tlg_dir / "G_no_prune.fst"
        if not g.is_file() or not gp.is_file():
            raise SystemExit("rescore=true requires G.fst and G_no_prune.fst")
        g_path = str(g)
        rescore_g = str(gp)

    opts = lm_decoder.DecodeOptions(
        int(cfg.get("max_active", 7000)),
        int(cfg.get("min_active", 200)),
        float(cfg.get("beam", 17.0)),
        float(cfg.get("lattice_beam", 8.0)),
        float(cfg.get("acoustic_scale", 1.0)),
        float(cfg.get("ctc_blank_skip_threshold", 1.0)),
        float(cfg.get("length_penalty", 0.0)),
        int(cfg.get("nbest", 1)),
    )
    resource = lm_decoder.DecodeResource(str(tlg), g_path, rescore_g, str(words), "")
    return lm_decoder.BrainSpeechDecoder(resource, opts), lm_decoder


def _decode_trial(lm_decoder, decoder, logits, blank_penalty, rescore):
    priors = np.zeros((1, logits.shape[1]), dtype=np.float32)
    lm_decoder.DecodeNumpy(decoder, logits, priors, float(blank_penalty))
    decoder.FinishDecoding()
    if rescore:
        decoder.Rescore()
    hyps = []
    for item in decoder.result():
        hyps.append(
            {
                "text": item.sentence,
                "acoustic_score": float(item.ac_score),
                "ngram_score": float(item.lm_score),
            }
        )
    decoder.Reset()
    return hyps


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", type=Path, required=True)
    parser.add_argument("--tlg", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)

    cfg = json.loads((args.job / "config.json").read_text())
    if cfg.get("schema") != "acorn_lm.kaldi_job.v1":
        raise SystemExit(f"unsupported job schema {cfg.get('schema')!r}")

    ram = _ram_bytes()
    if ram is not None and cfg.get("rescore") and ram < 250 * 1024**3:
        print(
            f"warning: lattice rescore usually needs ~350 GiB RAM; this host reports "
            f"{ram / 1024**3:.1f} GiB",
            file=sys.stderr,
        )

    decoder, lm_decoder = _build_decoder(args.tlg, cfg)
    n_trials = int(cfg["n_trials"])
    trial_dir = args.job / cfg.get("trial_dir", "trials")
    blank_penalty = float(cfg["blank_penalty"])
    rescore = bool(cfg.get("rescore"))
    trials = []
    for i in range(n_trials):
        path = trial_dir / f"{i:06d}.npy"
        logits = np.load(path)
        if logits.dtype != np.float32:
            logits = logits.astype(np.float32)
        logits = np.ascontiguousarray(logits)
        hyps = _decode_trial(lm_decoder, decoder, logits, blank_penalty, rescore)
        trials.append({"hypotheses": hyps})
        if (i + 1) % 10 == 0 or i + 1 == n_trials:
            print(f"decoded {i + 1}/{n_trials}", file=sys.stderr)

    payload = {
        "schema": "acorn_lm.nbest.v1",
        "session_key": cfg["session_key"],
        "task_key": cfg["task_key"],
        "trials": trials,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload))
    print("wrote", args.out)


if __name__ == "__main__":
    main()
