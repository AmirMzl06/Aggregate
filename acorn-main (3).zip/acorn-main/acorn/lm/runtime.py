"""LM rescoring orchestration. Docker inspect happens here, never at import."""

from __future__ import annotations

import json
import tempfile
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from acorn.lm.docker_run import (
    docker_has_nvidia_runtime,
    ensure_images,
    require_docker,
    run_kaldi_decode,
    run_neural_rescore,
)
from acorn.lm.download import ensure_graphs
from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.hardware import require_ram, require_tlg_dir
from acorn.lm.nbest import load_nbest
from acorn.lm.prepare import prepare_kaldi_job
from acorn.lm.presets import original_preset
from acorn.lm.schema import SessionExport, load_manifest, load_session
from acorn.lm.scoring import comparability_for, score_lm_metrics, score_ngram_metrics
from acorn.lm.transcripts import discover_transcripts

METRICS_SCHEMA = "acorn.lm.metrics.v1"


def require_lm_runtime(
    task_keys: Sequence[str],
    *,
    assume_yes: bool = False,
    host_ram_bytes: int | None = None,
) -> None:
    """Docker on PATH, speech NVIDIA runtime, RAM cap, images, then Dryad graphs."""
    require_docker()
    keys = list(dict.fromkeys(task_keys))
    if "speech" in keys and not docker_has_nvidia_runtime():
        raise LmPrerequisiteError(
            "Speech LM uses OPT-6.7B 8-bit and needs Docker's NVIDIA runtime. "
            "Install nvidia-container-toolkit so `docker info` lists the nvidia runtime."
        )
    for key in keys:
        require_ram(original_preset(key), available=host_ram_bytes)
    ensure_images()
    for key in keys:
        ensure_graphs(key, assume_yes=assume_yes)


def _session_report(
    session: SessionExport,
    *,
    assume_yes: bool,
    host_ram_bytes: int | None,
    export_dir: Path | None = None,
) -> dict[str, Any]:
    preset = original_preset(session.task_key)
    gold = discover_transcripts(export_dir, session) if export_dir is not None else None
    if gold is None:
        if session.transcripts is None:
            raise ValueError(
                f"{session.session_key}: no gold transcripts in the v1.1 export or sidecar JSON"
            )
        gold = session.transcripts
    tlg_dir = ensure_graphs(session.task_key, assume_yes=assume_yes)
    require_tlg_dir(tlg_dir, preset)

    with tempfile.TemporaryDirectory(prefix="acorn-lm-") as tmp:
        tmp_path = Path(tmp)
        job_dir = tmp_path / "job"
        nbest_path = tmp_path / "nbest.json"
        rescored_path = tmp_path / "rescored.json"
        prepare_kaldi_job(session, job_dir, preset)
        run_kaldi_decode(
            job_dir,
            tlg_dir,
            nbest_path,
            preset,
            host_ram_bytes=host_ram_bytes,
        )
        nbest = load_nbest(nbest_path)
        ngram_wer, ngram_char_cer = score_ngram_metrics(nbest, gold, session.task_key)
        run_neural_rescore(
            nbest_path,
            rescored_path,
            preset,
            host_ram_bytes=host_ram_bytes,
        )
        decoded_payload = json.loads(rescored_path.read_text())
        decoded = [str(x) for x in decoded_payload["decoded"]]
        if len(decoded) != len(gold):
            raise ValueError(
                f"{session.session_key}: neural decoded {len(decoded)} != gold {len(gold)}"
            )
        lm_wer, lm_char_cer = score_lm_metrics(decoded, gold, session.task_key)

    paper_comparable, comparability = comparability_for(preset, neural_ran=True)
    return {
        "session_key": session.session_key,
        "task_key": session.task_key,
        "graph_tier": preset.graph_tier,
        "paper_comparable": paper_comparable,
        "comparability": comparability,
        "ngram_wer": ngram_wer,
        "ngram_char_cer": ngram_char_cer,
        "lm_wer": lm_wer,
        "lm_char_cer": lm_char_cer,
    }


def _metrics_payload(sessions: list[dict[str, Any]]) -> dict[str, Any]:
    payload: dict[str, Any] = {"schema": METRICS_SCHEMA, "sessions": sessions}
    if len(sessions) == 1:
        payload.update({k: v for k, v in sessions[0].items()})
    else:
        payload["ngram_wer"] = {s["session_key"]: s["ngram_wer"] for s in sessions}
        payload["ngram_char_cer"] = {s["session_key"]: s["ngram_char_cer"] for s in sessions}
        payload["lm_wer"] = {s["session_key"]: s["lm_wer"] for s in sessions}
        payload["lm_char_cer"] = {s["session_key"]: s["lm_char_cer"] for s in sessions}
    return payload


def rescore_session_exports(
    exports: Sequence[SessionExport],
    *,
    assume_yes: bool = False,
    host_ram_bytes: int | None = None,
) -> dict[str, Any]:
    """Rescore in-memory session exports. Does not write persistent metrics files."""
    require_docker()
    task_keys = [session.task_key for session in exports]
    require_lm_runtime(task_keys, assume_yes=assume_yes, host_ram_bytes=host_ram_bytes)
    sessions = [
        _session_report(
            session,
            assume_yes=assume_yes,
            host_ram_bytes=host_ram_bytes,
        )
        for session in exports
    ]
    return _metrics_payload(sessions)


def rescore_export(
    export_dir: str | Path,
    *,
    assume_yes: bool = False,
    session_key: str | None = None,
    host_ram_bytes: int | None = None,
) -> dict[str, Any]:
    """Rescore a v1.1 export directory.

    Raises :class:`~acorn.lm.errors.LmPrerequisiteError` before work if
    Docker or RAM is missing. Returns the metrics payload. Does not write
    a persistent metrics file.

    Parameters
    ----------
    export_dir : str or pathlib.Path
        Directory written by ``examples/save_run.py`` / sequence export.
    assume_yes : bool, optional
        Skip confirmation prompts (graphs still download).
    session_key : str, optional
        Restrict to one session in the manifest.
    host_ram_bytes : int, optional
        Override detected host RAM for the 90% cap check.

    Returns
    -------
    dict
        Metrics including ``ngram_wer`` and ``lm_wer``.

    Raises
    ------
    LmPrerequisiteError
        Docker missing or daemon down, speech without an NVIDIA Docker
        runtime, or RAM below the preset after the host cap.
    KeyError
        If ``session_key`` is not in the manifest.
    """
    require_docker()
    export_dir = Path(export_dir)
    manifest = load_manifest(export_dir)
    keys = [str(item["session_key"]) for item in manifest.datasets]
    if session_key is not None:
        if session_key not in keys:
            raise KeyError(f"session_key {session_key!r} not in {keys}")
        keys = [session_key]
        task_keys = [
            str(item["task_key"])
            for item in manifest.datasets
            if str(item["session_key"]) == session_key
        ]
    else:
        task_keys = [str(item["task_key"]) for item in manifest.datasets]
    require_lm_runtime(task_keys, assume_yes=assume_yes, host_ram_bytes=host_ram_bytes)
    sessions = [
        _session_report(
            load_session(export_dir, key),
            assume_yes=assume_yes,
            host_ram_bytes=host_ram_bytes,
            export_dir=export_dir,
        )
        for key in keys
    ]
    return _metrics_payload(sessions)
