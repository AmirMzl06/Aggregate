"""Language-model rescoring for sequence CTC exports.

Import is side-effect free: no Docker inspect. Raise ``LmPrerequisiteError``
only when ``rescore_export`` / ``export_all_sessions(..., use_lm=True)`` runs.
"""

from __future__ import annotations

from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.runtime import rescore_export

__all__ = ["LmPrerequisiteError", "rescore_export"]
