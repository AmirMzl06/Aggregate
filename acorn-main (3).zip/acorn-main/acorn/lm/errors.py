"""Public LM prerequisite errors."""

from __future__ import annotations


class LmPrerequisiteError(RuntimeError):
    """Raised when Docker, NVIDIA runtime, or RAM cannot run LM rescoring.

    The call stops before n-gram or neural work. Speech needs Docker's
    NVIDIA runtime, not only ``nvidia-smi`` on the host.
    """
