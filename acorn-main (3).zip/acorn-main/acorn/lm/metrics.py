"""Named corpus error rates. Never emit an unlabeled ``wer`` / ``cer`` key."""

from __future__ import annotations


def edit_distance(a: list, b: list) -> int:
    n, m = len(a), len(b)
    dp = list(range(m + 1))
    for i in range(1, n + 1):
        prev = dp[0]
        dp[0] = i
        for j in range(1, m + 1):
            cur = dp[j]
            if a[i - 1] == b[j - 1]:
                dp[j] = prev
            else:
                dp[j] = 1 + min(prev, dp[j], dp[j - 1])
            prev = cur
    return dp[m]


def corpus_error_rate(hypotheses: list[list], references: list[list]) -> float:
    if len(hypotheses) != len(references):
        raise ValueError(
            f"hypothesis/reference length mismatch: {len(hypotheses)} vs {len(references)}"
        )
    total_edit = 0
    total_len = 0
    for hyp, ref in zip(hypotheses, references, strict=True):
        total_edit += edit_distance(hyp, ref)
        total_len += len(ref)
    if total_len == 0:
        return 0.0
    return total_edit / total_len


def char_cer(hypotheses: list[str], references: list[str]) -> float:
    return corpus_error_rate([list(h) for h in hypotheses], [list(r) for r in references])


def wer(hypotheses: list[list[str]], references: list[list[str]]) -> float:
    return corpus_error_rate(hypotheses, references)
