"""English gold transcripts from a v1.1 export."""

from __future__ import annotations

import json
from pathlib import Path

from acorn.lm.schema import SessionExport

SCHEMA_V1 = "acorn_lm.transcripts.v1"


def load_transcripts(path: Path, expected_n: int | None = None) -> list[str]:
    raw = json.loads(Path(path).read_text())
    schema = raw.get("schema")
    if schema != SCHEMA_V1:
        raise ValueError(f"Unsupported transcripts schema {schema!r}; expected {SCHEMA_V1}")
    transcripts = raw.get("transcripts")
    if not isinstance(transcripts, list):
        raise ValueError("transcripts must be a list of strings")
    out = [str(x) for x in transcripts]
    if expected_n is not None and len(out) != expected_n:
        raise ValueError(
            f"transcript count {len(out)} != n_trials {expected_n}. "
            "WER will not be computed from CTC label ids."
        )
    return out


def discover_transcripts(export_dir: Path, session: SessionExport) -> list[str]:
    """Gold order: v1.1 .pt, session JSON, root JSON."""
    if session.transcripts is not None:
        return session.transcripts
    root = Path(export_dir)
    session_json = root / f"{session.session_key}.transcripts.json"
    if session_json.is_file():
        return load_transcripts(session_json, expected_n=session.n_trials)
    shared_json = root / "transcripts.json"
    if shared_json.is_file():
        return load_transcripts(shared_json, expected_n=session.n_trials)
    raise ValueError(
        f"{session.session_key}: no gold transcripts in the v1.1 export or sidecar JSON"
    )
