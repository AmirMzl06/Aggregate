"""Library logging. Silent unless the user configures a handler or verbosity.

The ``acorn`` logger has a ``NullHandler`` so ``import acorn`` does not emit
"No handler found". This module does not call ``logging.basicConfig``.
"""

from __future__ import annotations

import logging

_LEVEL_NAMES = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARNING,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
    "NOTSET": logging.NOTSET,
}

_PACKAGE_LOGGER = logging.getLogger("acorn")
if not any(isinstance(handler, logging.NullHandler) for handler in _PACKAGE_LOGGER.handlers):
    _PACKAGE_LOGGER.addHandler(logging.NullHandler())


def get_logger(name: str | None = None) -> logging.Logger:
    """Return ``logging.getLogger(name)`` after installing the package NullHandler.

    Pass ``__name__`` from library modules. ``None`` returns the ``acorn`` logger.
    """
    if name is None:
        return _PACKAGE_LOGGER
    return logging.getLogger(name)


def set_verbosity(level: int | str) -> None:
    """Set the ``acorn`` logger level (``"INFO"`` / ``"WARNING"`` / int)."""
    if isinstance(level, str):
        key = level.strip().upper()
        if key not in _LEVEL_NAMES:
            raise ValueError(f"Unknown log level {level!r}. Use INFO, WARNING, DEBUG, ERROR.")
        resolved = _LEVEL_NAMES[key]
    else:
        resolved = int(level)
    _PACKAGE_LOGGER.setLevel(resolved)


__all__ = ["get_logger", "set_verbosity"]
