"""Dataset registry: single source of truth for dataset metadata.

Time-bin specs live under :mod:`acorn.data.groups` and are merged here. Macaque
XDS archives, Perich NWB recordings, and hippocampus joblib dumps each have a
group. Specs do not choose a training recipe. A genuinely new file format still
needs a loader in that group.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from acorn.models.label_format import LabelFormat

JANGO_LABEL_NAMES = [
    "EMG_ECRb",
    "EMG_ECRl",
    "EMG_ECU",
    "EMG_EDCr",
    "EMG_FCR",
    "EMG_FCU",
    "EMG_FDP",
]
POP_LABEL_NAMES = [
    "APB",
    "FPB",
    "Lum",
    "PT",
    "FDS1",
    "FCR2",
    "FCU1",
    "FDP",
    "1DI",
    "4DI",
    "EPM",
]
CURSOR_LABEL_NAMES = [
    "curs_px",
    "curs_py",
    "curs_vx",
    "curs_vy",
    "curs_ax",
    "curs_ay",
]


class DatasetSpec(BaseModel):
    """Time-bin dataset record used by loading, training, and plot export.

    ``dataset_group`` is ``perich``, ``hippo``, or ``macaque``. Field values
    are the source of truth for paths, smoothing, and plot metadata.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    key: str
    xds_name: str
    num_days: int
    use_smooth: bool
    xds_smooth: bool
    plot_type: str
    panel: str
    title: str
    label_names: tuple[str, ...]
    dataset_group: str = "macaque"
    gdrive_url: str | None = None
    http_url: str | None = None
    expected_n_neurons: int | None = 96
    file_type: str = "7z"
    label_format: LabelFormat = "time_bin_aligned"
    original_name: str | None = None
    plot_channels: tuple[str, ...] | None = None
    plot_channel_display: tuple[str, ...] | None = None
    pos_dims: tuple[int, ...] | None = None
    dayk_override: int | None = None
    # If False, available for download/load but omitted from list_datasets().
    train_enabled: bool = True

    def resolved_original_name(self) -> str:
        if self.original_name is not None:
            return self.original_name
        if self.xds_name.endswith("_raw"):
            return self.xds_name[:-4]
        return self.xds_name


def _build_registry() -> dict[str, DatasetSpec]:
    from acorn.data.groups.hippo import HIPPO_SPECS
    from acorn.data.groups.macaque import MACAQUE_SPECS
    from acorn.data.groups.perich import PERICH_SPECS

    merged: dict[str, DatasetSpec] = {}
    for part in (MACAQUE_SPECS, PERICH_SPECS, HIPPO_SPECS):
        overlap = set(merged) & set(part)
        if overlap:
            raise ValueError(f"Duplicate dataset keys: {sorted(overlap)}")
        merged.update(part)
    return merged


# ---------------------------------------------------------------------------
# Canonical registry (short key → DatasetSpec)
# ---------------------------------------------------------------------------

DATASET_REGISTRY: dict[str, DatasetSpec] = _build_registry()

# Short key → XDS long name, for runners (train_enabled only).
DATASETS: dict[str, str] = {
    key: spec.xds_name for key, spec in DATASET_REGISTRY.items() if spec.train_enabled
}

# Expected value for currently-enabled datasets (advisory; runners infer from data).
# Prefer ``spec.expected_n_neurons`` / ``bundle["n_neurons"]`` for new code.
N_NEURONS = 96

# Lookup by on-disk / xds_name (includes Perich and hippocampus keys).
_XDS_BY_NAME: dict[str, DatasetSpec] = {spec.xds_name: spec for spec in DATASET_REGISTRY.values()}

# XDS/gdown map used by DatasetLoader (only specs that have a Drive URL).
_GDRIVE_BY_XDS: dict[str, DatasetSpec] = {
    spec.xds_name: spec for spec in DATASET_REGISTRY.values() if spec.gdrive_url
}


def get_dataset(key: str) -> DatasetSpec:
    """Return the time-bin :class:`DatasetSpec` for ``key``.

    Parameters
    ----------
    key : str
        Registry key such as ``jango`` or ``perich_m_rt_3``.

    Returns
    -------
    DatasetSpec
        Frozen spec for that key.

    Raises
    ------
    KeyError
        If ``key`` is unknown, or is registered only for sequence training.
    """
    if key in DATASET_REGISTRY:
        return DATASET_REGISTRY[key]
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    if key in SEQUENCE_DATASET_REGISTRY:
        raise KeyError(
            f"Dataset key {key!r} is registered for sequence training. "
            "Use get_sequence_dataset, not get_dataset."
        )
    raise KeyError(f"Unknown dataset key {key!r}. Choices: {list(DATASET_REGISTRY)}")


def get_dataset_by_xds_name(xds_name: str) -> DatasetSpec:
    if xds_name not in _XDS_BY_NAME:
        raise KeyError(f"Unknown XDS dataset name {xds_name!r}.")
    return _XDS_BY_NAME[xds_name]


def list_datasets(
    *, train_enabled_only: bool = True, label_format: LabelFormat | None = None
) -> list[str]:
    """Sorted union of registered dataset keys.

    Parameters
    ----------
    train_enabled_only : bool, optional
        If True (default), omit time-bin keys with ``train_enabled=False``
        and omit the in-memory sequence ``demo`` session.
    label_format : {None, 'time_bin_aligned', 'sequence'}, optional
        Restrict to one family. ``None`` returns the union.

    Returns
    -------
    list of str
        Sorted registry keys.

    Raises
    ------
    ValueError
        If ``label_format`` is not a known family.
    """
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    tba = list(DATASETS) if train_enabled_only else list(DATASET_REGISTRY)
    seq = [key for key, spec in SEQUENCE_DATASET_REGISTRY.items() if not spec.demo_only]
    if label_format is None:
        return sorted(set(tba) | set(seq))
    if label_format == "time_bin_aligned":
        return sorted(tba)
    if label_format == "sequence":
        return sorted(seq)
    raise ValueError(
        f"Invalid label_format {label_format!r}. Use 'time_bin_aligned' or 'sequence'."
    )


def dataset_loading_flags(dataset_name: str) -> tuple[bool, bool]:
    """Return ``(use_smooth, xds_smooth)`` for a full dataset name."""
    return (
        _XDS_BY_NAME[dataset_name].use_smooth,
        _XDS_BY_NAME[dataset_name].xds_smooth,
    )


def loader_dataset_names() -> list[str]:
    return list(_GDRIVE_BY_XDS.keys())


def loader_dataset_urls() -> dict[str, str]:
    return {name: spec.gdrive_url for name, spec in _GDRIVE_BY_XDS.items() if spec.gdrive_url}


def loader_file_types() -> dict[str, str]:
    return {name: spec.file_type for name, spec in _GDRIVE_BY_XDS.items()}


def loader_num_days() -> dict[str, int]:
    return {name: spec.num_days for name, spec in _GDRIVE_BY_XDS.items()}


def loader_original_names() -> dict[str, str]:
    return {name: spec.resolved_original_name() for name, spec in _GDRIVE_BY_XDS.items()}
