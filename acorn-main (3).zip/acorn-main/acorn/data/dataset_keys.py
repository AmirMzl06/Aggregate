"""Family-aware dataset key validation for configs."""

from __future__ import annotations

from collections.abc import Mapping

from acorn.models.label_format import LabelFormat


def validate_dataset_keys(keys: list[str], *, family: LabelFormat) -> list[str]:
    """Reject empty, unknown, and cross-family dataset key lists."""
    if not keys:
        raise ValueError("No dataset keys given.")

    from acorn.data.registry import DATASET_REGISTRY, DATASETS
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    allowed: Mapping[str, object]
    other: Mapping[str, object]
    if family == "time_bin_aligned":
        allowed = DATASETS
        other = SEQUENCE_DATASET_REGISTRY
    elif family == "sequence":
        allowed = SEQUENCE_DATASET_REGISTRY
        other = DATASET_REGISTRY
    else:
        raise ValueError(f"Invalid family {family!r}. Use 'time_bin_aligned' or 'sequence'.")

    ok: list[str] = []
    foreign: list[str] = []
    unknown: list[str] = []
    for key in keys:
        if key in allowed:
            ok.append(key)
        elif key in other:
            foreign.append(key)
        else:
            unknown.append(key)

    choices = list(allowed)
    if unknown:
        if family == "time_bin_aligned":
            raise ValueError(f"Unknown dataset keys: {unknown}. Choices: {choices}")
        raise ValueError(f"Unknown sequence dataset keys: {unknown}. Choices: {choices}")

    if foreign and ok:
        if family == "time_bin_aligned":
            raise ValueError(
                f"Dataset list mixes time-bin and sequence keys: {foreign}. "
                f"Time-bin training only accepts: {choices}."
            )
        raise ValueError(
            f"Dataset list mixes sequence and time-bin keys: {foreign}. "
            f"Sequence training only accepts: {choices}."
        )

    if foreign:
        if len(foreign) == 1:
            key = foreign[0]
            if family == "time_bin_aligned":
                raise ValueError(
                    f"Dataset key {key!r} is registered for sequence training. "
                    "Use SequenceTrainConfig, not time-bin training."
                )
            raise ValueError(
                f"Dataset key {key!r} is registered for time-bin training. "
                "Use TrainConfig or examples/demo_time_bin.py, not sequence training."
            )
        if family == "time_bin_aligned":
            raise ValueError(
                f"Dataset list mixes time-bin and sequence keys: {foreign}. "
                f"Time-bin training only accepts: {choices}."
            )
        raise ValueError(
            f"Dataset list mixes sequence and time-bin keys: {foreign}. "
            f"Sequence training only accepts: {choices}."
        )

    return list(keys)
