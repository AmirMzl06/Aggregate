"""Trial tables, validity masks, 80/20 split, and stacked Perich arrays.

After a trial table exists, valid trials are split with ``test_size=0.2``,
``valid_size=0.0``, ``shuffle=False``. Center-out bins run from go-cue to
``stop_time + 0.0008``; random-target bins run from ``start`` to ``end + 0.0008``.
Labels are the 6-D concat of cursor position, velocity, and acceleration, then
``np.vstack``. The 20% split is the held-out test set.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.model_selection import train_test_split


@dataclass
class BinnedKinematics:
    """Binned spikes and cursor kinematics for one Perich NWB session."""

    time_frame: np.ndarray
    spike_counts: np.ndarray
    curs_p: np.ndarray
    curs_v: np.ndarray
    curs_a: np.ndarray


class TrialTable:
    """Column-oriented trial metadata with mask selection."""

    def __init__(self, columns: dict[str, np.ndarray]):
        self._columns = {name: np.asarray(values) for name, values in columns.items()}
        lengths = {name: len(values) for name, values in self._columns.items()}
        if lengths and len(set(lengths.values())) != 1:
            raise ValueError(f"Trial columns have mismatched lengths: {lengths}")

    def __len__(self) -> int:
        if not self._columns:
            return 0
        return len(next(iter(self._columns.values())))

    def __getattr__(self, name: str):
        try:
            return self._columns[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name: str, value: object) -> None:
        if name == "_columns":
            object.__setattr__(self, name, value)
            return
        self._columns[name] = np.asarray(value)

    def select_by_mask(self, mask: np.ndarray) -> TrialTable:
        mask = np.asarray(mask, dtype=bool)
        return TrialTable({name: values[mask] for name, values in self._columns.items()})


def trial_table_from_mapping(columns: dict[str, np.ndarray]) -> TrialTable:
    return TrialTable(columns)


def _go_cue_time_column(columns: dict[str, np.ndarray]) -> np.ndarray:
    key = "go_cue_time" if "go_cue_time" in columns else "go_cue_time_array"
    stacked: np.ndarray = np.vstack(tuple(np.asarray(columns[key])))
    return stacked.flatten()


def extract_center_out_reaching_trials(
    trial_cols: dict[str, np.ndarray], cursor_t_end: float
) -> TrialTable:
    """Mark valid center-out trials and attach inferred ``start`` / ``end`` bounds.

    Go-cue times use ``go_cue_time`` when present, otherwise stacked and flattened
    ``go_cue_time_array``.
    """
    target_on_time = np.asarray(trial_cols["target_on_time"], dtype=np.float64)
    stop_time = np.asarray(trial_cols["stop_time"], dtype=np.float64)
    start_time = np.asarray(trial_cols["start_time"], dtype=np.float64)

    trial_grid: np.ndarray = np.append(
        target_on_time, min(float(stop_time[-1] + 1.0), float(cursor_t_end))
    )
    default_value: np.ndarray = np.append(start_time[0], stop_time + 1.0)
    default_value[1:-1] = np.minimum(default_value[1:-1], stop_time[1:])
    nan_mask = np.isnan(trial_grid)
    trial_grid[nan_mask] = default_value[nan_mask]
    trial_grid = trial_grid.astype(np.float64)

    cols = {name: np.asarray(values) for name, values in trial_cols.items()}
    if "go_cue_time" in cols or "go_cue_time_array" in cols:
        cols["go_cue_time"] = _go_cue_time_column(cols)
    cols["end"] = trial_grid[1:]
    cols["start"] = trial_grid[:-1]
    trials = TrialTable(cols)

    success_mask = trials.result == "R"
    valid_target_mask = ~np.isnan(np.asarray(trials.target_id, dtype=np.float64))
    max_duration_mask = (trials.end - trials.start) < 6.0
    min_duration_mask = (trials.end - trials.start) > 0.5
    trials.is_valid = success_mask & valid_target_mask & max_duration_mask & min_duration_mask
    return trials


def extract_random_target_reaching_trials(trial_cols: dict[str, np.ndarray]) -> TrialTable:
    """Mark valid random-target trials; ``start_time``/``stop_time`` become ``start``/``end``."""
    cols = {name: np.asarray(values) for name, values in trial_cols.items()}
    cols["start"] = cols.pop("start_time")
    cols["end"] = cols.pop("stop_time")
    trials = TrialTable(cols)

    success_mask = trials.result == "R"
    valid_num_attempts = trials.num_attempted == 4
    max_duration_mask = (trials.end - trials.start) < 10.0
    min_duration_mask = (trials.end - trials.start) > 2.0
    trials.is_valid = success_mask & valid_num_attempts & max_duration_mask & min_duration_mask
    return trials


def split_trials(
    trials: TrialTable,
    test_size: float = 0.2,
    valid_size: float = 0.0,
) -> tuple[TrialTable, TrialTable, TrialTable]:
    """Contiguous train/valid/test split (``shuffle=False``). ``valid_size=0`` copies test."""
    num_trials = len(trials)
    train_size = 1.0 - test_size - valid_size
    train_valid_ids, test_ids = train_test_split(
        np.arange(num_trials),
        test_size=test_size,
        shuffle=False,
    )
    if valid_size > 0:
        train_ids, valid_ids = train_test_split(
            train_valid_ids,
            test_size=valid_size / (train_size + valid_size),
            shuffle=False,
        )
    else:
        train_ids = train_valid_ids
        valid_ids = test_ids

    all_ids = np.arange(num_trials)
    train_trials = trials.select_by_mask(np.isin(all_ids, train_ids))
    valid_trials = trials.select_by_mask(np.isin(all_ids, valid_ids))
    test_trials = trials.select_by_mask(np.isin(all_ids, test_ids))
    return train_trials, valid_trials, test_trials


def get_trials_idx_by_trial(
    time_frame: np.ndarray,
    trials: TrialTable,
    start_event: str,
    time_before_start: float = 0.0,
    time_after_end: float = 0.0,
) -> list[np.ndarray]:
    """Bin indices strictly inside ``(t_start, t_end + 0.0008)`` for each trial."""
    if start_event == "start":
        time_start = trials.start
        time_end = trials.end
    elif start_event == "gocue_time":
        try:
            go_cue_cols = {"go_cue_time": trials.go_cue_time}
        except AttributeError:
            go_cue_cols = {"go_cue_time_array": trials.go_cue_time_array}
        time_start = _go_cue_time_column(go_cue_cols)
        time_end = trials.stop_time
    else:
        raise NotImplementedError("start_event must be 'start' or 'gocue_time'")

    time_frame = np.asarray(time_frame).reshape(-1)
    trials_idx: list[np.ndarray] = []
    n = len(time_start)
    for i in range(n):
        t1 = time_start[i] - time_before_start
        t2 = time_end[i] + time_after_end + 0.0008
        if t2 > t1:
            idx = np.where((time_frame > t1) & (time_frame < t2))[0]
        else:
            idx = np.array([], dtype=int)
        trials_idx.append(idx)
    return trials_idx


def stack_trial_bins(
    dayk: BinnedKinematics, eligible_trials: TrialTable, start_event: str
) -> tuple[np.ndarray, np.ndarray]:
    """Vstack binned spikes and 6-D cursor labels for ``eligible_trials``."""
    idx_list = get_trials_idx_by_trial(dayk.time_frame, eligible_trials, start_event, 0.0)
    trial_spike_counts = [dayk.spike_counts[n, :] for n in idx_list]
    p_list = [dayk.curs_p[n, :] for n in idx_list]
    v_list = [dayk.curs_v[n, :] for n in idx_list]
    a_list = [dayk.curs_a[n, :] for n in idx_list]
    labels_list = [
        np.concatenate(arrs, axis=1) for arrs in zip(p_list, v_list, a_list, strict=True)
    ]
    if not trial_spike_counts:
        raise ValueError("No trials to stack.")
    return np.vstack(trial_spike_counts), np.vstack(labels_list)


def arrays_from_valid_trials(
    dayk: BinnedKinematics, trials: TrialTable, start_event: str
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split valid trials 80/20 and return stacked ``(train_x, train_y, test_x, test_y)``."""
    valid = trials.select_by_mask(np.asarray(trials.is_valid, dtype=bool))
    train_trials, _valid_trials, test_trials = split_trials(valid, test_size=0.2, valid_size=0.0)
    train_x, train_y = stack_trial_bins(dayk, train_trials, start_event)
    test_x, test_y = stack_trial_bins(dayk, test_trials, start_event)
    return train_x, train_y, test_x, test_y
