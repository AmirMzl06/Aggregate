"""Perich reaching sessions from DANDI 000688 (one spec per recording)."""

from __future__ import annotations

from acorn.data.registry import CURSOR_LABEL_NAMES, DatasetSpec

# Subject-task day counts. Keys are 1-based: perich_c_co_1 is day index 0.
PERICH_DAYS: dict[str, int] = {
    "C-CO": 53,
    "C-RT": 15,
    "J-CO": 3,
    "T-CO": 6,
    "T-RT": 6,
    "M-CO": 22,
    "M-RT": 6,
}

_TASK_TO_SLUG = {
    "C-CO": "c_co",
    "C-RT": "c_rt",
    "J-CO": "j_co",
    "T-CO": "t_co",
    "T-RT": "t_rt",
    "M-CO": "m_co",
    "M-RT": "m_rt",
}
_SLUG_TO_TASK = {slug: task for task, slug in _TASK_TO_SLUG.items()}


def perich_key(task: str, day_index: int) -> str:
    """Registry key for ``task`` (e.g. ``C-CO``) and 0-based day index."""
    return f"perich_{_TASK_TO_SLUG[task]}_{day_index + 1}"


def parse_perich_key(key: str) -> tuple[str, int]:
    """Return ``(task, day_index)`` for a ``perich_*`` registry key."""
    if not key.startswith("perich_"):
        raise ValueError(f"Not a Perich dataset key: {key!r}")
    prefix, n_str = key.rsplit("_", 1)
    slug = prefix.removeprefix("perich_")
    if slug not in _SLUG_TO_TASK:
        raise ValueError(f"Unknown Perich task slug in key {key!r}")
    return _SLUG_TO_TASK[slug], int(n_str) - 1


def _build_perich_specs() -> dict[str, DatasetSpec]:
    specs: dict[str, DatasetSpec] = {}
    for task, n_days in PERICH_DAYS.items():
        plot_type = "co_reach" if task.endswith("CO") else "rt_reach"
        for day_index in range(n_days):
            key = perich_key(task, day_index)
            specs[key] = DatasetSpec(
                key=key,
                dataset_group="perich",
                xds_name=key,
                num_days=1,
                use_smooth=False,
                xds_smooth=False,
                gdrive_url=None,
                plot_type=plot_type,
                panel="P",
                title=key,
                label_names=tuple(CURSOR_LABEL_NAMES),
                expected_n_neurons=None,
                file_type="nwb",
                pos_dims=(0, 1),
            )
    return specs


PERICH_SPECS: dict[str, DatasetSpec] = _build_perich_specs()
