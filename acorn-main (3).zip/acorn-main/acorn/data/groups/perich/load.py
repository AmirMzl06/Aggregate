"""Download DANDI 000688 and load one Perich session's train/test arrays."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from acorn.data.consent import confirm_download
from acorn.data.groups.normalize import zscore_spikes_independent
from acorn.data.groups.perich import parse_perich_key
from acorn.data.groups.perich.nwb_session import load_binned_nwb
from acorn.data.groups.perich.trials import (
    arrays_from_valid_trials,
    extract_center_out_reaching_trials,
    extract_random_target_reaching_trials,
)
from acorn.data.registry import DatasetSpec
from acorn.utils.constants import DATA_DIR

DANDISET_ID = "000688"


def perich_root(data_dir: str | Path | None = None) -> Path:
    return Path(data_dir or DATA_DIR).expanduser() / "perich"


def _sorted_session_files(task_dir: Path) -> list[Path]:
    if not task_dir.is_dir():
        return []
    names = sorted(p for p in task_dir.iterdir() if p.is_file())
    return names


def resolve_perich_nwb_path(spec: DatasetSpec, *, data_dir: str | Path | None = None) -> Path:
    """Return the NWB path for ``spec``. Raises if that session file is missing."""
    task, day_index = parse_perich_key(spec.key)
    task_dir = perich_root(data_dir) / task
    files = _sorted_session_files(task_dir)
    if not (0 <= day_index < len(files)):
        raise FileNotFoundError(
            f"Missing NWB for {spec.key}: expected day index {day_index} in "
            f"{task_dir} ({len(files)} file(s) present)."
        )
    return files[day_index]


def _organize_dandi_layout(root: Path) -> None:
    """Move ``sub-*`` NWB assets into ``C-CO`` / ``C-RT`` / ... folders."""
    dandiset_dir = root / DANDISET_ID
    if not dandiset_dir.is_dir():
        return
    for sub in sorted(dandiset_dir.iterdir()):
        if not sub.is_dir() or not sub.name.startswith("sub-"):
            continue
        letter = sub.name[-1]
        co_dir = root / f"{letter}-CO"
        rt_dir = root / f"{letter}-RT"
        co_dir.mkdir(parents=True, exist_ok=True)
        rt_dir.mkdir(parents=True, exist_ok=True)
        sessions = [p for p in sub.rglob("*") if p.is_file() and p.suffix == ".nwb"]
        if not sessions:
            sessions = [p for p in sub.iterdir() if p.is_file()]
        for session in sessions:
            dest_dir = rt_dir if "RT" in session.name else co_dir
            dest = dest_dir / session.name
            if dest.exists():
                continue
            session.replace(dest)


def ensure_perich_nwb(
    spec: DatasetSpec, *, assume_yes: bool = False, data_dir: str | Path | None = None
) -> Path:
    """Download DANDI 000688 if needed, then resolve ``spec``'s NWB path."""
    root = perich_root(data_dir)
    try:
        return resolve_perich_nwb_path(spec, data_dir=data_dir)
    except FileNotFoundError:
        pass

    dest = root / DANDISET_ID
    confirm_download(
        message=(
            f"About to download DANDI {DANDISET_ID} (Perich reaching NWBs) into {dest}. "
            "This can take a while and uses local disk."
        ),
        assume_yes=assume_yes,
        declined=f"Download of DANDI {DANDISET_ID} declined.",
    )
    dest.mkdir(parents=True, exist_ok=True)
    from dandi.download import download

    download(
        f"https://dandiarchive.org/dandiset/{DANDISET_ID}",
        output_dir=str(root),
        existing="skip",
    )
    _organize_dandi_layout(root)
    return resolve_perich_nwb_path(spec, data_dir=data_dir)


def load_perich_session(
    spec: DatasetSpec,
    *,
    assume_yes: bool = False,
    data_dir: str | Path | None = None,
    zscore: bool = True,
) -> dict[str, np.ndarray]:
    """Load one Perich recording and return train/test spike and label arrays."""
    fpath = ensure_perich_nwb(spec, assume_yes=assume_yes, data_dir=data_dir)
    dayk, trial_cols = load_binned_nwb(fpath)
    task, _day_index = parse_perich_key(spec.key)
    cursor_t_end = float(np.asarray(dayk.time_frame).reshape(-1)[-1])
    if task.endswith("CO"):
        trials = extract_center_out_reaching_trials(trial_cols, cursor_t_end)
        start_event = "gocue_time"
    else:
        trials = extract_random_target_reaching_trials(trial_cols)
        start_event = "start"
    train_x, train_y, test_x, test_y = arrays_from_valid_trials(dayk, trials, start_event)
    if zscore:
        train_x, test_x = zscore_spikes_independent(train_x, test_x)
    return {
        "train_x": np.asarray(train_x, dtype=np.float32),
        "train_y": np.asarray(train_y, dtype=np.float32),
        "test_x": np.asarray(test_x, dtype=np.float32),
        "test_y": np.asarray(test_y, dtype=np.float32),
    }
