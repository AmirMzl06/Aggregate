"""Read one Perich NWB file and bin spikes / cursor kinematics at 50 ms."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from acorn.data.groups.perich.trials import BinnedKinematics

BIN_SIZE = 0.05


def _load_nwb_arrays(
    fpath: str | Path,
) -> tuple[np.ndarray, list[np.ndarray], np.ndarray, np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    from pynwb import NWBHDF5IO

    with NWBHDF5IO(str(fpath), "r") as io:
        nwbfile = io.read()
        time_frame = np.asarray(
            nwbfile.processing["behavior"]["Position"]["cursor_pos"].timestamps[:]
        )
        curs_p = np.asarray(nwbfile.processing["behavior"]["Position"]["cursor_pos"].data[:])
        curs_v = np.asarray(nwbfile.processing["behavior"]["Velocity"]["cursor_vel"].data[:])
        curs_a = np.asarray(nwbfile.processing["behavior"]["Acceleration"]["cursor_acc"].data[:])
        spikes = [np.array(times).reshape(-1, 1) for times in nwbfile.units.spike_times_index[:]]
        trial_table = nwbfile.trials.to_dataframe()
        trial_cols = {
            name: np.asarray(trial_table[name].to_numpy()) for name in trial_table.columns
        }
    return time_frame, spikes, curs_p, curs_v, curs_a, trial_cols


def _bin_spikes(
    time_frame: np.ndarray, spikes: list[np.ndarray], bin_size: float, mode: str = "center"
) -> tuple[np.ndarray, np.ndarray]:
    if mode == "center":
        bins = np.arange(time_frame[0] - bin_size / 2, time_frame[-1] + bin_size / 2, bin_size)
    elif mode == "left":
        bins = np.arange(time_frame[0], time_frame[-1], bin_size)
    else:
        raise ValueError(f"Unknown bin mode {mode!r}")
    bins = bins.reshape((len(bins),))
    spike_counts = []
    for each in spikes:
        bb = each.reshape((len(each),))
        out, _ = np.histogram(bb, bins)
        spike_counts.append(out)
    bins = bins.reshape((len(bins), 1))
    return bins[1:], np.asarray(spike_counts).T


def _resample_kin(
    time_frame: np.ndarray,
    curs_p: np.ndarray,
    curs_v: np.ndarray,
    curs_a: np.ndarray,
    bin_width: float,
    new_bin_size: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = new_bin_size / bin_width
    length = int(np.floor(curs_p.shape[0] / n))
    idx = [int(np.floor(i * n)) for i in range(1, length)]
    return time_frame[idx], curs_p[idx, :], curs_v[idx, :], curs_a[idx, :]


def load_binned_nwb(
    fpath: str | Path, bin_size: float = BIN_SIZE
) -> tuple[BinnedKinematics, dict[str, np.ndarray]]:
    """Load cursor traces and spike times, then bin at ``bin_size`` seconds."""
    time_frame, spikes, curs_p, curs_v, curs_a, trial_cols = _load_nwb_arrays(fpath)
    if not (curs_p.shape[0] == curs_v.shape[0] == curs_a.shape[0] == time_frame.shape[0]):
        raise ValueError("Cursor position/velocity/acceleration and timestamps differ in length.")
    bin_width = round(float(time_frame[1] - time_frame[0]), 3)
    if round(float(time_frame[1] - time_frame[0]), 3) != round(
        float(time_frame[2] - time_frame[1]), 3
    ):
        raise AssertionError("Cursor timestamps are not regularly spaced.")
    if len(np.where(np.round(time_frame[1:] - time_frame[:-1], 3) > bin_width)[0]) != 0:
        time_frame = np.arange(0, bin_width * curs_p.shape[0], bin_width)
        if time_frame.shape[0] != curs_p.shape[0]:
            raise AssertionError("Rebuilt timestamp grid does not match cursor length.")

    t_spike, spike_counts = _bin_spikes(time_frame, spikes, bin_size)
    t_curs, curs_p, curs_v, curs_a = _resample_kin(
        time_frame, curs_p, curs_v, curs_a, bin_width, bin_size
    )
    if len(t_curs) > len(t_spike):
        curs_p = curs_p[: len(t_spike), :]
        curs_v = curs_v[: len(t_spike), :]
        curs_a = curs_a[: len(t_spike), :]
    dayk = BinnedKinematics(
        time_frame=np.asarray(t_spike).reshape(-1),
        spike_counts=spike_counts,
        curs_p=curs_p,
        curs_v=curs_v,
        curs_a=curs_a,
    )
    return dayk, trial_cols
