"""Download Figshare joblib dumps and split hippocampus sessions at ``int(0.8 * T)``."""

from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np

from acorn.data.consent import confirm_download
from acorn.data.groups.normalize import zscore_spikes_independent
from acorn.data.registry import DatasetSpec
from acorn.utils.constants import DATA_DIR

HIPPO_SPLIT_FRAC = 0.8


def hippo_root(data_dir: str | Path | None = None) -> Path:
    return Path(data_dir or DATA_DIR).expanduser() / "hippo"


def rat_name(spec: DatasetSpec) -> str:
    if not spec.key.startswith("hippo_"):
        raise ValueError(f"Not a hippocampus dataset key: {spec.key!r}")
    return spec.key.removeprefix("hippo_")


def hippo_jl_path(spec: DatasetSpec, *, data_dir: str | Path | None = None) -> Path:
    return hippo_root(data_dir) / f"{rat_name(spec)}.jl"


def ensure_hippo_jl(
    spec: DatasetSpec, *, assume_yes: bool = False, data_dir: str | Path | None = None
) -> Path:
    """Download ``DATA_DIR/hippo/{rat}.jl`` with CEBRA's Figshare helper if missing."""
    dest = hippo_jl_path(spec, data_dir=data_dir)
    if dest.exists():
        return dest
    if not spec.http_url:
        raise FileNotFoundError(f"No http_url on {spec.key} and {dest} is missing.")
    dest.parent.mkdir(parents=True, exist_ok=True)
    confirm_download(
        message=(f"About to download hippocampus file for {spec.key} from Figshare into {dest}."),
        assume_yes=assume_yes,
        declined=f"Download of {spec.key} declined.",
    )
    from cebra.data.assets import download_file_with_progress_bar
    from cebra.datasets.hippocampus import rat_dataset_urls

    info = rat_dataset_urls[rat_name(spec)]
    download_file_with_progress_bar(
        url=info["url"],
        expected_checksum=info["checksum"],
        location=str(dest.parent),
        file_name=dest.name,
    )
    if not dest.is_file():
        raise RuntimeError(
            f"CEBRA hippo download finished but {dest} is missing (Figshare URL {info['url']})."
        )
    return dest


def split_hippo_arrays(
    spikes: np.ndarray, position: np.ndarray, *, split_frac: float = HIPPO_SPLIT_FRAC
) -> dict[str, np.ndarray]:
    """Split spikes/position at ``int(split_frac * T)``; labels are ``position[:, :2]``."""
    spikes = np.asarray(spikes)
    position = np.asarray(position)
    labels = position[:, :2]
    split_idx = int(split_frac * len(spikes))
    return {
        "train_x": spikes[:split_idx],
        "test_x": spikes[split_idx:],
        "train_y": labels[:split_idx],
        "test_y": labels[split_idx:],
        "full_x": spikes,
        "full_y": labels,
    }


def load_hippo_session(
    spec: DatasetSpec,
    *,
    assume_yes: bool = False,
    data_dir: str | Path | None = None,
    zscore: bool = True,
) -> dict[str, np.ndarray]:
    """Load one rat joblib dump and return split plus full-T spike/label arrays."""
    path = ensure_hippo_jl(spec, assume_yes=assume_yes, data_dir=data_dir)
    payload = joblib.load(path)
    arrays = split_hippo_arrays(payload["spikes"], payload["position"])
    train_x, test_x = arrays["train_x"], arrays["test_x"]
    if zscore:
        train_x, test_x = zscore_spikes_independent(train_x, test_x)
    return {
        "train_x": np.asarray(train_x, dtype=np.float32),
        "train_y": np.asarray(arrays["train_y"], dtype=np.float32),
        "test_x": np.asarray(test_x, dtype=np.float32),
        "test_y": np.asarray(arrays["test_y"], dtype=np.float32),
        "full_x": np.asarray(arrays["full_x"], dtype=np.float32),
        "full_y": np.asarray(arrays["full_y"], dtype=np.float32),
    }


def hippo_all_from_full(full_x: np.ndarray, full_y: np.ndarray) -> dict[str, np.ndarray]:
    """Train=valid from raw ``full_*``, then independent ``std+1e-3`` on each copy."""
    full_x = np.asarray(full_x)
    full_y = np.asarray(full_y)
    train_x, test_x = zscore_spikes_independent(full_x, full_x)
    return {
        "train_x": np.asarray(train_x, dtype=np.float32),
        "test_x": np.asarray(test_x, dtype=np.float32),
        "train_y": np.asarray(full_y, dtype=np.float32),
        "test_y": np.asarray(full_y, dtype=np.float32),
        "full_x": np.asarray(full_x, dtype=np.float32),
        "full_y": np.asarray(full_y, dtype=np.float32),
    }
