"""Hippocampus rat sessions (Figshare joblib dumps)."""

from __future__ import annotations

from acorn.data.registry import DatasetSpec

# Figshare downloader URLs (file ids 40849463, 40849460, 40849457, 40849454).
HIPPO_RATS: tuple[str, ...] = ("achilles", "buddy", "cicero", "gatsby")
HIPPO_HTTP_URLS: dict[str, str] = {
    "achilles": (
        "https://figshare.com/ndownloader/files/40849463?private_link=9f91576cbbcc8b0d8828"
    ),
    "buddy": ("https://figshare.com/ndownloader/files/40849460?private_link=9f91576cbbcc8b0d8828"),
    "cicero": ("https://figshare.com/ndownloader/files/40849457?private_link=9f91576cbbcc8b0d8828"),
    "gatsby": ("https://figshare.com/ndownloader/files/40849454?private_link=9f91576cbbcc8b0d8828"),
}


def _build_hippo_specs() -> dict[str, DatasetSpec]:
    specs: dict[str, DatasetSpec] = {}
    for rat in HIPPO_RATS:
        key = f"hippo_{rat}"
        specs[key] = DatasetSpec(
            key=key,
            dataset_group="hippo",
            xds_name=key,
            num_days=1,
            use_smooth=False,
            xds_smooth=False,
            gdrive_url=None,
            http_url=HIPPO_HTTP_URLS[rat],
            plot_type="position",
            panel="H",
            title=key,
            label_names=("x", "y"),
            expected_n_neurons=None,
            file_type="jl",
            pos_dims=(0, 1),
        )
    return specs


HIPPO_SPECS: dict[str, DatasetSpec] = _build_hippo_specs()
