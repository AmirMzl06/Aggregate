"""Per-split spike z-score used when loading Perich and hippocampus sessions.

Each split is centered and scaled independently with ``std + 1e-3``.
"""

from __future__ import annotations

import numpy as np


def zscore_spikes_independent(
    train_x: np.ndarray, test_x: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Z-score train and test spikes with each split's own mean and ``std + 1e-3``."""
    train_x = np.asarray(train_x, dtype=np.float64)
    test_x = np.asarray(test_x, dtype=np.float64)
    train_mean = train_x.mean(axis=0)
    train_std = train_x.std(axis=0) + 1e-3
    test_mean = test_x.mean(axis=0)
    test_std = test_x.std(axis=0) + 1e-3
    return (train_x - train_mean) / train_std, (test_x - test_mean) / test_std
