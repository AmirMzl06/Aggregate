"""Time-bin dataset groups merged into ``DATASET_REGISTRY``.

Each group owns its specs and on-disk loader. Macaque sessions are XDS/gdown
archives; Perich sessions are DANDI NWB files; hippocampus sessions are Figshare
joblib dumps. Specs do not choose a training recipe.
"""
