"""Day-level train/test loading and z-score normalization for monkey reach/EMG recordings."""

import torch
from sklearn.model_selection import train_test_split

TRAIN_FRAC = 0.8


def _zscore_stats(train_x: torch.Tensor):
    mean = train_x.mean(dim=0, keepdim=True)
    std = train_x.std(dim=0, keepdim=True, unbiased=False)
    low_var = (std < 1e-3).squeeze()
    return mean, std, low_var


def _zscore_spikes(x: torch.Tensor, mean, std, low_var) -> torch.Tensor:
    x = (x - mean) / (std + 1e-8)
    x[:, low_var] = 0.0
    return x


def _split_and_zscore(spikes, labels, zscore: bool = True):
    train_x, test_x, train_y, test_y = train_test_split(
        spikes, labels, test_size=1.0 - TRAIN_FRAC, shuffle=False
    )
    if zscore:
        mean, std, low_var = _zscore_stats(train_x)
        train_x = _zscore_spikes(train_x, mean, std, low_var)
        test_x = _zscore_spikes(test_x, mean, std, low_var)
    return train_x, test_x, train_y, test_y


def load_day_split(
    loader,
    dataset_name: str,
    day_idx: int,
    xds_smooth: bool = True,
    zscore: bool = True,
    assume_yes: bool | None = None,
):
    """Load one day stacked, then apply a contiguous ``TRAIN_FRAC`` / remainder split."""
    if assume_yes is not None:
        loader.assume_yes = assume_yes
    spikes, labels = loader.load_dataset_day(day_idx, dataset_name, xds_smooth=xds_smooth)
    spikes = torch.from_numpy(spikes).float()
    labels = torch.from_numpy(labels).float()
    return _split_and_zscore(spikes, labels, zscore=zscore)


def load_day_trials(
    loader,
    dataset_name: str,
    day_idx: int,
    xds_smooth: bool = True,
    zscore: bool = True,
):
    """Load per-trial arrays and split on cumulative time at ``TRAIN_FRAC`` of total bins."""
    x_list, y_list = loader.load_dataset_day(
        day_idx, dataset_name, stack=False, xds_smooth=xds_smooth
    )
    x_list = [torch.from_numpy(x).float() for x in x_list]
    y_list = [torch.from_numpy(y).float() for y in y_list]

    total_bins = sum(x.shape[0] for x in x_list)
    split_time = int(TRAIN_FRAC * total_bins)

    train_trials, test_trials = [], []
    cum = 0
    for x, y in zip(x_list, y_list):
        t_end = cum + x.shape[0]
        if t_end <= split_time:
            train_trials.append((x, y))
        elif cum >= split_time:
            test_trials.append((x, y))
        else:
            cut = split_time - cum
            train_trials.append((x[:cut], y[:cut]))
            test_trials.append((x[cut:], y[cut:]))
        cum = t_end

    train_x = torch.cat([x for x, _ in train_trials], dim=0)
    test_x = torch.cat([x for x, _ in test_trials], dim=0)
    train_y = torch.cat([y for _, y in train_trials], dim=0)
    test_y = torch.cat([y for _, y in test_trials], dim=0)

    if zscore:
        mean, std, low_var = _zscore_stats(train_x)
        train_trials = [(_zscore_spikes(x, mean, std, low_var), y) for x, y in train_trials]
        test_trials = [(_zscore_spikes(x, mean, std, low_var), y) for x, y in test_trials]
        train_x = _zscore_spikes(train_x, mean, std, low_var)
        test_x = _zscore_spikes(test_x, mean, std, low_var)

    return train_trials, test_trials, train_x, train_y, test_x, test_y
