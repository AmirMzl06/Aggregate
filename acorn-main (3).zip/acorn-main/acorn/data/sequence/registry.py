"""Registry for sequence-format (CTC) datasets."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from acorn.data.sequence.vocabs import NLP_VOCAB, SPEECH_VOCAB


class SequenceDatasetSpec(BaseModel):
    """Sequence-format (CTC) dataset record.

    ``vocab`` index 0 must be the CTC blank. ``task_key`` groups sessions
    that share a CTC head (``nlp`` vs ``speech``).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    key: str
    task_key: str
    expected_n_features: int | None = None
    num_classes: int
    blank_index: int = 0
    vocab: tuple[str, ...]
    dryad_doi: str
    dryad_filename: str | None = None
    extract_only: tuple[str, ...] | None = None
    approx_download_size_gb: float
    use_smooth: bool = True
    demo_only: bool = False


SEQUENCE_DATASET_REGISTRY: dict[str, SequenceDatasetSpec] = {
    "nlp21": SequenceDatasetSpec(
        key="nlp21",
        task_key="nlp",
        expected_n_features=192,
        num_classes=32,
        vocab=NLP_VOCAB,
        dryad_doi="10.5061/dryad.hqbzkh1p6",
        dryad_filename="CORP_data_release.zip",
        extract_only=(
            "seed_model_training_data/mat/",
            "online_evaluation_data/no_recalibration/mat/",
            "online_evaluation_data/recalibration/mat/",
        ),
        approx_download_size_gb=3.57,
    ),
    "nlp10": SequenceDatasetSpec(
        key="nlp10",
        task_key="nlp",
        expected_n_features=192,
        num_classes=32,
        vocab=NLP_VOCAB,
        dryad_doi="10.5061/dryad.wh70rxwmv",
        dryad_filename=None,
        extract_only=("Datasets/",),
        approx_download_size_gb=1.41,
    ),
    "speech24": SequenceDatasetSpec(
        key="speech24",
        task_key="speech",
        expected_n_features=256,
        num_classes=41,
        vocab=SPEECH_VOCAB,
        dryad_doi="10.5061/dryad.x69p8czpq",
        dryad_filename="competitionData.tar.gz",
        extract_only=None,
        approx_download_size_gb=3.67,
    ),
    "speech45": SequenceDatasetSpec(
        key="speech45",
        task_key="speech",
        expected_n_features=512,
        num_classes=41,
        vocab=SPEECH_VOCAB,
        dryad_doi="10.5061/dryad.dncjsxm85",
        dryad_filename="t15_copyTask_neuralData.zip",
        extract_only=None,
        approx_download_size_gb=11.05,
    ),
    "demo": SequenceDatasetSpec(
        key="demo",
        task_key="nlp",
        expected_n_features=16,
        num_classes=32,
        vocab=NLP_VOCAB,
        dryad_doi="10.5061/dryad.demo",
        dryad_filename=None,
        extract_only=None,
        approx_download_size_gb=0.0,
        use_smooth=False,
        demo_only=True,
    ),
}


def get_sequence_dataset(key: str) -> SequenceDatasetSpec:
    """Return the sequence :class:`SequenceDatasetSpec` for ``key``.

    Parameters
    ----------
    key : str
        Registry key such as ``nlp21`` or ``speech24``.

    Returns
    -------
    SequenceDatasetSpec
        Frozen spec for that key.

    Raises
    ------
    KeyError
        If ``key`` is unknown, or is registered only for time-bin training.
    """
    if key in SEQUENCE_DATASET_REGISTRY:
        return SEQUENCE_DATASET_REGISTRY[key]
    from acorn.data.registry import DATASET_REGISTRY

    if key in DATASET_REGISTRY:
        raise KeyError(
            f"Dataset key {key!r} is registered for time-bin training. "
            "Use get_dataset, not get_sequence_dataset."
        )
    raise KeyError(f"Unknown sequence dataset {key!r}. Choices: {list(SEQUENCE_DATASET_REGISTRY)}")
