"""CTC vocabs. Index 0 is the blank token.

Transcribed from the handwriting CHARS table and the speech PHONE_DEF_SIL table.
"""

from __future__ import annotations

BLANK_TOKEN = "<BLANK>"

CHARS: tuple[str, ...] = (
    ">",
    ",",
    "?",
    "~",
    "'",
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
)

PHONE_DEF: tuple[str, ...] = (
    "AA",
    "AE",
    "AH",
    "AO",
    "AW",
    "AY",
    "B",
    "CH",
    "D",
    "DH",
    "EH",
    "ER",
    "EY",
    "F",
    "G",
    "HH",
    "IH",
    "IY",
    "JH",
    "K",
    "L",
    "M",
    "N",
    "NG",
    "OW",
    "OY",
    "P",
    "R",
    "S",
    "SH",
    "T",
    "TH",
    "UH",
    "UW",
    "V",
    "W",
    "Y",
    "Z",
    "ZH",
)

PHONE_DEF_SIL: tuple[str, ...] = PHONE_DEF + ("SIL",)

NLP_VOCAB: tuple[str, ...] = (BLANK_TOKEN, *CHARS)
SPEECH_VOCAB: tuple[str, ...] = (BLANK_TOKEN, *PHONE_DEF_SIL)

_NLP_SYM2IDX: dict[str, int] = {s: i + 1 for i, s in enumerate(CHARS)}
_NLP_SYM2IDX[BLANK_TOKEN] = 0
_SPEECH_SYM2IDX: dict[str, int] = {p: i + 1 for i, p in enumerate(PHONE_DEF_SIL)}
_SPEECH_SYM2IDX[BLANK_TOKEN] = 0


def nlp_text_to_ids(text: str) -> list[int]:
    """Map a handwriting transcript to CTC ids. Unknown chars are dropped."""
    return [_NLP_SYM2IDX[ch] for ch in text if ch in _NLP_SYM2IDX]


def speech_phones_to_ids(phones: list[str]) -> list[int]:
    """Map ARPAbet(+SIL) tokens to CTC ids (phoneToId + 1)."""
    return [_SPEECH_SYM2IDX[p] for p in phones]
