"""Trial-list types and last-frame-replicate collation for sequence datasets."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch.utils.data import Dataset


@dataclass
class SequenceSplit:
    features: list[np.ndarray]
    labels: list[np.ndarray]


@dataclass
class SequenceSession:
    session_key: str
    task_key: str
    use_smooth: bool
    n_features: int
    num_classes: int
    vocab: tuple[str, ...]
    blank_index: int
    train: SequenceSplit
    periodic_eval: SequenceSplit
    final_eval: SequenceSplit


class TrialDataset(Dataset):
    def __init__(self, split: SequenceSplit):
        self.xs = [torch.as_tensor(x, dtype=torch.float32) for x in split.features]
        self.ys = [torch.as_tensor(y, dtype=torch.long) for y in split.labels]

    def __len__(self) -> int:
        return len(self.xs)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.xs[idx], self.ys[idx]


def collate_fn(
    batch: list[tuple[torch.Tensor, torch.Tensor]],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Pad features by repeating each trial's last frame; pad labels with 0.

    Never sorts the batch by length.
    """
    xs, ys = zip(*batch, strict=True)
    widths = {int(x.shape[-1]) for x in xs}
    if len(widths) != 1:
        raise ValueError(f"mixed feature widths in batch: {sorted(widths)}")
    feat_dim = xs[0].shape[-1]
    input_lengths = torch.tensor([x.shape[0] for x in xs], dtype=torch.long)
    t_max = int(input_lengths.max().item())
    x_pad = torch.zeros(len(xs), t_max, feat_dim, dtype=torch.float32)
    for i, x in enumerate(xs):
        t = x.shape[0]
        x_pad[i, :t] = x
        if t < t_max:
            x_pad[i, t:] = x[-1:]
    target_lengths = torch.tensor([y.shape[0] for y in ys], dtype=torch.long)
    l_max = int(target_lengths.max().item()) if len(target_lengths) else 0
    y_pad = torch.zeros(len(ys), l_max, dtype=torch.long)
    for i, y in enumerate(ys):
        y_pad[i, : y.shape[0]] = y
    return x_pad, y_pad, input_lengths, target_lengths
