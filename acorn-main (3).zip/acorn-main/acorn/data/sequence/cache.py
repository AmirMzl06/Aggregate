"""Object-array .npz cache for variable-length trial lists.

Mirrors ``DatasetLoader._save_trials_to_disk_cache`` /
``_load_trials_from_disk_cache`` without touching that class.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from acorn.data.sequence.collate import SequenceSplit


def cache_path(dest_dir: Path, name: str) -> Path:
    return Path(dest_dir) / f"{name}_trials.npz"


def save_split(path: Path, split: SequenceSplit) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    x_obj: np.ndarray = np.empty(len(split.features), dtype=object)
    y_obj: np.ndarray = np.empty(len(split.labels), dtype=object)
    for i, (x, y) in enumerate(zip(split.features, split.labels, strict=True)):
        x_obj[i] = np.asarray(x)
        y_obj[i] = np.asarray(y)
    np.savez_compressed(path, x=x_obj, y=y_obj)


def load_split(path: Path) -> SequenceSplit | None:
    path = Path(path)
    if not path.exists():
        return None
    with np.load(path, allow_pickle=True) as data:
        return SequenceSplit(features=list(data["x"]), labels=list(data["y"]))
