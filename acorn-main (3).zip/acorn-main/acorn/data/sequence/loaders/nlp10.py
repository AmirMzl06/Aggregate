"""NLP10 (Willett et al. 2021 handwriting) sequence loader.

periodic_eval_split and final_eval_split are implemented independently:
they currently return different trial populations.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import scipy.io as sio
import torch

from acorn.data.download import confirm_and_download
from acorn.data.sequence.cache import cache_path, load_split, save_split
from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.data.sequence.nlp_mat import block_stats_chan, infer_n_features, safe_sentence
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY, SequenceDatasetSpec
from acorn.data.sequence.vocabs import nlp_text_to_ids
from acorn.utils.constants import DATA_DIR

FINAL_DAY = 5
N_DAYS = 10


def slow_time_2x(x: np.ndarray) -> np.ndarray:
    t = x.shape[0]
    if t % 2:
        x = x[:-1]
    xt = torch.as_tensor(x)
    xt = xt.reshape(xt.shape[0] // 2, 2, xt.shape[1]).sum(dim=1)
    return xt.numpy()


def _sentences_mats(root: Path) -> list[Path]:
    return sorted(root.rglob("sentences.mat"))


def is_ready(dest: Path) -> bool:
    return len(_sentences_mats(Path(dest))) >= N_DAYS


def _day_items(mat_path: Path) -> list[dict]:
    mat = sio.loadmat(mat_path)
    sents = mat["intendedText"]
    n = len(sents)
    trials = mat["neuralActivityCube"]
    lengths = mat["numTimeBinsPerSentence"]
    blocks = mat["sentenceBlockNums"]
    excluded = mat["excludedSentences"]
    day_list = []
    for i in range(n):
        if excluded[i, 0] == 1:
            continue
        trial = trials[i][: lengths[i, 0]]
        block = blocks[i, 0]
        sentence = str(safe_sentence(sents[i, 0])).replace("#", "").replace(" ", ">")
        if "3" in sentence or "5" in sentence:
            continue
        day_list.append({"trial": trial, "block": int(block), "sentence": sentence})
    return day_list


def load_nlp10_days(
    root: Path,
    days: range,
    *,
    train: bool = False,
    valid: bool = False,
    norm: bool = True,
    eps: float = 0.0,
) -> SequenceSplit:
    """Port of handwriting-day ``get_input`` (no in-loader gauss)."""
    files = _sentences_mats(root)
    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    for day_key in days:
        if day_key >= len(files):
            continue
        day_list = _day_items(files[day_key])
        for item in day_list:
            item["trial"] = slow_time_2x(np.asarray(item["trial"]))
        if not day_list:
            continue
        blocks = sorted({item["block"] for item in day_list})
        last_block = blocks[-1]
        stats_this_day = {}
        if norm:
            stats_this_day = block_stats_chan(
                [d["trial"] for d in day_list],
                np.array([d["block"] for d in day_list]),
            )
        for item in day_list:
            blk = item["block"]
            if train and blk == last_block:
                continue
            if valid and blk != last_block:
                continue
            x = np.asarray(item["trial"], dtype=np.float64)
            if x.ndim == 1:
                x = x[:, None]
            if norm:
                mu, std = stats_this_day[blk]
                std = np.maximum(std, eps + 1e-6)
                x = (x - mu) / std
            y = nlp_text_to_ids(item["sentence"])
            # Keep empty-ID trials: upstream ctc_collate never filters
            # (charset.text_to_int may return []); CTCLoss(zero_infinity=True) handles them.
            features.append(np.asarray(x, dtype=np.float32))
            labels.append(np.asarray(y, dtype=np.int64))
    return SequenceSplit(features=features, labels=labels)


class Nlp10Loader:
    def __init__(
        self,
        data_dir: str | Path | None = None,
        spec: SequenceDatasetSpec | None = None,
        assume_yes: bool = False,
    ):
        self.spec = spec or SEQUENCE_DATASET_REGISTRY["nlp10"]
        self.data_dir = Path(data_dir) if data_dir is not None else DATA_DIR / self.spec.key
        self.assume_yes = assume_yes
        self._train: SequenceSplit | None = None
        self._periodic: SequenceSplit | None = None
        self._final: SequenceSplit | None = None

    def _ensure_downloaded(self) -> None:
        confirm_and_download(
            self.data_dir,
            source="dryad",
            doi=self.spec.dryad_doi,
            dryad_filename=self.spec.dryad_filename,
            extract_only=self.spec.extract_only,
            size_hint_gb=self.spec.approx_download_size_gb,
            assume_yes=self.assume_yes,
            ready=is_ready,
        )

    def _load_or_build(self, name: str, builder) -> SequenceSplit:
        path = cache_path(self.data_dir, name)
        cached = load_split(path)
        if cached is not None:
            return cached
        split = builder()
        save_split(path, split)
        return split

    def _build_train(self) -> SequenceSplit:
        return load_nlp10_days(self.data_dir, range(FINAL_DAY), train=True, valid=False, norm=True)

    def _build_periodic(self) -> SequenceSplit:
        # multi_trainer_task_based.py: days=range(10), valid=True
        return load_nlp10_days(self.data_dir, range(N_DAYS), train=False, valid=True, norm=True)

    def _build_final(self) -> SequenceSplit:
        # eval_utils.py::get_dataset_loader_nlp_10
        part1 = load_nlp10_days(self.data_dir, range(FINAL_DAY), train=False, valid=True, norm=True)
        part2 = load_nlp10_days(
            self.data_dir, range(FINAL_DAY, N_DAYS), train=False, valid=False, norm=True
        )
        return SequenceSplit(
            features=part1.features + part2.features,
            labels=part1.labels + part2.labels,
        )

    def load(self) -> SequenceSession:
        self._ensure_downloaded()
        self._train = self._load_or_build("nlp10_train", self._build_train)
        self._periodic = self._load_or_build("nlp10_periodic", self._build_periodic)
        self._final = self._load_or_build("nlp10_final", self._build_final)
        n_features = infer_n_features(self._train, self.spec.expected_n_features, self.spec.key)
        return SequenceSession(
            session_key=self.spec.key,
            task_key=self.spec.task_key,
            use_smooth=self.spec.use_smooth,
            n_features=n_features,
            num_classes=self.spec.num_classes,
            vocab=self.spec.vocab,
            blank_index=self.spec.blank_index,
            train=self._train,
            periodic_eval=self._periodic,
            final_eval=self._final,
        )

    def train_split(self) -> SequenceSplit:
        if self._train is None:
            self.load()
        assert self._train is not None
        return self._train

    def periodic_eval_split(self) -> SequenceSplit:
        """In-training CER split. Known upstream inconsistency vs final_eval_split.

        Independently implemented. Do not call final_eval_split from here.
        """
        if self._periodic is None:
            self.load()
        assert self._periodic is not None
        return self._periodic

    def final_eval_split(self) -> SequenceSplit:
        """Standalone eval/export split. Known upstream inconsistency vs periodic_eval_split.

        Independently implemented; do not alias periodic_eval_split.
        """
        if self._final is None:
            self.load()
        assert self._final is not None
        return self._final


def load_nlp10(
    data_dir: str | Path | None = None,
    assume_yes: bool = False,
) -> SequenceSession:
    return Nlp10Loader(data_dir=data_dir, assume_yes=assume_yes).load()


def _collect_sentences_nlp10_days(
    root: Path, days: range, *, train: bool, valid: bool
) -> list[str]:
    files = _sentences_mats(root)
    sentences: list[str] = []
    for day_key in days:
        if day_key >= len(files):
            continue
        day_list = _day_items(files[day_key])
        if not day_list:
            continue
        blocks = sorted({item["block"] for item in day_list})
        last_block = blocks[-1]
        for item in day_list:
            blk = item["block"]
            if train and blk == last_block:
                continue
            if valid and blk != last_block:
                continue
            sentences.append(item["sentence"])
    return sentences


def collect_nlp10_final_transcripts(data_dir: Path) -> list[str]:
    root = Path(data_dir)
    part1 = _collect_sentences_nlp10_days(root, range(FINAL_DAY), train=False, valid=True)
    part2 = _collect_sentences_nlp10_days(root, range(FINAL_DAY, N_DAYS), train=False, valid=False)
    return part1 + part2
