"""In-memory synthetic sequence session for tests. Never calls Dryad."""

from __future__ import annotations

import numpy as np

from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

_N_TRIALS = 20
_T = 80


def load_demo(data_dir=None, assume_yes: bool = False) -> SequenceSession:
    spec = SEQUENCE_DATASET_REGISTRY["demo"]
    n_features = spec.expected_n_features or 16
    rng = np.random.default_rng(0)
    features = [rng.standard_normal((_T, n_features)).astype(np.float32) for _ in range(_N_TRIALS)]
    labels = [rng.integers(1, spec.num_classes, size=4, dtype=np.int64) for _ in range(_N_TRIALS)]
    split = SequenceSplit(features=features, labels=labels)
    return SequenceSession(
        session_key=spec.key,
        task_key=spec.task_key,
        use_smooth=spec.use_smooth,
        n_features=n_features,
        num_classes=spec.num_classes,
        vocab=spec.vocab,
        blank_index=spec.blank_index,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )
