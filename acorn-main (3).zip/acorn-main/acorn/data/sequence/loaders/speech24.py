"""SPEECH24 (Willett et al. 2023) sequence loader.

Feature slice: first 128 columns of ``tx1`` and ``spikePow`` concatenated
(matching upstream's exact slice). Periodic and final eval splits both use
the Dryad ``test`` sessions — independently implemented, currently equal.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import scipy.io as sio

from acorn.data.download import confirm_and_download
from acorn.data.sequence.cache import cache_path, load_split, save_split
from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.data.sequence.nlp_mat import infer_n_features
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY, SequenceDatasetSpec
from acorn.data.sequence.vocabs import speech_phones_to_ids
from acorn.utils.constants import DATA_DIR

TRAIN_DAYS = 12

_G2P = None


def _g2p_phonemes(text: str) -> list[str]:
    global _G2P
    from g2p_en import G2p

    if _G2P is None:
        _G2P = G2p()
    g2p = _G2P
    this = re.sub(r"[^a-zA-Z\- ']", "", text.strip())
    this = this.replace("--", "").lower()
    phonemes: list[str] = []
    for p in g2p(this):
        if p == " ":
            phonemes.append("SIL")
        p = re.sub(r"[0-9]", "", p)
        if re.match(r"[A-Z]+", p):
            phonemes.append(p)
    phonemes.append("SIL")
    return phonemes


def _session_features(mat) -> tuple[list[np.ndarray], list[str], np.ndarray]:
    n_trials = mat["sentenceText"].shape[0]
    input_features = []
    transcriptions = []
    for i in range(n_trials):
        features = np.concatenate(
            [mat["tx1"][0, i][:, 0:128], mat["spikePow"][0, i][:, 0:128]],
            axis=1,
        )
        input_features.append(features)
        transcriptions.append(str(mat["sentenceText"][i]).strip())
    block_nums = np.squeeze(mat["blockIdx"])
    return input_features, transcriptions, block_nums


def _block_normalize(input_features: list[np.ndarray], block_nums: np.ndarray) -> list[np.ndarray]:
    block_list = np.unique(block_nums)
    blocks: list[np.ndarray] = []
    for b in block_list:
        sent_idx: np.ndarray = np.argwhere(block_nums == b)[:, 0].astype(np.int32)
        blocks.append(sent_idx)
    out = list(input_features)
    for sent_idx in blocks:
        feats = np.concatenate(out[sent_idx[0] : (sent_idx[-1] + 1)], axis=0)
        feats_mean = np.mean(feats, axis=0, keepdims=True)
        feats_std = np.std(feats, axis=0, keepdims=True)
        for i in sent_idx:
            out[i] = (out[i] - feats_mean) / (feats_std + 1e-8)
    return out


def load_speech24_session(mat_path: Path, g2p_fn=_g2p_phonemes) -> SequenceSplit:
    mat = sio.loadmat(mat_path)
    input_features, transcriptions, block_nums = _session_features(mat)
    input_features = _block_normalize(input_features, block_nums)
    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    for feats, sentence in zip(input_features, transcriptions, strict=True):
        phones = g2p_fn(sentence)
        ids = speech_phones_to_ids(phones)
        # Keep empty-ID trials: upstream save_data_speech / ctc_collate never drop
        # zero-length phone maps; CTCLoss(zero_infinity=True) handles them.
        features.append(np.asarray(feats, dtype=np.float32))
        labels.append(np.asarray(ids, dtype=np.int64))
    return SequenceSplit(features=features, labels=labels)


def _sorted_mats(root: Path, split: str) -> list[Path]:
    matches = sorted(root.rglob(f"{split}/*.mat"))
    if matches:
        return matches
    return sorted(p for p in root.rglob("*.mat") if split in p.parts)


def is_ready(dest: Path) -> bool:
    dest = Path(dest)
    return len(_sorted_mats(dest, "train")) >= TRAIN_DAYS and len(_sorted_mats(dest, "test")) >= 1


class Speech24Loader:
    def __init__(
        self,
        data_dir: str | Path | None = None,
        spec: SequenceDatasetSpec | None = None,
        assume_yes: bool = False,
        g2p_fn=_g2p_phonemes,
    ):
        self.spec = spec or SEQUENCE_DATASET_REGISTRY["speech24"]
        self.data_dir = Path(data_dir) if data_dir is not None else DATA_DIR / self.spec.key
        self.assume_yes = assume_yes
        self.g2p_fn = g2p_fn
        self._train: SequenceSplit | None = None
        self._eval: SequenceSplit | None = None

    def _ensure_downloaded(self) -> None:
        confirm_and_download(
            self.data_dir,
            source="dryad",
            doi=self.spec.dryad_doi,
            dryad_filename=self.spec.dryad_filename,
            extract_only=self.spec.extract_only,
            size_hint_gb=self.spec.approx_download_size_gb,
            assume_yes=self.assume_yes,
            ready=is_ready,
        )

    def _load_or_build(self, name: str, builder) -> SequenceSplit:
        path = cache_path(self.data_dir, name)
        cached = load_split(path)
        if cached is not None:
            return cached
        split = builder()
        save_split(path, split)
        return split

    def _concat_sessions(self, paths: list[Path]) -> SequenceSplit:
        features: list[np.ndarray] = []
        labels: list[np.ndarray] = []
        for path in paths:
            split = load_speech24_session(path, g2p_fn=self.g2p_fn)
            features.extend(split.features)
            labels.extend(split.labels)
        return SequenceSplit(features=features, labels=labels)

    def _build_train(self) -> SequenceSplit:
        train_mats = _sorted_mats(self.data_dir, "train")[:TRAIN_DAYS]
        return self._concat_sessions(train_mats)

    def _build_eval(self) -> SequenceSplit:
        test_mats = _sorted_mats(self.data_dir, "test")
        return self._concat_sessions(test_mats)

    def load(self) -> SequenceSession:
        self._ensure_downloaded()
        self._train = self._load_or_build("speech24_train", self._build_train)
        self._eval = self._load_or_build("speech24_eval", self._build_eval)
        assert self._eval is not None
        n_features = infer_n_features(self._train, self.spec.expected_n_features, self.spec.key)
        return SequenceSession(
            session_key=self.spec.key,
            task_key=self.spec.task_key,
            use_smooth=self.spec.use_smooth,
            n_features=n_features,
            num_classes=self.spec.num_classes,
            vocab=self.spec.vocab,
            blank_index=self.spec.blank_index,
            train=self._train,
            periodic_eval=SequenceSplit(list(self._eval.features), list(self._eval.labels)),
            final_eval=SequenceSplit(list(self._eval.features), list(self._eval.labels)),
        )

    def train_split(self) -> SequenceSplit:
        if self._train is None:
            self.load()
        assert self._train is not None
        return self._train

    def periodic_eval_split(self) -> SequenceSplit:
        """In-training CER split. Same trial set as final_eval_split for SPEECH24.

        Independently implemented. Do not call final_eval_split from here.
        """
        if self._eval is None:
            self.load()
        assert self._eval is not None
        return SequenceSplit(list(self._eval.features), list(self._eval.labels))

    def final_eval_split(self) -> SequenceSplit:
        """Standalone eval/export split. Same trial set as periodic_eval_split for SPEECH24.

        Independently implemented; do not alias periodic_eval_split.
        """
        if self._eval is None:
            self.load()
        assert self._eval is not None
        return SequenceSplit(list(self._eval.features), list(self._eval.labels))


def load_speech24(
    data_dir: str | Path | None = None,
    assume_yes: bool = False,
    g2p_fn=_g2p_phonemes,
) -> SequenceSession:
    return Speech24Loader(data_dir=data_dir, assume_yes=assume_yes, g2p_fn=g2p_fn).load()


def collect_speech24_final_transcripts(data_dir: Path) -> list[str]:
    root = Path(data_dir)
    transcripts: list[str] = []
    for mat_path in _sorted_mats(root, "test"):
        mat = sio.loadmat(mat_path)
        n_trials = mat["sentenceText"].shape[0]
        for i in range(n_trials):
            transcripts.append(str(mat["sentenceText"][i]).strip())
    return transcripts
