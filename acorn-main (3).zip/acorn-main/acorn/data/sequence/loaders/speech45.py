"""SPEECH45 (Card et al. 2024 NEJM) sequence loader.

Reads ``hdf5_data_final/<session>/data_{train,val}.hdf5``. Training uses the
first 23 sessions' non-max blocks; eval uses every session's max block.
``data_test.hdf5`` is never read (labels withheld). The public Dryad zip (and
the original ``speech_gru_cebra`` tree) omit ``data_val.hdf5`` for four
sessions, including the first sorted session, so ``is_ready`` only requires
train files. Periodic and final eval splits are independently implemented and
currently return the same set.
"""

from __future__ import annotations

from pathlib import Path

import h5py

from acorn.data.download import confirm_and_download
from acorn.data.sequence.cache import cache_path, load_split, save_split
from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.data.sequence.nlp_mat import infer_n_features
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY, SequenceDatasetSpec
from acorn.utils.constants import DATA_DIR

TRAIN_SESSIONS = 23


def _trial_from_group(g) -> dict:
    x_len = int(g.attrs["n_time_steps"])
    y_len = int(g.attrs["seq_len"])
    x = g["input_features"][:x_len].astype("float32")
    y = g["seq_class_ids"][:y_len].astype("int64")
    block = int(g.attrs["block_num"])
    return {"x": x, "y": y, "block": block}


def _session_trials(session_dir: Path) -> list[dict]:
    trials: list[dict] = []
    train_path = session_dir / "data_train.hdf5"
    if train_path.exists():
        with h5py.File(train_path, "r") as f:
            for g in f.values():
                trials.append(_trial_from_group(g))
    val_path = session_dir / "data_val.hdf5"
    if val_path.exists():
        with h5py.File(val_path, "r") as f:
            for g in f.values():
                trials.append(_trial_from_group(g))
    return trials


def _hdf5_root(data_dir: Path) -> Path:
    direct = data_dir / "hdf5_data_final"
    if direct.is_dir():
        return direct
    matches = [p for p in data_dir.rglob("hdf5_data_final") if p.is_dir()]
    if matches:
        return sorted(matches)[0]
    return direct


def is_ready(dest: Path) -> bool:
    dest = Path(dest)
    root = _hdf5_root(dest)
    if not root.is_dir():
        return False
    sessions = sorted(p for p in root.iterdir() if p.is_dir())
    if len(sessions) < TRAIN_SESSIONS:
        return False
    for session_dir in sessions[:TRAIN_SESSIONS]:
        if not (session_dir / "data_train.hdf5").is_file():
            return False
    return True


def _split_session(trials: list[dict]) -> tuple[SequenceSplit, SequenceSplit]:
    if not trials:
        empty = SequenceSplit(features=[], labels=[])
        return empty, empty
    max_block = max(t["block"] for t in trials)
    train_t = [t for t in trials if t["block"] != max_block]
    val_t = [t for t in trials if t["block"] == max_block]
    train = SequenceSplit(
        features=[t["x"] for t in train_t],
        labels=[t["y"] for t in train_t],
    )
    val = SequenceSplit(
        features=[t["x"] for t in val_t],
        labels=[t["y"] for t in val_t],
    )
    return train, val


class Speech45Loader:
    def __init__(
        self,
        data_dir: str | Path | None = None,
        spec: SequenceDatasetSpec | None = None,
        assume_yes: bool = False,
    ):
        self.spec = spec or SEQUENCE_DATASET_REGISTRY["speech45"]
        self.data_dir = Path(data_dir) if data_dir is not None else DATA_DIR / self.spec.key
        self.assume_yes = assume_yes
        self._train: SequenceSplit | None = None
        self._eval: SequenceSplit | None = None

    def _ensure_downloaded(self) -> None:
        confirm_and_download(
            self.data_dir,
            source="dryad",
            doi=self.spec.dryad_doi,
            dryad_filename=self.spec.dryad_filename,
            extract_only=self.spec.extract_only,
            size_hint_gb=self.spec.approx_download_size_gb,
            assume_yes=self.assume_yes,
            ready=is_ready,
        )

    def _load_or_build(self, name: str, builder) -> SequenceSplit:
        path = cache_path(self.data_dir, name)
        cached = load_split(path)
        if cached is not None:
            return cached
        split = builder()
        save_split(path, split)
        return split

    def _all_session_splits(self) -> tuple[list[SequenceSplit], list[SequenceSplit]]:
        root = _hdf5_root(self.data_dir)
        sessions = sorted(p for p in root.iterdir() if p.is_dir())
        trains: list[SequenceSplit] = []
        vals: list[SequenceSplit] = []
        for session_dir in sessions:
            train, val = _split_session(_session_trials(session_dir))
            trains.append(train)
            vals.append(val)
        return trains, vals

    def _build_train(self) -> SequenceSplit:
        trains, _vals = self._all_session_splits()
        chosen = trains[:TRAIN_SESSIONS]
        return SequenceSplit(
            features=[x for split in chosen for x in split.features],
            labels=[y for split in chosen for y in split.labels],
        )

    def _build_eval(self) -> SequenceSplit:
        _trains, vals = self._all_session_splits()
        return SequenceSplit(
            features=[x for split in vals for x in split.features],
            labels=[y for split in vals for y in split.labels],
        )

    def load(self) -> SequenceSession:
        self._ensure_downloaded()
        self._train = self._load_or_build("speech45_train", self._build_train)
        self._eval = self._load_or_build("speech45_eval", self._build_eval)
        assert self._eval is not None
        n_features = infer_n_features(self._train, self.spec.expected_n_features, self.spec.key)
        return SequenceSession(
            session_key=self.spec.key,
            task_key=self.spec.task_key,
            use_smooth=self.spec.use_smooth,
            n_features=n_features,
            num_classes=self.spec.num_classes,
            vocab=self.spec.vocab,
            blank_index=self.spec.blank_index,
            train=self._train,
            periodic_eval=SequenceSplit(list(self._eval.features), list(self._eval.labels)),
            final_eval=SequenceSplit(list(self._eval.features), list(self._eval.labels)),
        )

    def train_split(self) -> SequenceSplit:
        if self._train is None:
            self.load()
        assert self._train is not None
        return self._train

    def periodic_eval_split(self) -> SequenceSplit:
        """In-training CER split. Same trial set as final_eval_split for SPEECH45.

        Independently implemented. Do not call final_eval_split from here.
        """
        if self._eval is None:
            self.load()
        assert self._eval is not None
        return SequenceSplit(list(self._eval.features), list(self._eval.labels))

    def final_eval_split(self) -> SequenceSplit:
        """Standalone eval/export split. Same trial set as periodic_eval_split for SPEECH45.

        Independently implemented; do not alias periodic_eval_split.
        """
        if self._eval is None:
            self.load()
        assert self._eval is not None
        return SequenceSplit(list(self._eval.features), list(self._eval.labels))


def load_speech45(
    data_dir: str | Path | None = None,
    assume_yes: bool = False,
) -> SequenceSession:
    return Speech45Loader(data_dir=data_dir, assume_yes=assume_yes).load()


def _transcription_chr_until_zero(g) -> str:
    chars: list[str] = []
    for value in g["transcription"][:]:
        code = int(value)
        if code == 0:
            break
        chars.append(chr(code))
    return "".join(chars)


def collect_speech45_final_transcripts(data_dir: Path) -> list[str]:
    root = _hdf5_root(Path(data_dir))
    transcripts: list[str] = []
    for session_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        block_nums: list[int] = []
        groups: list[tuple[int, str]] = []
        for h5_name in ("data_train.hdf5", "data_val.hdf5"):
            path = session_dir / h5_name
            if not path.is_file():
                continue
            with h5py.File(path, "r") as handle:
                for group in handle.values():
                    block = int(group.attrs["block_num"])
                    block_nums.append(block)
                    groups.append((block, _transcription_chr_until_zero(group)))
        if not groups:
            continue
        max_block = max(block_nums)
        for block, text in groups:
            if block == max_block:
                transcripts.append(text)
    return transcripts
