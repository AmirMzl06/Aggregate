"""NLP21 (Fan et al. 2023 CORP) sequence loader.

periodic_eval_split and final_eval_split are implemented independently:
they currently return different trial populations. Do not make
one call the other — the eventual fix is a one-line alias.
"""

from __future__ import annotations

from pathlib import Path

import scipy.io as sio

from acorn.data.download import confirm_and_download
from acorn.data.sequence.cache import cache_path, load_split, save_split
from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.data.sequence.nlp_mat import (
    concat_splits,
    infer_n_features,
    load_nlp21_mats,
    merge_by_borders,
)
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY, SequenceDatasetSpec
from acorn.utils.constants import DATA_DIR

_SEED = "seed_model_training_data/mat"
_NO_RECAL = "online_evaluation_data/no_recalibration/mat"
_RECAL = "online_evaluation_data/recalibration/mat"


def _find_dir(root: Path, relative: str) -> Path:
    direct = root / relative
    if direct.is_dir():
        return direct
    matches = [p for p in root.rglob(relative.split("/")[-1]) if p.is_dir() and relative in str(p)]
    if matches:
        return sorted(matches)[0]
    return direct


def is_ready(dest: Path) -> bool:
    dest = Path(dest)
    for rel in (_SEED, _NO_RECAL, _RECAL):
        found = _find_dir(dest, rel)
        if not found.is_dir() or not any(found.rglob("*.mat")):
            return False
    return True


class Nlp21Loader:
    def __init__(
        self,
        data_dir: str | Path | None = None,
        spec: SequenceDatasetSpec | None = None,
        assume_yes: bool = False,
    ):
        self.spec = spec or SEQUENCE_DATASET_REGISTRY["nlp21"]
        self.data_dir = Path(data_dir) if data_dir is not None else DATA_DIR / self.spec.key
        self.assume_yes = assume_yes
        self._train: SequenceSplit | None = None
        self._periodic: SequenceSplit | None = None
        self._final: SequenceSplit | None = None
        self._n_features: int | None = None

    def _ensure_downloaded(self) -> None:
        confirm_and_download(
            self.data_dir,
            source="dryad",
            doi=self.spec.dryad_doi,
            dryad_filename=self.spec.dryad_filename,
            extract_only=self.spec.extract_only,
            size_hint_gb=self.spec.approx_download_size_gb,
            assume_yes=self.assume_yes,
            ready=is_ready,
        )

    def _load_or_build(self, name: str, builder) -> SequenceSplit:
        path = cache_path(self.data_dir, name)
        cached = load_split(path)
        if cached is not None:
            return cached
        split = builder()
        save_split(path, split)
        return split

    def _build_train(self) -> SequenceSplit:
        return load_nlp21_mats(_find_dir(self.data_dir, _SEED), train=True, valid=False, norm=True)

    def _build_periodic(self) -> SequenceSplit:
        # multi_trainer_task_based.py::get_dataset_loaders_nlp_21 test split
        seed_holdout = load_nlp21_mats(
            _find_dir(self.data_dir, _SEED), train=False, valid=True, norm=True
        )
        recal_holdout = load_nlp21_mats(
            _find_dir(self.data_dir, _RECAL), train=False, valid=True, norm=True
        )
        return concat_splits(seed_holdout, recal_holdout)

    def _build_final(self) -> SequenceSplit:
        # eval_utils.py::get_dataset_loader_nlp_21
        no_recal, borders_1 = load_nlp21_mats(
            _find_dir(self.data_dir, _NO_RECAL),
            train=False,
            valid=False,
            norm=True,
            return_borders=True,
        )
        recal, borders_2 = load_nlp21_mats(
            _find_dir(self.data_dir, _RECAL),
            train=False,
            valid=False,
            norm=True,
            return_borders=True,
        )
        merged = merge_by_borders(no_recal, borders_1, recal, borders_2)
        seed_holdout = load_nlp21_mats(
            _find_dir(self.data_dir, _SEED), train=False, valid=True, norm=True
        )
        return concat_splits(seed_holdout, merged)

    def load(self) -> SequenceSession:
        self._ensure_downloaded()
        self._train = self._load_or_build("nlp21_train", self._build_train)
        self._periodic = self._load_or_build("nlp21_periodic", self._build_periodic)
        self._final = self._load_or_build("nlp21_final", self._build_final)
        self._n_features = infer_n_features(
            self._train, self.spec.expected_n_features, self.spec.key
        )
        return self.to_session()

    def train_split(self) -> SequenceSplit:
        if self._train is None:
            self.load()
        assert self._train is not None
        return self._train

    def periodic_eval_split(self) -> SequenceSplit:
        """In-training CER split. Known upstream inconsistency vs final_eval_split.

        Independently implemented. Do not call final_eval_split from here.
        """
        if self._periodic is None:
            self.load()
        assert self._periodic is not None
        return self._periodic

    def final_eval_split(self) -> SequenceSplit:
        """Standalone eval/export split. Known upstream inconsistency vs periodic_eval_split.

        Independently implemented; do not alias periodic_eval_split.
        """
        if self._final is None:
            self.load()
        assert self._final is not None
        return self._final

    def to_session(self) -> SequenceSession:
        assert self._train is not None and self._periodic is not None and self._final is not None
        n_features = infer_n_features(self._train, self.spec.expected_n_features, self.spec.key)
        return SequenceSession(
            session_key=self.spec.key,
            task_key=self.spec.task_key,
            use_smooth=self.spec.use_smooth,
            n_features=n_features,
            num_classes=self.spec.num_classes,
            vocab=self.spec.vocab,
            blank_index=self.spec.blank_index,
            train=self._train,
            periodic_eval=self._periodic,
            final_eval=self._final,
        )


def load_nlp21(
    data_dir: str | Path | None = None,
    assume_yes: bool = False,
) -> SequenceSession:
    return Nlp21Loader(data_dir=data_dir, assume_yes=assume_yes).load()


def _nlp21_sentences_with_borders(
    path: Path, *, train: bool, valid: bool
) -> tuple[list[str], list[int]]:
    from acorn.data.sequence.nlp_mat import cell_row, safe_sentence, to_scalar

    root = Path(path)
    sentences: list[str] = []
    borders: list[int] = []
    last_border = 0
    for file in sorted(root.rglob("*.mat")):
        mat = sio.loadmat(file)
        sents = cell_row(mat["sentences"])
        blocks = cell_row(mat["blocks"])
        block_ids = [to_scalar(b) for b in blocks]
        majority_block = max(block_ids)
        if train:
            idxs = [i for i, b in enumerate(block_ids) if b != majority_block]
        elif valid:
            idxs = [i for i, b in enumerate(block_ids) if b == majority_block]
        else:
            idxs = list(range(len(block_ids)))
        for i in idxs:
            sentences.append(str(safe_sentence(sents[i])))
        borders.append(last_border)
        last_border += len(idxs)
    return sentences, borders


def _merge_sentence_borders(
    data1: list[str],
    borders1: list[int],
    data2: list[str],
    borders2: list[int],
) -> list[str]:
    ends1 = borders1[1:] + [len(data1)]
    ends2 = borders2[1:] + [len(data2)]
    merged: list[str] = []
    for start1, end1, start2, end2 in zip(borders1, ends1, borders2, ends2, strict=True):
        merged.extend(data1[start1:end1])
        merged.extend(data2[start2:end2])
    return merged


def collect_nlp21_final_transcripts(data_dir: Path) -> list[str]:
    root = Path(data_dir)
    no_recal, borders_1 = _nlp21_sentences_with_borders(
        _find_dir(root, _NO_RECAL), train=False, valid=False
    )
    recal, borders_2 = _nlp21_sentences_with_borders(
        _find_dir(root, _RECAL), train=False, valid=False
    )
    merged = _merge_sentence_borders(no_recal, borders_1, recal, borders_2)
    seed_holdout, _b = _nlp21_sentences_with_borders(
        _find_dir(root, _SEED), train=False, valid=True
    )
    return seed_holdout + merged
