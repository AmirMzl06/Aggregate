"""Sequence dataset loaders."""

from acorn.data.sequence.loaders.demo import load_demo
from acorn.data.sequence.loaders.nlp10 import load_nlp10
from acorn.data.sequence.loaders.nlp21 import load_nlp21
from acorn.data.sequence.loaders.speech24 import load_speech24
from acorn.data.sequence.loaders.speech45 import load_speech45

LOAD_SEQUENCE_SESSION = {
    "nlp21": load_nlp21,
    "nlp10": load_nlp10,
    "speech24": load_speech24,
    "speech45": load_speech45,
    "demo": load_demo,
}


def load_sequence_session(key: str, data_dir=None, assume_yes: bool = False):
    if key not in LOAD_SEQUENCE_SESSION:
        raise KeyError(f"Unknown sequence dataset {key!r}. Choices: {list(LOAD_SEQUENCE_SESSION)}")
    return LOAD_SEQUENCE_SESSION[key](data_dir=data_dir, assume_yes=assume_yes)
