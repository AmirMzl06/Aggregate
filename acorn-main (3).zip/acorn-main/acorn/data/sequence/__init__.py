"""Sequence-format data package."""
