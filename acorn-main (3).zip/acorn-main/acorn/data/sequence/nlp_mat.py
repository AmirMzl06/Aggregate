"""Shared helpers for handwriting .mat files (NLP21)."""

from __future__ import annotations

from pathlib import Path
from typing import Literal, overload

import numpy as np
import scipy.io as sio

from acorn.data.sequence.collate import SequenceSplit
from acorn.data.sequence.vocabs import nlp_text_to_ids


def cell_row(arr):
    arr = np.asarray(arr, dtype=object)
    if arr.ndim == 2 and arr.shape[0] == 1:
        return arr[0]
    if arr.ndim == 2 and arr.shape[1] == 1:
        return arr[:, 0]
    return arr


def to_scalar(x):
    x = np.array(x).squeeze()
    return x.item() if x.shape == () else x


def safe_sentence(s):
    if isinstance(s, np.ndarray) and s.size == 1:
        s = s.item()
    if isinstance(s, bytes):
        s = s.decode("utf-8", errors="ignore")
    return s


def block_stats_chan(neural, block_ids, dtype=np.float64):
    stats = {}
    uniq = np.unique(block_ids)
    for b in uniq:
        n_total = 0
        mu = None
        m2 = None
        for i, bb in enumerate(block_ids):
            if bb != b:
                continue
            x = np.asarray(neural[i], dtype=dtype)
            if x.ndim == 1:
                x = x[:, None]
            n_i = x.shape[0]
            mu_i = x.mean(axis=0, dtype=dtype)
            diff = x - mu_i
            m2_i = (diff * diff).sum(axis=0, dtype=dtype)
            if n_total == 0:
                n_total = n_i
                mu = mu_i
                m2 = m2_i
            else:
                delta = mu_i - mu
                n = n_total + n_i
                mu = mu + delta * (n_i / n)
                m2 = m2 + m2_i + (delta * delta) * (n_total * n_i / n)
                n_total = n
        var = m2 / max(n_total, 1)
        var = np.maximum(var, 0.0)
        std = np.sqrt(var, dtype=dtype)
        stats[b] = (mu, std)
    return stats


@overload
def load_nlp21_mats(
    path: Path,
    *,
    train: bool = False,
    valid: bool = False,
    norm: bool = True,
    return_borders: Literal[False] = False,
    eps: float = 0.0,
) -> SequenceSplit: ...
@overload
def load_nlp21_mats(
    path: Path,
    *,
    train: bool = False,
    valid: bool = False,
    norm: bool = True,
    return_borders: Literal[True],
    eps: float = 0.0,
) -> tuple[SequenceSplit, list[int]]: ...
def load_nlp21_mats(
    path: Path,
    *,
    train: bool = False,
    valid: bool = False,
    norm: bool = True,
    return_borders: bool = False,
    eps: float = 0.0,
) -> SequenceSplit | tuple[SequenceSplit, list[int]]:
    """Port of handwriting ``get_input`` (no in-loader gauss)."""
    root = Path(path)
    files_recursive = sorted(root.rglob("*.mat"))
    per_file_block_stats = {}
    if norm:
        for fi, file in enumerate(files_recursive):
            mat = sio.loadmat(file)
            neural = cell_row(mat["tx_feats"])
            blocks = cell_row(mat["blocks"])
            block_ids = np.array([to_scalar(b) for b in blocks])
            per_file_block_stats[fi] = block_stats_chan(neural, block_ids)

    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    borders: list[int] = []
    last_border = 0
    for fi, file in enumerate(files_recursive):
        mat = sio.loadmat(file)
        neural = cell_row(mat["tx_feats"])
        sentences = cell_row(mat["sentences"])
        blocks = cell_row(mat["blocks"])
        block_ids = np.array([to_scalar(b) for b in blocks])
        majority_block = block_ids.max()
        if train:
            idxs = [i for i, b in enumerate(block_ids) if b != majority_block]
        elif valid:
            idxs = [i for i, b in enumerate(block_ids) if b == majority_block]
        else:
            idxs = list(range(len(block_ids)))
        stats_this_file = per_file_block_stats.get(fi, {}) if norm else {}
        n_this = 0
        for i in idxs:
            x = np.asarray(neural[i], dtype=np.float64)
            if x.ndim == 1:
                x = x[:, None]
            if norm:
                mu, std = stats_this_file[block_ids[i]]
                std = np.maximum(std, eps + 1e-6)
                x = (x - mu) / std
            y = nlp_text_to_ids(str(safe_sentence(sentences[i])))
            # Keep empty-ID trials: upstream ctc_collate never filters
            # (charset.text_to_int may return []); CTCLoss(zero_infinity=True) handles them.
            features.append(np.asarray(x, dtype=np.float32))
            labels.append(np.asarray(y, dtype=np.int64))
            n_this += 1
        borders.append(last_border)
        last_border += n_this
    split = SequenceSplit(features=features, labels=labels)
    if return_borders:
        return split, borders
    return split


def merge_by_borders(
    data1: SequenceSplit,
    borders1: list[int],
    data2: SequenceSplit,
    borders2: list[int],
) -> SequenceSplit:
    """Port of ``merge_by_borders``."""
    ends1 = borders1[1:] + [len(data1.features)]
    ends2 = borders2[1:] + [len(data2.features)]
    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    for start1, end1, start2, end2 in zip(borders1, ends1, borders2, ends2, strict=True):
        features.extend(data1.features[start1:end1])
        labels.extend(data1.labels[start1:end1])
        features.extend(data2.features[start2:end2])
        labels.extend(data2.labels[start2:end2])
    return SequenceSplit(features=features, labels=labels)


def concat_splits(*splits: SequenceSplit) -> SequenceSplit:
    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    for split in splits:
        features.extend(split.features)
        labels.extend(split.labels)
    return SequenceSplit(features=features, labels=labels)


def infer_n_features(split: SequenceSplit, expected: int | None, key: str) -> int:
    if not split.features:
        raise ValueError(f"{key}: no trials loaded")
    widths = {int(f.shape[1]) for f in split.features}
    if len(widths) != 1:
        raise ValueError(
            f"{key}: mixed feature widths {sorted(widths)} across {len(split.features)} trials"
        )
    n_features = next(iter(widths))
    if expected is not None and n_features != expected:
        raise ValueError(
            f"{key}: loaded n_features={n_features} does not match expected_n_features={expected}"
        )
    return n_features
