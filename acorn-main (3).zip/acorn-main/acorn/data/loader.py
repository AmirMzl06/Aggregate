"""XDS / Pop dataset loading, EMG preprocessing, and on-disk caches."""

import os
import re
import tempfile
from datetime import datetime
from pathlib import Path

import gdown
import numpy as np

from acorn.data.consent import confirm_download
from acorn.data.registry import (
    loader_dataset_names,
    loader_dataset_urls,
    loader_file_types,
    loader_num_days,
    loader_original_names,
)
from acorn.log import get_logger
from acorn.utils.constants import DATA_DIR as _DATA_DIR_PATH

DATA_DIR = str(_DATA_DIR_PATH)
CACHE_DIR = "./weights_cache/"
logger = get_logger(__name__)

EMG_CLIP_STD_MULT = 6
EMG_PCTL_LOW = 2
EMG_PCTL_HIGH = 90


def emg_preprocessing(
    trial_emg: list[np.ndarray], EMG_names: list[str]
) -> tuple[list[np.ndarray], list[str]]:
    """Clip and percentile-normalize EMG envelopes; keep the 7 shared good channels.

    Percentiles are computed on the concatenated trials *before* clipping (historical
    behavior). Returns ``(trials, good_channel_names)``.
    """

    # First, keep EMG channels that are good across all recorded sessions
    EMG_names_good = [
        "EMG_ECRb",
        "EMG_ECRl",
        "EMG_ECU",
        "EMG_EDCr",
        "EMG_FCR",
        "EMG_FCU",
        "EMG_FDP",
    ]
    idx_emg = [EMG_names.index(x) for x in EMG_names_good]
    for trial, val_trial in enumerate(trial_emg):
        trial_emg[trial] = val_trial[:, idx_emg]

    trial_emg_np = np.concatenate(trial_emg)

    # EMG clipping
    outlier = np.mean(trial_emg_np, axis=0) + EMG_CLIP_STD_MULT * np.std(trial_emg_np, axis=0)
    for i, _ in enumerate(trial_emg):
        for ii in range(len(outlier)):
            trial_emg[i][:, ii] = trial_emg[i][:, ii].clip(max=outlier[ii])

    # EMG normalization
    trial_emg_np_baseline = np.percentile(trial_emg_np, EMG_PCTL_LOW, axis=0)
    trial_emg_np_max = np.percentile(trial_emg_np - trial_emg_np_baseline, EMG_PCTL_HIGH, axis=0)
    for i, val in enumerate(trial_emg):
        trial_emg[i] = (val - trial_emg_np_baseline) / trial_emg_np_max

    return trial_emg, EMG_names_good


class DatasetLoader:
    """Singleton loader for XDS-raw and Pop pickle sessions.

    Registry fields (URLs, day counts, file types) come from ``DATASET_REGISTRY``.
    The first ``DatasetLoader(...)`` call wins; later calls return the same instance.
    Results are cached in memory (``weights_cache``) and under ``cache_dir``.
    """

    dataset_names = loader_dataset_names()
    dataset_original_names = loader_original_names()
    dataset_urls = loader_dataset_urls()
    file_types = loader_file_types()
    num_days = loader_num_days()

    weights_cache: dict[tuple, tuple] = {}
    data_root_dir: str
    cache_dir: str

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        inst = cls._instance
        cls._instance = None
        cls.weights_cache = {}
        if inst is not None:
            inst.__dict__.pop("_initialized", None)

    def __init__(self, data_root_dir: str = DATA_DIR, cache_dir: str = CACHE_DIR):
        data_root_dir = str(Path(data_root_dir).expanduser().resolve())
        cache_dir = str(Path(cache_dir).expanduser().resolve())
        if getattr(self, "_initialized", False):
            if data_root_dir != self.data_root_dir or cache_dir != self.cache_dir:
                raise RuntimeError(
                    f"DatasetLoader already initialized with "
                    f"data_root_dir={self.data_root_dir!r} and cache_dir={self.cache_dir!r}; "
                    f"got data_root_dir={data_root_dir!r} and cache_dir={cache_dir!r}. "
                    f"Call DatasetLoader.reset() before constructing a loader with a "
                    f"different root, or set ACORN_DATA_DIR before importing acorn."
                )
            return

        self.data_root_dir = data_root_dir
        self.cache_dir = cache_dir
        self.assume_yes = False

        if not os.path.exists(self.data_root_dir):
            logger.info("Creating %s directory...", self.data_root_dir)
            os.makedirs(self.data_root_dir)

        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

        self._initialized = True

    def _get_cache_filename(
        self,
        dataset_name,
        day_num,
        trial_start,
        bin_size,
        trial_window_size=None,
        xds_smooth=True,
    ):
        """Generate cache filename from parameters"""
        trial_start_str = trial_start if trial_start else "default"
        bin_size_str = f"{bin_size:.4f}".replace(".", "p")
        window_suffix = (
            f"_w{trial_window_size}"
            if trial_start == "fixed_window" and trial_window_size is not None
            else ""
        )
        smooth_suffix = "" if xds_smooth else "_xdsnosmooth"
        return (
            f"{dataset_name}_{day_num}_{trial_start_str}_{bin_size_str}"
            f"{window_suffix}{smooth_suffix}.npz"
        )

    def _get_cache_path(
        self,
        dataset_name,
        day_num,
        trial_start,
        bin_size,
        trial_window_size=None,
        xds_smooth=True,
    ):
        """Get full path to cache file"""
        filename = self._get_cache_filename(
            dataset_name,
            day_num,
            trial_start,
            bin_size,
            trial_window_size,
            xds_smooth,
        )
        return os.path.join(self.cache_dir, filename)

    @staticmethod
    def window_concatenated_trials(x_list, y_list, trial_window_size):
        """Concatenate trials and split into fixed-size windows (fake trials)."""
        x_cat = np.vstack(x_list)
        y_cat = np.vstack(y_list)
        n_bins = x_cat.shape[0]
        n_windows = n_bins // trial_window_size
        if n_windows == 0:
            raise ValueError(
                f"Not enough bins ({n_bins}) for trial_window_size={trial_window_size}"
            )
        x_windowed = [
            x_cat[i * trial_window_size : (i + 1) * trial_window_size] for i in range(n_windows)
        ]
        y_windowed = [
            y_cat[i * trial_window_size : (i + 1) * trial_window_size] for i in range(n_windows)
        ]
        return x_windowed, y_windowed

    def _load_from_disk_cache(self, cache_path):
        """Load stacked arrays from disk cache. Returns (x, y) or None."""
        if os.path.exists(cache_path):
            with np.load(cache_path) as data:
                return data["x"], data["y"]
        return None

    def _load_trials_from_disk_cache(self, cache_path):
        """Load trial-by-trial data from disk cache. Returns (list_x, list_y) or None."""
        trials_cache_path = cache_path.replace(".npz", "_trials.npz")
        if os.path.exists(trials_cache_path):
            with np.load(trials_cache_path, allow_pickle=True) as data:
                return list(data["x"]), list(data["y"])
        return None

    def _save_to_disk_cache(self, cache_path, x_np, y_np):
        """Save stacked arrays to disk cache."""
        np.savez_compressed(cache_path, x=x_np, y=y_np)

    def _save_trials_to_disk_cache(self, cache_path, x_list, y_list):
        """Save trial-by-trial data to disk cache (as object arrays)."""
        trials_cache_path = cache_path.replace(".npz", "_trials.npz")
        x_obj = np.empty(len(x_list), dtype=object)
        y_obj = np.empty(len(y_list), dtype=object)
        for i, (x, y) in enumerate(zip(x_list, y_list)):
            x_obj[i] = x
            y_obj[i] = y
        np.savez_compressed(trials_cache_path, x=x_obj, y=y_obj)

    def _resolved_assume_yes(self, assume_yes: bool | None) -> bool:
        if assume_yes is not None:
            return assume_yes
        return bool(getattr(self, "assume_yes", False))

    def download_from_drive(self, dataset_name: str, assume_yes: bool | None = None) -> str:
        """Download the dataset archive from Google Drive and return the local path."""
        file_type = self.file_types[dataset_name]
        dest = self.get_dataset_folder(dataset_name)
        confirm_download(
            message=(
                f"About to download several GB from Google Drive into {dest}. "
                "This can take a while and uses local disk."
            ),
            assume_yes=self._resolved_assume_yes(assume_yes),
            declined=f"Download of {dataset_name} declined.",
        )

        url = self.dataset_urls[dataset_name]
        file_id = url.split("/d/")[1].split("/")[0]
        download_url = f"https://drive.google.com/uc?id={file_id}"
        compressed_file_path = os.path.join(tempfile.gettempdir(), f"{dataset_name}.{file_type}")

        logger.info("Downloading %s from %s ...", dataset_name, download_url)
        gdown.download(download_url, compressed_file_path, quiet=False)

        return compressed_file_path

    def extract_compressed_dataset(self, compressed_file_path, dataset_name):
        file_type = self.file_types[dataset_name]
        dataset_dir = self.get_dataset_folder(dataset_name)

        # Step 3: Unzip into dataset_dir
        logger.info("Extracting %s into %s ...", compressed_file_path, dataset_dir)
        if file_type == "zip":
            import zipfile

            with zipfile.ZipFile(compressed_file_path, "r") as zip_ref:
                zip_ref.extractall(dataset_dir)
        elif file_type == "7z":
            import shutil

            import py7zr

            with py7zr.SevenZipFile(compressed_file_path, mode="r") as archive:
                archive.extractall(path=dataset_dir)
            # files will be saved in dataset_dir/original_name/* -> need to move them to dataset_dir/*
            original_name = self.dataset_original_names[dataset_name]
            original_dir = os.path.join(dataset_dir, original_name)
            for f in os.listdir(original_dir):
                shutil.move(os.path.join(original_dir, f), os.path.join(dataset_dir, f))
            shutil.rmtree(original_dir)

        return dataset_dir

    def prepare_dataset(self, dataset_name: str, assume_yes: bool | None = None) -> str:
        """Ensure ``dataset_name`` exists on disk, downloading it if the folder is empty."""
        if dataset_name not in self.dataset_urls:
            raise ValueError(f"Unknown dataset: {dataset_name}")

        dataset_dir = self.get_dataset_folder(dataset_name)
        if not os.path.exists(dataset_dir):
            os.makedirs(dataset_dir)

        if os.listdir(dataset_dir):
            return dataset_dir

        compressed_file_path = self.download_from_drive(dataset_name, assume_yes=assume_yes)

        # Unzip into dataset_dir
        dataset_dir = self.extract_compressed_dataset(compressed_file_path, dataset_name)

        # Remove the zip file to save space (optional)
        os.remove(compressed_file_path)
        logger.info("Finished! Files are in: %s", dataset_dir)
        return dataset_dir

    def get_dataset_folder(self, dataset_name: str) -> str:
        """On-disk directory for ``dataset_name`` under ``data_root_dir``."""
        return os.path.join(self.data_root_dir, dataset_name)

    def get_dataset_day_filename(self, day_num: int, dataset_name: str):
        dataset_folder = self.get_dataset_folder(dataset_name)
        file_list = sorted(
            f
            for f in os.listdir(dataset_folder)
            if not f.endswith(".py") and os.path.isfile(os.path.join(dataset_folder, f))
        )

        if not (0 <= day_num < len(file_list)):
            raise FileNotFoundError(
                f"Missing day file for {dataset_name} day_num={day_num} in "
                f"{dataset_folder}: found {len(file_list)} file(s). "
                "The folder may be incomplete."
            )

        return file_list[day_num]

    @staticmethod
    def parse_session_date(filename: str) -> datetime:
        """Parse YYYYMMDD session date from a dataset day filename."""
        for part in filename.split("_"):
            if re.fullmatch(r"\d{8}", part):
                return datetime.strptime(part, "%Y%m%d")
        raise ValueError(f"No YYYYMMDD date found in filename {filename!r}")

    def get_dataset_day_label(self, day_idx: int, dataset_name: str) -> int:
        """Calendar days since the first session file (Day-0 = 0, matches paper labels)."""
        if "/" in dataset_name:
            dataset_name = dataset_name.split("/")[-1]
        self.prepare_dataset(dataset_name)
        day0_name = self.get_dataset_day_filename(0, dataset_name)
        day_name = self.get_dataset_day_filename(day_idx, dataset_name)
        return (self.parse_session_date(day_name) - self.parse_session_date(day0_name)).days

    def get_dataset_day_file_path(self, day_num: int, dataset_name: str):
        if "/" in dataset_name:
            dataset_name = dataset_name.split("/")[-1]

        self.prepare_dataset(dataset_name)

        dataset_folder = self.get_dataset_folder(dataset_name)

        fname = self.get_dataset_day_filename(day_num, dataset_name)
        return os.path.join(dataset_folder, fname)

    def get_raw_dataset_xy(
        self,
        dayk_id,
        dataset_name,
        trial_start="gocue_time",
        bin_size=0.05,
        xds_smooth=True,
    ):
        """Returns lists of per-trial arrays (x_list, y_list)."""
        from xds import lab_data

        smooth_size = 0.1  # As mentioned above, we use Gaussian kernels (S.D. = 100 ms) to smooth the binned spikes

        # ============================================= Load day-k data ==================================================================#
        dayk_path = self.get_dataset_day_file_path(day_num=dayk_id, dataset_name=dataset_name)
        dayk_base_path, dayk_file_name = os.path.split(dayk_path)

        dayk_data = lab_data(dayk_base_path, dayk_file_name)
        dayk_data.update_bin_data(bin_size)
        if xds_smooth:
            dayk_data.smooth_binned_spikes(bin_size, "gaussian", smooth_size)
        dayk_unit_names = dayk_data.unit_names

        # -------- Extract smoothed spike counts in trials without temporal alignment --------#
        dayk_spike = dayk_data.get_trials_data_spike_counts("R", trial_start, 0.0, "end_time", 0)
        # -------- Extract EMG envelops in trials without temporal alignment --------#
        if "Jango" in dataset_name:
            dayk_label, _ = emg_preprocessing(
                dayk_data.get_trials_data_EMG("R", trial_start, 0.0, "end_time", 0),
                dayk_data.EMG_names,
            )
        else:
            dayk_label_raw = dayk_data.get_trials_data_cursor("R", trial_start, 0.0, "end_time", 0)
            dayk_label = [np.concatenate(arrs, axis=1) for arrs in zip(*dayk_label_raw)]
        # ============================================= Pre-processing ==================================================================#
        dayk_spike = self.spike_zero_padding(dataset_name, dayk_unit_names, dayk_spike)

        return dayk_spike, dayk_label  # lists of arrays

    def load_pop_pg(self, day_num: int):
        """Returns lists of per-trial arrays (x_list, y_list)."""
        import pickle

        path = self.get_dataset_day_file_path(day_num, "Pop_PG_2021")
        with open(path, "rb") as fp:
            spike_counts = pickle.load(fp)  # list of N arrays [T_i, 96]
            EMG = pickle.load(fp)  # list of N arrays [T_i, 11]
        return spike_counts, EMG

    def load_dataset_day(
        self,
        day_num: int,
        dataset_name: str,
        cache: bool = True,
        trial_start=None,
        bin_size=0.05,
        stack: bool = True,
        trial_window_size: int | None = None,
        xds_smooth: bool = True,
    ) -> tuple[np.ndarray, np.ndarray] | tuple[list[np.ndarray], list[np.ndarray]]:
        """
        Load a single day's data.

        Args:
            stack: If True (default), returns stacked (x, y) arrays of shape [T_total, D].
                   If False, returns (x_list, y_list) where each element is one trial.
            trial_window_size: Number of time bins per window when trial_start='fixed_window'.
                         Trials are extracted from start_time, concatenated, then split into
                         non-overlapping windows of this size."""
        if trial_start is None:
            trial_start = "gocue_time"

        if trial_start == "fixed_window" and trial_window_size is None:
            raise ValueError("trial_window_size must be set when trial_start='fixed_window'")

        load_trial_start = "start_time" if trial_start == "fixed_window" else trial_start

        cache_key = (
            dataset_name,
            day_num,
            trial_start,
            bin_size,
            stack,
            trial_window_size,
            xds_smooth,
        )

        # Check in-memory cache first
        if cache and cache_key in self.weights_cache:
            return self.weights_cache[cache_key]

        cache_path = self._get_cache_path(
            dataset_name,
            day_num,
            trial_start,
            bin_size,
            trial_window_size,
            xds_smooth,
        )

        if cache:
            if stack:
                cached = self._load_from_disk_cache(cache_path)
            else:
                cached = self._load_trials_from_disk_cache(cache_path)
            if cached is not None:
                self.weights_cache[cache_key] = cached
                return cached

        self.prepare_dataset(dataset_name)

        # Load as trial lists
        if "raw" in dataset_name:
            x_list, y_list = self.get_raw_dataset_xy(
                day_num,
                dataset_name,
                load_trial_start,
                bin_size,
                xds_smooth=xds_smooth,
            )
        elif dataset_name == "Pop_PG_2021":
            x_list, y_list = self.load_pop_pg(day_num)
        else:
            path = self.get_dataset_day_file_path(day_num, dataset_name)
            with np.load(path) as data:
                x_np, y_np = data["x"], data["y"]
            x_list, y_list = [x_np], [y_np]

        if trial_start == "fixed_window":
            x_list, y_list = self.window_concatenated_trials(x_list, y_list, trial_window_size)

        if "raw" not in dataset_name and dataset_name != "Pop_PG_2021":
            # npz datasets: optionally window, then return
            if cache:
                if stack:
                    self._save_to_disk_cache(cache_path, np.vstack(x_list), np.vstack(y_list))
                else:
                    self._save_trials_to_disk_cache(cache_path, x_list, y_list)
                result = (np.vstack(x_list), np.vstack(y_list)) if stack else (x_list, y_list)
                self.weights_cache[cache_key] = result
                other_key = (
                    dataset_name,
                    day_num,
                    trial_start,
                    bin_size,
                    not stack,
                    trial_window_size,
                    xds_smooth,
                )
                other_result = (x_list, y_list) if stack else (np.vstack(x_list), np.vstack(y_list))
                self.weights_cache[other_key] = other_result
            return (np.vstack(x_list), np.vstack(y_list)) if stack else (x_list, y_list)

        # For raw/Pop datasets we have genuine trial lists
        if cache:
            self._save_trials_to_disk_cache(cache_path, x_list, y_list)
            # Also save stacked version
            self._save_to_disk_cache(cache_path, np.vstack(x_list), np.vstack(y_list))

        if stack:
            result = (np.vstack(x_list), np.vstack(y_list))
        else:
            result = (x_list, y_list)

        if cache:
            self.weights_cache[cache_key] = result  # Cache the other form too
            other_key = (
                dataset_name,
                day_num,
                trial_start,
                bin_size,
                not stack,
                trial_window_size,
                xds_smooth,
            )
            other_result = (x_list, y_list) if stack else (np.vstack(x_list), np.vstack(y_list))
            self.weights_cache[other_key] = other_result

        return result

    def get_dataset_num_days(self, dataset_name: str):
        return self.num_days[dataset_name]

    def get_all_unit_names(self, dataset_name: str) -> list[str]:
        """Padded electrode names for ``dataset_name`` (see ``data.unit_names``)."""
        from acorn.data.unit_names import get_all_unit_names as _unit_names

        return _unit_names(dataset_name)

    def spike_zero_padding(self, dataset_name, spike_unit_names, spike):
        max_unit_names = self.get_all_unit_names(dataset_name)
        N_unit = len(max_unit_names)

        idx = [list(max_unit_names).index(e) for e in spike_unit_names]
        spike_ = [np.zeros((s.shape[0], N_unit)) for s in spike]
        for k in range(len(spike)):
            spike_[k][:, idx] = spike[k]
        return spike_
