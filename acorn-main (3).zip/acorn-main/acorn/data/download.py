"""Dryad download with size warning, y/n prompt, and selective extract.

Must not be imported by or import from ``acorn.data.loader``.

File listings are anonymous. Binary downloads use OAuth client credentials
(``DRYAD_CLIENT_ID`` + ``DRYAD_CLIENT_SECRET``). See docs/data.md.
"""

from __future__ import annotations

import hashlib
import json
import os
import tarfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from collections.abc import Callable
from pathlib import Path
from typing import Literal

from acorn.data.consent import ASSUME_YES_ENV, DownloadDeclined, confirm_download

DRYAD_ROOT = "https://datadryad.org"
DRYAD_CLIENT_ID_ENV = "DRYAD_CLIENT_ID"
DRYAD_CLIENT_SECRET_ENV = "DRYAD_CLIENT_SECRET"
_USER_AGENT = "acorn-dryad/1.0 (+https://github.com/alijabbari00/acorn)"
_DIGEST_CONSTRUCTORS = {
    "md5": hashlib.md5,
    "sha-1": hashlib.sha1,
    "sha1": hashlib.sha1,
    "sha-256": hashlib.sha256,
    "sha256": hashlib.sha256,
    "sha-384": hashlib.sha384,
    "sha-512": hashlib.sha512,
}

__all__ = [
    "ASSUME_YES_ENV",
    "DownloadDeclined",
    "DryadDownloadError",
    "confirm_and_download",
]


class DryadDownloadError(RuntimeError):
    """Dryad API/download failed (including missing client credentials)."""


def _prompt_yes(size_hint_gb: float, doi: str, assume_yes: bool) -> None:
    confirm_download(
        message=(
            f"About to download ~{size_hint_gb:.2f} GB from Dryad DOI {doi}. "
            "This can take a while and uses local disk."
        ),
        assume_yes=assume_yes,
        declined=f"Download of {doi} declined.",
    )


def _urlified_doi(doi: str) -> str:
    return doi.replace("/", "%2F")


def _cred_hint(doi: str, dest_dir: Path, filename: str | None = None) -> str:
    file_part = f"{filename} " if filename else "the archive "
    return (
        f"Dryad binary download needs {DRYAD_CLIENT_ID_ENV} and {DRYAD_CLIENT_SECRET_ENV}. "
        f"How to create an API account, set those variables, or place files by hand: "
        f"docs/data.md (Dryad section). "
        f"Needed for {file_part}of https://datadryad.org/dataset/doi:{doi} into {dest_dir}."
    )


def _manual_hint(doi: str, dest_dir: Path, filename: str | None = None) -> str:
    return _cred_hint(doi, dest_dir, filename)


def _request_json(url: str) -> dict:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": _USER_AGENT, "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.loads(response.read().decode())


def _oauth_token() -> str:
    client_id = os.environ.get(DRYAD_CLIENT_ID_ENV, "").strip()
    client_secret = os.environ.get(DRYAD_CLIENT_SECRET_ENV, "").strip()
    if not client_id or not client_secret:
        raise DryadDownloadError(
            f"Set {DRYAD_CLIENT_ID_ENV} and {DRYAD_CLIENT_SECRET_ENV}. See docs/data.md."
        )
    body = urllib.parse.urlencode(
        {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }
    ).encode()
    req = urllib.request.Request(
        f"{DRYAD_ROOT}/oauth/token",
        data=body,
        headers={
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as response:
        payload = json.loads(response.read().decode())
    token = payload.get("access_token")
    if not token:
        raise DryadDownloadError("Dryad OAuth response had no access_token.")
    return str(token)


def _get_json(url: str, doi: str, dest_dir: Path) -> dict:
    try:
        return _request_json(url)
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403}:
            raise DryadDownloadError(_cred_hint(doi, dest_dir)) from exc
        raise DryadDownloadError(f"Dryad request failed ({exc.code}): {url}") from exc


class _DropAuthOnForeignRedirect(urllib.request.HTTPRedirectHandler):
    """Dryad 302s file bytes to a signed S3 URL. Forwarding Bearer there is HTTP 400."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is None:
            return None
        if urllib.parse.urlparse(req.full_url).netloc == urllib.parse.urlparse(new.full_url).netloc:
            return new
        filtered = {k: v for k, v in new.header_items() if k.lower() != "authorization"}
        return urllib.request.Request(
            new.full_url,
            data=new.data,
            headers=filtered,
            origin_req_host=new.origin_req_host,
            unverifiable=True,
            method=new.get_method(),
        )


def _download_to(url: str, dest: Path, *, token: str) -> None:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": _USER_AGENT,
            "Accept": "*/*",
            "Authorization": f"Bearer {token}",
        },
    )
    dest.parent.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(_DropAuthOnForeignRedirect)
    with opener.open(req, timeout=600) as response, dest.open("wb") as fh:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            fh.write(chunk)


def _hash_file(path: Path, digest_type: str) -> str:
    ctor = _DIGEST_CONSTRUCTORS.get(digest_type.lower())
    if ctor is None:
        raise DryadDownloadError(f"Unsupported Dryad digestType {digest_type!r} for {path.name}.")
    hasher = ctor()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


def _verify_dryad_bytes(path: Path, file_info: dict) -> None:
    """Check size and digest from the Dryad file listing. Skip if no digest."""
    expected_size = file_info.get("size")
    if expected_size is not None and path.stat().st_size != int(expected_size):
        actual_size = path.stat().st_size
        path.unlink(missing_ok=True)
        raise DryadDownloadError(
            f"{path.name}: size {actual_size} != Dryad listing size {expected_size}."
        )
    expected = str(file_info.get("digest") or "").strip()
    digest_type = str(file_info.get("digestType") or "").strip()
    if not expected:
        return
    if not digest_type:
        path.unlink(missing_ok=True)
        raise DryadDownloadError(f"{path.name}: Dryad listed a digest but no digestType.")
    digest = _hash_file(path, digest_type)
    if digest.lower() != expected.lower():
        path.unlink(missing_ok=True)
        raise DryadDownloadError(
            f"{path.name}: {digest_type} mismatch (got {digest}, Dryad listed {expected})."
        )


def _matches_prefix(name: str, prefixes: tuple[str, ...]) -> bool:
    name = name.replace("\\", "/").lstrip("./")
    candidates = [name]
    if "/" in name:
        candidates.append(name.split("/", 1)[1])
    return any(c.startswith(p) for c in candidates for p in prefixes)


def _extract_zip(archive: Path, dest_dir: Path, extract_only: tuple[str, ...] | None) -> None:
    with zipfile.ZipFile(archive, "r") as zf:
        members = zf.namelist()
        if extract_only:
            members = [m for m in members if _matches_prefix(m, extract_only)]
        zf.extractall(dest_dir, members=members)


def _extract_tar(archive: Path, dest_dir: Path, extract_only: tuple[str, ...] | None) -> None:
    with tarfile.open(archive, "r:*") as tf:
        members = tf.getmembers()
        if extract_only:
            members = [m for m in members if _matches_prefix(m.name, extract_only)]
        try:
            tf.extractall(dest_dir, members=members, filter="data")
        except TypeError:
            tf.extractall(dest_dir, members=members)


def _extract(archive: Path, dest_dir: Path, extract_only: tuple[str, ...] | None) -> None:
    name = archive.name.lower()
    if name.endswith(".zip"):
        _extract_zip(archive, dest_dir, extract_only)
        return
    if name.endswith((".tar.gz", ".tgz", ".tar")):
        _extract_tar(archive, dest_dir, extract_only)
        return
    dest = dest_dir / archive.name
    if dest.resolve() != archive.resolve():
        dest.write_bytes(archive.read_bytes())


def confirm_and_download(
    dest_dir: Path,
    *,
    source: Literal["dryad"],
    doi: str,
    ready: Callable[[Path], bool],
    dryad_filename: str | None = None,
    extract_only: tuple[str, ...] | None = None,
    size_hint_gb: float,
    assume_yes: bool = False,
) -> None:
    if source != "dryad":
        raise ValueError(f"Unsupported download source {source!r}")
    dest_dir = Path(dest_dir)
    if ready(dest_dir):
        return
    dest_dir.mkdir(parents=True, exist_ok=True)
    _prompt_yes(size_hint_gb, doi, assume_yes)
    token = _oauth_token()

    versions_url = f"{DRYAD_ROOT}/api/v2/datasets/doi:{_urlified_doi(doi)}/versions"
    versions_info = _get_json(versions_url, doi, dest_dir)
    files_url_path = versions_info["_embedded"]["stash:versions"][-1]["_links"]["stash:files"][
        "href"
    ]
    files_info = _get_json(f"{DRYAD_ROOT}{files_url_path}", doi, dest_dir)
    file_infos = files_info["_embedded"]["stash:files"]

    downloaded = 0
    for file_info in file_infos:
        filename = file_info["path"]
        if filename == "README.md":
            continue
        if dryad_filename is not None and filename != dryad_filename:
            continue
        download_path = file_info["_links"]["stash:download"]["href"]
        download_url = f"{DRYAD_ROOT}{download_path}"
        download_to = dest_dir / filename
        try:
            _download_to(download_url, download_to, token=token)
        except urllib.error.HTTPError as exc:
            if exc.code in {401, 403}:
                raise DryadDownloadError(_cred_hint(doi, dest_dir, filename)) from exc
            raise DryadDownloadError(
                f"Failed to download {filename} ({exc.code}) from {doi}"
            ) from exc
        _verify_dryad_bytes(download_to, file_info)
        _extract(download_to, dest_dir, extract_only)
        name_l = download_to.name.lower()
        if name_l.endswith((".zip", ".tar.gz", ".tgz", ".tar")) and download_to.is_file():
            download_to.unlink()
        downloaded += 1
        if dryad_filename is not None:
            break
    if downloaded == 0:
        wanted = dryad_filename or "any archive"
        raise DryadDownloadError(f"No Dryad file matched {wanted!r} for DOI {doi}.")
