"""Shared y/N download consent so Drive and Dryad cannot drift.

Must not import ``acorn.data.loader`` or ``acorn.data.download``.
"""

from __future__ import annotations

import os

ASSUME_YES_ENV = "ACORN_DOWNLOAD_YES"
_TRUTHY = {"1", "true", "yes"}


class DownloadDeclined(RuntimeError):
    """User declined a dataset download prompt."""


def env_assume_yes() -> bool:
    return os.environ.get(ASSUME_YES_ENV, "").strip().lower() in _TRUTHY


def confirm_download(*, message: str, assume_yes: bool = False, declined: str) -> None:
    print(message)
    if assume_yes or env_assume_yes():
        return
    answer = input("Proceed? [y/N] ").strip().lower()
    if answer not in {"y", "yes"}:
        raise DownloadDeclined(declined)
