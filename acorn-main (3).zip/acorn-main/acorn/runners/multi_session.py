"""Two-phase multi-dataset runner: CEBRA encoder, then per-session embedding decoders."""

from __future__ import annotations

import os

import numpy as np
import torch

from acorn.data.loader import DatasetLoader
from acorn.data.registry import DATASET_REGISTRY, DATASETS, DatasetSpec, dataset_loading_flags
from acorn.data.splits import load_day_split
from acorn.eval.decoder_probe import evaluate_embedding_decoders
from acorn.eval.plot_config import figure2_dayk_index
from acorn.eval.plot_export import export_plot_data
from acorn.log import get_logger
from acorn.models.registry import DEFAULT_RECIPE, get_recipe
from acorn.train.config import AdvConfig, TrainConfig, set_seed
from acorn.train.result import TrainResult
from acorn.utils.constants import DATA_DIR
from acorn.utils.device import activate_torch_device, resolve_device

TRAIN_DAY = 0
_SKIP_PLOT_GROUPS = frozenset({"perich", "hippo"})
logger = get_logger(__name__)


def skip_plot_export(spec: DatasetSpec) -> bool:
    """Perich and hippocampus sessions do not use XDS trial-dir plot export."""
    return spec.dataset_group in _SKIP_PLOT_GROUPS


def _as_float_tensor(value) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        return value.float()
    return torch.from_numpy(np.asarray(value)).float()


def _load_group_arrays(spec: DatasetSpec, assume_yes: bool = False, zscore: bool = True) -> dict:
    if spec.dataset_group == "perich":
        from acorn.data.groups.perich.load import load_perich_session

        return load_perich_session(spec, assume_yes=assume_yes, zscore=zscore)
    if spec.dataset_group == "hippo":
        from acorn.data.groups.hippo.load import load_hippo_session

        return load_hippo_session(spec, assume_yes=assume_yes, zscore=zscore)
    raise ValueError(f"No group loader for dataset_group={spec.dataset_group!r}")


def build_session_bundles(
    loader: DatasetLoader,
    dataset_keys: list[str],
    assume_yes: bool = False,
    full_session: bool = False,
    zscore: bool = True,
) -> dict:
    bundles = {}
    for key in dataset_keys:
        dataset_name = DATASETS[key]
        spec = DATASET_REGISTRY[key]
        use_smooth, xds_smooth = dataset_loading_flags(dataset_name)
        extra = {}
        if spec.dataset_group == "macaque":
            train_x, test_x, train_y, test_y = load_day_split(
                loader,
                dataset_name,
                TRAIN_DAY,
                xds_smooth=xds_smooth,
                zscore=zscore,
                assume_yes=assume_yes,
            )
            num_days = loader.get_dataset_num_days(dataset_name)
        else:
            loaded = _load_group_arrays(spec, assume_yes=assume_yes, zscore=zscore)
            if spec.dataset_group == "hippo" and full_session:
                from acorn.data.groups.hippo.load import hippo_all_from_full

                loaded = hippo_all_from_full(loaded["full_x"], loaded["full_y"])
            train_x = _as_float_tensor(loaded["train_x"])
            test_x = _as_float_tensor(loaded["test_x"])
            train_y = _as_float_tensor(loaded["train_y"])
            test_y = _as_float_tensor(loaded["test_y"])
            num_days = 1
            if "full_x" in loaded:
                extra["full_x"] = _as_float_tensor(loaded["full_x"])
                extra["full_y"] = _as_float_tensor(loaded["full_y"])
        n_neurons = int(train_x.shape[1])
        if spec.expected_n_neurons is not None and n_neurons != spec.expected_n_neurons:
            raise ValueError(
                f"{key}: loaded n_neurons={n_neurons} does not match "
                f"DatasetSpec.expected_n_neurons={spec.expected_n_neurons}"
            )
        bundles[key] = {
            "dataset_key": key,
            "dataset_name": dataset_name,
            "dataset_group": spec.dataset_group,
            "use_smooth": use_smooth,
            "xds_smooth": xds_smooth,
            "n_neurons": n_neurons,
            "num_days": num_days,
            "dayk_idx": figure2_dayk_index(key, num_days),
            "train_x": train_x,
            "train_y": train_y,
            "test_x": test_x,
            "test_y": test_y,
            "n_labels": train_y.shape[1],
            "zscore": zscore,
            **extra,
        }
    return bundles


def train_model(config: TrainConfig | dict) -> TrainResult:
    """Run the full multi-session pipeline.

    Accepts a :class:`TrainConfig` or the legacy args ``dict`` for compatibility.
    Returns the results as in-memory artifacts;
    """
    if isinstance(config, TrainConfig):
        args = config.to_legacy_dict()
    else:
        args = dict(config)

    set_seed(int(args.get("seed", 42)))
    policy = args.get("device", "auto")
    device = resolve_device(policy)
    activate_torch_device(device)
    dataset_keys = args["dataset_keys"]
    window_size = args.get("window", 256)

    loader = DatasetLoader(data_root_dir=str(DATA_DIR))
    assume_yes = bool(args.get("assume_yes", False))
    loader.assume_yes = assume_yes
    zscore = bool(args.get("zscore", True))
    bundles = build_session_bundles(
        loader,
        dataset_keys,
        assume_yes=assume_yes,
        full_session=bool(args.get("full_session", False)),
        zscore=zscore,
    )

    recipe_name = args.get("recipe", DEFAULT_RECIPE)
    recipe_spec = get_recipe(recipe_name)
    model = recipe_spec.build_multi(
        ceb_hidden=args.get("ceb_hidden", 256),
        ceb_out=args.get("ceb_out", 64),
    )

    for key in dataset_keys:
        bundle = bundles[key]
        model.add_session(
            key, bundle["n_neurons"], bundle["n_labels"], use_smooth=bundle["use_smooth"]
        )

    model.to(device)

    adv_on = args.get("adv", True)
    amp_s = "bfloat16" if device.type == "cuda" else "off"
    logger.info("Multi-dataset: %s", ", ".join(dataset_keys))
    logger.info("Device       : %s", device)
    logger.info("Data dir     : %s", DATA_DIR)
    logger.info("Recipe       : %s (%s)", recipe_spec.display_name, recipe_name)
    logger.info("Encoder      : CEBRA time_delta contrastive")
    logger.info("Decoder      : per-session decoder on frozen embeddings")
    logger.info(
        "nBatch       : %s enc  /  %s dec",
        args["nBatch"],
        args.get("n_decoder_batches", args["nBatch"]),
    )
    logger.info("GRU mode     : windowed (%s bins)", window_size)
    logger.info(
        "batchSize    : %s  |  time_offset: %s",
        args.get("batchSize", 256),
        args.get("time_offset", 4),
    )
    logger.info("enc_lr       : %s", args.get("enc_lr", 3e-5))
    if adv_on:
        style = args.get("adv_style", "bin")
        alpha = args.get("adv_alpha")
        alpha_s = f"{alpha}" if alpha is not None else "default"
        eps_mode = args.get("adv_eps_mode", "fixed")
        eps_s = (
            "min_dist_half"
            if eps_mode == "min_dist_half"
            else f"{args.get('adv_eps', AdvConfig().eps)}"
        )
        logger.info(
            "Adv          : l2 %s eps=%s alpha=%s  |  AMP: %s", style, eps_s, alpha_s, amp_s
        )
    else:
        logger.info("Adv          : off  |  AMP: %s", amp_s)
    logger.info("Total params : %s", f"{sum(p.numel() for p in model.parameters()):,}")

    trainer = recipe_spec.trainer_cls(model, bundles, device, args)
    enc_val_metrics = trainer.run()
    if enc_val_metrics.get("encoder_val_checkpoint"):
        logger.info(
            "Encoder val checkpoint: step=%s, val_loss=%.4f",
            enc_val_metrics["encoder_best_step"],
            enc_val_metrics["encoder_best_val_loss"],
        )
    else:
        logger.info("Encoder val checkpoint: off")
    model.eval()

    logger.info("%s Evaluation %s", "=" * 3, "=" * 3)
    per_dataset = evaluate_embedding_decoders(
        model,
        loader,
        bundles,
        device,
        n_decoder_steps=args.get("n_decoder_batches", args["nBatch"]),
        seed=args.get("seed", 42),
        decoder_val_checkpoint=args.get("decoder_val_checkpoint", True),
        decoder_cls=recipe_spec.decoder_cls,
        decoder_kwargs=recipe_spec.decoder_kwargs,
        ceb_out=args.get("ceb_out", 64),
        window_size=window_size,
        decoder_adv=args.get("decoder_adv", "off"),
        mlp_decoder=bool(args.get("mlp_decoder", False)),
    )
    decoders = {key: model.session_decoder(key) for key in dataset_keys}

    plots: dict = {}
    skip_plots = os.environ.get("SKIP_PLOTS", "").strip() in ("1", "true", "yes")
    if not skip_plots:
        for key, bundle in bundles.items():
            spec = DATASET_REGISTRY[key]
            if skip_plot_export(spec):
                continue
            plots[key] = export_plot_data(
                model.session_encoder(key),
                model.session_decoder(key),
                loader,
                key,
                bundle["dataset_name"],
                bundle["dayk_idx"],
                device,
                xds_smooth=bundle["xds_smooth"],
                train_day=TRAIN_DAY,
                window_size=window_size,
                zscore=bool(bundle.get("zscore", True)),
            )
            logger.info("Prepared plot data for %s", key)
    else:
        logger.info("Skipping plot export (SKIP_PLOTS=1)")

    holdout_scores = [m["r2_holdout"] for m in per_dataset.values()]
    metrics = {
        "mode": "multi",
        "recipe": recipe_name,
        "datasets": dataset_keys,
        "seed": args.get("seed", 42),
        "nBatch": args["nBatch"],
        "n_decoder_batches": args.get("n_decoder_batches", args["nBatch"]),
        "batchSize": args.get("batchSize", 256),
        "offset": args["offset"],
        "window": window_size,
        "adv": adv_on,
        "adv_norm": args.get("adv_norm") if adv_on else None,
        "adv_eps": args.get("adv_eps")
        if adv_on and args.get("adv_eps_mode", "fixed") == "fixed"
        else None,
        "adv_eps_mode": args.get("adv_eps_mode", "fixed") if adv_on else None,
        "session_adv_eps": enc_val_metrics.get("session_adv_eps") if adv_on else None,
        "adv_style": args.get("adv_style", "bin") if adv_on else None,
        "adv_alpha": args.get("adv_alpha") if adv_on else None,
        "enc_lr": args.get("enc_lr", 3e-5),
        "amp": "bfloat16" if device.type == "cuda" else "off",
        "device": policy,
        "resolved_device": str(device),
        "time_offset": args.get("time_offset", 4),
        "encoder_val_checkpoint": args.get("encoder_val_checkpoint", True),
        "decoder_val_checkpoint": args.get("decoder_val_checkpoint", True),
        "encoder_best_step": enc_val_metrics.get("encoder_best_step"),
        "encoder_best_val_loss": enc_val_metrics.get("encoder_best_val_loss"),
        "per_dataset": per_dataset,
        "r2_mean_holdout": float(np.mean(holdout_scores)) if holdout_scores else float("nan"),
        "r2_mean_overall_all_days": float(
            np.mean([m.get("r2_overall_all_days", float("nan")) for m in per_dataset.values()])
        ),
    }
    logger.info("Mean holdout R^2 across datasets: %.3f", metrics["r2_mean_holdout"])
    logger.info("Mean overall R^2 (all days)      : %.3f", metrics["r2_mean_overall_all_days"])
    history = list(enc_val_metrics.get("history") or [])
    return TrainResult(
        model=model,
        decoders=decoders,
        metrics=metrics,
        history=history,
        plots=plots,
    )
