"""Neutral train_model dispatcher. Family runner modules never import this
file or each other; they self-register here by config type via
functools.singledispatch, mirroring the same deferred-import,
try/except-guarded self-registration pattern acorn.models.registry
already uses for recipes.
"""

from __future__ import annotations

from functools import singledispatch
from typing import Any

from acorn.log import get_logger
from acorn.train.result import TrainResult

logger = get_logger(__name__)


@singledispatch
def train_model(config: Any) -> TrainResult:
    """Train an Acorn model from a config object.

    Dispatches on the config class: :class:`~acorn.train.config.TrainConfig`
    (and ``dict``) run the time-bin encoder-then-decoder path;
    :class:`~acorn.train.sequence.config.SequenceTrainConfig` runs joint
    CTC + InfoNCE. Family runners never import each other.

    Parameters
    ----------
    config : TrainConfig or SequenceTrainConfig or dict
        Training hyperparameters. A plain ``dict`` is treated as time-bin
        ``TrainConfig`` kwargs.

    Returns
    -------
    TrainResult
        In-memory model, metrics, history, and optional plot/export
        payloads. Core training does not write a run directory.

    Raises
    ------
    TypeError
        If ``config`` is not a registered type.
    """
    registered = [c.__name__ for c in train_model.registry if c is not object]
    raise TypeError(f"Unrecognized config type {type(config)!r}. Registered: {registered}")


def _register_builtin_runners() -> None:
    try:
        from acorn.runners.multi_session import train_model as _run_time_bin_aligned
        from acorn.train.config import TrainConfig

        train_model.register(TrainConfig, _run_time_bin_aligned)
        train_model.register(dict, _run_time_bin_aligned)
    except ModuleNotFoundError as exc:
        logger.debug("[runners] skipped time_bin_aligned: %s", exc)

    try:
        from acorn.runners.sequence import train_sequence_model
        from acorn.train.sequence.config import SequenceTrainConfig

        train_model.register(SequenceTrainConfig, train_sequence_model)
    except ModuleNotFoundError as exc:
        logger.debug("[runners] skipped sequence: %s", exc)


_register_builtin_runners()
