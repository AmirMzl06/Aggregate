"""Sequence-format runner: load sessions, train jointly, eval CER, export logits."""

from __future__ import annotations

import numpy as np

from acorn.data.sequence.loaders import load_sequence_session
from acorn.eval.sequence.ctc_probe import evaluate_sequence_sessions
from acorn.eval.sequence.export import export_all_sessions
from acorn.log import get_logger
from acorn.models.registry import get_sequence_recipe
from acorn.train.config import set_seed
from acorn.train.result import TrainResult
from acorn.train.sequence.config import SequenceTrainConfig
from acorn.utils.constants import DATA_DIR
from acorn.utils.device import activate_torch_device, resolve_device

logger = get_logger(__name__)


def train_sequence_model(config: SequenceTrainConfig) -> TrainResult:
    set_seed(config.seed)
    device = resolve_device(config.device)
    activate_torch_device(device)

    sessions = {}
    for key in config.dataset_keys:
        sessions[key] = load_sequence_session(key, assume_yes=config.assume_yes)

    spec = get_sequence_recipe(config.recipe)
    model = spec.build_multi(
        ceb_hidden=config.ceb_hidden,
        ceb_out=config.ceb_out,
        kernel=config.kernel,
        stride=config.stride,
        hidden=config.hidden,
        layers=config.layers,
        dropout=config.dropout,
        bidir=config.bidir,
    )
    for key in config.dataset_keys:
        session = sessions[key]
        model.add_session(
            session.session_key,
            session.n_features,
            session.task_key,
            use_smooth=session.use_smooth,
        )
        model.add_task_head(session.task_key, session.num_classes)

    model.to(device)
    logger.info("Sequence datasets: %s", ", ".join(config.dataset_keys))
    logger.info("Device           : %s", device)
    logger.info("Data dir         : %s", DATA_DIR)
    logger.info("Recipe           : %s (%s)", spec.display_name, config.recipe)
    logger.info("nBatch           : %s  batchSize=%s", config.n_batch, config.batch_size)
    logger.info("enc_lr           : %s", config.enc_lr)
    logger.info("Total params     : %s", f"{sum(p.numel() for p in model.parameters()):,}")

    trainer = spec.trainer_cls(model, sessions, device, config)
    train_metrics = trainer.run()
    model.eval()

    per_dataset = evaluate_sequence_sessions(
        model, sessions, device, batch_size=config.batch_size, use_final=True
    )
    export_payload = export_all_sessions(model, sessions, device, batch_size=config.batch_size)

    cers = [m["cer"] for m in per_dataset.values()]
    metrics = {
        "mode": "sequence",
        "recipe": config.recipe,
        "datasets": list(config.dataset_keys),
        "seed": config.seed,
        "nBatch": config.n_batch,
        "batchSize": config.batch_size,
        "enc_lr": config.enc_lr,
        "amp": "bfloat16" if device.type == "cuda" else "off",
        "device": config.device,
        "resolved_device": str(device),
        "adv": config.adv.enabled,
        "adv_eps": config.adv.eps if config.adv.enabled else None,
        "per_dataset": per_dataset,
        "cer_mean": float(np.mean(cers)) if cers else float("nan"),
        "best_cer": train_metrics.get("best_cer"),
    }
    history = list(train_metrics.get("history") or [])
    return TrainResult(
        model=model,
        decoders={},
        metrics=metrics,
        history=history,
        plots={"export": export_payload},
    )
