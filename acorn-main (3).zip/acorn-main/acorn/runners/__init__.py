"""High-level experiment runners that wire data, models, train, and eval."""

from acorn.runners.dispatch import train_model
from acorn.runners.multi_session import build_session_bundles

__all__ = ["build_session_bundles", "train_model"]
