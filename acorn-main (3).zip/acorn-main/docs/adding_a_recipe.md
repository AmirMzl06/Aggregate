# Adding a recipe

Recipes are registered encoder, decoder, and trainer bundles. The how-to is
[Add a recipe](guides/add-a-recipe.md).

`offset36_cebra` is the sklearn `CEBRA.fit` recipe. It trains **N=1** and
calls `CEBRA(...).fit` / `.transform` on repo `cebra/`. It is not an N=1
`offset36_gru` / `EncoderTrainer` analog.

Next: [Add a recipe](guides/add-a-recipe.md)
