"""Sphinx config for optional local HTML (``uv pip install -e ".[docs]"``)."""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
from pathlib import Path, PurePosixPath

from docutils import nodes
from pydantic import BaseModel

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

project = "Acorn"
copyright = "2026, acorn contributors"
author = "acorn contributors"
release = "0.1.0"
version = "0.1.0"

extensions = [
    "myst_nb",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx_copybutton",
    "sphinxcontrib.mermaid",
]

root_doc = "index"
exclude_patterns = [
    "_build",
    "plan-runs",
    "investigations",
    "Thumbs.db",
    ".DS_Store",
    "**.ipynb_checkpoints",
]

myst_enable_extensions = []
myst_heading_anchors = 2
myst_fence_as_directive = ["mermaid"]

nb_execution_mode = "off"
nb_merge_streams = True
# Prefer stored PNG/SVG over matplotlib text/plain reprs when both exist.
# Do not set text/plain to priority 0 (that would hide images).
nb_mime_priority_overrides = [
    ("html", "image/png", 10),
    ("html", "image/svg+xml", 20),
]

napoleon_google_docstring = False
napoleon_numpy_docstring = True
napoleon_use_param = True
napoleon_use_rtype = True

autodoc_typehints = "description"
autodoc_class_signature = "separated"
autodoc_default_options = {
    "members": True,
    "undoc-members": False,
    "show-inheritance": False,
    "exclude-members": (
        "model_config, model_computed_fields, model_extra, model_fields, "
        "model_fields_set, model_post_init, construct, copy, dict, json, "
        "parse_obj, parse_raw, parse_file, schema, schema_json, validate, "
        "from_orm, update_forward_refs, model_dump, model_dump_json, "
        "model_validate, model_validate_json, model_rebuild, model_parametrized_name, "
        "model_construct, to_legacy_dict"
    ),
}

html_theme = "pydata_sphinx_theme"
html_static_path = ["_static"]
html_css_files = ["notebooks.css"]
html_copy_source = True
templates_path = ["_templates"]
html_title = "Acorn"
html_theme_options = {
    "header_links_before_dropdown": 5,
    "navbar_align": "left",
    "navbar_persistent": ["search-button-field"],
    "show_nav_level": 1,
    "navigation_depth": 2,
    "show_toc_level": 2,
    "logo": {"text": "Acorn"},
    "icon_links": [
        {
            "name": "GitHub",
            "url": "https://github.com/alijabbari00/acorn",
            "icon": "fa-brands fa-github",
            "type": "fontawesome",
        }
    ],
    "footer_start": ["copyright", "footer_project"],
}

suppress_warnings = ["toc.not_included"]

# Off while the repository is private. After it is public:
# ``ACORN_DOCS_COLAB=1 sphinx-build ...`` injects an Open-in-Colab badge on
# rendered notebook pages. Notebook sources stay badge-free.
_ACORN_COLAB = os.environ.get("ACORN_DOCS_COLAB", "").strip() == "1"
_COLAB_NB_ROOT = (
    "https://colab.research.google.com/github/alijabbari00/acorn/blob/main/examples/notebooks"
)

_DEMO_NOTEBOOKS = (
    "demo_nlp21_lm",
    "demo_perich_single",
    "demo_perich_multi",
    "demo_hippo_single",
    "demo_hippo_multi",
    "demo_macaque_iwj",
    "demo_macaque_multi",
    "demo_macaque_multi_baseline",
    "demo_nlp21",
    "demo_sequence_multi",
)

_NB_HREF = re.compile(r"\]\((?:(?:\.\./)+|/)?examples/notebooks/(demo_[A-Za-z0-9_]+)\.ipynb\)")
_REPO_FILE_HREF = re.compile(r"\]\(/((?:examples|acorn)/[^)\s]+)\)")
_TQDM_LINE = re.compile(r"(?:it/s|\?it/s|%\|)")


def _stream_text(out: dict) -> str:
    text = out.get("text", "")
    if isinstance(text, list):
        return "".join(text)
    return str(text)


def _mime_blob(data: dict, mime: str) -> str:
    """Join Jupyter mime payloads (string or list-of-base64-chunks after json.dumps)."""
    value = data.get(mime, "")
    if isinstance(value, list):
        return "".join(str(part) for part in value)
    if value is None:
        return ""
    return str(value)


def _output_has_image(out: dict) -> bool:
    data = out.get("data")
    if not isinstance(data, dict):
        return False
    for mime in ("image/png", "image/svg+xml"):
        if mime in data and _mime_blob(data, mime).strip():
            return True
    return False


def _is_matplotlib_repr_only(out: dict) -> bool:
    """True when the output is only a Figure/Axes text repr (no image mime)."""
    if out.get("output_type") not in {"execute_result", "display_data"}:
        return False
    if _output_has_image(out):
        return False
    data = out.get("data") if isinstance(out.get("data"), dict) else {}
    text = _mime_blob(data, "text/plain")
    return any(marker in text for marker in ("Figure size", "[<Figure", "Axes"))


def _is_tqdm_progress(text: str) -> bool:
    return bool(_TQDM_LINE.search(text))


def _sanitize_notebook(nb: dict) -> dict:
    """Collapse tqdm stderr; drop Figure-repr-only outputs; never drop PNG/SVG."""
    for cell in nb.get("cells", []):
        if cell.get("cell_type") != "code":
            continue
        kept: list[dict] = []
        last_tqdm = None
        n_tqdm = 0
        for out in cell.get("outputs") or []:
            if out.get("output_type") == "stream":
                text = _stream_text(out)
                if out.get("name") == "stderr" and _is_tqdm_progress(text):
                    last_tqdm = text.strip().splitlines()[-1] if text.strip() else text.strip()
                    n_tqdm += 1
                    continue
            elif _is_matplotlib_repr_only(out):
                continue
            kept.append(out)
        if n_tqdm and last_tqdm:
            kept.append(
                {
                    "output_type": "stream",
                    "name": "stderr",
                    "text": [f"[training progress: {n_tqdm} updates] {last_tqdm}\n"],
                }
            )
        cell["outputs"] = kept
    return nb


def _stage_notebooks() -> None:
    dest_dir = Path(__file__).resolve().parent / "demos" / "notebooks"
    dest_dir.mkdir(parents=True, exist_ok=True)
    src_dir = _ROOT / "examples" / "notebooks"
    wanted = {f"{name}.ipynb" for name in _DEMO_NOTEBOOKS}
    for name in _DEMO_NOTEBOOKS:
        src = src_dir / f"{name}.ipynb"
        if not src.is_file():
            raise FileNotFoundError(src)
        dest = dest_dir / f"{name}.ipynb"
        if dest.is_symlink() or dest.exists():
            dest.unlink()
        nb = json.loads(src.read_text(encoding="utf-8"))
        dest.write_text(json.dumps(_sanitize_notebook(nb)), encoding="utf-8")
    for leftover in dest_dir.glob("*.ipynb"):
        if leftover.name not in wanted:
            leftover.unlink()


_stage_notebooks()

_SECTION_TOCS: dict[str, str] = {
    "index": """
```{toctree}
:hidden:
:maxdepth: 2

start/index
learn/index
guides/index
demos/index
api/index
```
""",
    "start/index": """
```{toctree}
:hidden:
:maxdepth: 1

faq
```
""",
    "learn/index": """
```{toctree}
:hidden:
:maxdepth: 1

why-acorn
families-and-metrics
glossary
```
""",
    "guides/index": """
```{toctree}
:hidden:
:maxdepth: 2

time-bin
sequence
save-and-resume
evaluation
/language_model
datasets/index
add-a-time-bin-dataset
add-a-sequence-dataset
add-a-recipe
architecture
```
""",
    "guides/datasets/index": """
```{toctree}
:hidden:
:maxdepth: 1

dandi
figshare
drive
dryad
```
""",
    "demos/index": """
```{toctree}
:hidden:
:maxdepth: 1

reaching
hippocampus
macaque
handwriting
multi-session
scripts
"""
    + "\n".join(f"notebooks/{name}" for name in _DEMO_NOTEBOOKS)
    + "\n```\n",
    "api/index": """
```{toctree}
:hidden:
:maxdepth: 1

training
data
recipes
evaluation
language-model
```
""",
}

_API_AUTODOC: dict[str, str] = {
    "api/training": """
```{eval-rst}
.. autofunction:: acorn.runners.dispatch.train_model
.. autoclass:: acorn.train.config.TrainConfig
.. autoclass:: acorn.train.sequence.config.SequenceTrainConfig
.. autoclass:: acorn.train.config.AdvConfig
.. autoclass:: acorn.train.result.TrainResult
.. autofunction:: acorn.train.config.set_seed
```
""",
    "api/data": """
```{eval-rst}
.. autoclass:: acorn.data.registry.DatasetSpec
.. autoclass:: acorn.data.sequence.registry.SequenceDatasetSpec
.. autofunction:: acorn.data.registry.list_datasets
.. autofunction:: acorn.data.registry.get_dataset
.. autofunction:: acorn.data.sequence.registry.get_sequence_dataset
```
""",
    "api/recipes": """
```{eval-rst}
.. autoclass:: acorn.models.registry.RecipeSpec
.. autoclass:: acorn.models.registry.SequenceRecipeSpec
.. autofunction:: acorn.models.registry.list_recipes
.. autofunction:: acorn.models.registry.get_recipe
.. autofunction:: acorn.models.registry.get_sequence_recipe
.. autofunction:: acorn.models.registry.register_recipe
.. autofunction:: acorn.models.registry.register_sequence_recipe
```
""",
    "api/evaluation": """
```{eval-rst}
.. autofunction:: acorn.eval.windowed.evaluate_r2
.. autofunction:: acorn.eval.decoder_probe.evaluate_embedding_decoders
.. autofunction:: acorn.eval.sequence.ctc_probe.evaluate_sequence_sessions
.. autofunction:: acorn.eval.sequence.export.export_all_sessions
```
""",
    "api/language-model": """
```{eval-rst}
.. autofunction:: acorn.lm.runtime.rescore_export
.. autoexception:: acorn.lm.errors.LmPrerequisiteError
```
""",
}


def _nb_href(docname: str, stem: str) -> str:
    src_dir = PurePosixPath(docname).parent
    dest = PurePosixPath("demos/notebooks") / stem
    src_parts = () if str(src_dir) == "." else src_dir.parts
    dest_parts = dest.parts
    i = 0
    for left, right in zip(src_parts, dest_parts, strict=False):
        if left != right:
            break
        i += 1
    ups = ("..",) * (len(src_parts) - i)
    rest = dest_parts[i:]
    return "/".join((*ups, *rest)) if (ups or rest) else "."


def _rewrite_notebook_hrefs(docname: str, text: str) -> str:
    return _NB_HREF.sub(lambda m: f"]({_nb_href(docname, m.group(1))})", text)


def _repo_file_href(docname: str, repo_path: str) -> str:
    src_dir = PurePosixPath(docname).parent
    depth = 0 if str(src_dir) == "." else len(src_dir.parts)
    ups = "/".join(("..",) * (depth + 1))
    return f"{ups}/{repo_path}"


def _rewrite_repo_file_hrefs(docname: str, text: str) -> str:
    return _REPO_FILE_HREF.sub(lambda m: f"]({_repo_file_href(docname, m.group(1))})", text)


def _inject_sphinx_markup(app, docname, source):
    text = _rewrite_notebook_hrefs(docname, source[0])
    source[0] = _rewrite_repo_file_hrefs(docname, text)
    extra = _SECTION_TOCS.get(docname, "") + _API_AUTODOC.get(docname, "")
    if extra:
        source[0] = source[0] + extra


def _pydantic_field_docs(app, what, name, obj, options, lines):
    if what != "class" or not isinstance(obj, type):
        return
    try:
        if not issubclass(obj, BaseModel):
            return
    except TypeError:
        return
    fields = getattr(obj, "model_fields", None)
    if not fields:
        return
    if any(line.strip() == "Attributes" for line in lines):
        return
    lines.append("")
    lines.append("Attributes")
    lines.append("----------")
    for field_name, field in fields.items():
        desc = field.description or ""
        lines.append(field_name)
        lines.append(f"    {desc}" if desc else "    ")


def _copy_lm_plot(app):
    dest = Path(app.outdir) / "_static"
    dest.mkdir(parents=True, exist_ok=True)
    src = _ROOT / "examples" / "assets" / "demo_nlp21_lm.png"
    if src.is_file():
        shutil.copy2(src, dest / src.name)


def _notebook_chrome(app, doctree, docname):
    if not docname.startswith("demos/notebooks/"):
        return
    stem = docname.rsplit("/", 1)[-1]
    chunks: list[str] = []
    if _ACORN_COLAB:
        url = f"{_COLAB_NB_ROOT}/{stem}.ipynb"
        chunks.append(
            f'<p class="acorn-colab"><a href="{url}">'
            '<img alt="Open in Colab" '
            'src="https://colab.research.google.com/assets/colab-badge.svg">'
            "</a></p>"
        )
    if stem == "demo_nlp21_lm":
        rel = "../" * docname.count("/") + "_static/demo_nlp21_lm.png"
        chunks.append(
            f'<p class="acorn-nb-hero"><img src="{rel}" '
            'alt="Saved NLP21 language-model scores"></p>'
        )
    if chunks:
        doctree.insert(0, nodes.raw("", "\n".join(chunks), format="html"))


def setup(app):
    app.connect("source-read", _inject_sphinx_markup)
    app.connect("autodoc-process-docstring", _pydantic_field_docs)
    app.connect("builder-inited", _copy_lm_plot)
    app.connect("doctree-resolved", _notebook_chrome)
    return {"parallel_read_safe": True, "parallel_write_safe": True}
