# Adding a dataset

Time-bin datasets (one label vector per neural bin) are documented in
[Add a time-bin dataset](guides/add-a-time-bin-dataset.md). That page covers
existing families (Perich NWB, Hippo joblib, macaque XDS/Pop) and how a new
file format extends the loader.

For handwriting or speech transcripts, see
[Adding a B2T dataset](adding_a_b2t_dataset.md).

Next: [Add a time-bin dataset](guides/add-a-time-bin-dataset.md)
