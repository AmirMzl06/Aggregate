# Training

Public training entry points. `train_model` lives in
`acorn.runners.dispatch` and is re-exported as `acorn.train_model`.

```python
from acorn import AdvConfig, SequenceTrainConfig, TrainConfig, TrainResult, set_seed, train_model
```

**`train_model(config)`** — Dispatch on config class. `TrainConfig` (and
`dict`) run time-bin encoder-then-decoder. `SequenceTrainConfig` runs joint
CTC + InfoNCE. Returns `TrainResult`. Core training does not write a run
directory.

**`TrainConfig`** — Time-bin hyperparameters. Required: `dataset_keys`.
Default recipe `offset36_gru`.

**`SequenceTrainConfig`** — Sequence hyperparameters. Required:
`dataset_keys`. Default recipe `offset36_ctc`.

**`AdvConfig`** — Encoder L2 PGD settings (`enabled`, `eps`, `style` including
`cluster_pgd`, …). Nested on both train configs as `adv`.

**`TrainResult`** — In-memory `model`, `decoders`, `metrics`, `history`,
`plots`.

**`set_seed(seed)`** — Seed Python, NumPy, and Torch.

Next: [Data](data.md)
