# Language model

Optional rescoring after a sequence export. `train_model` never turns this
on. Prerequisites: Docker (NVIDIA runtime for speech), RAM, and graphs.

```python
from acorn.lm import LmPrerequisiteError, rescore_export
```

**`rescore_export(export_dir, *, assume_yes=False, session_key=None, host_ram_bytes=None)`** —
Rescore a v1.1 export directory. Returns a metrics dict (`ngram_wer`,
`lm_wer`). Does not write `lm_metrics.json`. Raises `LmPrerequisiteError`
before work if Docker or RAM is missing.

**`LmPrerequisiteError`** — Docker, NVIDIA runtime, or RAM is insufficient.

Guide: [Language-model rescoring](../language_model.md).

Next: [Citing](../project/citing.md)
