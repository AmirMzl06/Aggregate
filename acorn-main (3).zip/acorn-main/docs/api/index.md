# API

Curated public symbols. HTML builds attach autodoc; this page stays readable
on GitHub. The installed package never `automodule`s `acorn.train` as a dump,
and vendored `cebra/` / `xds/` are not documented here.

- [Training](training.md) — configs, `train_model`, `TrainResult`, `set_seed`
- [Data](data.md) — dataset specs and listing
- [Recipes](recipes.md) — register and look up recipes
- [Evaluation](evaluation.md) — R², CER, export
- [Language model](language-model.md) — `rescore_export`, `LmPrerequisiteError`
