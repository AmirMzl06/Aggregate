# Evaluation

Scores and exports after `train_model`. Helpers under `examples/eval_*.py`
call these with a `TrainResult`.

```python
from acorn.eval.windowed import evaluate_r2
from acorn.eval.decoder_probe import evaluate_embedding_decoders
from acorn.eval.sequence import evaluate_sequence_sessions, export_all_sessions
```

**`evaluate_r2(encoder, decoder, x, y, device, window_size=256)`** —
Coefficient of determination over non-overlapping windows.

**`evaluate_embedding_decoders(model, loader, bundles, device, n_decoder_steps, ...)`** —
Fit per-session probes on frozen embeddings; return train / holdout R²
dicts.

**`evaluate_sequence_sessions(model, sessions, device, batch_size=16, use_final=True)`** —
Per-session greedy CER (`use_final=True` uses `final_eval`).

**`export_all_sessions(model, sessions, device, ..., use_lm=False, assume_yes=False)`** —
Logits payload (`acorn.ctc_export.v1.1`). `use_lm=True` runs optional
rescoring in the same call.

Greedy CER is not paper WER.

Next: [Language model](language-model.md)
