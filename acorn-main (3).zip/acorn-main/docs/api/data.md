# Data

Registry lookup. `list_datasets()` is the sorted union of training-enabled
time-bin and sequence keys. The in-memory `demo` session is omitted.

```python
from acorn import (
    DatasetSpec,
    SequenceDatasetSpec,
    get_dataset,
    get_sequence_dataset,
    list_datasets,
)
```

**`list_datasets(*, train_enabled_only=True, label_format=None)`** — Sorted
keys. `label_format="time_bin_aligned"` or `"sequence"` filters one family.

**`get_dataset(key)`** — Time-bin `DatasetSpec`. Raises if the key is
sequence-only.

**`get_sequence_dataset(key)`** — Sequence `SequenceDatasetSpec`. Raises if
the key is time-bin-only.

**`DatasetSpec`** — Per-dataset knobs including `dataset_group` (`perich`,
`hippo`, `macaque`).

**`SequenceDatasetSpec`** — Dryad fields, vocab (blank at index 0),
`task_key`.

Grouped tables: [Datasets](../guides/datasets/index.md).

Next: [Recipes](recipes.md)
