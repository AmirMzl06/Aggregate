# Recipes

A recipe is an encoder container, decoder class, and trainer class
registered under a name.

```python
from acorn import (
    RecipeSpec,
    SequenceRecipeSpec,
    get_recipe,
    get_sequence_recipe,
    list_recipes,
    register_recipe,
    register_sequence_recipe,
)
```

**`list_recipes(*, label_format=None)`** — Sorted names. Filter with
`time_bin_aligned` or `sequence`.

**`get_recipe(name)`** / **`get_sequence_recipe(name)`** — Look up one spec.
Cross-family keys raise `KeyError` pointing at the other getter.

**`register_recipe(spec)`** / **`register_sequence_recipe(spec)`** — Add a
sibling bundle. Time-bin and sequence registries stay separate.

**`RecipeSpec`** / **`SequenceRecipeSpec`** — The registered records.

How-to: [Add a recipe](../guides/add-a-recipe.md).

Next: [Evaluation](evaluation.md)
