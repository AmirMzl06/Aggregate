# Get started

Install Acorn, confirm the test suite, then open one demo. Notebooks are the
tutorial path. Scripts are the how-to path once you know which family you want.

## Install Acorn

This repository is private. Clone it with GitHub access, then from the repo
root:

```bash
uv pip install -e ".[dev]"
pytest -q
```

`pytest -q` needs no datasets and no GPU. `uv.lock` is gitignored;
`uv sync --extra dev` is optional locally.

## Choose a demo

| Notebook | Time | Data | GPU |
| --- | --- | --- | --- |
| [demo_nlp21_lm.ipynb](/examples/notebooks/demo_nlp21_lm.ipynb) | Seconds (saved plot) | Dryad NLP21 scores in the notebook | No |
| [demo_perich_single.ipynb](/examples/notebooks/demo_perich_single.ipynb) | Hours | DANDI reaching | Yes |
| [demo_hippo_single.ipynb](/examples/notebooks/demo_hippo_single.ipynb) | Hours | Figshare hippocampus | Yes |
| [demo_macaque_iwj.ipynb](/examples/notebooks/demo_macaque_iwj.ipynb) | Hours | Google Drive motor EMG | Yes |
| [demo_nlp21.ipynb](/examples/notebooks/demo_nlp21.ipynb) | Hours | Dryad handwriting (~3.6 GB) | Yes |

Listed trainings download public data and run to completion. The saved
language-model plot does not train.

- [FAQ](faq.md) — GPU, private repo, metrics, Dryad, own data
- [Demos](../demos/index.md) — full notebook table and per-family pages

Next: [FAQ](faq.md)
