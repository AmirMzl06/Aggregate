# FAQ

Short answers. Each topic links to the page that teaches the rest.

## Do I need a GPU?

The saved NLP21 language-model notebook
([demo_nlp21_lm.ipynb](/examples/notebooks/demo_nlp21_lm.ipynb)) does not.
Every listed training demo does. `pytest -q` does not.

## Why is clone access required?

The GitHub repository is private. There is no anonymous clone URL and no
Open-in-Colab badge yet. Clone with an account that can see the repo.

## How does ACORN relate to CEBRA?

ACORN is CEBRA-style contrastive training plus an adversarial objective
for session shift. The `offset36_cebra` recipe calls sklearn `CEBRA.fit`
on one session; it is not the default multi-session recipe. See
[Why ACORN exists](../learn/why-acorn.md).

## Time-bin or sequence?

Time-bin experiments have one label vector per neural bin (cursor, EMG,
position) and report R². Sequence experiments have a shorter handwriting or
speech transcript and report greedy character error rate (CER).
[Two families and metrics](../learn/families-and-metrics.md) compares them.

## Is greedy CER the paper WER?

No. Training reports greedy token CER on CTC ids. Paper tables use word error
rate after language-model rescoring. See
[Language-model rescoring](../language_model.md).

## Can I skip training with `RESUME_DIR`?

Yes. Set `RESUME_DIR` in a demo notebook to a folder written by
`examples/save_run.py` to plot saved metrics instead of calling
`train_model`. See [Save and resume](../guides/save-and-resume.md).

## How do Dryad keys work?

Listings are anonymous. File bytes need `DRYAD_CLIENT_ID` and
`DRYAD_CLIENT_SECRET`. Setup: [Datasets](../data.md) (Dryad section) and
[Dryad](../guides/datasets/dryad.md).

## How do I use my own data?

Add a key in an existing family (Perich NWB, Hippo joblib, macaque XDS
archives or Pop pickles) or extend that family's loader for a new file
format. Sequence datasets register a `SequenceDatasetSpec` and implement
both eval-split methods. Start at
[Add a time-bin dataset](../guides/add-a-time-bin-dataset.md) or
[Add a sequence dataset](../guides/add-a-sequence-dataset.md).

Next: [Demos](../demos/index.md)
