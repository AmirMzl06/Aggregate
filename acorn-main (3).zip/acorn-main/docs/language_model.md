# Language-model rescoring

Training a brain-to-text model reports greedy character error rate on
`TrainResult.metrics`. Language-model rescoring is an **optional next step**
after you save that run (`examples/save_run.py`). It re-reads the exported
logits and often lowers word error.

You do not need this to train. `train_model` never turns it on.

If you only want to look at already-computed NLP21 numbers, open
[`examples/notebooks/demo_nlp21_lm.ipynb`](/examples/notebooks/demo_nlp21_lm.ipynb) — that notebook
does not need Docker.

## After a training run

Point `rescore_export` at a run directory saved with `examples/save_run.py`:

```python
from acorn.lm import LmPrerequisiteError, rescore_export

report = rescore_export("runs/nlp21", assume_yes=True)
print(report["ngram_wer"], report["lm_wer"])
```

If you are already exporting logits yourself, the same rescoring can run in
that call:

```python
from acorn.eval.sequence import export_all_sessions

export_all_sessions(
    model, sessions, device, use_lm=True, assume_yes=True
)
```

`assume_yes=True` (or `ACORN_DOWNLOAD_YES=1`) skips the confirmation prompt.
Graphs still download. If Docker or RAM is missing, the call raises
`LmPrerequisiteError` before it starts work.

Start with a handwriting run (`nlp21` / `nlp10`). Speech is the same API and a
much heavier machine.

## What you need

Docker on PATH, with the daemon running. The first call builds two images
(Kaldi on CPU, a neural LM on CUDA). You do not install Kaldi or
`transformers` on the host.

Handwriting/NLP can run the neural step on CPU if needed (slow). Speech needs
Docker's NVIDIA runtime (`nvidia-container-toolkit`, so `docker info` lists
`nvidia`) — not only `nvidia-smi` on the host.

## What the call does

1. Checks Docker (and the NVIDIA runtime for speech).
2. Builds the two images if they are not already present.
3. Downloads Kaldi graphs from Dryad if they are not already cached.
4. Runs an n-gram decode, then a neural language model.
5. Returns a metrics dict (`ngram_wer` / `lm_wer`). It does not write
   `lm_metrics.json`. Temporary npy job files are deleted.

## Disk, RAM, and cache (when you are ready)

NLP (the usual first path): about 64 GiB RAM, GPT-2 XL weights (~6 GB), and
the NLP graph zip (~3.6 GB download, a few extra GB while extracting).

Speech: about 350 GiB RAM, OPT-6.7B 8-bit weights (~7 GB), and the 5-gram
graphs (~38 GB compressed; plan on ~160 GB free while extracting).

Graphs land under `~/.cache/acorn/lm`. Hugging Face weights use `HF_HOME` or
`~/.cache/huggingface` and are bind-mounted into the neural container.

Docker `--memory` is `min(preset, floor(0.9 * host RAM))`.

## Recipes

Acorn uses the original CORP decode knobs: NLP is a 3-gram graph plus GPT-2 XL;
speech is a 5-gram graph plus OPT-6.7B 8-bit. The True path does not use a
speech 3-gram.

NLP GPT-2 is Hugging Face PyTorch, not CORP `TFGPT2LMHeadModel`. Decode knobs
match; the weight stack does not. Speech `paper_comparable` is only the 5-gram
+ OPT 8-bit stack with α=0.5.

## Errors

`LmPrerequisiteError` means the call stopped before rescoring: Docker missing
or the daemon down, speech without an NVIDIA Docker runtime, or RAM below the
preset after the 90% host cap.

Next: [Demos](demos/index.md)
