# Two families and metrics

Acorn splits experiments by **label format**, not by species.

## Time-bin

One label vector per neural bin: cursor position, EMG, or hippocampal
position. Training has two phases: a shared contrastive encoder, then a
per-session decoder. The score is **R²** on held-out time (and, in the
notebooks, under noise or a small input attack). Recipes:
`offset36_gru`, `offset36_gru_advdec`, and `offset36_cebra`.

## Sequence

A handwriting or speech transcript that is shorter than the neural timeline.
There is no per-bin character label. Training is joint CTC + InfoNCE
(`offset36_ctc`). The in-repo score is **greedy character error rate (CER)**
on CTC token ids after collapsing repeats and dropping the CTC blank.

## Greedy CER is not paper WER

Greedy CER never builds English words. Published brain-to-text tables report
**word error rate (WER)** after an n-gram decode and a neural language
model. Optional rescoring is a separate step after a sequence export. See
[Language-model rescoring](../language_model.md).

Next: [Glossary](glossary.md)
