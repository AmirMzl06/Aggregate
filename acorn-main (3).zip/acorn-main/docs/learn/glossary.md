# Glossary

Words the public docs use. Distilled for a first reading of the code, not a
lab checklist.

**session.** One recording day (or one registry key). Multi-session training
shares an encoder across several keys.

**embedding.** The encoder's vector for a time bin. Decoders read embeddings,
not raw spikes.

**recipe.** A registered bundle: encoder container, decoder class, trainer
class. Time-bin names include `offset36_gru` and `offset36_cebra`. Sequence
uses `offset36_ctc`. Select it with `TrainConfig.recipe` or
`SequenceTrainConfig.recipe`.

**InfoNCE.** Contrastive loss that pulls similar time bins together.

**CTC.** Connectionist Temporal Classification. Trains a sequence model when
the transcript is shorter than neural time and there is no frame-level
alignment, by summing over blanks and collapsed repeats.

**blank.** CTC's "emit nothing" class (index 0). It skips frames and
separates two identical tokens so they do not merge. It is not speech
silence (`SIL` is a real speech class).

**rescoring.** Optional second pass after a sequence export: an n-gram
decode, then a neural language model, producing word error. Distinct from
greedy CER on `TrainResult.metrics`.

Next: [Get started](../start/index.md)
