# Understand

Why ACORN exists, how the two training families differ, and the words the
rest of the docs use. These pages explain. They do not run a training loop.

- [Why ACORN exists](why-acorn.md) — BCIs, session drift, adversarial
  contrastive encoder, zero-shot day
- [Two families and metrics](families-and-metrics.md) — time-bin R² vs
  sequence CER; greedy CER is not paper WER
- [Glossary](glossary.md) — session, embedding, recipe, CTC, blank, rescoring
