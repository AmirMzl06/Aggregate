# Why ACORN exists

A brain-computer interface (BCI) reads electrical activity from neurons and
turns it into a cursor, a muscle command, or text. The mapping is learned
from labeled recordings: spikes or threshold crossings in time bins, paired
with behavior or a transcript.

## Session drift

The same person or animal, recorded on a new day, does not produce the same
voltage patterns. Electrodes move, firing statistics change, and a decoder
fit yesterday misses today's targets. Labs often recalibrate: collect a new
labeled session and train again. That cost is the problem ACORN is built
for.

## Session-invariant embeddings

ACORN trains a shared encoder on several sessions at once. The encoder maps
each time bin to a vector (an embedding) that is meant to keep the behavior
or language signal while dropping session identity. An adversarial
contrastive objective pushes embeddings of similar behavior together and
uses a small attack on the encoder so the representation does not latch onto
day-specific noise.

## Zero-shot day

After training, a decoder reads those embeddings. On a session the encoder
has not seen, you should not need a new labeled calibration set for the
embedding space itself. Motor demos report holdout R². Brain-to-text demos
report greedy character error, and optional language-model rescoring reports
word error. Those numbers are the point of the draft abstract: language
error down, motor R² up, without a per-day refit of the encoder.

Next: [Two families and metrics](families-and-metrics.md)
