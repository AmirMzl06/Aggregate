# Datasets

Acorn downloads into `./data` unless `ACORN_DATA_DIR` is set. Training jobs
prompt before a large fetch unless `assume_yes=True` or `ACORN_DOWNLOAD_YES=1`.

**Do not start several jobs that write the same dataset directory.** Download
once per group, then train. Different groups may download in parallel.

The committed key catalog (matched to live `list_datasets()` /
`list_recipes()`) is [Datasets](guides/datasets/index.md).

## Groups

| Group | Keys (examples) | Source | On disk under `$ACORN_DATA_DIR` |
|-------|-----------------|--------|----------------------------------|
| Perich reaching | `perich_c_co_1`, `perich_m_rt_3`, … | [DANDI 000688](https://dandiarchive.org/dandiset/000688) | `perich/{C-CO,C-RT,…}/*.nwb` |
| Hippocampus | `hippo_achilles`, `hippo_buddy`, `hippo_cicero`, `hippo_gatsby` | Figshare joblib dumps | `hippo/{rat}.jl` |
| Macaque motor | `jango`, `mihili_co`, `mihili_rt`, `pop` | Google Drive XDS / pickle archives | `Jango_ISO_2015_raw/`, `Mihili_CO_2014_raw/`, `Mihili_RT_2013_2014_raw/`, `Pop_PG_2021/` |
| Brain-to-text | `nlp21`, `nlp10`, `speech24`, `speech45` | Dryad | `nlp21/`, `nlp10/`, `speech24/`, `speech45/` |

Automatic path (library): `train_model(...)` with `assume_yes=True`, or any
example script after `ACORN_DOWNLOAD_YES=1`.

## Dryad (nlp21 / nlp10 / speech24 / speech45)

Listings (`GET /api/v2/datasets/.../versions` and `.../files`) are anonymous.
**File bytes** (`GET /api/v2/files/{id}/download`) require a bearer token from
OAuth client credentials. That is a Dryad API rule, not a missing URL in Acorn.

### Credentials (non-interactive)

Do **not** paste credentials into git, notebooks, or committed job scripts.

1. Sign in at [Dryad](https://datadryad.org/).
2. Open [Managing my account](https://datadryad.org/help/account/management) →
   **Create a Dryad API account** (details:
   [API accounts](https://github.com/datadryad/dryad-app/blob/main/documentation/apis/api_accounts.md)).
3. Copy **Client ID** and **Secret**.
4. Export, then run training:

```bash
export DRYAD_CLIENT_ID='…'
export DRYAD_CLIENT_SECRET='…'
export ACORN_DOWNLOAD_YES=1
python examples/sequence_nlp21.py --output-dir runs/nlp21
```

Acorn exchanges those values for a token
(`POST https://datadryad.org/oauth/token`, `grant_type=client_credentials`)
and uses it for the file download. After each file lands, Acorn checks the
listing's `size` and `digest`/`digestType` (sha-256 on current sequence
archives). A mismatch deletes the file and raises.

If those variables are missing, Acorn **raises** `DryadDownloadError` with this
section’s URL rather than hanging on a prompt (non-interactive jobs have no TTY).

### Manual placement (no API account)

Open the dataset page, download the archive, and extract until the loader’s
layout exists:

| Key | Dataset page | File | Ready when |
|-----|--------------|------|------------|
| nlp21 | [doi:10.5061/dryad.hqbzkh1p6](https://datadryad.org/dataset/doi:10.5061/dryad.hqbzkh1p6) | `CORP_data_release.zip` | `nlp21/seed_model_training_data/mat/*.mat` and the two `online_evaluation_data/.../mat/` trees |
| nlp10 | [doi:10.5061/dryad.wh70rxwmv](https://datadryad.org/dataset/doi:10.5061/dryad.wh70rxwmv) | Dryad archive | `nlp10/Datasets/` |
| speech24 | [doi:10.5061/dryad.x69p8czpq](https://datadryad.org/dataset/doi:10.5061/dryad.x69p8czpq) | `competitionData.tar.gz` | extracted under `speech24/` |
| speech45 | [doi:10.5061/dryad.dncjsxm85](https://datadryad.org/dataset/doi:10.5061/dryad.dncjsxm85) | `t15_copyTask_neuralData.zip` | extracted under `speech45/` |

API overview: [datadryad.org/api](https://datadryad.org/api#?route=overview).

## Other sources

- **DANDI (Perich):** no extra token. `dandi.download` verifies each NWB against
  the dandiset digest. One process should write `perich/` until `C-CO` (and
  siblings) contain NWB files. How-to: [DANDI](guides/datasets/dandi.md).
- **Figshare (hippo):** CEBRA's Figshare helper (`download_file_with_progress_bar`)
  with the same URLs and MD5s as `cebra.datasets.hippocampus`. One job should
  write `hippo/`. How-to: [Figshare](guides/datasets/figshare.md).
- **Google Drive (macaque):** `gdown` via `DatasetLoader.prepare_dataset`. Drive
  does not publish checksums. How-to: [Google Drive](guides/datasets/drive.md).

Next: [Datasets](guides/datasets/index.md)
