# Adding a B2T / sequence-format dataset

Brain-to-text datasets register in `acorn/data/sequence/registry.py`. The
how-to is [Add a sequence dataset](guides/add-a-sequence-dataset.md).
Movement and EMG datasets are documented in
[Adding a dataset](adding_a_dataset.md).

Implement `periodic_eval_split` and `final_eval_split` as separate methods
(do not alias one to the other). Copy the NLP21 loader.

## Eval and export

Eval is Python. After a run, greedy CER and a logits export
(`acorn.ctc_export.v1.1`) live on `TrainResult` (`metrics` and
`plots["export"]`). You can also call `evaluate_sequence_sessions` and
`export_all_sessions` yourself.

Language-model rescoring is a separate, optional step after that export. It is
not part of registering a dataset. See
[Language-model rescoring](language_model.md).

## Checklist

- [ ] `SequenceDatasetSpec` with `task_key`, `vocab` (blank at index 0), Dryad fields
- [ ] Loader writes last-frame-replicate collatable `(T, F)` + `(L,)` int labels
- [ ] `periodic_eval_split` / `final_eval_split` are separate methods
- [ ] Feature count inferred from data; `expected_n_features` only asserts
- [ ] `pytest tests/test_sequence_data.py tests/test_sequence_model.py -q`

Next: [Add a sequence dataset](guides/add-a-sequence-dataset.md)
