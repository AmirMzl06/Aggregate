# Train from the Python API

This page is the Python API hub: copy-paste `train_model` snippets after
[Get started](start/index.md). Install Acorn, then train either a
movement/EMG decoder or a brain-to-text decoder. Grouped dataset keys live
in [Datasets](guides/datasets/index.md), not in a pasted dump here.

## Install

Clone the repository with GitHub access (it is private until it is public).
`uv.lock` is gitignored; `uv sync --extra dev` is optional locally:

```bash
uv pip install -e ".[dev]"
pytest -q
```

`pytest -q` works with no datasets and no GPU.

## Two kinds of experiments

Some recordings have a label for every time bin — cursor position, EMG, and
similar. Those train a shared encoder, then a GRU decoder (`TrainConfig`).
Others have a transcript of handwriting or speech that is shorter than the
neural timeline. Those train encoder and CTC decoder together
(`SequenceTrainConfig`). `train_model` picks the runner from the config class.

Why the two families exist: [Why ACORN exists](learn/why-acorn.md).

Worked Jupyter demos: [Demos](demos/index.md). Instant language-model plot
(no GPU):
[`examples/notebooks/demo_nlp21_lm.ipynb`](/examples/notebooks/demo_nlp21_lm.ipynb).
Library-default Jango script (recipe `offset36_gru`):
[`examples/demo_time_bin.py`](/examples/demo_time_bin.py).
Macaque motor with recipe `offset36_gru_advdec`:
[`examples/offset36_gru_advdec.py`](/examples/offset36_gru_advdec.py).

## Time-bin API (library defaults)

`TrainConfig` defaults include `n_batch=30000`, `n_decoder_batches=30000`,
`batch_size=256`, `recipe="offset36_gru"`, `device="auto"`.

```python
from acorn import TrainConfig, train_model

cfg = TrainConfig(dataset_keys=["jango"])
result = train_model(cfg)
```

Training metrics live on `result.metrics` and `result.history`. The library
logger is silent by default. To see step lines on stderr:

```python
import logging
from acorn import set_verbosity

logging.basicConfig(level=logging.INFO)
set_verbosity("INFO")
```

## Sequence API (library defaults)

`SequenceTrainConfig` defaults include `n_batch=20000`, `batch_size=16`,
`recipe="offset36_ctc"`, `device="auto"`. One dataset versus all four Dryad
corpora (NLP10, NLP21, Speech24, Speech45) uses the same recipe; Multi is
all four.

```python
from acorn import SequenceTrainConfig, train_model

seq = SequenceTrainConfig(dataset_keys=["nlp21"])
result = train_model(seq)
```

Non-interactive Dryad: `assume_yes=True` plus API env vars. See
[Datasets](data.md).

## Language-model rescoring (optional)

`train_model` returns greedy CER on `TrainResult.metrics` and logits in RAM.
To write a run directory (needed by `rescore_export`), use
`examples/save_run.py`. Then:

```python
from acorn.lm import rescore_export

report = rescore_export("runs/nlp21", assume_yes=True)
print(report["ngram_wer"], report["lm_wer"])
```

Needs Docker. The same step can run during export if you pass `use_lm=True` to
`export_all_sessions`. Walkthrough (what Docker does, NLP vs speech, disk and
RAM): [Language-model rescoring](language_model.md).

## Next

[Get started](start/index.md)
