# Changelog

Release notes live in the repository-root `CHANGELOG.md` file
(<https://github.com/alijabbari00/acorn>). This project follows Keep a
Changelog and Semantic Versioning. Version switcher is not shipped while
the package is `0.1.0`.

Next: [License](license.md)
