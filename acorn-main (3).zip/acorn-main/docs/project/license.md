# License

The MIT license at the repository root covers **first-party Acorn code
only** (`acorn/`, `tests/`, `docs/`, `examples/`, and the repo-root entry
points). Full text: the root `LICENSE` file.

Vendored `cebra/` and `xds/` keep their own terms:
[Third-party code](third-party.md).

Next: [Third-party code](third-party.md)
