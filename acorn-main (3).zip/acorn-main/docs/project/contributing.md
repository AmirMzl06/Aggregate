# Contributing

Clone with GitHub access (the repository is private). Then:

```bash
uv pip install -e ".[dev]"
pytest -q
ruff check acorn tests examples
mypy acorn
```

`pytest -q` needs no datasets and no GPU. To build HTML locally:

```bash
uv pip install -e ".[docs]"
sphinx-build -W -b html docs docs/_build/html
```

The `[docs]` extra is for maintainers and CI. It is not part of `.[dev]`.
HTML stays local while this repository is private.

Next: [Get started](../start/index.md)
