# Third-party code

CEBRA and XDS are vendored in git. They are not PyPI dependencies and are
excluded from the installable wheel. Inventory, licenses, and local
modifications live in the repository-root `THIRD_PARTY.md` file
(<https://github.com/alijabbari00/acorn>).

`import acorn` puts the repo root on `sys.path` so `import cebra` and
`from xds import lab_data` resolve here. Neither project endorses Acorn.

Next: [Contributing](contributing.md)
