# Citing

The ACORN manuscript is still a draft. Until a publication DOI exists, cite
this software by the GitHub repository URL and version `0.1.0`.

CEBRA and XDS remain third-party; cite those projects on their own terms.
See [Third-party code](third-party.md).

Next: [Changelog](changelog.md)
