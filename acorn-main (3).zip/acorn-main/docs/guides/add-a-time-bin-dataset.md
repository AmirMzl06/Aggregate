# Add a time-bin dataset

Movement and EMG datasets (one label vector per neural bin) register in
[`acorn/data/registry.py`](/acorn/data/registry.py) via the group
modules under `acorn/data/groups/`. Handwriting or speech transcripts use
[Add a sequence dataset](add-a-sequence-dataset.md).

New keys of an **existing** family reuse that family's loader: Perich NWB,
Hippo joblib, or macaque XDS/Pop. A new on-disk format extends the loader
in that group.

## Existing family

1. Open the group module (`acorn/data/groups/perich/`, `hippo/`, or
   `macaque/`).
2. Add a `DatasetSpec` (macaque) or extend the group's key table (Perich
   days, Hippo rats) so `DATASET_REGISTRY` picks it up.
3. Keep `dataset_group` set to `perich`, `hippo`, or `macaque`.
4. Put data where that loader already looks, or let `train_model` download.

Macaque XDS-raw / Pop pickle example:

```python
DATASET_REGISTRY["my_monkey"] = DatasetSpec(
    key="my_monkey",
    dataset_group="macaque",
    xds_name="MyMonkey_CO_2020_raw",
    num_days=10,
    expected_n_neurons=96,
    use_smooth=True,
    xds_smooth=False,
    gdrive_url="https://drive.google.com/file/d/.../view?usp=sharing",
    file_type="7z",
    plot_type="co_reach",
    panel="E",
    title="My CO reach",
    label_names=tuple(CURSOR_LABEL_NAMES),
    pos_dims=(0, 1),
    train_enabled=True,
)
```

Perich reaching sessions are DANDI NWB files (`file_type="nwb"`), one
recording per key. Extra days of an **existing** Perich task belong in that
group's day table (`PERICH_DAYS` in `acorn/data/groups/perich/`) so the
current NWB loader can find them. That path assumes the DANDI 000688 layout
the loader already parses. A different NWB schema or folder layout is a new
file format: extend `acorn/data/groups/perich/` rather than adding a
registry-only spec.

Hippocampus sessions are Figshare joblib dumps (`file_type="jl"`,
`http_url=...`), one rat per key. Extra rats of the **existing** dump layout
go in `HIPPO_RATS` / `HIPPO_HTTP_URLS` in `acorn/data/groups/hippo/`. A
different joblib payload is loader work, not a registry-only spec.

Copy a neighboring spec in that group rather than mixing fields across
families.

Train:

```python
from acorn import TrainConfig, train_model

cfg = TrainConfig(dataset_keys=["my_monkey"], seed=42)
# train_model(cfg)
```

### Checklist

- [ ] `DatasetSpec` added with `train_enabled=True` and the correct `dataset_group`
- [ ] `expected_n_neurons` matches the spike channel count (or omit to skip the assertion)
- [ ] Smoothing and plot fields match the family you copied
- [ ] `pytest tests/test_dataset_registry.py` passes

## New file format

A new binary / HDF5 / NPZ layout cannot be abstracted by the registry
alone — extend the group's loader.

1. Still add a `DatasetSpec` (URLs, neuron counts, plot meta stay
   centralized).
2. Teach the group loader to parse the files and return `(spikes, labels)`:
   spikes `(T, n_neurons)`, labels `(T, n_labels)`.
3. Prefer the existing disk-cache helpers so repeated runs stay fast.
4. Add a small unit test that loads a tiny fixture (or mocks the parser).

Keep format-specific parsing in the loader; keep keys, days, and plot meta
in the registry.

## Tips

- Train-enabled time-bin keys are those with `train_enabled=True`
  (`list_datasets(label_format="time_bin_aligned")`).
- Data lands in `./data` unless `ACORN_DATA_DIR` is set.

Next: [Add a sequence dataset](add-a-sequence-dataset.md)
