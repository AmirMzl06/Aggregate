# Add a sequence dataset

To add a brain-to-text dataset (handwriting or speech transcripts), register
it in [`acorn/data/sequence/registry.py`](/acorn/data/sequence/registry.py).
Movement and EMG datasets (one label per time bin) are registered separately —
see [Add a time-bin dataset](add-a-time-bin-dataset.md).

| Label format | Labels | Training | Metric |
| --- | --- | --- | --- |
| `time_bin_aligned` | one vector per neural bin | two-phase encoder then decoder | R² |
| `sequence` | a shorter discrete transcript | joint CTC + InfoNCE | CER |

Shared across both: `Offset36_multi` trunk, `FixedCosineInfoNCE`, PGD
primitives in `acorn.train.adversarial`, `TrainResult` (model, metrics,
history), `acorn.train_model(config)` (dispatched on config class).

## Register a dataset

Add a `SequenceDatasetSpec` to `SEQUENCE_DATASET_REGISTRY`:

```python
SEQUENCE_DATASET_REGISTRY["my_b2t"] = SequenceDatasetSpec(
    key="my_b2t",
    task_key="speech",            # sessions that share a CTC head use the same key
    expected_n_features=256,      # advisory; the runner infers from loaded data
    num_classes=41,
    vocab=SPEECH_VOCAB,           # index 0 must be the CTC blank
    dryad_doi="10.5061/dryad....",
    dryad_filename="needed_file.tar.gz",  # or None if the DOI has one archive
    extract_only=None,            # or ("Datasets/",) to skip bundled extras
    approx_download_size_gb=3.67,
)
```

Then add a loader under `acorn/data/sequence/loaders/` that returns a
`SequenceSession`. Implement `periodic_eval_split` and `final_eval_split` as
two methods on that loader. Do not alias one to the other. The NLP21 loader
is the pattern to copy.

Wire the loader in `acorn/data/sequence/loaders/__init__.py`.

## Train

Pass an explicit `dataset_keys` list (omitting it does not train all four Dryad
corpora). One dataset versus all four uses the same recipe; Multi is all four
Dryad corpora. Snippets use library defaults (`n_batch=20000`, `batch_size=16`).

```python
from acorn import SequenceTrainConfig, train_model

cfg = SequenceTrainConfig(
    dataset_keys=["nlp21"],          # one dataset vs all four is the same recipe
    # recipe="offset36_ctc",         # SequenceRecipeSpec name; default is fine
    # dataset_keys=["speech24", "nlp10", "nlp21", "speech45"]  # Multi: all four
)
# train_model(cfg)
```

`train_model` dispatches on the config class (`TrainConfig` → time-bin-aligned,
`SequenceTrainConfig` → sequence). The two family runners never import each
other.

Downloads prompt for confirmation and print a size warning. Set
`assume_yes=True` or `ACORN_DOWNLOAD_YES=1` for non-interactive use. Tests
never hit Dryad.

## Eval and export

Eval is Python. After a run, greedy CER and a logits export
(`acorn.ctc_export.v1.1`) live on `TrainResult` (`metrics` and
`plots["export"]`). You can also call `evaluate_sequence_sessions` and
`export_all_sessions` yourself.

Language-model rescoring is a separate, optional step after that export. It is
not part of registering a dataset. See
[Language-model rescoring](../language_model.md).

## Checklist

- [ ] `SequenceDatasetSpec` with `task_key`, `vocab` (blank at index 0), Dryad fields
- [ ] Loader writes last-frame-replicate collatable `(T, F)` + `(L,)` int labels
- [ ] `periodic_eval_split` / `final_eval_split` are separate methods
- [ ] Feature count inferred from data; `expected_n_features` only asserts
- [ ] `pytest tests/test_sequence_data.py tests/test_sequence_model.py -q`

Next: [Add a recipe](add-a-recipe.md)
