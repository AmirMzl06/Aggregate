# How-to

Task pages for after you have installed Acorn and opened a demo. Notebooks
remain the tutorial; these pages are the scripts-and-API path.

- [Train a time-bin model](time-bin.md) — movement, EMG, hippocampus; R²
- [Train a sequence model](sequence.md) — handwriting and speech; greedy CER
- [Save and resume](save-and-resume.md) — `examples/save_run.py` and `RESUME_DIR`
- [Evaluate a run](evaluation.md) — R² helpers, sequence CER, export
- [Language-model rescoring](../language_model.md) — optional WER after export
- [Datasets](datasets/index.md) — Perich, hippocampus, macaque, brain-to-text
- [Add a time-bin dataset](add-a-time-bin-dataset.md) — existing family or new format
- [Add a sequence dataset](add-a-sequence-dataset.md) — B2T registry and both eval splits
- [Add a recipe](add-a-recipe.md) — sibling encoder/decoder/trainer bundle
- [Architecture](architecture.md) — package diagram
