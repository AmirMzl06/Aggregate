# DANDI

Perich reaching sessions come from
[DANDI 000688](https://dandiarchive.org/dandiset/000688) as NWB files. There
is no extra token. `dandi.download` verifies each file against the dandiset
digest.

On disk under `$ACORN_DATA_DIR`: `perich/{C-CO,C-RT,…}/*.nwb`. One process
should write `perich/` until those folders contain NWB files. Registry keys
use `dataset_group="perich"` (for example `perich_m_rt_3` for paper task
M-RT, day 3).

Automatic path: `train_model(..., assume_yes=True)` or an example script
after `ACORN_DOWNLOAD_YES=1`.

Full key table: [Datasets](index.md).

Next: [Figshare](figshare.md)
