# Datasets

Acorn groups public recordings into four families. Time-bin keys use `DatasetSpec.dataset_group` (`perich`, `hippo`, or `macaque`). Sequence keys split into handwriting (`nlp10`, `nlp21`) and speech (`speech24`, `speech45`). `list_datasets()` is the sorted union of training-enabled keys. The in-memory `demo` session is omitted (tests only).

Downloads land in `./data` unless `ACORN_DATA_DIR` is set. Training prompts before a large fetch unless `assume_yes=True` or `ACORN_DOWNLOAD_YES=1`. Do not start several jobs that write the same dataset directory.

- [DANDI (Perich)](dandi.md) — reaching NWB files, no extra token
- [Figshare (hippocampus)](figshare.md) — rat position joblib dumps
- [Google Drive (macaque)](drive.md) — XDS / pickle motor archives
- [Dryad (brain-to-text)](dryad.md) — handwriting and speech; file bytes need API credentials

Source details that notebooks already link: [Datasets](../../data.md).

## Perich

Reaching sessions from DANDI 000688. Paper names such as M-RT map to keys like `perich_m_rt_3`.

| Key | Paper task |
| --- | --- |
| `perich_c_co_1` | C-CO |
| `perich_c_co_10` | C-CO |
| `perich_c_co_11` | C-CO |
| `perich_c_co_12` | C-CO |
| `perich_c_co_13` | C-CO |
| `perich_c_co_14` | C-CO |
| `perich_c_co_15` | C-CO |
| `perich_c_co_16` | C-CO |
| `perich_c_co_17` | C-CO |
| `perich_c_co_18` | C-CO |
| `perich_c_co_19` | C-CO |
| `perich_c_co_2` | C-CO |
| `perich_c_co_20` | C-CO |
| `perich_c_co_21` | C-CO |
| `perich_c_co_22` | C-CO |
| `perich_c_co_23` | C-CO |
| `perich_c_co_24` | C-CO |
| `perich_c_co_25` | C-CO |
| `perich_c_co_26` | C-CO |
| `perich_c_co_27` | C-CO |
| `perich_c_co_28` | C-CO |
| `perich_c_co_29` | C-CO |
| `perich_c_co_3` | C-CO |
| `perich_c_co_30` | C-CO |
| `perich_c_co_31` | C-CO |
| `perich_c_co_32` | C-CO |
| `perich_c_co_33` | C-CO |
| `perich_c_co_34` | C-CO |
| `perich_c_co_35` | C-CO |
| `perich_c_co_36` | C-CO |
| `perich_c_co_37` | C-CO |
| `perich_c_co_38` | C-CO |
| `perich_c_co_39` | C-CO |
| `perich_c_co_4` | C-CO |
| `perich_c_co_40` | C-CO |
| `perich_c_co_41` | C-CO |
| `perich_c_co_42` | C-CO |
| `perich_c_co_43` | C-CO |
| `perich_c_co_44` | C-CO |
| `perich_c_co_45` | C-CO |
| `perich_c_co_46` | C-CO |
| `perich_c_co_47` | C-CO |
| `perich_c_co_48` | C-CO |
| `perich_c_co_49` | C-CO |
| `perich_c_co_5` | C-CO |
| `perich_c_co_50` | C-CO |
| `perich_c_co_51` | C-CO |
| `perich_c_co_52` | C-CO |
| `perich_c_co_53` | C-CO |
| `perich_c_co_6` | C-CO |
| `perich_c_co_7` | C-CO |
| `perich_c_co_8` | C-CO |
| `perich_c_co_9` | C-CO |
| `perich_c_rt_1` | C-RT |
| `perich_c_rt_10` | C-RT |
| `perich_c_rt_11` | C-RT |
| `perich_c_rt_12` | C-RT |
| `perich_c_rt_13` | C-RT |
| `perich_c_rt_14` | C-RT |
| `perich_c_rt_15` | C-RT |
| `perich_c_rt_2` | C-RT |
| `perich_c_rt_3` | C-RT |
| `perich_c_rt_4` | C-RT |
| `perich_c_rt_5` | C-RT |
| `perich_c_rt_6` | C-RT |
| `perich_c_rt_7` | C-RT |
| `perich_c_rt_8` | C-RT |
| `perich_c_rt_9` | C-RT |
| `perich_j_co_1` | J-CO |
| `perich_j_co_2` | J-CO |
| `perich_j_co_3` | J-CO |
| `perich_m_co_1` | M-CO |
| `perich_m_co_10` | M-CO |
| `perich_m_co_11` | M-CO |
| `perich_m_co_12` | M-CO |
| `perich_m_co_13` | M-CO |
| `perich_m_co_14` | M-CO |
| `perich_m_co_15` | M-CO |
| `perich_m_co_16` | M-CO |
| `perich_m_co_17` | M-CO |
| `perich_m_co_18` | M-CO |
| `perich_m_co_19` | M-CO |
| `perich_m_co_2` | M-CO |
| `perich_m_co_20` | M-CO |
| `perich_m_co_21` | M-CO |
| `perich_m_co_22` | M-CO |
| `perich_m_co_3` | M-CO |
| `perich_m_co_4` | M-CO |
| `perich_m_co_5` | M-CO |
| `perich_m_co_6` | M-CO |
| `perich_m_co_7` | M-CO |
| `perich_m_co_8` | M-CO |
| `perich_m_co_9` | M-CO |
| `perich_m_rt_1` | M-RT |
| `perich_m_rt_2` | M-RT |
| `perich_m_rt_3` | M-RT |
| `perich_m_rt_4` | M-RT |
| `perich_m_rt_5` | M-RT |
| `perich_m_rt_6` | M-RT |
| `perich_t_co_1` | T-CO |
| `perich_t_co_2` | T-CO |
| `perich_t_co_3` | T-CO |
| `perich_t_co_4` | T-CO |
| `perich_t_co_5` | T-CO |
| `perich_t_co_6` | T-CO |
| `perich_t_rt_1` | T-RT |
| `perich_t_rt_2` | T-RT |
| `perich_t_rt_3` | T-RT |
| `perich_t_rt_4` | T-RT |
| `perich_t_rt_5` | T-RT |
| `perich_t_rt_6` | T-RT |

## Hippocampus

Figshare joblib dumps. Four rats.

| Key |
| --- |
| `hippo_achilles` |
| `hippo_buddy` |
| `hippo_cicero` |
| `hippo_gatsby` |

## Macaque

Motor EMG and reach from Google Drive. Paper names in prose are IW-J (`jango`), CO-M (`mihili_co`), RT-M (`mihili_rt`), and PG-P (`pop`).

| Key |
| --- |
| `jango` |
| `mihili_co` |
| `mihili_rt` |
| `pop` |

## Brain-to-text

Handwriting (NLP) and speech corpora from Dryad. Multi is all four keys together.

### Handwriting

| Key |
| --- |
| `nlp10` |
| `nlp21` |

### Speech

| Key |
| --- |
| `speech24` |
| `speech45` |

## Recipes

`list_recipes()` is the sorted union of time-bin and sequence recipes.

| Recipe | Label format |
| --- | --- |
| `offset36_cebra` | time-bin |
| `offset36_ctc` | sequence |
| `offset36_gru` | time-bin |
| `offset36_gru_advdec` | time-bin |

Next: [Add a time-bin dataset](../add-a-time-bin-dataset.md)
