# Google Drive

Macaque motor archives download with `gdown` via
`DatasetLoader.prepare_dataset`. Drive does not publish checksums. You
confirm a prompt unless `assume_yes=True` or `ACORN_DOWNLOAD_YES=1`.

On disk under `$ACORN_DATA_DIR`: `Jango_ISO_2015_raw/`, `Mihili_CO_2014_raw/`,
`Mihili_RT_2013_2014_raw/`, `Pop_PG_2021/`. Keys: `jango` (paper IW-J),
`mihili_co` (CO-M), `mihili_rt` (RT-M), `pop` (PG-P).

Full key table: [Datasets](index.md).

Next: [Dryad](dryad.md)
