# Dryad

Brain-to-text corpora (`nlp21`, `nlp10`, `speech24`, `speech45`) download
from Dryad. Listings (`GET /api/v2/datasets/.../versions` and `.../files`)
are anonymous. **File bytes** (`GET /api/v2/files/{id}/download`) require a
bearer token from OAuth client credentials. That is a Dryad API rule, not a
missing URL in Acorn.

The same steps live on [Datasets](../../data.md) (Dryad section), which
notebooks already link.

## Credentials (non-interactive)

Do **not** paste credentials into git, notebooks, or committed job scripts.

1. Sign in at [Dryad](https://datadryad.org/).
2. Open [Managing my account](https://datadryad.org/help/account/management) →
   **Create a Dryad API account** (details:
   [API accounts](https://github.com/datadryad/dryad-app/blob/main/documentation/apis/api_accounts.md)).
3. Copy **Client ID** and **Secret**.
4. Export, then run training:

```bash
export DRYAD_CLIENT_ID='…'
export DRYAD_CLIENT_SECRET='…'
export ACORN_DOWNLOAD_YES=1
python examples/sequence_nlp21.py --output-dir runs/nlp21
```

Acorn exchanges those values for a token
(`POST https://datadryad.org/oauth/token`, `grant_type=client_credentials`)
and uses it for the file download. After each file lands, Acorn checks the
listing's `size` and `digest`/`digestType` (sha-256 on current sequence
archives). A mismatch deletes the file and raises.

If those variables are missing, Acorn **raises** `DryadDownloadError` with
the Datasets URL rather than hanging on a prompt.

## Manual placement (no API account)

Open the dataset page, download the archive, and extract until the loader's
layout exists. Table: [Datasets](../../data.md).

Next: [Add a time-bin dataset](../add-a-time-bin-dataset.md)
