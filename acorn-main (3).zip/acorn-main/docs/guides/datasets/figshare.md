# Figshare

Hippocampus recordings are joblib dumps from Figshare, using the same URLs
and MD5s as `cebra.datasets.hippocampus`. One job should write `hippo/`.

On disk under `$ACORN_DATA_DIR`: `hippo/{rat}.jl` for `achilles`, `buddy`,
`cicero`, and `gatsby`. Keys are `hippo_achilles` and siblings
(`dataset_group="hippo"`).

Automatic path: `train_model(..., assume_yes=True)` or an example script
after `ACORN_DOWNLOAD_YES=1`.

Full key table: [Datasets](index.md).

Next: [Google Drive](drive.md)
