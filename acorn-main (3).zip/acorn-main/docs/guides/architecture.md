# Architecture

Package layout for people who already know what ACORN is for. Training loops
live in the How-to pages, not here.

```mermaid
graph TD
    data["acorn/data<br/>registry DatasetSpec, loader, splits<br/>sequence/ B2T loaders"]
    models["acorn/models<br/>interfaces, registry, encoder, decoder<br/>sequence/ CTC head"]
    trainpkg["acorn/train<br/>config, adversarial, encoder_trainer<br/>sequence/ CTC trainer"]
    evalpkg["acorn/eval<br/>windowed R2, decoder_probe, plots<br/>sequence/ CER + export"]
    utils["acorn/utils<br/>amp, constants, history"]
    runners["acorn/runners<br/>dispatch → multi_session / sequence"]

    trainpkg --> models
    trainpkg --> data
    trainpkg --> utils
    evalpkg --> models
    evalpkg --> data
    evalpkg --> utils
    runners --> data
    runners --> models
    runners --> trainpkg
    runners --> evalpkg
    runners --> utils
```

`train_model` in `acorn.runners.dispatch` is the public entry. Family
runners never import each other. Vendored `cebra/` and `xds/` stay off the
autodoc pages.

Next: [API](../api/index.md)
