# Save and resume

`train_model` returns a `TrainResult` in memory. The installed package does
not write run directories. File output is
[`examples/save_run.py`](/examples/save_run.py).

## Write a run directory

```python
from acorn import SequenceTrainConfig, train_model
from examples.save_run import save_run

result = train_model(SequenceTrainConfig(dataset_keys=["nlp21"], assume_yes=True))
save_run(result, "runs/nlp21")
```

Training scripts also accept optional `--output-dir`, which writes through
the same helper.

## Skip training in a notebook

Demo notebooks read `RESUME_DIR`. Point it at a folder `save_run` already
wrote to plot saved metrics without calling `train_model`. A generic
`save_run` folder is enough for clean holdout R². Noise and attack
comparison needs the eval that notebook writes (or a live `TrainResult`);
otherwise the plots show clean holdout only. Set `SAVE_DIR` when you want a
new run on disk.

Next: [Evaluate a run](evaluation.md)
