# Evaluate a run

Eval helpers are Python callables. Import them and pass a `TrainResult`, or
print usage with `--help`. Running `python examples/eval_*.py` with no
arguments does not train and does not run a full eval by itself.

## Time-bin R²

`evaluate_r2` scores non-overlapping windows. After a multi-session run,
`evaluate_embedding_decoders` fits per-session probes on frozen embeddings
and reports train / holdout R². Notebooks plot clean holdout, and optional
noise or attack comparisons when those evals are present.

Example usage:

```text
python examples/eval_perich.py --help
```

## Sequence CER and export

`evaluate_sequence_sessions` reports greedy CER. `export_all_sessions`
writes logits (`acorn.ctc_export.v1.1`) for later rescoring. Pass
`use_lm=True` only when you want the optional language-model step in that
same call.

Greedy CER is not paper WER. Optional WER:
[Language-model rescoring](../language_model.md).

Next: [Language-model rescoring](../language_model.md)
