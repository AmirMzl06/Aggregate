# Train a sequence model

Sequence runs pair neural time with a shorter handwriting or speech
transcript. `train_model` dispatches on `SequenceTrainConfig` and trains
encoder plus CTC decoder together (`offset36_ctc`). The in-repo metric is
greedy CER, not paper WER.

## Compose a config

Library defaults include `n_batch=20000`, `batch_size=16`,
`recipe="offset36_ctc"`. One dataset versus all four Dryad corpora uses the
same recipe; Multi is NLP10, NLP21, Speech24, and Speech45 together.

```python
from acorn import SequenceTrainConfig, train_model

seq = SequenceTrainConfig(dataset_keys=["nlp21"], assume_yes=True)
result = train_model(seq)
print(result.metrics)
```

Dryad file bytes need `DRYAD_CLIENT_ID` and `DRYAD_CLIENT_SECRET`. See
[Datasets](../data.md) (Dryad section).

## After training

Greedy CER lands on `TrainResult.metrics`. Logits stay in RAM until you
export. Language-model rescoring is optional and needs a run directory from
`examples/save_run.py`. It is not part of `train_model`.

Next: [Save and resume](save-and-resume.md)
