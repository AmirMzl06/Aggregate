# Train a time-bin model

Time-bin runs have one label vector per neural bin. `train_model` dispatches
on `TrainConfig`: shared encoder, then per-session decoders. Expect hours on
a GPU and a download into `./data` (or `ACORN_DATA_DIR`).

## Compose a config

Library defaults include `recipe="offset36_gru"`, `n_batch=30000`,
`batch_size=256`. Pass `assume_yes=True` to skip download prompts.

```python
from acorn import TrainConfig, train_model

cfg = TrainConfig(dataset_keys=["jango"])
result = train_model(cfg)
print(result.metrics)
```

Reaching (paper task M-RT, day 3) uses a Perich key:

```python
cfg = TrainConfig(dataset_keys=["perich_m_rt_3"], recipe="offset36_cebra")
```

Hippocampus uses `hippo_achilles` (and siblings). Macaque motor EMG in the
paper IW-J sense uses `jango` with recipe `offset36_gru_advdec` in
[`examples/offset36_gru_advdec.py`](/examples/offset36_gru_advdec.py).

## Read the result

`TrainResult` stays in RAM. Core training does not write a run directory.
`result.metrics` holds R²-style scores; `result.history` holds curves.
To persist files, see [Save and resume](save-and-resume.md).

Grouped keys: [Datasets](datasets/index.md).

Next: [Train a sequence model](sequence.md)
