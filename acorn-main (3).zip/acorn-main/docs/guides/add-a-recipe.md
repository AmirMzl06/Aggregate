# Add a recipe

To add a new encoder/decoder/trainer bundle, register it in
[`acorn/models/registry.py`](/acorn/models/registry.py).

A recipe bundles:

- a multi-session encoder container (`multi_cls`)
- a per-session decoder class (`decoder_cls` + optional `decoder_kwargs`)
- an encoder trainer class (`encoder_trainer_cls`)

The default production recipe is `offset36_gru`
(`MultiSessionModel` + `MonkeyDecoder` + `EncoderTrainer`).
`offset36_gru_advdec` is the adversarial-decoder recipe
(`AdversarialMonkeyDecoder` + `AdvDecEncoderTrainer`).
`offset36_cebra` is the sklearn `CEBRA.fit` recipe
(`CebraFitModel` + `MonkeyDecoder` + `CebraFitTrainer`): Adam `3e-4`,
`weight_decay=0`, `adv_alternate=False`, `attack_norm="l2"`, and
`training_mode="clean"` or `"adversarial"`. It trains **N=1** and calls
`CEBRA(...).fit` / `.transform` on repo `cebra/`. It is not an N=1
`offset36_gru` / `EncoderTrainer` analog.

Recipes are **siblings of a shared base**, never subclasses of each other.
Deleting one recipe's files must not require editing another recipe's files
(only the one registration line in `registry.py`).

Sequence-format recipes (`offset36_ctc`) are a sibling family, registered via
`SequenceRecipeSpec` and selected with `SequenceTrainConfig.recipe`.
See [Add a sequence dataset](add-a-sequence-dataset.md).

## What you must implement

Structural contracts live in
[`acorn/models/interfaces.py`](/acorn/models/interfaces.py):

- **`EncoderModel`** — multi-session container used by the runner:
  `add_session`, `encode`, `encode_cebra_windows`, `transform`, `get_offset`,
  `set_session_decoder`, `session_encoder` / `session_decoder`, freeze/train
  helpers, `encoder_parameters`, `.to`, `.eval`.
- **`DecoderModel`** — per-session probe fitted on frozen embeddings:
  `fit`, `score`, `forward`, plus `best_epoch_` / `best_val_r2_`.

Decoder training-loop changes override `_train_window_step` on
[`BaseGRUDecoder`](/acorn/models/decoder_base.py).
Encoder optimizer / scheduler / grad-clip changes override hooks on
[`EncoderTrainer`](/acorn/train/encoder_trainer.py).

## Worked example: `offset36_gru_advdec`

This is the pattern to copy.

1. **Decoder** — new file, subclass the *neutral* base, never `MonkeyDecoder`:

```python
# acorn/models/decoder_adversarial.py
from acorn.models.decoder_base import BaseGRUDecoder

class AdversarialMonkeyDecoder(BaseGRUDecoder):
    def _train_window_step(self, ...):
        # clean MSE step, then L2 PGD on the same batch
        ...
```

2. **Encoder trainer** — new file, subclass the *neutral* `EncoderTrainer`:

```python
# acorn/train/encoder_trainer_advdec.py
from acorn.train.encoder_trainer import EncoderTrainer


class AdvDecEncoderTrainer(EncoderTrainer):
    def build_optimizer(self, params): ...
    def build_scheduler(self, optimizer, n_batches): ...
    def clip_grad(self, params): ...
```

3. **Register** the bundle (one entry; this is the only shared file you touch):

```python
register_recipe(
    RecipeSpec(
        name="offset36_gru_advdec",
        display_name="Offset36_multi + AdversarialMonkeyDecoder",
        multi_cls=MultiSessionModel,
        decoder_cls=AdversarialMonkeyDecoder,
        decoder_kwargs={"adv_eps": 0.1},
        encoder_trainer_cls=AdvDecEncoderTrainer,
    )
)
```

4. **Use it** — compose `TrainConfig` in Python. See
   [`examples/offset36_gru_advdec.py`](/examples/offset36_gru_advdec.py)
   (`n_batch` / `n_decoder_batches` omitted so paper defaults apply):

```python
from acorn import AdvConfig, TrainConfig, train_model

cfg = TrainConfig(
    dataset_keys=["jango"],
    recipe="offset36_gru_advdec",
    enc_lr=0.02,
    batch_size=1024,
    adv=AdvConfig(enabled=True, eps=0.5, style="bin"),
)
# train_model(cfg)
```

## Step-by-step for a new recipe

1. **Implement** decoder and/or trainer in new files under `acorn/models/`
   and `acorn/train/`. Subclass `BaseGRUDecoder` / `EncoderTrainer`, not
   another recipe's concrete class.
2. **Register** one `RecipeSpec` at the bottom of `registry.py`.
3. **Select** it via `TrainConfig.recipe`.
4. **Verify**:

```bash
pytest tests/test_recipe_registry.py tests/test_recipe_independence_imports.py tests/test_encoder_trainer.py tests/test_decoder_adversarial.py -q
mypy acorn
```

Independence check (MRO): `AdversarialMonkeyDecoder` must not list
`MonkeyDecoder`, and `AdvDecEncoderTrainer` only adds `EncoderTrainer`.

## Tips

- Time-bin recipes use `register_recipe`; sequence / B2T recipes use
  `register_sequence_recipe`.
- Default remains `offset36_gru`. Time-bin `device='auto'` uses CPU when no
  GPU is visible; pass `TrainConfig(..., device="cpu")` to pin CPU. Sequence
  `auto` may use CPU.
- Compare recipes from each `TrainResult`: `history` (training curves) and
  `metrics` (final scores). Save with `examples/save_run.py` if you want files.

Next: [Architecture](architecture.md)
