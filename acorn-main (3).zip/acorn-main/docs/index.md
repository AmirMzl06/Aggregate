# Acorn

Brain-computer interfaces decode movement or language from neural activity.
Recordings drift from day to day, which forces recalibration. ACORN learns
session-invariant embeddings with an adversarial contrastive objective so a
decoder can run zero-shot on unseen sessions: language error down, motor R² up.

1. [See a result now](/examples/notebooks/demo_nlp21_lm.ipynb) — saved NLP21
   language-model scores; seconds; no GPU.
2. [Understand why ACORN exists](learn/why-acorn.md) — BCI basics, session
   drift, and what the model does.
3. [Train from Python](start/index.md) — pick a demo, then a full GPU run.

This repository is private. Clone it with GitHub access. HTML built with
`uv pip install -e ".[docs]"` stays on your machine.

- [Get started](start/index.md) — install and choose a demo
- [Understand](learn/index.md) — why ACORN, two families, glossary
- [How-to](guides/index.md) — train, data, add a recipe
- [Demos](demos/index.md) — notebooks, then scripts
- [API](api/index.md) — public Python surface

Citing, changelog, license, third-party code, and contributing live under
[Project](project/citing.md).
