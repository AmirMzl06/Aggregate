# Hippocampus

Rat position from Figshare joblib dumps. Keys: `hippo_achilles`,
`hippo_buddy`, `hippo_cicero`, `hippo_gatsby`.

## [demo_hippo_single.ipynb](/examples/notebooks/demo_hippo_single.ipynb)

What you get: ACORN vs CEBRA on rat hippocampus position (Achilles).

Time, data, GPU: hours; two GPU trainings (2,500 and 5,000 steps); Figshare;
GPU required.

## [demo_hippo_multi.ipynb](/examples/notebooks/demo_hippo_multi.ipynb)

What you get: one encoder on four rats. Clean / noise / attack R².

Time, data, GPU: hours; 20,000 steps; Figshare; GPU required.

Next: [Macaque](macaque.md)
