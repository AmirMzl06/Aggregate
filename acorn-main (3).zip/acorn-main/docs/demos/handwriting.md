# Handwriting

NLP21 is a Dryad handwriting corpus (~3.6 GB). Training reports greedy CER.
Optional language-model rescoring reports word error; that step is not
paper WER unless you actually run it.

## [demo_nlp21_lm.ipynb](/examples/notebooks/demo_nlp21_lm.ipynb)

What you get: saved NLP21 language-model scores, or live `rescore_export`
when `ACORN_NB_RUN_NGRAM=1`.

Time, data, GPU: seconds for the saved plot (no GPU); hours if you run the
LM (Docker, ~64 GiB RAM).

## [demo_nlp21.ipynb](/examples/notebooks/demo_nlp21.ipynb)

What you get: brain-to-text handwriting (CTC). ACORN, then the CEBRA model.

Time, data, GPU: many hours; two 20,000-step trainings; Dryad (~3.6 GB);
GPU required.

Dryad credentials: [Datasets](../data.md) (Dryad section).

Next: [Multi-session](multi-session.md)
