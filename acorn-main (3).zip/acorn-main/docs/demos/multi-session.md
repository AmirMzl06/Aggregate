# Multi-session

One shared encoder, several registry keys. Time-bin Multi notebooks live on
[Reaching](reaching.md), [Hippocampus](hippocampus.md), and
[Macaque](macaque.md). This page is the sequence Multi walkthrough.

## [demo_sequence_multi.ipynb](/examples/notebooks/demo_sequence_multi.ipynb)

What you get: one sequence model on NLP10, NLP21, Speech24, and Speech45.
Greedy CER. Optional comparison without adversarial training.

Time, data, GPU: many hours; 20,000 steps (and a second 20,000-step run if
the comparison flag stays on); Dryad (Speech45 is ~11 GB); GPU required.

Single-dataset NLP10 / NLP21 / Speech24 / Speech45 scripts (and their
no-adversarial comparisons) live in [Scripts](scripts.md). This folder's
notebooks keep the four-corpus Multi walkthrough plus the NLP21 demos.

Next: [Scripts](scripts.md)
