# Reaching

Perich DANDI sessions. Prose uses paper task names (M-RT); code uses registry
keys (`perich_m_rt_3`).

## [demo_perich_single.ipynb](/examples/notebooks/demo_perich_single.ipynb)

What you get: ACORN vs CEBRA on one reaching session (paper task M-RT, day
3). Clean / noise / attack R².

Time, data, GPU: hours; two GPU trainings (2,500 and 5,000 steps); DANDI;
GPU required.

## [demo_perich_multi.ipynb](/examples/notebooks/demo_perich_multi.ipynb)

What you get: one encoder on many reaching sessions. Clean / noise / attack
R².

Time, data, GPU: many hours; 40,000 steps; DANDI; GPU required.

Scripts for the same family: [Scripts](scripts.md).

Next: [Hippocampus](hippocampus.md)
