# Demos

Notebooks are the tutorial path. Each listed training run takes hours on a
GPU and downloads public data. The saved language-model notebook does not
train.

| Notebook | Time | Data | GPU |
| --- | --- | --- | --- |
| [demo_nlp21_lm.ipynb](/examples/notebooks/demo_nlp21_lm.ipynb) | Seconds (saved plot); hours if you run the LM | Dryad NLP21 scores in the notebook | No for the saved plot; Docker + ~64 GiB RAM if you run the LM |
| [demo_perich_single.ipynb](/examples/notebooks/demo_perich_single.ipynb) | Hours (2,500 and 5,000 steps) | DANDI | Yes |
| [demo_perich_multi.ipynb](/examples/notebooks/demo_perich_multi.ipynb) | Many hours (40,000 steps) | DANDI | Yes |
| [demo_hippo_single.ipynb](/examples/notebooks/demo_hippo_single.ipynb) | Hours (2,500 and 5,000 steps) | Figshare | Yes |
| [demo_hippo_multi.ipynb](/examples/notebooks/demo_hippo_multi.ipynb) | Hours (20,000 steps) | Figshare | Yes |
| [demo_macaque_iwj.ipynb](/examples/notebooks/demo_macaque_iwj.ipynb) | Hours (30,000 steps) | Google Drive | Yes |
| [demo_macaque_multi.ipynb](/examples/notebooks/demo_macaque_multi.ipynb) | Hours (30,000 steps) | Google Drive | Yes |
| [demo_macaque_multi_baseline.ipynb](/examples/notebooks/demo_macaque_multi_baseline.ipynb) | Hours (30,000 steps) | Google Drive | Yes |
| [demo_nlp21.ipynb](/examples/notebooks/demo_nlp21.ipynb) | Many hours (two 20,000-step trainings) | Dryad (~3.6 GB) | Yes |
| [demo_sequence_multi.ipynb](/examples/notebooks/demo_sequence_multi.ipynb) | Many hours (20,000 steps) | Dryad (Speech45 is ~11 GB) | Yes |

Set `RESUME_DIR` to a folder written by `examples/save_run.py` to skip
training and plot saved metrics. Dryad notebooks need
`DRYAD_CLIENT_ID` / `DRYAD_CLIENT_SECRET`; see [Datasets](../data.md)
(Dryad section).

- [Reaching](reaching.md) — Perich / paper task M-RT
- [Hippocampus](hippocampus.md) — four rats
- [Macaque](macaque.md) — IW-J, CO-M, RT-M, PG-P
- [Handwriting](handwriting.md) — NLP21 train and saved LM plot
- [Multi-session](multi-session.md) — many keys, one encoder
- [Scripts](scripts.md) — family/recipe catalog
