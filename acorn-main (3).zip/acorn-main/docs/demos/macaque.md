# Macaque

Motor EMG and reach from Google Drive. Paper names in prose: IW-J, CO-M,
RT-M, PG-P. Registry keys in code: `jango`, `mihili_co`, `mihili_rt`, `pop`.

## [demo_macaque_iwj.ipynb](/examples/notebooks/demo_macaque_iwj.ipynb)

What you get: ACORN on IW-J (isometric wrist EMG). Day-0 vs Day-K R² and EMG
traces. Optional comparison without adversarial training.

Time, data, GPU: hours; 30,000 steps; Google Drive; GPU required.

## [demo_macaque_multi.ipynb](/examples/notebooks/demo_macaque_multi.ipynb)

What you get: one encoder on IW-J, CO-M, RT-M, and PG-P. Day-0 vs Day-K R²
and behavior traces. Optional comparison without adversarial training.

Time, data, GPU: hours; 30,000 steps (and a second 30,000-step run if the
comparison flag stays on); Google Drive; GPU required.

## [demo_macaque_multi_baseline.ipynb](/examples/notebooks/demo_macaque_multi_baseline.ipynb)

What you get: the same four datasets without adversarial training.

Time, data, GPU: hours; 30,000 steps; Google Drive; GPU required.

Recipe `offset36_gru_advdec` is the macaque motor default in these demos.

Next: [Handwriting](handwriting.md)
