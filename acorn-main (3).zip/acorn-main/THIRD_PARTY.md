# Third-party code

The MIT license at the repository root covers **first-party Acorn code only**
(`acorn/`, `tests/`, `docs/`, `examples/`, and the repo-root entry points).

These trees are vendored in git. They are **not** declared as PyPI
dependencies and are excluded from the installable wheel
(`pyproject.toml` `setuptools.packages.find`).

| Path | Origin | License in this repo | What Acorn changed |
| --- | --- | --- | --- |
| [`cebra/`](cebra/) | [AdaptiveMotorControlLab/CEBRA](https://github.com/AdaptiveMotorControlLab/CEBRA) | Apache-2.0 — [`cebra/LICENSE.md`](cebra/LICENSE.md), [`cebra/NOTICE`](cebra/NOTICE) | Drifted local fork (encoder / multi-session / loaders). `pkg_resources` replaced with `packaging.version`. Not reconciled with a PyPI CEBRA release. |
| [`xds/`](xds/) | [limblab/xds](https://github.com/limblab/xds) (snapshot via [alijabbari00/xds](https://github.com/alijabbari00/xds)) | **No license published upstream** — [`xds/LICENSE.md`](xds/LICENSE.md), [`xds/NOTICE`](xds/NOTICE) | Python only (MATLAB omitted). `trial_start="gocue_time"` loader fix. |

Neither project endorses Acorn. Do not relicense these directories as MIT.
