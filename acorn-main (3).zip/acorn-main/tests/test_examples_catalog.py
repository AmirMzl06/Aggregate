"""README catalog vs notes; # HYPERS vs frozen rows."""

from __future__ import annotations

import ast
import os
import subprocess
import sys
from pathlib import Path

import pytest

from acorn.train.config import TrainConfig
from acorn.train.sequence.config import SequenceTrainConfig
from examples._common import HIPPO_KEYS, PERICH_KEYS, SEQUENCE_KEYS, output_dir_parser

_REPO = Path(__file__).resolve().parents[1]
_README = _REPO / "examples" / "README.md"
_NOTES = _REPO / ".docs" / "perich_hippo_notes.txt"
_skip_without_notes = pytest.mark.skipif(
    not _NOTES.is_file(),
    reason="private notes file is not in this checkout",
)

FROZEN_HYPERS = {
    "perich_cebra_adv.py": {
        "recipe": "offset36_cebra",
        "n_batch": 2500,
        "ceb_hidden": 512,
        "decoder_adv": "pgd",
        "zscore": False,
    },
    "perich_cebra_adv_nozscore.py": {
        "recipe": "offset36_cebra",
        "n_batch": 2500,
        "ceb_hidden": 512,
        "decoder_adv": "pgd",
        "zscore": False,
    },
    "perich_cebra_time_adv.py": {
        "recipe": "offset36_cebra",
        "n_batch": 2500,
        "ceb_hidden": 64,
        "conditional": None,
    },
    "perich_cebra.py": {
        "recipe": "offset36_cebra",
        "n_batch": 5000,
        "ceb_hidden": 512,
        "mlp_decoder": True,
        "zscore": False,
        "enabled": False,
    },
    "perich_cebra_time.py": {
        "recipe": "offset36_cebra",
        "conditional": None,
        "mlp_decoder": True,
        "zscore": False,
        "enabled": False,
    },
    "perich_multi_oneshot.py": {
        "recipe": "offset36_gru",
        "style": "oneshot",
        "decoder_adv": "oneshot",
    },
    "perich_multi.py": {"recipe": "offset36_gru", "style": "cluster_pgd", "decoder_adv": "pgd"},
    "perich_multi_nozscore.py": {
        "recipe": "offset36_gru",
        "style": "cluster_pgd",
        "decoder_adv": "pgd",
        "zscore": False,
    },
    "perich_multi_time.py": {
        "recipe": "offset36_gru",
        "conditional": "time",
        "ceb_hidden": 64,
    },
    "hippo_multi.py": {"recipe": "offset36_gru", "n_batch": 20000},
    "hippo_multi_time.py": {"recipe": "offset36_gru", "conditional": "time"},
    "hippo_multi_nozscore.py": {"recipe": "offset36_gru", "n_batch": 20000, "zscore": False},
    "hippo_multi_time_nozscore.py": {
        "recipe": "offset36_gru",
        "conditional": "time",
        "zscore": False,
    },
    "hippo_all.py": {"full_session": True},
    "hippo_all_time.py": {"full_session": True, "conditional": "time"},
    "hippo_cebra.py": {"mlp_decoder": True, "zscore": False, "enabled": False},
    "hippo_cebra_adv.py": {
        "recipe": "offset36_cebra",
        "decoder_adv": "pgd",
        "ceb_hidden": 64,
        "zscore": False,
    },
    "hippo_cebra_adv_nozscore.py": {
        "recipe": "offset36_cebra",
        "decoder_adv": "pgd",
        "ceb_hidden": 64,
        "zscore": False,
    },
    "hippo_cebra_adv_time.py": {
        "recipe": "offset36_cebra",
        "conditional": "time",
        "decoder_adv": "pgd",
    },
    "hippo_cebra_time_mlp.py": {
        "ceb_hidden": 32,
        "conditional": "time",
        "mlp_decoder": True,
        "zscore": False,
        "enabled": False,
    },
    "hippo_embedding.py": {
        "recipe": "offset36_cebra",
        "mlp_decoder": True,
        "zscore": False,
        "enabled": False,
    },
    "macaque_n1_jango.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "n_batch": 30000,
    },
    "macaque_n1_mihili_co.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "n_batch": 30000,
    },
    "macaque_n1_mihili_rt.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "n_batch": 30000,
    },
    "macaque_n1_pop.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "n_batch": 30000,
    },
    "macaque_multi.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "n_batch": 30000,
    },
    "sequence_nlp10.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": True,
        "style": "bin",
    },
    "sequence_nlp21.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": True,
        "style": "bin",
    },
    "sequence_speech24.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": True,
        "style": "bin",
    },
    "sequence_speech45.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": True,
        "style": "bin",
    },
    "sequence_nlp10_baseline.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": False,
        "style": "bin",
    },
    "sequence_nlp21_baseline.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": False,
        "style": "bin",
    },
    "sequence_speech24_baseline.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": False,
        "style": "bin",
    },
    "sequence_speech45_baseline.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": False,
        "style": "bin",
    },
    "sequence_multi.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": True,
        "style": "bin",
    },
    "sequence_multi_baseline.py": {
        "recipe": "offset36_ctc",
        "n_batch": 20000,
        "batch_size": 16,
        "hidden": 1024,
        "layers": 5,
        "bidir": True,
        "offset": 4,
        "kernel": 32,
        "stride": 4,
        "cont_batch": 1024,
        "enc_lr": 0.02,
        "eps": 0.8,
        "enabled": False,
        "style": "bin",
    },
    "perich_supervised.py": {
        "recipe": "offset36_gru",
        "ceb_hidden": 256,
        "decoder_adv": "off",
        "style": "cluster_pgd",
    },
    "offset36_gru_advdec.py": {
        "recipe": "offset36_gru_advdec",
        "enc_lr": 0.02,
        "batch_size": 1024,
        "style": "bin",
    },
}

_SKIP_TRAIN_HYPERS = {"demo_time_bin.py", "save_run.py", "_common.py"}


def _assign_map(path: Path) -> dict:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) in {
            "TrainConfig",
            "SequenceTrainConfig",
            "AdvConfig",
        }:
            for kw in node.keywords:
                if isinstance(kw.value, ast.Constant):
                    out[kw.arg] = kw.value.value
                elif isinstance(kw.value, ast.List):
                    out[kw.arg] = [
                        elt.id if isinstance(elt, ast.Name) else getattr(elt, "value", None)
                        for elt in kw.value.elts
                    ]
    return out


@_skip_without_notes
def test_readme_table_covers_notes_except_fair():
    from tests.test_cluster_flow_matrix import NOTES_TO_EXAMPLE

    for line in _NOTES.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line.startswith("python "):
            continue
        cmd = line.split()[1]
        if cmd.endswith("fair.py"):
            continue
        stem = Path(cmd).name
        assert stem in NOTES_TO_EXAMPLE, stem
        example, _recipe = NOTES_TO_EXAMPLE[stem]
        assert (_REPO / "examples" / example).is_file()


_CEBRA_NO_ADV = (
    "perich_cebra.py",
    "perich_cebra_time.py",
    "hippo_cebra.py",
    "hippo_cebra_time_mlp.py",
    "hippo_embedding.py",
)

_ACORN_CEBRA_N1_NOZSCORE = (
    "perich_cebra_adv.py",
    "hippo_cebra_adv.py",
)
_ACORN_CEBRA_TIME_ADV = (
    "perich_cebra_time_adv.py",
    "hippo_cebra_adv_time.py",
)
_ACORN_CEBRA_FAMILY = _ACORN_CEBRA_N1_NOZSCORE + _ACORN_CEBRA_TIME_ADV


def test_hypers_vs_frozen_rows():
    for filename, expect in FROZEN_HYPERS.items():
        assigns = _assign_map(_REPO / "examples" / filename)
        text = (_REPO / "examples" / filename).read_text(encoding="utf-8")
        assert "# HYPERS" in text
        sequence = filename.startswith("sequence_")
        for key, value in expect.items():
            if sequence:
                assert key in assigns, (filename, key)
                assert assigns[key] == value, (filename, key, assigns.get(key))
                continue
            if key == "style":
                assert f'style="{value}"' in text or f"style='{value}'" in text
            elif key == "recipe":
                assert value in text
            else:
                assert assigns.get(key, value) == value or key in text


def test_cebra_no_adv_examples_mlp_zscore_off():
    for filename in _CEBRA_NO_ADV:
        assigns = _assign_map(_REPO / "examples" / filename)
        assert assigns["mlp_decoder"] is True, filename
        assert assigns["zscore"] is False, filename
        assert assigns["enabled"] is False, filename


def test_acorn_cebra_family_keeps_gru_and_adv():
    for filename in _ACORN_CEBRA_FAMILY:
        assigns = _assign_map(_REPO / "examples" / filename)
        assert assigns.get("mlp_decoder") is not True, filename
        assert assigns["enabled"] is True, filename
    for filename in _ACORN_CEBRA_N1_NOZSCORE:
        assigns = _assign_map(_REPO / "examples" / filename)
        assert assigns.get("zscore") is False, filename
    for filename in _ACORN_CEBRA_TIME_ADV:
        assigns = _assign_map(_REPO / "examples" / filename)
        assert assigns.get("zscore") is not False, filename


def test_frozen_hypers_covers_train_examples():
    for path in sorted((_REPO / "examples").glob("*.py")):
        if path.name in _SKIP_TRAIN_HYPERS or path.name.startswith("eval_"):
            continue
        text = path.read_text(encoding="utf-8")
        if "train_model(" not in text:
            continue
        assert path.name in FROZEN_HYPERS, path.name


def test_example_overlays_do_not_change_library_defaults():
    cfg = TrainConfig(dataset_keys=["jango"])
    assert cfg.recipe == "offset36_gru"
    assert cfg.enc_lr == 3e-5
    assert cfg.window == 256
    assert cfg.batch_size == 256
    assert cfg.seed == 42
    seq = SequenceTrainConfig(dataset_keys=["nlp21"])
    assert seq.recipe == "offset36_ctc"
    assert seq.n_batch == 20000
    assert seq.batch_size == 16
    assert seq.hidden == 1024
    assert seq.layers == 5
    assert seq.bidir is True
    assert seq.offset == 4
    assert seq.kernel == 32
    assert seq.stride == 4
    assert seq.cont_batch == 1024
    assert seq.enc_lr == 0.02
    assert seq.adv.enabled is True
    assert seq.adv.eps == 0.8
    assert seq.adv.style == "bin"


def test_newcomer_path_points_at_examples_catalog():
    root_readme = (_REPO / "README.md").read_text(encoding="utf-8")
    getting = (_REPO / "docs" / "getting_started.md").read_text(encoding="utf-8")
    assert _README.is_file()
    before_training, rest = root_readme.split("## Training from Python", 1)
    training = rest.split("## Extending", 1)[0]
    assert "demo_nlp21_lm" in before_training
    assert "mgd14" not in root_readme
    assert "runai" not in root_readme
    assert "macorn" not in root_readme
    assert "examples/README.md" in training
    assert "[Examples catalog]" in training
    assert 'recipe="offset36_gru"' in training
    assert "offset36_gru_advdec.py" in training
    next_section = getting.split("## Next", 1)[1]
    assert "start/index.md" in next_section
    assert "mgd14" not in getting
    assert "Library-default" in getting
    assert "demo_time_bin.py`](../examples/demo_time_bin.py) and" not in getting


def test_eval_readme_is_helper_not_cluster_cli():
    text = _README.read_text(encoding="utf-8")
    assert "does not" in text.lower()
    assert "reproduce cluster eval" not in text
    assert "TrainResult" in text
    assert "--help" in text
    assert "python examples/eval_perich.py --help" in text
    assert "Four training recipes" in text
    assert "Three training recipes" not in text
    for name in ("offset36_gru", "offset36_gru_advdec", "offset36_cebra", "offset36_ctc"):
        assert f"`{name}`" in text
    assert "Training scripts accept optional `--output-dir`" in text
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cols = [c.strip() for c in line.strip("|").split("|")]
        if len(cols) < 2:
            continue
        file_col, recipe_col = cols[0], cols[1]
        if "eval_" in file_col:
            assert recipe_col == "helper", line
            assert recipe_col != "eval"


def test_eval_hypers_keep_source_not_recipe_eval():
    for path in sorted((_REPO / "examples").glob("eval_*.py")):
        text = path.read_text(encoding="utf-8")
        assert "recipe=eval" not in text, path.name
        assert "# HYPERS" in text, path.name
        assert "source=" in text, path.name


def test_eval_mains_print_help():
    for path in sorted((_REPO / "examples").glob("eval_*.py")):
        text = path.read_text(encoding="utf-8")
        assert "parser.print_help()" in text, path.name
        tree = ast.parse(text)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == "main":
                prints = [
                    n
                    for n in ast.walk(node)
                    if isinstance(n, ast.Call) and getattr(n.func, "id", None) == "print"
                ]
                assert prints == [], path.name


@pytest.mark.parametrize(
    "script",
    sorted((_REPO / "examples").glob("*.py")),
    ids=lambda path: path.name,
)
def test_example_script_help_exits_0_without_train_model(script: Path):
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join(filter(None, [str(_REPO), env.get("PYTHONPATH", "")]))
    proc = subprocess.run(
        [sys.executable, str(script), "--help"],
        cwd=_REPO,
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    combined = proc.stdout + proc.stderr
    assert proc.returncode == 0, combined
    assert "usage:" in combined.lower()
    if script.name.startswith("eval_"):
        assert "--output-dir" not in combined, script.name
        assert "--seed" not in combined, script.name
        assert "recipe=" not in combined, script.name
        assert "# HYPERS" not in combined, script.name
    elif script.name not in {"save_run.py"}:
        assert "--seed" in combined, script.name


def test_output_dir_parser_seed_default_is_42():
    assert output_dir_parser("x").parse_args([]).seed == 42
    assert output_dir_parser("x").parse_args(["--seed", "0"]).seed == 0


def test_train_examples_pass_cli_seed():
    skip = {"save_run.py", "_common.py"}
    for path in sorted((_REPO / "examples").glob("*.py")):
        if path.name in skip or path.name.startswith("eval_"):
            continue
        text = path.read_text(encoding="utf-8")
        if "train_model(" not in text:
            continue
        assert "seed=args.seed" in text, path.name


def test_default_multi_lists_full_and_ci_does_not_train_them():
    assert len(PERICH_KEYS) == 111
    assert len(HIPPO_KEYS) == 4
    assert SEQUENCE_KEYS == ["speech24", "nlp10", "nlp21", "speech45"]
    oneshot = (_REPO / "examples" / "perich_multi_oneshot.py").read_text(encoding="utf-8")
    assert "PERICH_KEYS" in oneshot
    sequence_multi = (_REPO / "examples" / "sequence_multi.py").read_text(encoding="utf-8")
    assert "SEQUENCE_KEYS" in sequence_multi
    assert '["nlp21", "nlp10"]' not in sequence_multi
    sequence_multi_baseline = (_REPO / "examples" / "sequence_multi_baseline.py").read_text(
        encoding="utf-8"
    )
    assert "SEQUENCE_KEYS" in sequence_multi_baseline
    assert '["nlp21", "nlp10"]' not in sequence_multi_baseline
    tree = ast.parse(Path(__file__).read_text(encoding="utf-8"))
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "train_model"
    ]
    assert calls == []
