"""Tiny CPU lock of eval-time L2 attack vs cluster multi_under_adv math."""

from __future__ import annotations

import torch
import torch.nn as nn

from acorn.eval.adv import l2_attack_eval
from tests.reference_macorn_adv import reference_l2_attack_eval


class _IdEnc(nn.Module):
    def __init__(self):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(1))

    def transform(self, x, session):
        return x + self.bias * 0.0


class _IdDec(nn.Module):
    def __init__(self):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(1))
        self.gru = None

    def forward_window(self, predictions, y, device):
        return predictions, y


def test_l2_attack_eval_matches_cluster_multi_under_adv():
    torch.manual_seed(0)
    x = torch.randn(4, 3)
    y = torch.randn(4, 3)
    prod_enc = _IdEnc()
    prod_dec = _IdDec()
    ref_enc = _IdEnc()
    ref_dec = _IdDec()
    ref_enc.load_state_dict(prod_enc.state_dict())
    ref_dec.load_state_dict(prod_dec.state_dict())
    device = torch.device("cpu")
    got = l2_attack_eval(
        x.clone(),
        y.clone(),
        prod_enc,
        prod_dec,
        "s",
        epsilon=0.2,
        num_steps=3,
        device=device,
    )
    expect = reference_l2_attack_eval(
        x.clone(),
        y.clone(),
        ref_enc,
        ref_dec,
        "s",
        epsilon=0.2,
        num_steps=3,
        device=device,
    )
    torch.testing.assert_close(got, expect)
    assert not torch.allclose(got, x)
