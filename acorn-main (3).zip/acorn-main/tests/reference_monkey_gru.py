"""Reference copies of monkey_gru Offset36_multi and encoder AdamW optimizer.

Used only by tests to check the port is numerically identical. Not imported
by production code.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

import cebra.data
import cebra.models.layers as cebra_layers
from acorn.models.augmentation import GaussianSmoothing

SMOOTH_KERNEL = 20
SMOOTH_SIGMA = 2.0


class Session_layer(nn.Module):
    def __init__(self, num_units, kernel=2) -> None:
        super().__init__()
        self.num_units = num_units
        self.kernel = kernel
        self.session_dict = nn.ModuleDict()

    def add_session(self, session_name, num_neurons):
        self.session_dict.add_module(
            session_name, nn.Conv1d(num_neurons, self.num_units, self.kernel)
        )

    def forward(self, x, session_name):
        return self.session_dict[session_name](x)


class Offset36_multi(nn.Module):
    def _make_layers(self, num_units, p, n):
        return [
            cebra_layers._Skip(
                torch.nn.Dropout1d(p=p), nn.Conv1d(num_units, num_units, 3), nn.GELU()
            )
            for _ in range(n)
        ]

    def __init__(self, num_units, num_outputs, normalize=True) -> None:
        super().__init__()
        self.num_units = num_units
        self.session_layer = Session_layer(num_units, 2)
        net = [
            torch.nn.Dropout1d(p=0.1),
            nn.GELU(),
            *self._make_layers(num_units, 0.1, 16),
        ]
        self.first_net = nn.Sequential(*net)
        self.last_layer_multi = Session_layer(num_outputs, 3)
        self.smoothers = nn.ModuleDict()
        tail = []
        if normalize:
            tail += (cebra_layers._Norm(),)
        tail += (cebra_layers.Squeeze(),)
        self.last_net = nn.Sequential(*tail)

    def _apply_smoother(self, x, session):
        smoother = self.smoothers[session]
        if isinstance(smoother, nn.Identity):
            return x
        x = x.permute(0, 2, 1)
        x = smoother(x)
        return x.permute(0, 2, 1)

    def forward(self, x, session):
        x = self._apply_smoother(x, session)
        x = self.session_layer(x, session)
        x = self.first_net(x)
        x = self.last_layer_multi(x, session)
        x = self.last_net(x)
        return x

    def add_session(self, session_name, num_neurons, use_smooth=False):
        self.session_layer.add_session(session_name, num_neurons)
        self.last_layer_multi.add_session(session_name, self.num_units)
        if use_smooth:
            self.smoothers[session_name] = GaussianSmoothing(
                num_neurons, SMOOTH_KERNEL, SMOOTH_SIGMA, dim=1
            )
        else:
            self.smoothers[session_name] = nn.Identity()

    def get_offset(self):
        return cebra.data.Offset(18, 18)

    def transform(self, x, session):
        offset = self.get_offset()
        x = F.pad(x.unsqueeze(0), (0, 0, offset.left, offset.right - 1), mode="replicate").permute(
            0, 2, 1
        )
        x = self.forward(x, session).squeeze(0).permute(1, 0)
        return x


def reference_monkey_gru_build_encoder_optimizer(params, args):
    """Exact monkey_gru ``multi_trainer._build_encoder_optimizer``."""
    enc_lr = args.get("enc_lr", 3e-5)
    weight_decay = args.get("enc_weight_decay", 0.01)
    opt_name = args.get("enc_optimizer", "adamw").lower()
    adam_eps = args.get("adam_eps")
    opt_kwargs = {"lr": enc_lr, "weight_decay": weight_decay}
    if adam_eps is not None:
        opt_kwargs["eps"] = adam_eps
    if opt_name == "adam":
        opt_kwargs["betas"] = tuple(args.get("adam_betas", (0.9, 0.999)))
        optimizer = torch.optim.Adam(params, **opt_kwargs)
    elif opt_name == "adamw":
        optimizer = torch.optim.AdamW(params, **opt_kwargs)
    else:
        raise ValueError(f"Unknown enc_optimizer={opt_name!r}; use adam or adamw")

    scheduler = None
    if args.get("linear_lr", False):
        lr_end = args.get("lr_end", 0.002)
        if enc_lr <= 0:
            raise ValueError("enc_lr must be > 0 when linear_lr is enabled")
        scheduler = torch.optim.lr_scheduler.LinearLR(
            optimizer,
            start_factor=1.0,
            end_factor=lr_end / enc_lr,
            total_iters=max(args["nBatch"], 1),
        )
    return optimizer, scheduler
