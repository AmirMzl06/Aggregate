"""Tier A / Tier B bit-match tests (tiny CPU fixtures)."""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn.functional as F

from acorn.models.encoder import MonkeyEncoder
from acorn.models.sequence.multi_task_model import SequenceMultiTaskModel
from acorn.models.sequence.unfolder import Unfolder
from acorn.train.config import AdvConfig
from acorn.train.sequence.adversarial_ctc import l2_adv_ctc
from acorn.train.sequence.config import SequenceTrainConfig
from acorn.train.sequence.ctc_trainer import ADAM_EPS, WEIGHT_DECAY, CtcTrainer
from acorn.train.sequence.get_batch import get_batch
from acorn.utils.vendor_path import ensure_vendored_on_path
from tests.reference_speech_b2t import reference_clean_and_pgd_step, reference_get_batch


def _copy_dropoutv2_into_multi(v2, multi, session_key: str) -> None:
    sk = MonkeyEncoder._safe_key(session_key)
    v2_sd = v2.state_dict()
    mapped = {}
    for key, value in v2_sd.items():
        if not key.startswith("net."):
            continue
        parts = key.split(".")
        idx = int(parts[1])
        rest = ".".join(parts[2:])
        if idx == 0:
            mapped[f"session_layer.session_dict.{sk}.{rest}"] = value
        elif 1 <= idx <= 18:
            mapped[f"first_net.{idx - 1}.{rest}"] = value
        elif idx == 19:
            mapped[f"last_layer_multi.session_dict.{sk}.{rest}"] = value
        else:
            mapped[f"last_net.{idx - 20}.{rest}"] = value
    missing = multi.load_state_dict(mapped, strict=False)
    unexpected = [k for k in missing.unexpected_keys if not k.startswith("smoothers.")]
    assert not unexpected, unexpected


def test_n1_trunk_matches_offset36_dropoutv2():
    ensure_vendored_on_path()
    import cebra

    torch.manual_seed(0)
    kernel, stride = 4, 2
    f, t = 6, 40
    ceb_hidden, ceb_out = 16, 8
    in_ch = f * kernel
    v2 = cebra.models.Offset36Dropoutv2(in_ch, ceb_hidden, ceb_out)
    model = SequenceMultiTaskModel(
        ceb_hidden=ceb_hidden,
        ceb_out=ceb_out,
        kernel=kernel,
        stride=stride,
        hidden=8,
        layers=1,
        dropout=0.0,
    )
    model.add_session("nlp21", f, "nlp", use_smooth=False)
    _copy_dropoutv2_into_multi(v2, model.encoder, "nlp21")
    model.eval()
    v2.eval()
    x = torch.randn(2, t, f)
    lengths = torch.tensor([t, t], dtype=torch.long)
    with torch.no_grad():
        embs, _ = model.encode(x, lengths, "nlp21")
        unfolded, _ = Unfolder(kernel, stride)(x, lengths)
        x_c = unfolded.permute(0, 2, 1)
        x_c = F.pad(x_c, (18, 17), mode="replicate")
        ref = v2(x_c)
        if ref.dim() == 2:
            ref = ref.unsqueeze(-1)
        ref = ref.permute(0, 2, 1)
    assert embs.shape == ref.shape
    assert torch.allclose(embs, ref, atol=1e-5, rtol=1e-5)


def test_get_batch_matches_frozen_reference():
    torch.manual_seed(0)
    x = torch.randn(3, 20, 8)
    x_len = torch.tensor([20, 18, 16])
    torch.manual_seed(1)
    got = get_batch(x, x_len, batch_size=7, offset=2)
    torch.manual_seed(1)
    ref = reference_get_batch(x, x_len, 7, 2)
    assert len(got) == len(ref)
    for a, b in zip(got, ref, strict=True):
        assert torch.equal(a, b)


def test_four_sessions_two_shared_heads():
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    pairs = (
        ("speech24", "speech", 5, 5),
        ("nlp10", "nlp", 4, 6),
        ("nlp21", "nlp", 4, 7),
        ("speech45", "speech", 5, 8),
    )
    for key, task, n_cls, n_feat in pairs:
        model.add_session(key, n_feat, task, use_smooth=False)
        model.add_task_head(task, n_cls)
    assert model.session_decoder("speech24") is model.session_decoder("speech45")
    assert model.session_decoder("nlp10") is model.session_decoder("nlp21")
    assert model.session_decoder("speech24") is not model.session_decoder("nlp10")
    assert model.session_keys == ["speech24", "nlp10", "nlp21", "speech45"]
    shared_trunk = model.encoder.first_net
    for key, _task, _n_cls, n_feat in pairs:
        sk = model._safe_key(key)
        conv = model.encoder.session_layer.session_dict[sk]
        assert conv.in_channels == n_feat * 4
        assert model.encoder.first_net is shared_trunk


def test_pgd_inner_loop_detaches_pos_neg():
    text = (
        Path(__file__).resolve().parents[1] / "acorn/train/sequence/adversarial_ctc.py"
    ).read_text(encoding="utf-8")
    assert "positive = embeddings_adv[ref_batch_idx, pos_time_idx].detach()" in text
    assert "negative = embeddings_adv[neg_batch_idx, neg_time_idx].detach()" in text
    assert (
        "ref_batch_idx, ref_time_idx, pos_time_idx, neg_batch_idx, neg_time_idx = triples" in text
    )


def _tiny_ctc_model():
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    model.add_session("nlp21", 6, "nlp", use_smooth=False)
    model.add_task_head("nlp", 5)
    return model


def test_clean_and_pgd_step_matches_frozen_reference(tmp_path):
    """Tier B(2): numeric parity of one clean step + l2 PGD vs frozen trainer.py port."""
    ensure_vendored_on_path()
    import cebra

    torch.manual_seed(7)
    device = torch.device("cpu")
    prod = _tiny_ctc_model()
    ref_model = _tiny_ctc_model()
    ref_model.load_state_dict(prod.state_dict())
    prod.train()
    ref_model.train()

    x = torch.randn(2, 40, 6)
    x_len = torch.tensor([40, 36], dtype=torch.long)
    y = torch.tensor([[1, 2, 3, 0], [2, 1, 0, 0]], dtype=torch.long)
    y_len = torch.tensor([3, 2], dtype=torch.long)
    ctc_criterion = torch.nn.CTCLoss(blank=0, reduction="mean", zero_infinity=True)
    infonce = cebra.models.FixedCosineInfoNCE(0.4).to(device)
    opt_kwargs = {
        "lr": 0.02,
        "betas": (0.9, 0.999),
        "eps": ADAM_EPS,
        "weight_decay": WEIGHT_DECAY,
    }
    opt_prod = torch.optim.Adam(prod.parameters(), **opt_kwargs)
    opt_ref = torch.optim.Adam(ref_model.parameters(), **opt_kwargs)
    cfg = SequenceTrainConfig(
        dataset_keys=["nlp21"],
        n_batch=1,
        batch_size=2,
        kernel=4,
        stride=2,
        hidden=8,
        layers=1,
        dropout=0.0,
        ceb_hidden=16,
        ceb_out=8,
        offset=2,
        cont_batch=8,
        temperature=0.4,
        adv=AdvConfig(enabled=True, eps=0.8, steps=2),
    )
    trainer = CtcTrainer(prod, {}, device, cfg)

    torch.manual_seed(11)
    loss_clean, _ctc, _nce, triples = trainer._clean_step(
        x, y, x_len, y_len, "nlp21", opt_prod, ctc_criterion, infonce
    )
    loss_adv, x_adv = l2_adv_ctc(
        prod,
        opt_prod,
        x,
        y,
        x_len,
        y_len,
        "nlp21",
        ctc_criterion,
        infonce,
        triples,
        adv_eps=0.8,
        adv_steps=2,
        alpha=None,
    )

    torch.manual_seed(11)
    ref_clean, ref_x_adv, ref_adv = reference_clean_and_pgd_step(
        ref_model,
        opt_ref,
        x,
        y,
        x_len,
        y_len,
        "nlp21",
        ctc_criterion,
        infonce,
        cont_batch=8,
        offset=2,
        adv_eps=0.8,
        adv_steps=2,
        alpha=None,
    )
    assert torch.allclose(loss_clean, ref_clean, atol=1e-5, rtol=1e-5)
    assert torch.allclose(x_adv, ref_x_adv, atol=1e-5, rtol=1e-5)
    assert torch.allclose(loss_adv, ref_adv, atol=1e-5, rtol=1e-5)
    for p_a, p_b in zip(prod.parameters(), ref_model.parameters(), strict=True):
        assert torch.allclose(p_a, p_b, atol=1e-5, rtol=1e-5)


def test_ctc_gru_is_bidirectional():
    model = _tiny_ctc_model()
    gru = model.session_decoder("nlp21").gru
    assert gru.bidirectional is True
    assert model.bidir is True
