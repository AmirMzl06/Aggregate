"""adv_alternate=True still rotate + unpermuted global L2."""

from __future__ import annotations

import copy

import torch
import torch.nn as nn

import cebra
import cebra.data
from cebra.solver.single_session import SingleSessionSolver
from tests.reference_cebra_alternate_step import reference_alternate_step


class _TinyEnc(nn.Module):
    def __init__(self):
        super().__init__()
        self.lin = nn.Linear(4, 3)

    def forward(self, x):
        return torch.nn.functional.normalize(self.lin(x.mean(dim=-1)), dim=-1)


def test_cebra_solver_alternate_unchanged():
    torch.manual_seed(0)
    model = _TinyEnc()
    criterion = cebra.models.FixedCosineInfoNCE(0.4)
    opt = torch.optim.Adam(list(model.parameters()) + list(criterion.parameters()), lr=3e-4)
    prod = SingleSessionSolver(
        model=model,
        criterion=criterion,
        optimizer=opt,
        training_mode="adversarial",
        attack_norm="l2",
        adv_alternate=True,
        adv_epsilon=0.5,
        adv_alpha=0.1,
        adv_steps=2,
    )
    prod.perturbed = "ref"
    ref_model = _TinyEnc()
    ref_model.load_state_dict(copy.deepcopy(model.state_dict()))
    ref_crit = cebra.models.FixedCosineInfoNCE(0.4)
    ref_crit.load_state_dict(copy.deepcopy(criterion.state_dict()))
    ref_opt = torch.optim.Adam(list(ref_model.parameters()) + list(ref_crit.parameters()), lr=3e-4)
    ref_opt.load_state_dict(copy.deepcopy(opt.state_dict()))
    frozen = SingleSessionSolver(
        model=ref_model,
        criterion=ref_crit,
        optimizer=ref_opt,
        training_mode="adversarial",
        attack_norm="l2",
        adv_alternate=True,
        adv_epsilon=0.5,
        adv_alpha=0.1,
        adv_steps=2,
    )
    frozen.perturbed = "ref"
    g = torch.Generator().manual_seed(7)
    batch = cebra.data.Batch(
        torch.randn(2, 4, 6, generator=g),
        torch.randn(2, 4, 6, generator=g),
        torch.randn(2, 4, 6, generator=g),
    )
    torch.manual_seed(11)
    prod.step(batch)
    torch.manual_seed(11)
    reference_alternate_step(frozen, batch)
    for k, v in prod.model.state_dict().items():
        torch.testing.assert_close(v, frozen.model.state_dict()[k], atol=1e-5, rtol=1e-5)
