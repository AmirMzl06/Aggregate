"""CPU-synthetic sequence trainer + get_batch + vocabs."""

from __future__ import annotations

import math

import numpy as np
import pytest
import torch

from acorn.data.sequence.collate import SequenceSession, SequenceSplit, collate_fn
from acorn.data.sequence.vocabs import NLP_VOCAB, SPEECH_VOCAB, nlp_text_to_ids
from acorn.eval.sequence.ctc_probe import corpus_cer, greedy_decode
from acorn.eval.sequence.export import SCHEMA
from acorn.models.sequence.multi_task_model import SequenceMultiTaskModel
from acorn.train.config import AdvConfig
from acorn.train.sequence.config import SequenceTrainConfig
from acorn.train.sequence.ctc_trainer import CtcTrainer
from acorn.train.sequence.get_batch import get_batch
from tests.conftest import device_params


def _tiny_split(n_trials=3, t=48, f=6, vocab_size=5) -> SequenceSplit:
    rng = np.random.default_rng(0)
    features = [rng.standard_normal((t, f)).astype(np.float32) for _ in range(n_trials)]
    labels = [rng.integers(1, vocab_size, size=4, dtype=np.int64) for _ in range(n_trials)]
    return SequenceSplit(features=features, labels=labels)


def _tiny_session(key="nlp21", task="nlp", f=6, num_classes=5) -> SequenceSession:
    split = _tiny_split(f=f, vocab_size=num_classes)
    return SequenceSession(
        session_key=key,
        task_key=task,
        use_smooth=False,
        n_features=f,
        num_classes=num_classes,
        vocab=tuple(str(i) for i in range(num_classes)),
        blank_index=0,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )


def test_vocabs_match_upstream_sizes():
    assert len(NLP_VOCAB) == 32
    assert NLP_VOCAB[0] == "<BLANK>"
    assert len(SPEECH_VOCAB) == 41
    assert SPEECH_VOCAB[0] == "<BLANK>"
    assert SPEECH_VOCAB[-1] == "SIL"
    assert nlp_text_to_ids(">cat")[0] == 1


def test_collate_last_frame_replicate_and_no_sort():
    xs = [
        torch.arange(6, dtype=torch.float32).reshape(3, 2),
        torch.arange(4, dtype=torch.float32).reshape(2, 2),
    ]
    ys = [torch.tensor([1, 2]), torch.tensor([3])]
    x_pad, y_pad, in_len, tgt_len = collate_fn(list(zip(xs, ys, strict=True)))
    assert in_len.tolist() == [3, 2]
    assert tgt_len.tolist() == [2, 1]
    assert torch.equal(x_pad[1, 2], xs[1][-1])
    assert y_pad[1, 1] == 0


def test_get_batch_shapes():
    torch.manual_seed(0)
    x = torch.randn(3, 20, 8)
    x_len = torch.tensor([20, 18, 16])
    ref, pos, neg, *idx = get_batch(x, x_len, batch_size=7, offset=2)
    assert ref.shape == (7, 8)
    assert pos.shape == (7, 8)
    assert neg.shape == (7, 8)
    assert idx[0].shape == (7,)


def test_greedy_cer_global_ratio():
    logits = torch.zeros(2, 4, 3)
    logits[0, :, 1] = 1
    logits[1, :2, 2] = 1
    hyps = greedy_decode(logits, torch.tensor([4, 2]), blank=0)
    assert hyps[0] == [1]
    cer = corpus_cer(hyps, [[1], [2, 2]])
    assert 0.0 <= cer <= 1.0


@pytest.mark.parametrize("device", device_params)
def test_ctc_trainer_records_history(tmp_path, device):
    torch.manual_seed(0)
    session = _tiny_session()
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    model.add_session(session.session_key, session.n_features, session.task_key, use_smooth=False)
    model.add_task_head(session.task_key, session.num_classes)
    model.to(device)
    cfg = SequenceTrainConfig(
        dataset_keys=[session.session_key],
        n_batch=2,
        batch_size=2,
        kernel=4,
        stride=2,
        hidden=8,
        layers=1,
        dropout=0.0,
        ceb_hidden=16,
        ceb_out=8,
        offset=2,
        cont_batch=8,
        periodic_eval_every=1,
        adv=AdvConfig(enabled=False),
        device=device.type,
    )
    result = CtcTrainer(model, {session.session_key: session}, device, cfg).run()
    assert next(model.parameters()).device.type == device.type
    rows = result["history"]
    assert any(row["phase"] == "ctc_step" for row in rows)
    for row in rows:
        if row["phase"] == "ctc_step":
            for value in row["losses"].values():
                assert math.isfinite(value)
    assert not (tmp_path / "encoder_best.pt").is_file()
    assert not list(tmp_path.iterdir())


@pytest.mark.parametrize("device", device_params)
def test_train_sequence_model_end_to_end(tmp_path, monkeypatch, device):
    session = _tiny_session()
    monkeypatch.setattr("acorn.runners.sequence.load_sequence_session", lambda *a, **k: session)
    from acorn.runners.sequence import train_sequence_model

    cfg = SequenceTrainConfig(
        dataset_keys=["nlp21"],
        n_batch=2,
        batch_size=2,
        kernel=4,
        stride=2,
        hidden=8,
        layers=1,
        dropout=0.0,
        ceb_hidden=16,
        ceb_out=8,
        offset=2,
        cont_batch=8,
        periodic_eval_every=1,
        adv=AdvConfig(enabled=False),
        device=device.type,
    )
    result = train_sequence_model(cfg)
    assert not (tmp_path / "checkpoint.pt").exists()
    assert not (tmp_path / "metrics.json").exists()
    assert not (tmp_path / "ctc_export_manifest.json").exists()
    export = result.plots["export"]
    assert export["schema"] == SCHEMA
    entry = export["datasets"][0]
    assert entry["dataset_key"] == "nlp21"
    assert entry["task_key"] == "nlp"
    assert entry["session_key"] == "nlp21"
    assert "vocab" in entry
    assert "nlp21" in export["sessions"]
    metrics = result.metrics
    assert "cer_mean" in metrics
    assert math.isfinite(metrics["cer_mean"])
    assert metrics["recipe"] == cfg.recipe
    assert metrics["device"] == device.type
    assert metrics["resolved_device"].startswith(device.type)
    assert result.model is not None


@pytest.mark.parametrize("device", device_params)
def test_ctc_trainer_round_robin_and_pgd_four_sessions(tmp_path, device):
    torch.manual_seed(0)
    keys_tasks = (
        ("speech24", "speech"),
        ("nlp10", "nlp"),
        ("nlp21", "nlp"),
        ("speech45", "speech"),
    )
    sessions = {
        key: _tiny_session(key=key, task=task, f=6, num_classes=5) for key, task in keys_tasks
    }
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    registered_tasks: set[str] = set()
    for key, task in keys_tasks:
        session = sessions[key]
        model.add_session(
            session.session_key, session.n_features, session.task_key, use_smooth=False
        )
        if task not in registered_tasks:
            model.add_task_head(task, session.num_classes)
            registered_tasks.add(task)
    model.to(device)
    cfg = SequenceTrainConfig(
        dataset_keys=[key for key, _task in keys_tasks],
        n_batch=2,
        batch_size=2,
        kernel=4,
        stride=2,
        hidden=8,
        layers=1,
        dropout=0.0,
        ceb_hidden=16,
        ceb_out=8,
        offset=2,
        cont_batch=8,
        periodic_eval_every=10,
        adv=AdvConfig(enabled=True, steps=1),
        device=device.type,
    )
    trainer = CtcTrainer(model, sessions, device, cfg)
    order: list[str] = []
    orig_clean = trainer._clean_step

    def _clean(x, y, x_len, y_len, session_key, *rest):
        order.append(session_key)
        return orig_clean(x, y, x_len, y_len, session_key, *rest)

    trainer._clean_step = _clean
    sched_steps = {"n": 0}
    real_sched = trainer.build_scheduler

    def _sched(optimizer, n_batches):
        sch = real_sched(optimizer, n_batches)
        inner = sch.step

        def _step(*a, **k):
            sched_steps["n"] += 1
            return inner(*a, **k)

        sch.step = _step
        return sch

    trainer.build_scheduler = _sched
    adv_calls = {"n": 0}
    last_adv: dict = {"ret": None}
    orig_adv = trainer._adversarial_step

    def _adv(*a, **k):
        adv_calls["n"] += 1
        last_adv["ret"] = orig_adv(*a, **k)
        return last_adv["ret"]

    trainer._adversarial_step = _adv
    result = trainer.run()
    assert next(model.parameters()).device.type == device.type
    expected = [key for key, _task in keys_tasks]
    assert order == expected + expected
    assert sched_steps["n"] == 2
    assert adv_calls["n"] == 8
    assert last_adv["ret"] is not None
    rows = result["history"]
    for row in rows:
        if row["phase"] == "ctc_step":
            for value in row["losses"].values():
                assert math.isfinite(value)
    assert not (tmp_path / "rr4").exists()


def test_sequence_train_config_defaults():
    cfg = SequenceTrainConfig(dataset_keys=["nlp21"])
    assert cfg.output_dir is None
    assert cfg.recipe == "offset36_ctc"
    assert cfg.enc_lr == 0.02
    assert cfg.n_batch == 20000
    assert cfg.batch_size == 16
    assert cfg.kernel == 32
    assert cfg.stride == 4
    assert cfg.hidden == 1024
    assert cfg.layers == 5
    assert cfg.dropout == 0.4
    assert cfg.offset == 4
    assert cfg.cont_batch == 1024
    assert cfg.temperature == 0.4
    assert cfg.periodic_eval_every == 50
    assert cfg.assume_yes is False
    assert cfg.device == "auto"
    assert cfg.bidir is True


def test_sequence_optimizer_is_adam():
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    model.add_session("nlp21", 6, "nlp", use_smooth=False)
    model.add_task_head("nlp", 5)
    cfg = SequenceTrainConfig(
        dataset_keys=["nlp21"],
        n_batch=1,
        kernel=4,
        stride=2,
        hidden=8,
        layers=1,
        dropout=0.0,
        ceb_hidden=16,
        ceb_out=8,
        cont_batch=8,
    )
    opt = CtcTrainer(model, {}, torch.device("cpu"), cfg).build_optimizer()
    assert type(opt) is torch.optim.Adam
    assert cfg.enc_lr == 0.02
    assert opt.param_groups[0]["lr"] == 0.02
