"""Tiny CPU Solver.step parity: gated False path vs frozen CEBRA-main-time."""

from __future__ import annotations

import copy

import torch
import torch.nn as nn

import cebra
import cebra.data
from cebra.solver.single_session import SingleSessionSolver
from tests.reference_cebra_main_time_step import reference_main_time_step


class _TinyEnc(nn.Module):
    def __init__(self):
        super().__init__()
        self.lin = nn.Linear(4, 3)

    def forward(self, x):
        return torch.nn.functional.normalize(self.lin(x.mean(dim=-1)), dim=-1)


def _batch(seed: int) -> cebra.data.Batch:
    g = torch.Generator().manual_seed(seed)
    ref = torch.randn(2, 4, 6, generator=g)
    pos = torch.randn(2, 4, 6, generator=g)
    neg = torch.randn(2, 4, 6, generator=g)
    return cebra.data.Batch(ref, pos, neg)


def _solver(training_mode: str, *, seed: int = 0) -> SingleSessionSolver:
    torch.manual_seed(seed)
    model = _TinyEnc()
    criterion = cebra.models.FixedCosineInfoNCE(0.4)
    opt = torch.optim.Adam(
        list(model.parameters()) + list(criterion.parameters()), lr=3e-4, weight_decay=0
    )
    return SingleSessionSolver(
        model=model,
        criterion=criterion,
        optimizer=opt,
        training_mode=training_mode,
        attack_norm="l2",
        adv_alternate=False,
        adv_epsilon=0.5,
        adv_alpha=0.1,
        adv_steps=2,
    )


def _clone_solver(src: SingleSessionSolver) -> SingleSessionSolver:
    dst = _solver(src.training_mode, seed=0)
    dst.model.load_state_dict(copy.deepcopy(src.model.state_dict()))
    dst.criterion.load_state_dict(copy.deepcopy(src.criterion.state_dict()))
    dst.optimizer.load_state_dict(copy.deepcopy(src.optimizer.state_dict()))
    return dst


def _assert_state(a: SingleSessionSolver, b: SingleSessionSolver) -> None:
    for ka, va in a.model.state_dict().items():
        torch.testing.assert_close(va, b.model.state_dict()[ka], atol=1e-5, rtol=1e-5)
    for ka, va in a.criterion.state_dict().items():
        torch.testing.assert_close(va, b.criterion.state_dict()[ka], atol=1e-5, rtol=1e-5)
    for group_a, group_b in zip(
        a.optimizer.state_dict()["state"].values(),
        b.optimizer.state_dict()["state"].values(),
        strict=False,
    ):
        for key in group_a:
            if torch.is_tensor(group_a[key]):
                torch.testing.assert_close(group_a[key], group_b[key], atol=1e-5, rtol=1e-5)


def _run_pair(training_mode: str, batches: list) -> None:
    prod = _solver(training_mode, seed=0)
    ref = _clone_solver(prod)
    torch.manual_seed(123)
    for batch in batches:
        torch.manual_seed(123)
        prod.step(batch)
        torch.manual_seed(123)
        reference_main_time_step(ref, batch)
        _assert_state(prod, ref)


def test_cebra_fit_solver_parity_clean_and_l2_then_two_steps():
    b0 = _batch(1)
    b1 = _batch(2)
    _run_pair("clean", [b0])
    _run_pair("adversarial", [b0])
    _run_pair("adversarial", [b0, b1])


def test_false_path_cpu_autocast_disabled(monkeypatch):
    seen = []
    real = torch.autocast

    def _spy(*args, **kwargs):
        seen.append((args, dict(kwargs)))
        return real(*args, **kwargs)

    monkeypatch.setattr(torch, "autocast", _spy)
    prod = _solver("clean", seed=0)
    prod.step(_batch(3))
    enabled_cpu = [
        kw.get("enabled", True)
        for args, kw in seen
        if (args and args[0] == "cpu") or kw.get("device_type") == "cpu"
    ]
    assert enabled_cpu, "expected autocast to be entered on the False path"
    assert all(flag is False for flag in enabled_cpu)


def test_cebra_fit_trainer_training_mode_never_standard():
    from acorn.models.cebra_fit_model import CebraFitModel
    from acorn.train.cebra_fit import CebraFitTrainer

    model = CebraFitModel(ceb_hidden=8, ceb_out=4)
    trainer = CebraFitTrainer(
        model,
        {"s": {"train_x": torch.zeros(4, 3), "train_y": torch.zeros(4, 2)}},
        torch.device("cpu"),
        {"adv": True, "adv_eps": 0.5, "nBatch": 2, "ceb_hidden": 8, "ceb_out": 4},
    )
    kwargs = trainer._cebra_kwargs(True)
    assert kwargs["training_mode"] == "adversarial"
    assert kwargs["adv_alternate"] is False
    assert kwargs["attack_norm"] == "l2"
    assert kwargs["learning_rate"] == 3e-4
    clean = trainer._cebra_kwargs(False)
    assert clean["training_mode"] == "clean"
    assert "standard" not in (kwargs["training_mode"], clean["training_mode"])
