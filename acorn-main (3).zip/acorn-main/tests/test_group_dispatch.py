"""Perich/hippocampus keys use group loaders instead of XDS ``load_day_split``."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from acorn.data.registry import get_dataset
from acorn.runners.multi_session import (
    _load_group_arrays,
    build_session_bundles,
    skip_plot_export,
)
from acorn.train.config import TrainConfig


def test_skip_plot_export_for_perich_and_hippo():
    assert skip_plot_export(get_dataset("perich_c_co_1")) is True
    assert skip_plot_export(get_dataset("hippo_achilles")) is True
    assert skip_plot_export(get_dataset("jango")) is False
    assert skip_plot_export(get_dataset("mihili_co")) is False


def test_build_session_bundles_perich_skips_load_day_split(monkeypatch):
    fake = {
        "train_x": np.ones((10, 3), dtype=np.float32),
        "train_y": np.ones((10, 6), dtype=np.float32),
        "test_x": np.ones((4, 3), dtype=np.float32),
        "test_y": np.ones((4, 6), dtype=np.float32),
    }
    called = {"day_split": 0, "group": 0}

    def _fake_group(spec, assume_yes=False, zscore=True):
        called["group"] += 1
        assert spec.dataset_group == "perich"
        return fake

    def _fake_day_split(*_a, **_k):
        called["day_split"] += 1
        raise AssertionError("load_day_split must not run for Perich keys")

    monkeypatch.setattr("acorn.runners.multi_session._load_group_arrays", _fake_group)
    monkeypatch.setattr("acorn.runners.multi_session.load_day_split", _fake_day_split)
    bundles = build_session_bundles(loader=None, dataset_keys=["perich_c_co_1"])
    assert called == {"day_split": 0, "group": 1}
    bundle = bundles["perich_c_co_1"]
    assert bundle["num_days"] == 1
    assert bundle["dataset_group"] == "perich"
    assert bundle["n_neurons"] == 3
    assert bundle["n_labels"] == 6
    assert isinstance(bundle["train_x"], torch.Tensor)


def test_build_session_bundles_hippo_keeps_full_t(monkeypatch):
    fake = {
        "train_x": np.ones((8, 2), dtype=np.float32),
        "train_y": np.ones((8, 2), dtype=np.float32),
        "test_x": np.ones((2, 2), dtype=np.float32),
        "test_y": np.ones((2, 2), dtype=np.float32),
        "full_x": np.ones((10, 2), dtype=np.float32),
        "full_y": np.ones((10, 2), dtype=np.float32),
    }
    monkeypatch.setattr(
        "acorn.runners.multi_session._load_group_arrays",
        lambda spec, assume_yes=False, zscore=True: fake,
    )
    monkeypatch.setattr(
        "acorn.runners.multi_session.load_day_split",
        lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("no XDS split")),
    )
    bundles = build_session_bundles(loader=None, dataset_keys=["hippo_buddy"])
    bundle = bundles["hippo_buddy"]
    assert bundle["num_days"] == 1
    assert bundle["full_x"].shape == (10, 2)
    assert bundle["n_labels"] == 2


def test_train_config_accepts_new_keys_and_keeps_window():
    cfg = TrainConfig(dataset_keys=["perich_c_co_1", "hippo_achilles"])
    assert cfg.window == 256
    assert cfg.dataset_keys == ["perich_c_co_1", "hippo_achilles"]


def test_multi_session_runner_has_no_sequence_substring():
    src = (
        Path(__file__).resolve().parents[1] / "acorn" / "runners" / "multi_session.py"
    ).read_text(encoding="utf-8")
    assert "sequence" not in src


def test_load_group_arrays_dispatches(monkeypatch):
    monkeypatch.setattr(
        "acorn.data.groups.perich.load.load_perich_session",
        lambda spec, assume_yes=False, zscore=True: {"group": "perich", "key": spec.key},
    )
    monkeypatch.setattr(
        "acorn.data.groups.hippo.load.load_hippo_session",
        lambda spec, assume_yes=False, zscore=True: {"group": "hippo", "key": spec.key},
    )
    perich = _load_group_arrays(get_dataset("perich_t_rt_2"))
    hippo = _load_group_arrays(get_dataset("hippo_gatsby"))
    assert perich == {"group": "perich", "key": "perich_t_rt_2"}
    assert hippo == {"group": "hippo", "key": "hippo_gatsby"}


def test_load_group_arrays_forwards_zscore(monkeypatch):
    seen = {}
    arrays = {
        "train_x": np.ones((4, 2), dtype=np.float32),
        "train_y": np.ones((4, 2), dtype=np.float32),
        "test_x": np.ones((2, 2), dtype=np.float32),
        "test_y": np.ones((2, 2), dtype=np.float32),
    }

    def _perich(spec, assume_yes=False, zscore=True):
        seen["perich"] = zscore
        return arrays

    def _hippo(spec, assume_yes=False, zscore=True):
        seen["hippo"] = zscore
        return arrays

    monkeypatch.setattr("acorn.data.groups.perich.load.load_perich_session", _perich)
    monkeypatch.setattr("acorn.data.groups.hippo.load.load_hippo_session", _hippo)
    _load_group_arrays(get_dataset("perich_c_co_1"), zscore=False)
    _load_group_arrays(get_dataset("hippo_achilles"), zscore=False)
    assert seen["perich"] is False
    assert seen["hippo"] is False


def test_build_session_bundles_records_zscore_false(monkeypatch):
    seen = {}

    def _perich(spec, assume_yes=False, zscore=True):
        seen["zscore"] = zscore
        return {
            "train_x": np.ones((10, 3), dtype=np.float32),
            "train_y": np.ones((10, 6), dtype=np.float32),
            "test_x": np.ones((4, 3), dtype=np.float32),
            "test_y": np.ones((4, 6), dtype=np.float32),
        }

    monkeypatch.setattr("acorn.data.groups.perich.load.load_perich_session", _perich)
    monkeypatch.setattr(
        "acorn.runners.multi_session.load_day_split",
        lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("no XDS split")),
    )
    bundles = build_session_bundles(loader=None, dataset_keys=["perich_c_co_1"], zscore=False)
    assert seen["zscore"] is False
    assert bundles["perich_c_co_1"]["zscore"] is False
