"""Example-script smoke tests (no training)."""

from __future__ import annotations

import pytest


def test_demo_time_bin_download_declined_exits_1(monkeypatch, capsys):
    from acorn.data.download import DownloadDeclined
    from examples.demo_time_bin import main as demo_main

    def _boom(config):
        raise DownloadDeclined("nope")

    monkeypatch.setattr("examples.demo_time_bin.train_model", _boom)
    with pytest.raises(SystemExit) as exc_info:
        demo_main([])
    assert exc_info.value.code == 1
    assert "nope" in capsys.readouterr().out
