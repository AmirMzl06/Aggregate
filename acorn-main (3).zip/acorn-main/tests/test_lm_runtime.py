"""P-04: raise on use, not import; no logits write / docker build."""

from __future__ import annotations

import subprocess

import numpy as np
import pytest
import torch

from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.eval.sequence.export import export_all_sessions
from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.hardware import require_ram
from acorn.lm.presets import original_preset
from acorn.lm.runtime import require_lm_runtime, rescore_export


class _DummyModel:
    def eval(self):
        return self

    def __call__(self, x, x_len, session_key):
        t = x.shape[1]
        return x.new_zeros(x.shape[0], t, 5), x_len


def _tiny_sessions():
    split = SequenceSplit(features=[np.zeros((2, 4), np.float32)], labels=[np.array([1])])
    session = SequenceSession(
        session_key="nlp10",
        task_key="nlp",
        use_smooth=False,
        n_features=4,
        num_classes=5,
        vocab=tuple(str(i) for i in range(5)),
        blank_index=0,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )
    return {"nlp10": session}


def test_require_runtime_raises_without_docker_no_build(monkeypatch, tmp_path):
    builds = []

    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: None)
    monkeypatch.setattr(
        "acorn.lm.docker_run.build_kaldi_image",
        lambda **k: builds.append("kaldi"),
    )
    monkeypatch.setattr(
        "acorn.lm.docker_run.build_neural_image",
        lambda **k: builds.append("neural"),
    )
    with pytest.raises(LmPrerequisiteError, match="docker"):
        require_lm_runtime(["nlp"], assume_yes=True)
    assert builds == []


def test_export_use_lm_missing_docker_writes_no_logits(monkeypatch, tmp_path):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: None)
    builds = []
    monkeypatch.setattr("acorn.lm.docker_run.build_kaldi_image", lambda **k: builds.append("k"))
    monkeypatch.setattr("acorn.lm.docker_run.build_neural_image", lambda **k: builds.append("n"))
    with pytest.raises(LmPrerequisiteError, match="docker"):
        export_all_sessions(
            _DummyModel(),
            _tiny_sessions(),
            torch.device("cpu"),
            use_lm=True,
            assume_yes=True,
        )
    assert not any(tmp_path.rglob("*_logits.pt"))
    assert builds == []


def test_rescore_export_missing_docker_no_metrics(monkeypatch, tmp_path):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: None)
    (tmp_path / "ctc_export_manifest.json").write_text("{}")
    with pytest.raises(LmPrerequisiteError, match="docker"):
        rescore_export(tmp_path, assume_yes=True)
    assert not (tmp_path / "lm_metrics.json").exists()


def test_speech_without_nvidia_raises_before_gpus(monkeypatch):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr("acorn.lm.docker_run._docker_info_text", lambda fmt: "")
    monkeypatch.setattr("acorn.lm.runtime.docker_has_nvidia_runtime", lambda: False)
    ram_calls = []
    monkeypatch.setattr(
        "acorn.lm.runtime.require_ram",
        lambda *a, **k: ram_calls.append(True),
    )
    builds = []
    monkeypatch.setattr("acorn.lm.runtime.ensure_images", lambda **k: builds.append("img"))
    with pytest.raises(LmPrerequisiteError, match="NVIDIA"):
        require_lm_runtime(["speech"], assume_yes=True, host_ram_bytes=400 * 1024**3)
    assert builds == []


def test_speech_dead_daemon_raises_docker_not_nvidia(monkeypatch):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")

    def boom(cmd, *args, **kwargs):
        raise subprocess.CalledProcessError(1, cmd)

    monkeypatch.setattr("acorn.lm.docker_run.subprocess.run", boom)
    with pytest.raises(LmPrerequisiteError, match="daemon") as exc:
        require_lm_runtime(["speech"], assume_yes=True, host_ram_bytes=400 * 1024**3)
    assert "NVIDIA" not in str(exc.value)


def test_nlp_dead_daemon_raises_before_build(monkeypatch):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")
    builds = []
    monkeypatch.setattr("acorn.lm.docker_run.build_kaldi_image", lambda **k: builds.append("k"))
    monkeypatch.setattr("acorn.lm.docker_run.build_neural_image", lambda **k: builds.append("n"))

    def boom(cmd, *args, **kwargs):
        raise subprocess.CalledProcessError(1, cmd)

    monkeypatch.setattr("acorn.lm.docker_run.subprocess.run", boom)
    with pytest.raises(LmPrerequisiteError, match="daemon") as exc:
        require_lm_runtime(["nlp"], assume_yes=True, host_ram_bytes=72 * 1024**3)
    assert "NVIDIA" not in str(exc.value)
    assert "docker build" not in str(exc.value)
    assert builds == []


def test_ram_error_mentions_min_preset_floor(monkeypatch):
    with pytest.raises(LmPrerequisiteError, match=r"min\(preset, floor\(0\.9\*host\)\)") as exc:
        require_ram(original_preset("nlp"), available=8 * 1024**3)
    msg = str(exc.value)
    assert "64" in msg
    require_ram(original_preset("nlp"), available=int(72 * 1024**3))
