"""P-03: original_preset mapping; never speech 3-gram on the True path."""

from __future__ import annotations

import math
from pathlib import Path

import pytest

from acorn.lm.presets import original_preset

_LM = Path(__file__).resolve().parents[1] / "acorn" / "lm"
_TRUE_PATH = (
    _LM / "presets.py",
    _LM / "runtime.py",
    _LM / "download.py",
    _LM / "docker_run.py",
)


def test_original_preset_nlp():
    preset = original_preset("nlp")
    assert preset.graph_tier == "nlp_3gram"
    assert preset.search_acoustic_scale == 0.8
    assert preset.nbest == 10
    assert preset.beam == 17.0
    assert preset.blank_penalty == pytest.approx(math.log(11.0))
    assert preset.mix_acoustic_scale == 0.5
    assert preset.neural_alpha == 1.0
    assert preset.neural_model == "gpt2-xl"
    assert preset.neural_8bit is False
    assert preset.lattice_rescore is False


def test_original_preset_speech():
    preset = original_preset("speech")
    assert preset.graph_tier == "speech_5gram"
    assert preset.search_acoustic_scale == 0.5
    assert preset.nbest == 100
    assert preset.beam == 18.0
    assert preset.blank_penalty == pytest.approx(math.log(7.0))
    assert preset.lattice_rescore is True
    assert preset.neural_alpha == 0.5
    assert preset.neural_model == "facebook/opt-6.7b"
    assert preset.neural_8bit is True
    assert preset.mix_acoustic_scale == 0.5


def test_true_path_never_selects_speech_3gram_or_nlp_mix_08():
    assert original_preset("speech").name != "speech_3gram"
    assert original_preset("nlp").mix_acoustic_scale != 0.8
    for path in _TRUE_PATH:
        text = path.read_text(encoding="utf-8")
        assert "speech_3gram" not in text
        assert "hero_preset" not in text
        assert "languageModel.tar.gz" not in text
