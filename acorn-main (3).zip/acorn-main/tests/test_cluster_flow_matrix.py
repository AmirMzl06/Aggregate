"""Notes → example → recipe matrix, loader styles, hippo_all, attack geometry."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
import torch

from acorn.data.groups.hippo.load import hippo_all_from_full
from acorn.models.registry import get_recipe
from acorn.train.adversarial import init_adv_noise, pgd_step
from acorn.train.cebra_contrastive import build_cebra_loader, build_cebra_train_dataset
from acorn.train.config import TrainConfig
from examples._common import HIPPO_KEYS, PERICH_KEYS
from tests.reference_macorn_adv import (
    reference_cluster_pgd_init,
    reference_cluster_pgd_step,
    reference_oneshot_init,
)
from tests.reference_macorn_cluster import reference_hippo_all_from_full

_REPO = Path(__file__).resolve().parents[1]
_NOTES = _REPO / ".docs" / "perich_hippo_notes.txt"
_skip_without_notes = pytest.mark.skipif(
    not _NOTES.is_file(),
    reason="private notes file is not in this checkout",
)

NOTES_TO_EXAMPLE = {
    "single_runai_time.py": ("perich_cebra_adv.py", "offset36_cebra"),
    "single_runai_time_no_noise.py": ("perich_cebra_time_adv.py", "offset36_cebra"),
    "runai_perich_cebra.py": ("perich_cebra.py", "offset36_cebra"),
    "runai_perich_cebra_time.py": ("perich_cebra_time.py", "offset36_cebra"),
    "multi_runai_final.py": ("perich_multi_oneshot.py", "offset36_gru"),
    "macorn_perich_old_time.py": ("perich_multi.py", "offset36_gru"),
    "multi_runai_final_no_noise.py": ("perich_multi_time.py", "offset36_gru"),
    "multi_runai_final_hippo.py": ("hippo_multi.py", "offset36_gru"),
    "multi_runai_final_hippo_all.py": ("hippo_all.py", "offset36_gru"),
    "runai_hippo_single.py": ("hippo_cebra.py", "offset36_cebra"),
    "runai_hippo_cebra_time.py": ("hippo_cebra_time_mlp.py", "offset36_cebra"),
    "hippo_script.py": ("eval_hippo.py", "eval"),
    "perich_script.py": ("eval_perich.py", "eval"),
    "multi_perich_script.py": ("eval_perich_multi.py", "eval"),
    "multi_hippo_script.py": ("eval_hippo_multi.py", "eval"),
    "save_details.py": ("eval_details.py", "eval"),
    "save_details_hippo.py": ("eval_details_hippo.py", "eval"),
    "runai_hippo_single_emb.py": ("hippo_embedding.py", "offset36_cebra"),
    "multi_embedding_script.py": ("eval_embeddings_hippo_multi.py", "eval"),
    "hippo_embedding.py": ("hippo_embedding.py", "offset36_cebra"),
    "consistency_calculator.py": ("eval_consistency.py", "eval"),
    "embeddings_plot.py": ("eval_plot_embeddings.py", "eval"),
}


@_skip_without_notes
def test_notes_commands_except_fair_have_examples():
    text = _NOTES.read_text(encoding="utf-8")
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("python "):
            continue
        cmd = line.split()[1]
        if cmd == "setup_no_shuffle/fair.py":
            continue
        name = Path(cmd).name
        assert name in NOTES_TO_EXAMPLE, name
        example, _recipe = NOTES_TO_EXAMPLE[name]
        assert (_REPO / "examples" / example).is_file()


def test_multi_key_lists_are_full_grids():
    assert len(PERICH_KEYS) == 111
    assert len(HIPPO_KEYS) == 4


def test_library_defaults_unchanged():
    cfg = TrainConfig(dataset_keys=["jango"])
    assert cfg.recipe == "offset36_gru"
    assert cfg.enc_lr == 3e-5
    assert cfg.batch_size == 256
    assert cfg.window == 256
    assert cfg.conditional == "time_delta"
    assert cfg.decoder_adv == "off"
    assert cfg.adv.style == "bin"
    assert cfg.mlp_decoder is False
    assert cfg.full_session is False


def test_oneshot_and_cluster_pgd_not_bin():
    ref = torch.randn(2, 5, 7)
    torch.manual_seed(0)
    oneshot = init_adv_noise(ref, 0.5, "oneshot", ref.device)
    torch.manual_seed(0)
    bin_noise = init_adv_noise(ref, 0.5, "bin", ref.device)
    torch.manual_seed(0)
    cluster = init_adv_noise(ref, 0.5, "cluster_pgd", ref.device)
    assert oneshot.shape == ref.shape == cluster.shape == bin_noise.shape
    assert not torch.allclose(oneshot, bin_noise)
    assert not torch.allclose(cluster, bin_noise)
    torch.manual_seed(0)
    torch.testing.assert_close(oneshot, reference_oneshot_init(ref, 0.5))
    torch.manual_seed(0)
    torch.testing.assert_close(cluster, reference_cluster_pgd_init(ref, 0.5))
    dummy_grad = torch.ones_like(ref)
    torch.manual_seed(1)
    stepped = pgd_step(cluster.clone(), dummy_grad, ref, 0.5, 0.1, "cluster_pgd")
    torch.manual_seed(1)
    ref_step = reference_cluster_pgd_step(cluster.clone(), dummy_grad, ref, 0.5, 0.1)
    torch.testing.assert_close(stepped, ref_step)


def test_time_loader_styles():
    x = np.random.randn(80, 6).astype(np.float32)
    y = np.random.randn(80, 2).astype(np.float32)

    from acorn.models.offset36_multi import Offset36_multi

    offset = Offset36_multi(8, 4).get_offset()
    ds = build_cebra_train_dataset(x, y, offset, torch.device("cpu"))
    assert ds.continuous_index is not None

    perich_time = build_cebra_loader(ds, 8, 2, 1, conditional="time", is_cont=False)
    hippo_time = build_cebra_loader(ds, 8, 2, 1, conditional="time", is_cont=None)
    b0 = next(iter(perich_time))
    b1 = next(iter(hippo_time))
    assert b0.reference.shape[0] == 8
    assert b1.reference.shape[0] == 8
    assert type(perich_time.distribution).__name__ == "TimeContrastive"
    assert type(hippo_time.distribution).__name__ == "TimeContrastive"
    assert perich_time.conditional == "time"
    assert hippo_time.conditional == "time"

    # Perich Offset36_multi --time: is_cont=False forces time sampling even if
    # labels stay on the dataset (time_delta extra is ignored).
    perich_forced = build_cebra_loader(ds, 8, 2, 1, conditional="time_delta", is_cont=False)
    assert ds.continuous_index is not None
    assert perich_forced.conditional == "time"
    assert type(perich_forced.distribution).__name__ == "TimeContrastive"

    # Hippo Offset36_multi --time: keep labels and only set conditional="time".
    # With is_cont=None the labels are used when conditional is time_delta.
    hippo_delta = build_cebra_loader(ds, 8, 2, 1, conditional="time_delta", is_cont=None)
    assert ds.continuous_index is not None
    assert hippo_delta.conditional == "time_delta"
    assert type(hippo_delta.distribution).__name__ == "TimedeltaDistribution"


def test_hippo_all_from_full_independent_zscore():
    full_x = np.arange(12, dtype=np.float64).reshape(6, 2)
    full_y = np.ones((6, 2), dtype=np.float64)
    out = hippo_all_from_full(full_x, full_y)
    expect = reference_hippo_all_from_full(full_x, full_y)
    np.testing.assert_allclose(out["train_x"], out["test_x"])
    np.testing.assert_allclose(out["train_y"], full_y)
    np.testing.assert_allclose(out["train_x"], expect["train_x"])
    assert out["train_x"].shape == full_x.shape


def test_dropoutv2_forward_not_claimed_as_training_step_match():
    text = (_REPO / "docs" / "adding_a_recipe.md").read_text(encoding="utf-8")
    assert "not an N=1" in text.lower() or "not an N=1" in text
    assert "CEBRA.fit" in text


def test_n1_perich_multi_not_claimed_as_cebra_fit():
    src = (_REPO / "examples" / "perich_multi.py").read_text(encoding="utf-8")
    assert "offset36_gru" in src
    assert "offset36_cebra" not in src
    assert get_recipe("offset36_gru").name == "offset36_gru"
    assert get_recipe("offset36_cebra").name == "offset36_cebra"
