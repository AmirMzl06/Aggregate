"""Frozen CEBRA-main-time Solver.step + amp_ctx (cluster tree, not vendored True body)."""

from __future__ import annotations

import torch

import cebra.data


def amp_ctx(device):
    use_cuda = device.type == "cuda"
    return torch.autocast(
        "cuda" if use_cuda else "cpu",
        dtype=torch.bfloat16,
        enabled=use_cuda,
    )


def reference_main_time_step(solver, batch: cebra.data.Batch) -> dict:
    solver.optimizer.zero_grad()
    device = batch.reference.device
    with amp_ctx(device):
        pred = solver._inference(batch)
        loss, align, uniform = solver.criterion(pred.reference, pred.positive, pred.negative)
    loss.backward()
    solver.optimizer.step()

    solver.history.append(loss.item())
    stats = dict(
        pos=align.item(),
        neg=uniform.item(),
        total=loss.item(),
        temperature=solver.criterion.temperature,
    )

    if solver.training_mode == "adversarial":
        if solver.attack_norm == "l2":
            solver.optimizer.zero_grad()
            adv_eps, adv_alpha, adv_steps = solver.adv_epsilon, solver.adv_alpha, solver.adv_steps
            x_adv = batch.reference.clone().detach().permute(0, 2, 1)
            noise = torch.randn_like(x_adv)
            noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
            noise_normalized = noise / noise_norm
            noise_normalized *= (
                torch.rand((noise.shape[0], noise.shape[1], 1), device=noise.device) * adv_eps
            )
            x_adv = x_adv + noise_normalized
            x_adv = x_adv.permute(0, 2, 1)
            x_adv.requires_grad_(True)
            for _ in range(adv_steps):
                if x_adv.grad is not None:
                    x_adv.grad.zero_()
                with amp_ctx(device):
                    adv_b = cebra.data.Batch(
                        reference=x_adv, positive=batch.positive, negative=batch.negative
                    )
                    adv_out = solver._inference(adv_b)
                    adv_loss, _, _ = solver.criterion(
                        adv_out.reference, adv_out.positive, adv_out.negative
                    )
                (grad,) = torch.autograd.grad(
                    adv_loss, x_adv, retain_graph=False, create_graph=False
                )
                with torch.no_grad():
                    grad = grad.permute(0, 2, 1)
                    x_adv = x_adv.permute(0, 2, 1)
                    grad_norm = grad.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
                    x_adv = (x_adv + adv_alpha * (grad / grad_norm)).detach()
                    delta = x_adv - batch.reference.permute(0, 2, 1)
                    delta_norm = delta.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
                    scale = torch.clamp(adv_eps / delta_norm, max=1.0)
                    x_adv = (batch.reference + (delta * scale).permute(0, 2, 1)).detach()
                    x_adv.requires_grad_(True)
            adv_b = cebra.data.Batch(
                reference=x_adv, positive=batch.positive, negative=batch.negative
            )
            with amp_ctx(device):
                out = solver._inference(adv_b)
                loss3, _, _ = solver.criterion(out.reference, out.positive, out.negative)
            loss3.backward()
            solver.optimizer.step()

    if solver.scheduler is not None:
        solver.scheduler.step()
    for k, v in stats.items():
        solver.log[k].append(v)
    return stats
