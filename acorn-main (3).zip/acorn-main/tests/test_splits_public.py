"""Tests for load_day_split / load_day_trials temporal boundaries."""

from __future__ import annotations

import numpy as np
import torch

from acorn.data.splits import TRAIN_FRAC, load_day_split, load_day_trials


class _FakeDayLoader:
    def __init__(self, x_list, y_list):
        self.x_list = x_list
        self.y_list = y_list

    def load_dataset_day(self, day_idx, dataset_name, stack=True, xds_smooth=True):
        if stack:
            return np.vstack(self.x_list), np.vstack(self.y_list)
        return list(self.x_list), list(self.y_list)


def test_train_frac_constant():
    assert TRAIN_FRAC == 0.8


def test_load_day_split_contiguous_fraction():
    spikes = np.arange(100, dtype=np.float32).reshape(100, 1)
    labels = np.arange(100, dtype=np.float32).reshape(100, 1)
    loader = _FakeDayLoader([spikes], [labels])
    train_x, test_x, train_y, test_y = load_day_split(loader, "fake", 0, zscore=False)
    assert train_x.shape[0] == 80
    assert test_x.shape[0] == 20
    assert float(train_y[0, 0]) == 0.0
    assert float(test_y[0, 0]) == 80.0


def test_load_day_trials_splits_on_cumulative_time():
    # 30 + 30 + 40 bins = 100; split at 80 → first two trials train, last trial split 20/20.
    x_list = [
        np.ones((30, 2), dtype=np.float32),
        np.ones((30, 2), dtype=np.float32) * 2,
        np.ones((40, 2), dtype=np.float32) * 3,
    ]
    y_list = [np.full((x.shape[0], 1), i, dtype=np.float32) for i, x in enumerate(x_list)]
    loader = _FakeDayLoader(x_list, y_list)
    train_trials, test_trials, train_x, train_y, test_x, test_y = load_day_trials(
        loader, "fake", 0, zscore=False
    )
    assert [t[0].shape[0] for t in train_trials] == [30, 30, 20]
    assert [t[0].shape[0] for t in test_trials] == [20]
    assert train_x.shape[0] == 80
    assert test_x.shape[0] == 20
    assert float(train_y[-1, 0]) == 2.0
    assert float(test_y[0, 0]) == 2.0


def test_load_day_trials_zscore_zeros_constant_train_channel():
    x_list = [
        np.stack([np.ones(50), np.linspace(0, 1, 50)], axis=1).astype(np.float32),
        np.stack([np.ones(50), np.linspace(1, 2, 50)], axis=1).astype(np.float32),
    ]
    y_list = [np.zeros((50, 1), dtype=np.float32), np.zeros((50, 1), dtype=np.float32)]
    loader = _FakeDayLoader(x_list, y_list)
    _, _, train_x, _, test_x, _ = load_day_trials(loader, "fake", 0, zscore=True)
    assert torch.allclose(train_x[:, 0], torch.zeros(train_x.shape[0]))
    assert torch.allclose(test_x[:, 0], torch.zeros(test_x.shape[0]))
