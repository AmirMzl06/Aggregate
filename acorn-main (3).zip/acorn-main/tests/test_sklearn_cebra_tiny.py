"""Tiny sklearn CEBRA.fit constructor lock (CPU)."""

from __future__ import annotations

import numpy as np
import torch

from acorn.utils.vendor_path import ensure_vendored_on_path


def _tiny_cebra_kwargs(**extra):
    kwargs = dict(
        model_architecture="offset36-model-more-dropout",
        num_hidden_units=8,
        output_dimension=4,
        max_iterations=2,
        batch_size=16,
        learning_rate=3e-4,
        device="cpu",
        verbose=False,
        temperature=0.4,
        time_offsets=1,
        adv_alternate=False,
        attack_norm="l2",
        training_mode="clean",
    )
    kwargs.update(extra)
    return kwargs


def test_sklearn_cebra_tiny_cpu_fit_constructor():
    ensure_vendored_on_path()
    from cebra import CEBRA

    data = np.random.randn(64, 8).astype(np.float32)
    labels = np.random.randn(64, 2).astype(np.float32)
    model = CEBRA(**_tiny_cebra_kwargs())
    assert model.adv_alternate is False
    assert model.attack_norm == "l2"
    assert model.training_mode == "clean"
    assert model.learning_rate == 3e-4
    assert not hasattr(model, "conditional") or model.conditional is None
    model.fit(data, labels)
    emb = model.transform(data)
    assert emb.shape[0] == data.shape[0]
    assert emb.shape[1] == 4


def test_cebra_fit_transform_keeps_input_grad():
    """Eval L2 attack needs a graph through sklearn CEBRA ``model_``."""
    ensure_vendored_on_path()
    from acorn.models.cebra_fit_model import CebraFitModel
    from cebra import CEBRA

    data = np.random.randn(64, 8).astype(np.float32)
    estimator = CEBRA(**_tiny_cebra_kwargs())
    estimator.fit(data)
    wrapper = CebraFitModel(ceb_hidden=8, ceb_out=4)
    wrapper.add_session("s", 8, n_labels=2)
    wrapper.attach_estimator(estimator)
    wrapper.eval()

    detached = wrapper.transform(torch.as_tensor(data), "s")
    np.testing.assert_allclose(detached.numpy(), estimator.transform(data), atol=1e-5)

    x = torch.tensor(data, dtype=torch.float32, requires_grad=True)
    emb = wrapper.transform(x, "s")
    assert emb.requires_grad
    grad = torch.autograd.grad(emb.sum(), x)[0]
    assert torch.isfinite(grad).all()
    assert float(grad.abs().sum()) > 0


def test_sklearn_cebra_tiny_unlabeled_fit_omits_conditional():
    """Perich time-clean: constructor omits conditional and calls fit(data,)."""
    ensure_vendored_on_path()
    from cebra import CEBRA

    data = np.random.randn(64, 8).astype(np.float32)
    kwargs = _tiny_cebra_kwargs()
    assert "conditional" not in kwargs
    model = CEBRA(**kwargs)
    assert getattr(model, "conditional", None) is None
    model.fit(data)
    emb = model.transform(data)
    assert emb.shape[0] == data.shape[0]
    assert emb.shape[1] == 4


class _FakeCEBRA:
    last_init = None
    last_fit = None

    def __init__(self, **kwargs):
        type(self).last_init = dict(kwargs)
        self.offset_ = None

    def fit(self, *args, **kwargs):
        type(self).last_fit = (args, dict(kwargs))
        return self


def _trainer(args: dict):
    from acorn.models.cebra_fit_model import CebraFitModel
    from acorn.train.cebra_fit import CebraFitTrainer

    model = CebraFitModel(ceb_hidden=8, ceb_out=4)
    return CebraFitTrainer(
        model,
        {"s": {"train_x": torch.zeros(8, 4), "train_y": torch.zeros(8, 2)}},
        torch.device("cpu"),
        {"nBatch": 2, "ceb_hidden": 8, "ceb_out": 4, "batchSize": 8, **args},
    )


def test_cebra_fit_trainer_fit_arity_and_training_mode(monkeypatch):
    ensure_vendored_on_path()
    import cebra

    monkeypatch.setattr(cebra, "CEBRA", _FakeCEBRA)

    time_clean = _trainer({"adv": False, "conditional": None})
    kwargs = time_clean._cebra_kwargs(False)
    assert "conditional" not in kwargs
    assert kwargs["training_mode"] == "clean"
    assert kwargs["training_mode"] != "standard"
    time_clean.run()
    assert len(_FakeCEBRA.last_fit[0]) == 1

    hippo_time = _trainer({"adv": False, "conditional": "time"})
    kwargs = hippo_time._cebra_kwargs(False)
    assert kwargs["conditional"] == "time"
    hippo_time.run()
    assert len(_FakeCEBRA.last_fit[0]) == 1

    labeled = _trainer({"adv": False, "conditional": "time_delta"})
    labeled.run()
    assert len(_FakeCEBRA.last_fit[0]) == 2

    adv = _trainer({"adv": True, "conditional": "time_delta"})
    kwargs = adv._cebra_kwargs(True)
    assert kwargs["training_mode"] == "adversarial"
    assert kwargs["training_mode"] != "standard"
    assert kwargs["adv_alternate"] is False
    assert kwargs["attack_norm"] == "l2"
    adv.run()
    assert _FakeCEBRA.last_init["training_mode"] == "adversarial"
    assert "standard" not in (
        kwargs["training_mode"],
        _FakeCEBRA.last_init["training_mode"],
    )
