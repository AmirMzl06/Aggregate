"""Sequence-format unit tests: Unfolder, CTC head, task-keyed model, collate."""

from __future__ import annotations

import torch

from acorn.models.multi_session import MultiSessionModel
from acorn.models.sequence.interfaces import SequenceEncoderModel
from acorn.models.sequence.multi_task_model import SequenceMultiTaskModel
from acorn.models.sequence.task_head import CtcTaskHead
from acorn.models.sequence.unfolder import Unfolder
from acorn.train.sequence.adversarial_ctc import ctc_adv_alpha
from tests.reference_speech_b2t import (
    reference_ctc_adv_alpha,
    reference_unfold_ctc_length,
    reference_unfold_tensor_length,
)


def test_unfolder_tensor_and_length_formulas_differ():
    kernel, stride, t = 32, 4, 40
    x = torch.randn(2, t, 6)
    lengths = torch.tensor([t, t], dtype=torch.long)
    out, out_len = Unfolder(kernel, stride)(x, lengths)
    tensor_t = reference_unfold_tensor_length(t, kernel, stride)
    ctc_t = reference_unfold_ctc_length(t, kernel, stride)
    assert tensor_t == 3
    assert ctc_t == 2
    assert tensor_t == ctc_t + 1
    assert out.shape == (2, tensor_t, 6 * kernel)
    assert out_len.tolist() == [ctc_t, ctc_t]


def test_ctc_head_does_not_pack_and_has_right_width():
    head = CtcTaskHead(num_classes=5, ceb_out=8, hidden=16, layers=1, dropout=0.0, bidir=True)
    embs = torch.randn(2, 7, 8)
    logits = head(embs, lengths=torch.tensor([7, 5]))
    assert logits.shape == (2, 7, 5)


def test_sequence_model_shares_task_head():
    model = SequenceMultiTaskModel(
        ceb_hidden=16, ceb_out=8, kernel=4, stride=2, hidden=8, layers=1, dropout=0.0
    )
    model.add_session("speech24", num_neurons=6, task_key="speech", use_smooth=False)
    model.add_session("speech45", num_neurons=6, task_key="speech", use_smooth=False)
    model.add_task_head("speech", num_classes=5)
    assert model.session_decoder("speech24") is model.session_decoder("speech45")
    assert isinstance(model, SequenceEncoderModel)
    x = torch.randn(2, 40, 6)
    lengths = torch.tensor([40, 40], dtype=torch.long)
    logits, out_len = model(x, lengths, "speech24")
    assert logits.shape[0] == 2
    assert logits.shape[-1] == 5
    assert out_len.dtype == torch.int32


def test_task_key_default_preserves_one_to_one():
    model = MultiSessionModel(ceb_hidden=16, ceb_out=4)
    model.add_session("jango", num_neurons=8, n_labels=2, use_smooth=False)
    model.add_session("pop", num_neurons=8, n_labels=2, use_smooth=False)

    class _Dec(torch.nn.Module):
        def forward(self, embs, lengths=None):
            return embs

    d1, d2 = _Dec(), _Dec()
    model.set_session_decoder("jango", d1)
    model.set_session_decoder("pop", d2)
    assert model.session_decoder("jango") is d1
    assert model.session_decoder("pop") is d2


def test_shared_task_key_returns_same_head():
    model = MultiSessionModel(ceb_hidden=16, ceb_out=4)
    model.add_session("a", num_neurons=8, n_labels=2, use_smooth=False, task_key="t")
    model.add_session("b", num_neurons=8, n_labels=2, use_smooth=False, task_key="t")

    class _Dec(torch.nn.Module):
        def forward(self, embs, lengths=None):
            return embs

    dec = _Dec()
    model.set_session_decoder("a", dec)
    assert model.session_decoder("b") is dec


def test_ctc_adv_alpha_is_eps_over_five_not_two_eps_over_steps():
    assert ctc_adv_alpha(0.8) == reference_ctc_adv_alpha(0.8)
    assert ctc_adv_alpha(0.8) == 0.16
    from acorn.train.adversarial import default_adv_alpha

    assert default_adv_alpha(0.8, 5, "bin") != ctc_adv_alpha(0.8)
