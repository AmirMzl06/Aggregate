"""JSONL history writer: append, flush, survive an existing file."""

from __future__ import annotations

import json

from acorn.utils.history import HISTORY_FILENAME, append_history


def test_append_history_writes_valid_jsonl(tmp_path):
    append_history(tmp_path, {"phase": "encoder_step", "step": 0, "val_loss": 1.25})
    dest = tmp_path / HISTORY_FILENAME
    assert dest.is_file()
    rows = [json.loads(line) for line in dest.read_text(encoding="utf-8").splitlines()]
    assert rows == [{"phase": "encoder_step", "step": 0, "val_loss": 1.25}]


def test_append_history_appends_across_calls(tmp_path):
    append_history(tmp_path, {"phase": "encoder_step", "step": 0})
    append_history(tmp_path, {"phase": "encoder_best", "step": 1, "val_loss": 0.9})
    rows = [
        json.loads(line)
        for line in (tmp_path / HISTORY_FILENAME).read_text(encoding="utf-8").splitlines()
    ]
    assert [row["phase"] for row in rows] == ["encoder_step", "encoder_best"]
    assert rows[1]["val_loss"] == 0.9


def test_append_history_survives_existing_file(tmp_path):
    dest = tmp_path / HISTORY_FILENAME
    dest.write_text('{"phase": "preexisting"}\n', encoding="utf-8")
    append_history(tmp_path, {"phase": "encoder_step", "step": 2})
    rows = [json.loads(line) for line in dest.read_text(encoding="utf-8").splitlines()]
    assert rows[0] == {"phase": "preexisting"}
    assert rows[1]["step"] == 2
