"""Shared pytest device parametrization (not an autouse fixture)."""

from __future__ import annotations

import pytest
import torch

requires_cuda = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
device_params = [
    pytest.param(torch.device("cpu"), id="cpu"),
    pytest.param(
        torch.device("cuda"),
        marks=[requires_cuda, pytest.mark.gpu],
        id="cuda",
    ),
]
