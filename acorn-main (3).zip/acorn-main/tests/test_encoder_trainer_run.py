"""EncoderTrainer.run with synthetic sessions (CPU and CUDA when available)."""

from __future__ import annotations

import math

import pytest
import torch

from acorn.models.multi_session import MultiSessionModel
from acorn.train.encoder_trainer import EncoderTrainer
from tests.conftest import device_params, requires_cuda


def _tiny_encoder_run(tmp_path, device: torch.device, *, adv: bool, adv_steps: int):
    torch.manual_seed(0)
    model = MultiSessionModel(ceb_hidden=32, ceb_out=8)
    model.add_session("s", num_neurons=16, n_labels=2, use_smooth=False)
    model.to(device)
    t = 80
    bundles = {
        "s": {
            "train_x": torch.randn(t, 16, device=device),
            "train_y": torch.randn(t, 2, device=device),
        }
    }
    args = {
        "nBatch": 4,
        "batchSize": 8,
        "time_offset": 4,
        "temperature": 0.4,
        "enc_lr": 3e-5,
        "adv": adv,
        "adv_steps": adv_steps,
        "adv_eps_mode": "fixed",
        "encoder_val_checkpoint": True,
    }
    result = EncoderTrainer(model, bundles, device, args).run()
    assert next(model.parameters()).device.type == device.type
    assert result["encoder_val_checkpoint"] is True
    assert not (tmp_path / "encoder_best.pt").exists()
    history = result["history"]
    step_rows = [row for row in history if row["phase"] == "encoder_step"]
    assert len(step_rows) == args["nBatch"]
    for row in step_rows:
        for value in row["losses"].values():
            assert math.isfinite(value)
        if adv:
            assert math.isfinite(row["adv"])
    assert any(row["phase"] == "encoder_best" for row in history)
    assert result["encoder_best_step"] >= 1
    assert math.isfinite(result["encoder_best_val_loss"])
    return result, model


@pytest.mark.parametrize("device", device_params)
def test_encoder_trainer_run_keeps_best_weights_in_ram(tmp_path, device):
    _tiny_encoder_run(tmp_path, device, adv=False, adv_steps=1)


@pytest.mark.parametrize("device", device_params)
def test_encoder_trainer_run_adv_keeps_history_in_ram(tmp_path, device):
    _tiny_encoder_run(tmp_path, device, adv=True, adv_steps=1)


@requires_cuda
@pytest.mark.gpu
def test_encoder_trainer_run_adv_two_steps(tmp_path):
    device = torch.device("cuda")
    _tiny_encoder_run(tmp_path, device, adv=True, adv_steps=2)
