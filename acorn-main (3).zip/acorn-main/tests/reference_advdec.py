"""Reference copies of offset36_gru_advdec (commit 489a733) optimizer + decoder-PGD math.

Used only by tests to check the port is numerically identical. Not imported
by production code.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import optim

from acorn.train.adversarial import l2_normalize, proj_l2_ball, rand_radius_like


def reference_advdec_build_optimizer(params, enc_lr: float, n_batches: int):
    """Exact 489a733 encoder optimizer + LinearLR."""
    optimizer = torch.optim.Adam(params, lr=enc_lr, weight_decay=1e-5, eps=0.1)
    scheduler = torch.optim.lr_scheduler.LinearLR(
        optimizer,
        start_factor=1.0,
        end_factor=0.002 / enc_lr,
        total_iters=max(n_batches, 1),
    )
    return optimizer, scheduler


def reference_advdec_decoder_pgd_after_clean(
    decoder: nn.Module,
    x_batch: torch.Tensor,
    y_batch: torch.Tensor,
    lengths: torch.Tensor,
    optimizer: optim.Optimizer,
    mse_fn: nn.Module,
    eps: float = 0.1,
    alpha: float | None = None,
    steps: int = 10,
) -> None:
    """Exact 489a733 adversarial phase of the decoder window step."""
    if alpha is None:
        alpha = eps / 5.0
    x_adv = (
        x_batch + l2_normalize(torch.randn_like(x_batch)) * rand_radius_like(x_batch) * eps
    ).detach()
    x_adv.requires_grad_(True)
    for _ in range(steps):
        adv_loss = mse_fn(decoder.forward(x_adv, lengths), y_batch)
        (grad_x,) = torch.autograd.grad(adv_loss, x_adv, retain_graph=False, create_graph=False)
        with torch.no_grad():
            x_adv = proj_l2_ball(x_adv + alpha * l2_normalize(grad_x), x_batch, eps)
        x_adv.requires_grad_(True)
    x_adv.requires_grad_(False)
    optimizer.zero_grad(set_to_none=True)
    adv_loss = mse_fn(decoder.forward(x_adv, lengths), y_batch)
    if torch.isfinite(adv_loss):
        adv_loss.backward()
        nn.utils.clip_grad_norm_(decoder.parameters(), 1.0)
        optimizer.step()
