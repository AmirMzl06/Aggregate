"""P-02: ``from acorn.lm import rescore_export`` is side-effect free."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_import_rescore_export_does_not_invoke_docker(monkeypatch):
    real_run = subprocess.run

    def wrapped(*args, **kwargs):
        argv = args[0] if args else kwargs.get("args")
        first = None
        if isinstance(argv, (list, tuple)) and argv:
            first = Path(str(argv[0])).name
        elif isinstance(argv, str) and argv.strip():
            first = Path(argv.split()[0]).name
        if first == "docker":
            raise AssertionError(f"docker invoked: {argv}")
        return real_run(*args, **kwargs)

    monkeypatch.setattr(subprocess, "run", wrapped)
    from acorn.lm import rescore_export

    assert "acorn.lm" in sys.modules
    assert callable(rescore_export)
