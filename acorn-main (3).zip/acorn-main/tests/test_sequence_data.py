"""Synthetic on-disk fixtures for sequence dataset loaders (no Dryad)."""

from __future__ import annotations

import zipfile
from pathlib import Path

import h5py
import numpy as np
import pytest
import scipy.io as sio
import torch

from acorn.data.sequence.loaders.nlp10 import Nlp10Loader
from acorn.data.sequence.loaders.nlp21 import Nlp21Loader
from acorn.data.sequence.loaders.speech24 import Speech24Loader
from acorn.data.sequence.loaders.speech45 import Speech45Loader
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY


def _spec(key: str, n_features: int | None):
    return SEQUENCE_DATASET_REGISTRY[key].model_copy(update={"expected_n_features": n_features})


def test_nlp21_splits_are_independent(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "acorn.data.sequence.loaders.nlp21.confirm_and_download", lambda *a, **k: None
    )
    f = 8
    t = 12

    def write_mat(path: Path, blocks: list[int]):
        path.parent.mkdir(parents=True, exist_ok=True)
        n = len(blocks)
        xs = np.empty((1, n), dtype=object)
        sents = np.empty((1, n), dtype=object)
        bl = np.empty((1, n), dtype=object)
        for i, b in enumerate(blocks):
            xs[0, i] = np.random.randn(t, f).astype(np.float32)
            sents[0, i] = ">ab"
            bl[0, i] = b
        sio.savemat(path, {"tx_feats": xs, "sentences": sents, "blocks": bl})

    write_mat(tmp_path / "seed_model_training_data/mat/d0.mat", [0, 1, 2])
    write_mat(tmp_path / "online_evaluation_data/no_recalibration/mat/d1.mat", [0, 1])
    write_mat(tmp_path / "online_evaluation_data/recalibration/mat/d2.mat", [0, 3])
    loader = Nlp21Loader(data_dir=tmp_path, spec=_spec("nlp21", f), assume_yes=True)
    session = loader.load()
    assert session.n_features == f
    assert session.task_key == "nlp"
    train = loader.train_split()
    periodic = loader.periodic_eval_split()
    final = loader.final_eval_split()
    assert len(train.features) == 2
    assert len(periodic.features) >= 1
    assert len(final.features) >= len(periodic.features)
    src = Path(__file__).resolve().parents[1] / "acorn/data/sequence/loaders/nlp21.py"
    text = src.read_text(encoding="utf-8")
    assert "Do not call final_eval_split from here" in text


def test_nlp10_slow_time_and_splits(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "acorn.data.sequence.loaders.nlp10.confirm_and_download", lambda *a, **k: None
    )
    f, t = 8, 16

    def write_day(day: int, texts: list[str], blocks: list[int], excluded: list[int]):
        folder = tmp_path / "Datasets" / f"day{day:02d}"
        folder.mkdir(parents=True, exist_ok=True)
        n = len(texts)
        cube = np.random.randn(n, t, f).astype(np.float32)
        sio.savemat(
            folder / "sentences.mat",
            {
                "intendedText": np.array([[s] for s in texts], dtype=object),
                "neuralActivityCube": cube,
                "numTimeBinsPerSentence": np.array([[t]] * n),
                "sentenceBlockNums": np.array([[b] for b in blocks]),
                "excludedSentences": np.array([[e] for e in excluded]),
            },
        )

    # Days 0 and 5 are the only usable days (2 trials each). Days 1-4 exist so
    # rglob indices reach FINAL_DAY=5; they are fully excluded.
    write_day(0, ["hello", "a cat"], [1, 2], [0, 0])
    for day in range(1, 5):
        write_day(day, ["skip"], [1], [1])
    write_day(5, ["hello", "a cat"], [1, 2], [0, 0])
    loader = Nlp10Loader(data_dir=tmp_path, spec=_spec("nlp10", f), assume_yes=True)
    session = loader.load()
    assert session.n_features == f
    assert loader.train_split().features[0].shape[0] == t // 2
    assert len(loader.train_split().features) == 1
    assert len(loader.periodic_eval_split().features) == 2
    assert len(loader.final_eval_split().features) == 3
    src = Path(__file__).resolve().parents[1] / "acorn/data/sequence/loaders/nlp10.py"
    text = src.read_text(encoding="utf-8")
    assert "Do not call final_eval_split from here" in text


def test_speech24_feature_slice(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "acorn.data.sequence.loaders.speech24.confirm_and_download", lambda *a, **k: None
    )
    t = 10

    def write_session(path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        n = 2
        tx1 = np.empty((1, n), dtype=object)
        sp = np.empty((1, n), dtype=object)
        for i in range(n):
            tx1[0, i] = np.random.randn(t, 256).astype(np.float32)
            sp[0, i] = np.random.randn(t, 256).astype(np.float32)
        sio.savemat(
            path,
            {
                "tx1": tx1,
                "spikePow": sp,
                "sentenceText": np.array(["hi", "bye"]),
                "blockIdx": np.array([1, 1]),
            },
        )

    write_session(tmp_path / "train" / "s0.mat")
    write_session(tmp_path / "test" / "s0.mat")

    def fake_g2p(_text: str) -> list[str]:
        return ["HH", "AY", "SIL"]

    loader = Speech24Loader(
        data_dir=tmp_path, spec=_spec("speech24", 256), assume_yes=True, g2p_fn=fake_g2p
    )
    session = loader.load()
    assert session.n_features == 256
    assert session.task_key == "speech"
    assert session.periodic_eval is not session.final_eval
    assert len(loader.periodic_eval_split().features) == len(loader.final_eval_split().features)


def test_speech45_hdf5_schema(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "acorn.data.sequence.loaders.speech45.confirm_and_download", lambda *a, **k: None
    )
    f, t = 8, 12
    root = tmp_path / "hdf5_data_final" / "t15.2023.08.11"
    root.mkdir(parents=True)

    def write_h5(name: str, block: int):
        with h5py.File(root / name, "w") as fh:
            g = fh.create_group("trial_0000")
            g.create_dataset("input_features", data=np.random.randn(t, f).astype(np.float32))
            g.create_dataset("seq_class_ids", data=np.array([1, 2, 3], dtype=np.int64))
            g.attrs["n_time_steps"] = t
            g.attrs["seq_len"] = 3
            g.attrs["block_num"] = block

    write_h5("data_train.hdf5", 1)
    write_h5("data_val.hdf5", 2)
    loader = Speech45Loader(data_dir=tmp_path, spec=_spec("speech45", f), assume_yes=True)
    session = loader.load()
    assert session.n_features == f
    assert session.periodic_eval is not session.final_eval
    assert len(loader.train_split().features) == 1
    assert len(loader.final_eval_split().features) == 1


def test_download_skips_when_dest_has_data(tmp_path, monkeypatch):
    from acorn.data.download import confirm_and_download
    from acorn.data.sequence.loaders.nlp21 import is_ready as nlp21_ready

    dest = tmp_path / "already"
    dest.mkdir()
    (dest / "marker.txt").write_text("x")
    called = {"n": 0}

    def fail(*_a, **_k):
        called["n"] += 1
        raise AssertionError("should not download")

    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download.urllib.request.urlopen", fail)
    with pytest.raises(AssertionError, match="should not download"):
        confirm_and_download(
            dest,
            source="dryad",
            doi="10.5061/dryad.example",
            size_hint_gb=0.01,
            assume_yes=True,
            ready=nlp21_ready,
        )
    assert called["n"] == 1

    complete = tmp_path / "nlp21_complete"
    for rel in (
        "seed_model_training_data/mat",
        "online_evaluation_data/no_recalibration/mat",
        "online_evaluation_data/recalibration/mat",
    ):
        folder = complete / rel
        folder.mkdir(parents=True)
        (folder / "d0.mat").write_bytes(b"x")
    called["n"] = 0
    confirm_and_download(
        complete,
        source="dryad",
        doi="10.5061/dryad.example",
        size_hint_gb=0.01,
        assume_yes=True,
        ready=nlp21_ready,
    )
    assert called["n"] == 0


def test_nlp21_partial_layout_does_not_skip(tmp_path, monkeypatch):
    from acorn.data.download import confirm_and_download
    from acorn.data.sequence.loaders.nlp21 import is_ready as nlp21_ready

    dest = tmp_path / "partial"
    seed = dest / "seed_model_training_data" / "mat"
    seed.mkdir(parents=True)
    (seed / "d0.mat").write_bytes(b"x")
    called = {"n": 0}

    def fail(*_a, **_k):
        called["n"] += 1
        raise AssertionError("should not skip")

    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download.urllib.request.urlopen", fail)
    with pytest.raises(AssertionError, match="should not skip"):
        confirm_and_download(
            dest,
            source="dryad",
            doi="10.5061/dryad.example",
            size_hint_gb=0.01,
            assume_yes=True,
            ready=nlp21_ready,
        )
    assert called["n"] == 1


def test_complete_nested_tree_skips_per_loader(tmp_path, monkeypatch):
    from acorn.data.download import confirm_and_download
    from acorn.data.sequence.loaders.nlp10 import is_ready as nlp10_ready
    from acorn.data.sequence.loaders.nlp21 import is_ready as nlp21_ready
    from acorn.data.sequence.loaders.speech24 import is_ready as speech24_ready
    from acorn.data.sequence.loaders.speech45 import is_ready as speech45_ready

    called = {"n": 0}

    def fail(*_a, **_k):
        called["n"] += 1
        raise AssertionError("should not download")

    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download.urllib.request.urlopen", fail)

    nlp21 = tmp_path / "nlp21"
    for rel in (
        "seed_model_training_data/mat",
        "online_evaluation_data/no_recalibration/mat",
        "online_evaluation_data/recalibration/mat",
    ):
        folder = nlp21 / rel
        folder.mkdir(parents=True)
        (folder / "d0.mat").write_bytes(b"x")

    nlp10 = tmp_path / "nlp10"
    for day in range(10):
        folder = nlp10 / "Datasets" / f"day{day:02d}"
        folder.mkdir(parents=True)
        (folder / "sentences.mat").write_bytes(b"x")

    speech24 = tmp_path / "speech24"
    (speech24 / "train").mkdir(parents=True)
    (speech24 / "test").mkdir()
    for i in range(12):
        (speech24 / "train" / f"s{i}.mat").write_bytes(b"x")
    (speech24 / "test" / "s0.mat").write_bytes(b"x")

    speech45 = tmp_path / "speech45"
    root = speech45 / "hdf5_data_final"
    root.mkdir(parents=True)
    for i in range(23):
        session = root / f"sess{i:02d}"
        session.mkdir()
        (session / "data_train.hdf5").write_bytes(b"x")
        (session / "data_val.hdf5").write_bytes(b"x")

    for dest, ready in (
        (nlp21, nlp21_ready),
        (nlp10, nlp10_ready),
        (speech24, speech24_ready),
        (speech45, speech45_ready),
    ):
        called["n"] = 0
        confirm_and_download(
            dest,
            source="dryad",
            doi="10.5061/dryad.example",
            size_hint_gb=0.01,
            assume_yes=True,
            ready=ready,
        )
        assert called["n"] == 0

    bare = tmp_path / "speech45_bare"
    (bare / "hdf5_data_final").mkdir(parents=True)
    called["n"] = 0
    with pytest.raises(AssertionError, match="should not download"):
        confirm_and_download(
            bare,
            source="dryad",
            doi="10.5061/dryad.example",
            size_hint_gb=0.01,
            assume_yes=True,
            ready=speech45_ready,
        )
    assert called["n"] == 1


def test_speech45_ready_without_val_on_first_sorted_session(tmp_path, monkeypatch):
    from acorn.data.download import confirm_and_download
    from acorn.data.sequence.loaders.speech45 import is_ready as speech45_ready

    called = {"n": 0}

    def fail(*_a, **_k):
        called["n"] += 1
        raise AssertionError("should not download")

    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download.urllib.request.urlopen", fail)

    root = tmp_path / "speech45" / "hdf5_data_final"
    root.mkdir(parents=True)
    first = root / "t15.2023.08.11"
    first.mkdir()
    (first / "data_train.hdf5").write_bytes(b"x")
    for i in range(22):
        session = root / f"sess{i:02d}"
        session.mkdir()
        (session / "data_train.hdf5").write_bytes(b"x")
        (session / "data_val.hdf5").write_bytes(b"x")
    assert speech45_ready(tmp_path / "speech45")
    confirm_and_download(
        tmp_path / "speech45",
        source="dryad",
        doi="10.5061/dryad.example",
        size_hint_gb=0.01,
        assume_yes=True,
        ready=speech45_ready,
    )
    assert called["n"] == 0


def test_feature_inference_regression_time_bin(monkeypatch):
    import torch

    from acorn.runners.multi_session import build_session_bundles

    t, n = 20, 96
    train_x = torch.randn(t, n)
    test_x = torch.randn(t, n)
    train_y = torch.randn(t, 2)
    test_y = torch.randn(t, 2)
    monkeypatch.setattr(
        "acorn.runners.multi_session.load_day_split",
        lambda *a, **k: (train_x, test_x, train_y, test_y),
    )

    class FakeLoader:
        def get_dataset_num_days(self, _name):
            return 2

    bundles = build_session_bundles(FakeLoader(), ["jango", "mihili_co", "mihili_rt", "pop"])
    for key in bundles:
        assert bundles[key]["n_neurons"] == 96


def test_speech24_does_not_repeat_area_6v_label():
    src = Path(__file__).resolve().parents[1] / "acorn/data/sequence/loaders/speech24.py"
    assert "6v" not in src.read_text(encoding="utf-8")


def test_speech24_g2p_constructed_once(monkeypatch):
    from acorn.data.sequence.loaders import speech24

    constructed = {"n": 0}

    class FakeG2p:
        def __init__(self):
            constructed["n"] += 1

        def __call__(self, text):
            return ["HH", "AH0", "L", "OW1"]

    monkeypatch.setattr(speech24, "_G2P", None)
    monkeypatch.setattr("g2p_en.G2p", FakeG2p)
    first = speech24._g2p_phonemes("hello")
    second = speech24._g2p_phonemes("hello")
    assert constructed["n"] == 1
    assert first == second
    assert first


def test_speech24_g2p_real_cmu_optional():
    pytest.importorskip("g2p_en")
    from acorn.data.sequence.loaders import speech24

    speech24._G2P = None
    try:
        hello = speech24._g2p_phonemes("hello")
        goodbye = speech24._g2p_phonemes("goodbye")
        hello_again = speech24._g2p_phonemes("hello")
    except LookupError:
        pytest.skip("CMU dictionary not available")
    assert hello == hello_again
    assert hello
    assert goodbye


def test_extract_only_skips_bundled_extras(tmp_path):
    from acorn.data.download import _extract_zip

    archive = tmp_path / "bundle.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("Datasets/day00/sentences.mat", b"ok")
        zf.writestr("BigramLM/lm.bin", b"skip")
        zf.writestr("RNNTrainingSteps/model.bin", b"skip")
    dest = tmp_path / "out"
    dest.mkdir()
    _extract_zip(archive, dest, ("Datasets/",))
    assert (dest / "Datasets" / "day00" / "sentences.mat").is_file()
    assert not (dest / "BigramLM").exists()
    assert not (dest / "RNNTrainingSteps").exists()


def test_download_declined_raises(tmp_path, monkeypatch):
    from acorn.data.download import DownloadDeclined, confirm_and_download

    monkeypatch.setattr("builtins.input", lambda *_a, **_k: "n")
    with pytest.raises(DownloadDeclined):
        confirm_and_download(
            tmp_path / "empty",
            source="dryad",
            doi="10.5061/dryad.example",
            size_hint_gb=0.01,
            assume_yes=False,
            ready=lambda dest: False,
        )


def test_dryad_filename_downloads_only_named_file(tmp_path, monkeypatch):
    from acorn.data.download import confirm_and_download

    fetched: list[str] = []

    def fake_json(url, doi, dest_dir):
        if "versions" in url:
            return {
                "_embedded": {"stash:versions": [{"_links": {"stash:files": {"href": "/files"}}}]}
            }
        return {
            "_embedded": {
                "stash:files": [
                    {
                        "path": "needed.tar.gz",
                        "_links": {"stash:download": {"href": "/dl/needed"}},
                    },
                    {
                        "path": "skip.bin",
                        "_links": {"stash:download": {"href": "/dl/skip"}},
                    },
                ]
            }
        }

    def fake_retrieve(url, dest, *, token=None):
        fetched.append(url)
        assert token == "test-token"
        Path(dest).write_bytes(b"x")

    monkeypatch.setattr("acorn.data.download._get_json", fake_json)
    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download._download_to", fake_retrieve)
    monkeypatch.setattr("acorn.data.download._extract", lambda *_a, **_k: None)
    confirm_and_download(
        tmp_path / "new",
        source="dryad",
        doi="10.5061/dryad.example",
        dryad_filename="needed.tar.gz",
        size_hint_gb=0.01,
        assume_yes=True,
        ready=lambda dest: False,
    )
    assert fetched == ["https://datadryad.org/dl/needed"]


def test_dryad_download_verifies_listing_digest(tmp_path, monkeypatch):
    import hashlib

    from acorn.data.download import DryadDownloadError, confirm_and_download

    payload = b"dryad-bytes"
    digest = hashlib.sha256(payload).hexdigest()

    def fake_json(url, doi, dest_dir):
        if "versions" in url:
            return {
                "_embedded": {"stash:versions": [{"_links": {"stash:files": {"href": "/files"}}}]}
            }
        return {
            "_embedded": {
                "stash:files": [
                    {
                        "path": "needed.bin",
                        "size": len(payload),
                        "digest": digest,
                        "digestType": "sha-256",
                        "_links": {"stash:download": {"href": "/dl/needed"}},
                    }
                ]
            }
        }

    def fake_retrieve(url, dest, *, token=None):
        Path(dest).write_bytes(payload)

    monkeypatch.setattr("acorn.data.download._get_json", fake_json)
    monkeypatch.setattr("acorn.data.download._oauth_token", lambda: "test-token")
    monkeypatch.setattr("acorn.data.download._download_to", fake_retrieve)
    monkeypatch.setattr("acorn.data.download._extract", lambda *_a, **_k: None)
    dest = tmp_path / "ok"
    confirm_and_download(
        dest,
        source="dryad",
        doi="10.5061/dryad.example",
        dryad_filename="needed.bin",
        size_hint_gb=0.01,
        assume_yes=True,
        ready=lambda _d: False,
    )
    assert (dest / "needed.bin").read_bytes() == payload

    def fake_bad(url, dest, *, token=None):
        Path(dest).write_bytes(b"x" * len(payload))

    monkeypatch.setattr("acorn.data.download._download_to", fake_bad)
    dest_bad = tmp_path / "bad"
    with pytest.raises(DryadDownloadError, match="sha-256 mismatch"):
        confirm_and_download(
            dest_bad,
            source="dryad",
            doi="10.5061/dryad.example",
            dryad_filename="needed.bin",
            size_hint_gb=0.01,
            assume_yes=True,
            ready=lambda _d: False,
        )
    assert not (dest_bad / "needed.bin").exists()


def test_redirect_drops_authorization_when_host_changes():
    import urllib.request

    from acorn.data.download import _DropAuthOnForeignRedirect

    handler = _DropAuthOnForeignRedirect()
    req = urllib.request.Request(
        "https://datadryad.org/api/v2/files/1/download",
        headers={"Authorization": "Bearer secret", "User-Agent": "t"},
    )
    new = handler.redirect_request(
        req,
        fp=None,
        code=302,
        msg="Found",
        headers={"Location": "https://bucket.s3.amazonaws.com/file?X-Amz-Algorithm=AWS4"},
        newurl="https://bucket.s3.amazonaws.com/file?X-Amz-Algorithm=AWS4",
    )
    assert new is not None
    assert "Authorization" not in dict(new.header_items())
    same = handler.redirect_request(
        req,
        fp=None,
        code=302,
        msg="Found",
        headers={"Location": "https://datadryad.org/next"},
        newurl="https://datadryad.org/next",
    )
    assert same is not None
    assert dict(same.header_items()).get("Authorization") == "Bearer secret"


def test_infer_n_features_rejects_mixed_widths():
    from acorn.data.sequence.collate import SequenceSplit
    from acorn.data.sequence.nlp_mat import infer_n_features

    split = SequenceSplit(
        features=[
            np.zeros((4, 6), dtype=np.float32),
            np.zeros((4, 8), dtype=np.float32),
        ],
        labels=[np.array([1], dtype=np.int64), np.array([1], dtype=np.int64)],
    )
    with pytest.raises(ValueError, match="mixed feature widths"):
        infer_n_features(split, expected=None, key="nlp21")


def test_collate_rejects_mixed_feature_widths():
    from acorn.data.sequence.collate import collate_fn

    xs = [torch.zeros(3, 4), torch.zeros(2, 6)]
    ys = [torch.tensor([1]), torch.tensor([2])]
    with pytest.raises(ValueError, match="mixed feature widths"):
        collate_fn(list(zip(xs, ys, strict=True)))


def test_empty_label_trials_are_kept():
    from acorn.data.sequence.collate import SequenceSplit, collate_fn
    from acorn.data.sequence.nlp_mat import infer_n_features

    split = SequenceSplit(
        features=[np.zeros((8, 6), dtype=np.float32)],
        labels=[np.zeros((0,), dtype=np.int64)],
    )
    assert infer_n_features(split, expected=6, key="nlp21") == 6
    x_pad, y_pad, in_len, tgt_len = collate_fn(
        [(torch.zeros(8, 6), torch.zeros(0, dtype=torch.long))]
    )
    assert in_len.tolist() == [8]
    assert tgt_len.tolist() == [0]
    assert y_pad.shape == (1, 0)


def test_manual_hint_contains_filename_when_passed(tmp_path):
    from acorn.data.download import DRYAD_CLIENT_ID_ENV, DRYAD_CLIENT_SECRET_ENV, _manual_hint

    hint = _manual_hint("10.5061/dryad.example", tmp_path, "needed.tar.gz")
    assert "needed.tar.gz" in hint
    assert DRYAD_CLIENT_ID_ENV in hint
    assert DRYAD_CLIENT_SECRET_ENV in hint
    assert "docs/data.md" in hint
    without = _manual_hint("10.5061/dryad.example", tmp_path)
    assert "needed.tar.gz" not in without


def test_demo_session_never_calls_dryad(monkeypatch):
    from acorn.data.sequence.loaders import load_sequence_session
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY
    from acorn.train.sequence.config import SequenceTrainConfig

    def _boom(*args, **kwargs):
        raise AssertionError("Dryad")

    monkeypatch.setattr("acorn.data.download.confirm_and_download", _boom)
    session = load_sequence_session("demo")
    assert session.session_key == "demo"
    assert session.n_features == SEQUENCE_DATASET_REGISTRY["demo"].expected_n_features
    cfg = SequenceTrainConfig(dataset_keys=["demo"])
    assert cfg.dataset_keys == ["demo"]
    src = Path(__file__).resolve().parents[1] / "acorn/data/sequence/loaders/demo.py"
    text = src.read_text(encoding="utf-8")
    assert "confirm_and_download" not in text
