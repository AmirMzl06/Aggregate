"""Completeness contract for DATASET_REGISTRY."""

import pytest
from pydantic import ValidationError

from acorn.data.loader import DatasetLoader
from acorn.data.registry import (
    DATASET_REGISTRY,
    DATASETS,
    DatasetSpec,
    dataset_loading_flags,
    get_dataset,
    loader_dataset_urls,
    loader_file_types,
    loader_num_days,
    loader_original_names,
)
from acorn.eval.plot_config import (
    FIGURE2_DAY_K,
    PLOT_DEFAULTS,
    figure2_dayk_index,
    plot_channel_indices,
)

_MACAQUE_TRAIN = {"jango", "mihili_co", "mihili_rt", "pop"}
_HIPPO_KEYS = {"hippo_achilles", "hippo_buddy", "hippo_cicero", "hippo_gatsby"}
_PERICH_COUNTS = {
    "c_co": 53,
    "c_rt": 15,
    "j_co": 3,
    "t_co": 6,
    "t_rt": 6,
    "m_co": 22,
    "m_rt": 6,
}


def _enabled_keys() -> set[str]:
    return {k for k, s in DATASET_REGISTRY.items() if s.train_enabled}


def test_train_enabled_keys_match_datasets():
    enabled = _enabled_keys()
    assert enabled == set(DATASETS)
    assert _MACAQUE_TRAIN <= enabled
    assert "chewie_co" not in enabled
    perich = {k for k in enabled if k.startswith("perich_")}
    assert len(perich) == 111
    assert not any("j_rt" in k for k in DATASET_REGISTRY)
    assert _HIPPO_KEYS <= enabled
    for slug, count in _PERICH_COUNTS.items():
        keys = [k for k in perich if k.startswith(f"perich_{slug}_")]
        assert len(keys) == count
        assert {int(k.rsplit("_", 1)[1]) for k in keys} == set(range(1, count + 1))


def test_chewie_download_only():
    assert "chewie_co" in DATASET_REGISTRY
    assert DATASET_REGISTRY["chewie_co"].train_enabled is False
    assert "chewie_co" not in DATASETS
    assert "Chewie_CO_2016_raw" in loader_dataset_urls()


def test_registered_archives_are_7z():
    assert all(
        spec.file_type == "7z" for spec in DATASET_REGISTRY.values() if spec.gdrive_url is not None
    )


def test_dataset_spec_forbids_extra():
    payload = DATASET_REGISTRY["jango"].model_dump()
    payload["not_a_field"] = 1
    with pytest.raises(ValidationError):
        DatasetSpec(**payload)


def test_every_train_dataset_round_trips_plot_and_flags():
    for key, spec in DATASET_REGISTRY.items():
        if not spec.train_enabled:
            continue
        use_smooth, xds_smooth = dataset_loading_flags(spec.xds_name)
        assert use_smooth == spec.use_smooth
        assert xds_smooth == spec.xds_smooth
        assert key in PLOT_DEFAULTS
        dayk = figure2_dayk_index(key, spec.num_days)
        assert isinstance(dayk, int)
        if spec.dayk_override is not None:
            assert dayk == spec.dayk_override
            assert FIGURE2_DAY_K[key] == spec.dayk_override
        n_labels = len(spec.label_names)
        indices, display = plot_channel_indices(key, n_labels)
        assert len(indices) >= 1
        assert len(display) == len(indices)
        if spec.dataset_group in {"perich", "hippo"}:
            assert spec.pos_dims == (0, 1)
            assert spec.num_days == 1
        if spec.dataset_group == "hippo":
            assert spec.plot_type not in {"emg", "co_reach", "rt_reach"}


def test_pop_plot_channels_single_emg():
    spec = DATASET_REGISTRY["pop"]
    assert spec.plot_channels == ("EPM",)
    assert spec.plot_channel_display == ("EPM",)
    indices, display = plot_channel_indices("pop", len(spec.label_names))
    assert indices == [spec.label_names.index("EPM")]
    assert display == ["EPM"]
    jango = DATASET_REGISTRY["jango"]
    assert jango.plot_channels == ("EMG_EDCr", "EMG_FCR")
    assert len(jango.plot_channels) == 2
    from acorn.eval.plot_config import SHOWCASE_LEN, showcase_len_for, showcase_step_for

    assert showcase_len_for("jango") == SHOWCASE_LEN
    assert showcase_len_for("pop") == 50
    assert showcase_len_for("mihili_co") == SHOWCASE_LEN
    assert showcase_len_for("mihili_rt") == SHOWCASE_LEN
    assert showcase_step_for("pop") == 1
    assert showcase_step_for("jango") is None


def test_loader_views_cover_all_registry_xds_names():
    urls = loader_dataset_urls()
    types = loader_file_types()
    days = loader_num_days()
    originals = loader_original_names()
    for spec in DATASET_REGISTRY.values():
        if spec.gdrive_url is None:
            assert spec.xds_name not in urls
            continue
        assert spec.xds_name in urls
        assert urls[spec.xds_name] == spec.gdrive_url
        assert isinstance(spec.gdrive_url, str)
        assert types[spec.xds_name] == spec.file_type
        assert days[spec.xds_name] == spec.num_days
        assert originals[spec.xds_name] == spec.resolved_original_name()


def test_dataset_loader_class_attrs_derived():
    assert set(DatasetLoader.dataset_urls) == set(loader_dataset_urls())
    assert DatasetLoader.num_days == loader_num_days()
    assert DatasetLoader.file_types == loader_file_types()


def test_get_dataset_and_n_neurons_default():
    jango = get_dataset("jango")
    assert jango.expected_n_neurons == 96
    assert jango.xds_name == "Jango_ISO_2015_raw"
    assert jango.dataset_group == "macaque"
    for spec in DATASET_REGISTRY.values():
        if spec.train_enabled:
            assert spec.label_format == "time_bin_aligned"
            if spec.dataset_group == "macaque":
                assert spec.expected_n_neurons == 96
            else:
                assert spec.expected_n_neurons is None


def test_list_datasets_sorted_union():
    from acorn.data.registry import list_datasets
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    seq = [key for key, spec in SEQUENCE_DATASET_REGISTRY.items() if not spec.demo_only]
    assert list_datasets() == sorted(set(DATASETS) | set(seq))
    assert list_datasets(train_enabled_only=False) == sorted(set(DATASET_REGISTRY) | set(seq))
    assert list_datasets(label_format="time_bin_aligned") == sorted(DATASETS)
    assert list_datasets(label_format="time_bin_aligned", train_enabled_only=False) == sorted(
        DATASET_REGISTRY
    )
    assert list_datasets(label_format="sequence") == [
        "nlp10",
        "nlp21",
        "speech24",
        "speech45",
    ]
    assert list_datasets(label_format="sequence", train_enabled_only=False) == [
        "nlp10",
        "nlp21",
        "speech24",
        "speech45",
    ]
    with pytest.raises(ValueError, match="Invalid label_format"):
        list_datasets(label_format="not_a_family")  # type: ignore[arg-type]
    assert "demo" in SEQUENCE_DATASET_REGISTRY
    assert SEQUENCE_DATASET_REGISTRY["demo"].demo_only is True
    assert "demo" not in list_datasets()
    assert "demo" not in list_datasets(label_format="sequence")
    catalog = list_datasets()
    assert "perich_c_co_1" in catalog
    assert "hippo_achilles" in catalog
    assert "jango" in catalog


def test_get_dataset_family_errors():
    from acorn.data.registry import DATASET_REGISTRY, get_dataset
    from acorn.data.sequence.registry import get_sequence_dataset

    with pytest.raises(KeyError) as exc_info:
        get_dataset("nlp21")
    assert exc_info.value.args[0] == (
        "Dataset key 'nlp21' is registered for sequence training. "
        "Use get_sequence_dataset, not get_dataset."
    )
    with pytest.raises(KeyError) as exc_info:
        get_sequence_dataset("jango")
    assert exc_info.value.args[0] == (
        "Dataset key 'jango' is registered for time-bin training. "
        "Use get_dataset, not get_sequence_dataset."
    )
    with pytest.raises(KeyError) as exc_info:
        get_dataset("nope")
    assert exc_info.value.args[0] == (
        f"Unknown dataset key 'nope'. Choices: {list(DATASET_REGISTRY)}"
    )
    assert "get_sequence_dataset" not in exc_info.value.args[0]


def test_hippo_figshare_file_ids():
    ids = {
        "hippo_achilles": "40849463",
        "hippo_buddy": "40849460",
        "hippo_cicero": "40849457",
        "hippo_gatsby": "40849454",
    }
    for key, file_id in ids.items():
        spec = DATASET_REGISTRY[key]
        assert spec.http_url is not None
        assert file_id in spec.http_url
        assert spec.dataset_group == "hippo"
        assert spec.file_type == "jl"
