"""Library logger: NullHandler by default, INFO when asked, no core prints."""

from __future__ import annotations

import logging
import re
from pathlib import Path

import pytest
import torch

import acorn
from acorn.eval import decoder_probe
from acorn.eval.decoder_probe import evaluate_embedding_decoders
from acorn.log import get_logger, set_verbosity

_REPO = Path(__file__).resolve().parents[1]
_PRINT_STMT_RE = re.compile(r"(?m)^\s*print\(")


def test_acorn_logger_has_null_handler():
    logger = logging.getLogger("acorn")
    assert any(isinstance(handler, logging.NullHandler) for handler in logger.handlers)
    assert get_logger() is logger
    assert get_logger("acorn.eval.decoder_probe").name == "acorn.eval.decoder_probe"


def test_set_verbosity_changes_level():
    logger = logging.getLogger("acorn")
    previous = logger.level
    try:
        set_verbosity("INFO")
        assert logger.level == logging.INFO
        set_verbosity(logging.WARNING)
        assert logger.level == logging.WARNING
        set_verbosity("debug")
        assert logger.level == logging.DEBUG
    finally:
        logger.setLevel(previous)


def test_set_verbosity_rejects_unknown_name():
    with pytest.raises(ValueError, match="Unknown log level"):
        set_verbosity("LOUD")


class _FakeDecoder:
    best_epoch_ = 1
    best_val_r2_ = 0.5

    def score(self, *_args, **_kwargs):
        return 0.42


class _FakeModel:
    def set_session_decoder(self, _key, _decoder):
        return None


def _tiny_bundles() -> dict:
    return {
        "s": {
            "train_x": torch.zeros(4, 2),
            "train_y": torch.zeros(4, 1),
            "test_x": torch.zeros(4, 2),
            "test_y": torch.zeros(4, 1),
            "n_labels": 1,
            "num_days": 1,
            "dataset_name": "fake",
            "use_smooth": True,
            "xds_smooth": False,
            "dayk_idx": 0,
        }
    }


def _run_evaluate(monkeypatch) -> None:
    monkeypatch.setattr(decoder_probe, "train_session_decoder", lambda *_a, **_k: _FakeDecoder())
    monkeypatch.setattr(
        decoder_probe,
        "encode_full_trajectory",
        lambda *_a, **_k: torch.zeros(4, 2),
    )
    evaluate_embedding_decoders(
        _FakeModel(),
        loader=None,
        bundles=_tiny_bundles(),
        device=torch.device("cpu"),
        n_decoder_steps=1,
        decoder_val_checkpoint=False,
    )


def test_evaluate_emits_at_info_and_is_silent_at_warning(caplog, monkeypatch):
    with caplog.at_level(logging.INFO, logger="acorn.eval.decoder_probe"):
        _run_evaluate(monkeypatch)
    assert "--- s (fake) ---" in caplog.text
    assert "R^2" in caplog.text

    caplog.clear()
    with caplog.at_level(logging.WARNING, logger="acorn.eval.decoder_probe"):
        _run_evaluate(monkeypatch)
    assert "--- s (fake) ---" not in caplog.text


def test_no_print_in_library_package():
    root = _REPO / "acorn"
    hits: list[str] = []
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root).as_posix()
        if rel == "data/consent.py":
            continue
        if rel.startswith("lm/sidecar/"):
            continue
        text = path.read_text(encoding="utf-8")
        for match in _PRINT_STMT_RE.finditer(text):
            line_no = text[: match.start()].count("\n") + 1
            hits.append(f"{rel}:{line_no}")
    assert hits == [], "print( in acorn/ (consent and sidecar are allowed):\n" + "\n".join(hits)


def test_public_logging_helpers_exported():
    assert acorn.get_logger is get_logger
    assert acorn.set_verbosity is set_verbosity
