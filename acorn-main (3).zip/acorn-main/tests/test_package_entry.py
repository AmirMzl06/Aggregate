"""Package entry: no console script, ``python -m acorn`` fails."""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
_CLI_MOD = "acorn" + ".cli"
_RUN_PY = "run" + ".py"
_CLI_ENTRY = _CLI_MOD + ":main"


def test_pyproject_has_no_acorn_console_script():
    text = (_REPO / "pyproject.toml").read_text(encoding="utf-8")
    assert "[project.scripts]" not in text
    assert _CLI_ENTRY not in text


def test_cli_module_absent():
    assert importlib.util.find_spec(_CLI_MOD) is None
    assert not (_REPO / "acorn" / "__main__.py").exists()
    assert not (_REPO / _RUN_PY).exists()


def test_python_m_acorn_fails():
    proc = subprocess.run(
        [sys.executable, "-m", "acorn"],
        cwd=_REPO,
        check=False,
        capture_output=True,
        text=True,
    )
    assert proc.returncode != 0
