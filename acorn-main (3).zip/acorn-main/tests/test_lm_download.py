"""P-07: Dryad NLP zip / speech 5-gram; TINY fixtures only."""

from __future__ import annotations

import hashlib
from unittest.mock import patch

import pytest

from acorn.lm.download import (
    NLP_LM,
    SPEECH_5GRAM,
    DryadArtifact,
    DryadDownloadError,
    _download_stream,
    _is_complete,
    _write_complete,
    artifact_for_task,
    ensure_graphs,
)
from acorn.lm.graphs import _lm_cache_root, flatten_graph_artifacts

TINY = DryadArtifact(
    key="tiny",
    version_number=1,
    doi="10.5061/dryad.test",
    filename="tiny.zip",
    size_bytes=1000,
    sha256=hashlib.sha256(b"x" * 1000).hexdigest(),
    cache_subdir="nlp/language_model",
    download_gb=0.001,
    peak_disk_gb=0.01,
    ram_gib=1,
)


def test_artifact_for_task_never_3gram():
    assert artifact_for_task("nlp") is NLP_LM
    assert artifact_for_task("speech") is SPEECH_5GRAM
    assert artifact_for_task("speech").filename == "languageModel_5gram.tar.gz"
    assert artifact_for_task("speech").filename != "languageModel.tar.gz"


def test_product_min_free_gb_matches_peak_disk():
    assert NLP_LM.min_free_gb == NLP_LM.peak_disk_gb
    assert SPEECH_5GRAM.min_free_gb == SPEECH_5GRAM.peak_disk_gb
    assert TINY.min_free_gb == 0.0


def test_min_free_gb_check_runs_before_network(tmp_path, monkeypatch):
    cache = tmp_path / "nlp" / "language_model"
    monkeypatch.setattr("acorn.lm.download._disk_free_gb", lambda p: 0.01)
    monkeypatch.setattr(
        "acorn.lm.download._version_files_url",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("no network")),
    )
    with pytest.raises(DryadDownloadError, match="free"):
        ensure_graphs("nlp", assume_yes=True, graph_dir=cache)


def test_complete_marker_skips_redownload(tmp_path, monkeypatch):
    cache = tmp_path / "nlp" / "language_model"
    cache.mkdir(parents=True)
    (cache / "TLG.fst").write_bytes(b"fst")
    (cache / "words.txt").write_text("<eps>\n>\n,\n?\n.\n'\n")
    _write_complete(cache, NLP_LM)
    monkeypatch.setattr(
        "acorn.lm.download._version_files_url",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("no network")),
    )
    out = ensure_graphs("nlp", assume_yes=True, graph_dir=cache)
    assert out == cache


def test_sha_mismatch_raises_on_tiny_part(tmp_path):
    dest = tmp_path / "x.zip"
    part = dest.with_suffix(dest.suffix + ".part")
    part.write_bytes(b"z" * TINY.size_bytes)

    class Resp:
        def read(self, n=-1):
            return b""

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    with patch("acorn.lm.download.urllib.request.urlopen", return_value=Resp()):
        with pytest.raises(DryadDownloadError, match="sha256"):
            _download_stream("http://example/x", dest, TINY, tmp_path)


def test_download_stream_range_resume_tiny(tmp_path):
    dest = tmp_path / "tiny.zip"
    part = dest.with_suffix(dest.suffix + ".part")
    prefix_len = 400
    part.write_bytes(b"x" * prefix_len)
    suffix = b"x" * (TINY.size_bytes - prefix_len)
    seen_range: list[str] = []

    class Resp:
        def read(self, n=-1):
            if not hasattr(self, "_done"):
                self._done = True
                return suffix
            return b""

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def fake_urlopen(request):
        seen_range.append(request.get_header("Range"))
        return Resp()

    with patch("acorn.lm.download.urllib.request.urlopen", side_effect=fake_urlopen):
        _download_stream("http://example/x", dest, TINY, tmp_path)

    assert seen_range == [f"bytes={prefix_len}-"]
    assert dest.stat().st_size == TINY.size_bytes
    assert dest.stat().st_size != NLP_LM.size_bytes
    assert dest.stat().st_size != SPEECH_5GRAM.size_bytes


def test_speech_true_path_uses_consent_env(monkeypatch, tmp_path):
    from acorn.data.consent import ASSUME_YES_ENV

    monkeypatch.setenv(ASSUME_YES_ENV, "1")
    cache = tmp_path / "speech" / "5gram"

    def boom(*a, **k):
        raise DryadDownloadError("403")

    monkeypatch.setattr("acorn.lm.download._version_files_url", boom)
    with pytest.raises(DryadDownloadError):
        ensure_graphs("speech", assume_yes=False, graph_dir=cache)


def test_flatten_5gram_four_files(tmp_path, monkeypatch):
    staging = tmp_path / "staging"
    sub = staging / "lang_test"
    sub.mkdir(parents=True)
    for name in ("TLG.fst", "G.fst", "G_no_prune.fst", "words.txt"):
        (sub / name).write_bytes(b"x")
    dest = tmp_path / "out"

    def boom(self, *a, **k):
        raise AssertionError("must not slurp graph files into memory")

    monkeypatch.setattr(type(sub / "TLG.fst"), "read_bytes", boom)
    monkeypatch.setattr(type(sub / "TLG.fst"), "write_bytes", boom)
    flatten_graph_artifacts(
        staging,
        dest,
        ("TLG.fst", "G.fst", "G_no_prune.fst", "words.txt"),
    )
    assert len(list(dest.iterdir())) == 4
    assert (dest / "G_no_prune.fst").open("rb").read() == b"x"


def test_lm_cache_root_expands_user(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("ACORN_LM_CACHE", "~/lm-cache")
    assert _lm_cache_root() == (tmp_path / "lm-cache").resolve()


def test_is_complete_requires_marker_fields(tmp_path):
    cache = tmp_path / "c"
    cache.mkdir()
    assert not _is_complete(cache, NLP_LM)
    (cache / f".{NLP_LM.filename}.complete").write_text('{"sha256":"nope","size_bytes":1}')
    assert not _is_complete(cache, NLP_LM)
