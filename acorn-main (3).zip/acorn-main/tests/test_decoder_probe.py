"""CPU smoke tests for post-hoc embedding decoder probes."""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from acorn.eval.decoder_probe import (
    encode_full_trajectory,
    evaluate_embedding_decoders,
    train_session_decoder,
)
from acorn.models.decoder_base import BaseGRUDecoder


class _FakeEncoderModel(nn.Module):
    def transform(self, x, session_key):
        return x

    def set_session_decoder(self, session_key, decoder):
        self._decoders = {session_key: decoder}


def test_encode_full_trajectory_restores_train_mode():
    model = _FakeEncoderModel()
    model.train()
    x = torch.randn(16, 8)
    out = encode_full_trajectory(model, "s", x, torch.device("cpu"))
    assert out.shape == (16, 8)
    assert model.training is True


def test_train_session_decoder_fixed_steps():
    model = _FakeEncoderModel()
    train_x = torch.randn(64, 8)
    train_y = torch.randn(64, 2)
    dec = train_session_decoder(
        model,
        "s",
        train_x,
        train_y,
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=3,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
    )
    assert dec.best_epoch_ == 3
    score = dec.score(train_x, train_y, torch.device("cpu"))
    assert isinstance(score, float)
    assert math.isfinite(score)


def test_train_session_decoder_honors_window_size():
    model = _FakeEncoderModel()
    train_x = torch.randn(80, 8)
    train_y = torch.randn(80, 2)
    dec = train_session_decoder(
        model,
        "s",
        train_x,
        train_y,
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=2,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        window_size=64,
    )
    assert dec.window_size == 64


def test_evaluate_embedding_decoders_single_day(monkeypatch):
    def _boom(*_a, **_k):
        raise AssertionError("load_day_split must not run when num_days==1")

    monkeypatch.setattr("acorn.eval.decoder_probe.load_day_split", _boom)
    model = _FakeEncoderModel()
    bundles = {
        "s": {
            "train_x": torch.randn(64, 8),
            "train_y": torch.randn(64, 2),
            "test_x": torch.randn(32, 8),
            "test_y": torch.randn(32, 2),
            "n_labels": 2,
            "num_days": 1,
            "dataset_name": "fake",
            "use_smooth": True,
            "xds_smooth": False,
            "dayk_idx": 0,
        }
    }
    metrics = evaluate_embedding_decoders(
        model,
        loader=None,
        bundles=bundles,
        device=torch.device("cpu"),
        n_decoder_steps=2,
        seed=0,
        decoder_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
    )
    assert "s" in metrics
    assert "r2_holdout" in metrics["s"]
    assert metrics["s"]["r2_other_days"] == {}
    assert "s" in model._decoders


def test_evaluate_embedding_decoders_keeps_decoder_in_memory(tmp_path):
    model = _FakeEncoderModel()
    bundles = {
        "s": {
            "train_x": torch.randn(64, 8),
            "train_y": torch.randn(64, 2),
            "test_x": torch.randn(32, 8),
            "test_y": torch.randn(32, 2),
            "n_labels": 2,
            "num_days": 1,
            "dataset_name": "fake",
            "use_smooth": True,
            "xds_smooth": False,
            "dayk_idx": 0,
        }
    }
    metrics = evaluate_embedding_decoders(
        model,
        loader=None,
        bundles=bundles,
        device=torch.device("cpu"),
        n_decoder_steps=2,
        seed=0,
        decoder_val_checkpoint=True,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
    )
    assert "s" in metrics
    assert "s" in model._decoders
    decoder = model._decoders["s"]
    assert decoder.best_epoch_ >= 1
    assert not list(tmp_path.iterdir())
    assert not (tmp_path / "decoder_s_best.pt").exists()


def test_probe_mlp_does_not_take_gru_kwargs():
    from acorn.models.decoder_mlp import TwoLayerMLP

    model = _FakeEncoderModel()
    dec = train_session_decoder(
        model,
        "s",
        torch.randn(32, 8),
        torch.randn(32, 2),
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=2,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        window_size=64,
        mlp_decoder=True,
    )
    assert isinstance(dec, TwoLayerMLP)
    assert not hasattr(dec, "window_size")


def test_probe_decoder_adv_oneshot_halves_steps():
    from acorn.models.decoder_oneshot import OneshotMonkeyDecoder

    model = _FakeEncoderModel()
    dec = train_session_decoder(
        model,
        "s",
        torch.randn(48, 8),
        torch.randn(48, 2),
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=4,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        decoder_adv="oneshot",
    )
    assert isinstance(dec, OneshotMonkeyDecoder)
    assert dec.best_epoch_ == 2


def test_probe_decoder_adv_pgd_halves_steps():
    from acorn.models.decoder_cluster_pgd import ClusterPgdMonkeyDecoder

    model = _FakeEncoderModel()
    dec = train_session_decoder(
        model,
        "s",
        torch.randn(48, 8),
        torch.randn(48, 2),
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=4,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        decoder_adv="pgd",
    )
    assert isinstance(dec, ClusterPgdMonkeyDecoder)
    assert dec.best_epoch_ == 2
