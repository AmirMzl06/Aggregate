"""Unit tests for z-score / train-test split helpers."""

import torch

from acorn.data.splits import _split_and_zscore, _zscore_spikes, _zscore_stats


def test_zscore_stats_low_var_mask():
    x = torch.ones(100, 3)
    x[:, 1] = torch.linspace(0, 10, 100)
    mean, std, low_var = _zscore_stats(x)
    assert mean.shape == (1, 3)
    assert bool(low_var[0].item()) is True  # constant channel
    assert bool(low_var[1].item()) is False


def test_zscore_spikes_zeros_low_var():
    x = torch.randn(50, 2)
    mean = x.mean(0, keepdim=True)
    std = torch.ones(1, 2)
    low_var = torch.tensor([True, False])
    out = _zscore_spikes(x.clone(), mean, std, low_var)
    assert torch.all(out[:, 0] == 0.0)
    assert not torch.all(out[:, 1] == 0.0)


def test_split_and_zscore_sizes_and_no_shuffle():
    spikes = torch.arange(100, dtype=torch.float32).unsqueeze(1).expand(100, 4).clone()
    spikes = spikes + torch.randn(100, 4) * 0.01
    labels = torch.arange(100, dtype=torch.float32).unsqueeze(1)
    train_x, test_x, train_y, test_y = _split_and_zscore(spikes, labels, zscore=True)
    assert train_x.shape[0] == 80
    assert test_x.shape[0] == 20
    # Contiguous split (no shuffle): first train label is 0, first test is 80.
    assert float(train_y[0, 0]) == 0.0
    assert float(test_y[0, 0]) == 80.0
