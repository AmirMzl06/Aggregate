"""Frozen cluster data-math (hippo_all independent std+1e-3). No macorn_cluster import."""

from __future__ import annotations

import numpy as np


def reference_independent_zscore(train_x, test_x):
    """Each split uses its own mean and ``std + 1e-3`` (cluster hippo_all / Perich)."""
    train_x = np.asarray(train_x, dtype=np.float64)
    test_x = np.asarray(test_x, dtype=np.float64)
    train_mean = train_x.mean(axis=0)
    train_std = train_x.std(axis=0) + 1e-3
    test_mean = test_x.mean(axis=0)
    test_std = test_x.std(axis=0) + 1e-3
    return (train_x - train_mean) / train_std, (test_x - test_mean) / test_std


def reference_hippo_all_from_full(full_x, full_y):
    """``int(1.0 * T)`` train=valid from raw full arrays, then independent z-score."""
    full_x = np.asarray(full_x)
    full_y = np.asarray(full_y)
    train_x, test_x = reference_independent_zscore(full_x, full_x)
    return {
        "train_x": np.asarray(train_x, dtype=np.float32),
        "test_x": np.asarray(test_x, dtype=np.float32),
        "train_y": np.asarray(full_y, dtype=np.float32),
        "test_y": np.asarray(full_y, dtype=np.float32),
        "full_x": np.asarray(full_x, dtype=np.float32),
        "full_y": np.asarray(full_y, dtype=np.float32),
    }
