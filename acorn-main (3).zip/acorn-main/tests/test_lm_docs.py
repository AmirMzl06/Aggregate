"""LM docs: getting-started stays light; details live in language_model.md."""

from __future__ import annotations

import re
from pathlib import Path

_DOCS = Path(__file__).resolve().parents[1] / "docs"
_GETTING_STARTED = _DOCS / "getting_started.md"
_LM = _DOCS / "language_model.md"
_B2T = _DOCS / "adding_a_b2t_dataset.md"

_INVERTED_GRAPH_DOWNLOAD = re.compile(
    r"graphs?\s+download[\s\S]{0,200}?\bunless\b[\s\S]{0,80}?"
    r"(assume_yes|ACORN_DOWNLOAD_YES)",
    re.IGNORECASE,
)


def test_getting_started_points_at_lm_guide():
    text = _GETTING_STARTED.read_text(encoding="utf-8")
    assert "rescore_export" in text
    assert "use_lm" in text
    assert "language_model.md" in text
    lm_section = text.split("## Language-model rescoring", 1)[1]
    assert "NVIDIA" not in lm_section
    assert "paper_comparable" not in lm_section
    assert "350 GiB" not in lm_section
    assert _INVERTED_GRAPH_DOWNLOAD.search(lm_section) is None


def test_language_model_guide_teaches_the_call():
    text = _LM.read_text(encoding="utf-8")
    assert "rescore_export" in text
    assert "use_lm" in text
    assert "LmPrerequisiteError" in text
    assert "Docker" in text
    assert "NVIDIA" in text
    assert "assume_yes" in text
    assert "ACORN_DOWNLOAD_YES" in text
    assert "64 GiB" in text
    assert "skip" in text.lower() and "prompt" in text.lower()
    assert _INVERTED_GRAPH_DOWNLOAD.search(text) is None
    headings = re.findall(r"^## .+$", text, re.M)
    assert headings[0].startswith("## After a training run")
    assert headings[1].startswith("## What you need")


def test_b2t_eval_defers_lm_to_the_guide():
    text = _B2T.read_text(encoding="utf-8")
    eval_section = text.split("## Eval and export", 1)[1].split("## Checklist", 1)[0]
    assert "language_model.md" in eval_section
    assert "evaluate_sequence_sessions" in eval_section
    assert "rescore_export" not in eval_section
    assert "NVIDIA" not in eval_section
    assert _INVERTED_GRAPH_DOWNLOAD.search(eval_section) is None
