"""Plot-export helpers: split alignment, showcase pick, npz/manifest smoke."""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from acorn.data.splits import load_day_trials
from acorn.eval.plot_config import EMG_SHOWCASE, RTM_TRIAL_INDICES
from acorn.eval.plot_export import (
    _align_target_dirs_all_trials,
    _align_target_dirs_with_test_trials,
    _day_npz_payload,
    export_plot_data,
)
from examples.save_run import save_day_npz


class _IdentityEncoder(nn.Module):
    def forward(self, x, lengths):
        return x, lengths

    def eval(self):
        return super().eval()


class _IdentityDecoder(nn.Module):
    def forward(self, embs, lengths=None):
        return embs

    def eval(self):
        return super().eval()


class _FakeLoader:
    def __init__(self, x_list, y_list):
        self.x_list = x_list
        self.y_list = y_list

    def load_dataset_day(self, day_idx, dataset_name, stack=True, xds_smooth=True):
        if stack:
            return np.vstack(self.x_list), np.vstack(self.y_list)
        return list(self.x_list), list(self.y_list)

    def get_dataset_day_label(self, day_idx, dataset_name):
        return day_idx * 10

    def get_dataset_day_filename(self, day_idx, dataset_name):
        return f"day_{day_idx}.mat"


def test_align_test_dirs_matches_load_day_trials_count(monkeypatch):
    x_list = [np.ones((30, 2)), np.ones((30, 2)), np.ones((40, 2))]
    y_list = [np.zeros((30, 2)), np.zeros((30, 2)), np.zeros((40, 2))]
    dirs = np.array([0.0, 90.0, 180.0])
    loader = _FakeLoader(x_list, y_list)
    monkeypatch.setattr(
        "acorn.eval.plot_export._load_trial_target_dirs",
        lambda *_a, **_k: (dirs, np.arange(3)),
    )
    _, test_trials, *_ = load_day_trials(loader, "Mihili_CO_2014_raw", 0, zscore=False)
    aligned = _align_target_dirs_with_test_trials(loader, "Mihili_CO_2014_raw", 0, len(test_trials))
    assert aligned is not None
    assert aligned.shape[0] == len(test_trials)


def test_align_all_dirs_pads_when_short(monkeypatch):
    loader = _FakeLoader([np.ones((5, 2))], [np.zeros((5, 2))])
    monkeypatch.setattr(
        "acorn.eval.plot_export._load_trial_target_dirs",
        lambda *_a, **_k: (np.array([1.0, 2.0]), np.array([0, 1])),
    )
    out = _align_target_dirs_all_trials(loader, "Mihili_CO_2014_raw", 0, 4)
    assert out is not None
    assert out.shape == (4,)
    assert np.isnan(out[2])


def test_save_day_npz_roundtrip(tmp_path):
    payload = _day_npz_payload(
        [np.ones((4, 2))],
        [np.zeros((4, 2))],
        0.5,
        np.array([0.4, 0.6]),
        np.array([45.0]),
        0,
        1,
    )
    path = tmp_path / "day0.npz"
    save_day_npz(path, payload)
    loaded = np.load(path, allow_pickle=True)
    assert float(loaded["r2_overall"]) == 0.5
    assert int(loaded["showcase_trial_idx"]) == 0


def test_export_plot_data_returns_payload(tmp_path, monkeypatch):
    n_labels = 7
    trial = (torch.randn(256, n_labels), torch.randn(256, n_labels))
    train_trials = [trial, trial]
    test_trials = [trial]

    def _fake_trials(*_a, **_k):
        x = torch.cat([t[0] for t in train_trials + test_trials])
        y = torch.cat([t[1] for t in train_trials + test_trials])
        return train_trials, test_trials, x, y, x, y

    monkeypatch.setattr("acorn.eval.plot_export.load_day_trials", _fake_trials)
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_with_test_trials",
        lambda *_a, **_k: None,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_all_trials",
        lambda *_a, **_k: None,
    )
    loader = _FakeLoader([], [])
    payload = export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        loader,
        "jango",
        "Jango_ISO_2015_raw",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=False,
        train_day=0,
    )
    assert payload["manifest"]["dataset_key"] == "jango"
    assert payload["manifest"]["plot_type"] == "emg"
    assert "actual_trials" in payload["day0"]
    assert "actual_trials" in payload["dayk"]
    assert not (tmp_path / "manifest.json").exists()
    assert not list(tmp_path.iterdir())
    assert payload["manifest"]["showcase_len"] == 40
    assert int(payload["day0"]["showcase_trial_idx"]) == EMG_SHOWCASE["jango"]["day0"][0]
    assert int(payload["dayk"]["showcase_trial_idx"]) == EMG_SHOWCASE["jango"]["dayk"][0]
    assert len(payload["manifest"]["plot_channel_display"]) == 2


def test_export_plot_data_pop_single_channel_window(tmp_path, monkeypatch):
    n_labels = 11
    trial = (torch.randn(256, n_labels), torch.randn(256, n_labels))

    def _fake_trials(*_a, **_k):
        return [trial], [trial], trial[0], trial[1], trial[0], trial[1]

    monkeypatch.setattr("acorn.eval.plot_export.load_day_trials", _fake_trials)
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_with_test_trials",
        lambda *_a, **_k: None,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_all_trials",
        lambda *_a, **_k: None,
    )
    payload = export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        _FakeLoader([], []),
        "pop",
        "Pop_PG_2021",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=True,
        train_day=0,
    )
    assert payload["manifest"]["dataset_key"] == "pop"
    assert payload["manifest"]["plot_channel_display"] == ["EPM"]
    assert len(payload["manifest"]["plot_channel_indices"]) == 1
    assert payload["manifest"]["showcase_len"] == 50
    assert int(payload["day0"]["showcase_len"]) == 50
    assert int(payload["day0"]["showcase_trial_idx"]) == EMG_SHOWCASE["pop"]["day0"][0]
    assert int(payload["day0"]["showcase_start"]) == EMG_SHOWCASE["pop"]["day0"][1]
    assert int(payload["dayk"]["showcase_trial_idx"]) == EMG_SHOWCASE["pop"]["dayk"][0]
    assert not (tmp_path / "manifest.json").exists()


def test_export_plot_data_forwards_window_size(monkeypatch):
    seen: list[int] = []

    def _fake_collect(encoder, decoder, trials, device, window_size=256):
        seen.append(window_size)
        n_labels = 7
        preds = [torch.zeros(256, n_labels).numpy() for _ in trials]
        actuals = [torch.zeros(256, n_labels).numpy() for _ in trials]
        return preds, actuals, 0.0, torch.zeros(n_labels).numpy()

    monkeypatch.setattr("acorn.eval.plot_export.collect_stream_trial_predictions", _fake_collect)
    monkeypatch.setattr(
        "acorn.eval.plot_export.load_day_trials",
        lambda *_a, **_k: (
            [(torch.zeros(256, 7), torch.zeros(256, 7))],
            [(torch.zeros(256, 7), torch.zeros(256, 7))],
            None,
            None,
            None,
            None,
        ),
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_with_test_trials",
        lambda *_a, **_k: None,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_all_trials",
        lambda *_a, **_k: None,
    )
    export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        _FakeLoader([], []),
        "jango",
        "Jango_ISO_2015_raw",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=False,
        train_day=0,
        window_size=64,
    )
    assert seen
    assert all(value == 64 for value in seen)


def test_export_mihili_rt_stores_fixed_plot_trial_indices(monkeypatch):
    train_trials = [_cursor_trial(0.0), _cursor_trial(1.0)]
    test_trials = [_cursor_trial(float(i)) for i in range(8)]
    _patch_reach_export(monkeypatch, train_trials, test_trials)
    payload = export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        _FakeLoader([], []),
        "mihili_rt",
        "Mihili_RT_2013_2014_raw",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=False,
        train_day=0,
    )
    idx = [int(i) for i in payload["day0"]["plot_trial_indices"]]
    assert idx == list(RTM_TRIAL_INDICES["day0"])
    assert [int(i) for i in payload["dayk"]["plot_trial_indices"]] == list(
        RTM_TRIAL_INDICES["dayk"]
    )
    assert "plot_trial_indices" not in payload["manifest"]


def _fake_rtm_collect(encoder, decoder, trials, device, window_size=256):
    actuals = [t[1].detach().cpu().numpy() for t in trials]
    preds = [actual + 3.0 for actual in actuals]
    n_labels = actuals[0].shape[1] if actuals else 2
    return preds, actuals, 0.1, np.zeros(n_labels)


def _patch_reach_export(monkeypatch, train_trials, test_trials):
    monkeypatch.setattr(
        "acorn.eval.plot_export.load_day_trials",
        lambda *_a, **_k: (train_trials, test_trials, None, None, None, None),
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export.collect_stream_trial_predictions",
        _fake_rtm_collect,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_with_test_trials",
        lambda *_a, **_k: None,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_all_trials",
        lambda *_a, **_k: None,
    )


def _cursor_trial(offset: float):
    n_labels = 6
    y = torch.arange(32, dtype=torch.float32).unsqueeze(1).repeat(1, n_labels) + offset
    x = torch.zeros(32, n_labels)
    return x, y


def test_export_mihili_co_omits_plot_trial_indices(monkeypatch):
    train_trials = [_cursor_trial(0.0), _cursor_trial(1.0)]
    test_trials = [_cursor_trial(float(i)) for i in range(8)]
    _patch_reach_export(monkeypatch, train_trials, test_trials)
    payload = export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        _FakeLoader([], []),
        "mihili_co",
        "Mihili_CO_2014_raw",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=False,
        train_day=0,
    )
    assert "plot_trial_indices" not in payload["day0"]
    assert "plot_trial_indices" not in payload["dayk"]
