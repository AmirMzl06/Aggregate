"""P-06 / P-08: export hook, named metrics dict, temp npy cleanup."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import torch
from pydantic import ValidationError

from acorn.data.sequence.collate import SequenceSession, SequenceSplit
from acorn.eval.sequence.export import export_all_sessions
from acorn.lm.nbest import Hypothesis, NBest, save_nbest
from acorn.lm.runtime import rescore_export
from acorn.train.sequence.config import SequenceTrainConfig

NLP_VOCAB = ["<BLANK>", ">", ",", "?", "~", "'"] + [chr(ord("a") + i) for i in range(26)]


class _DummyModel:
    def eval(self):
        return self

    def __call__(self, x, x_len, session_key):
        t = x.shape[1]
        logits = x.new_zeros(x.shape[0], t, 32)
        logits[..., 1] = 1.0
        return logits, x_len


def _session():
    split = SequenceSplit(
        features=[np.zeros((2, 4), np.float32)],
        labels=[np.array([1])],
    )
    return SequenceSession(
        session_key="nlp21",
        task_key="nlp",
        use_smooth=False,
        n_features=4,
        num_classes=32,
        vocab=tuple(NLP_VOCAB),
        blank_index=0,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )


def _write_export(root: Path, session_keys: tuple[str, ...] = ("nlp21",)) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    datasets = []
    for key in session_keys:
        dest = root / f"{key}_logits.pt"
        torch.save(
            {
                "logits": [torch.zeros(2, 32)],
                "input_lengths": torch.tensor([2], dtype=torch.long),
                "label_ids": [torch.tensor([1])],
                "dataset_key": key,
                "task_key": "nlp",
                "session_key": key,
                "vocab": NLP_VOCAB,
                "blank_index": 0,
                "transcripts": ["she was."],
            },
            dest,
        )
        datasets.append(
            {
                "dataset_key": key,
                "task_key": "nlp",
                "session_key": key,
                "vocab": NLP_VOCAB,
                "blank_index": 0,
                "path": dest.name,
                "has_transcripts": True,
            }
        )
    manifest = {"schema": "acorn.ctc_export.v1.1", "datasets": datasets}
    (root / "ctc_export_manifest.json").write_text(json.dumps(manifest, indent=2))
    return root


def _patch_runtime_success(monkeypatch, tmp_path, job_dirs):
    cache = tmp_path / "graphs"
    cache.mkdir()
    (cache / "TLG.fst").write_bytes(b"fst")
    (cache / "words.txt").write_text("<eps>\n>\n,\n?\n.\n'\n")

    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr("acorn.lm.docker_run._docker_info_text", lambda fmt: "")
    monkeypatch.setattr("acorn.lm.docker_run.docker_has_nvidia_runtime", lambda: True)
    monkeypatch.setattr("acorn.lm.docker_run.docker_image_exists", lambda image: True)
    monkeypatch.setattr("acorn.lm.runtime.ensure_images", lambda **k: None)
    monkeypatch.setattr("acorn.lm.runtime.require_ram", lambda *a, **k: None)
    monkeypatch.setattr("acorn.lm.runtime.ensure_graphs", lambda *a, **k: cache)
    monkeypatch.setattr("acorn.lm.runtime.require_tlg_dir", lambda *a, **k: None)

    def fake_kaldi(job_dir, tlg_dir, out_path, preset, **kwargs):
        job_dirs.append(Path(job_dir))
        nbest = NBest(
            session_key="nlp21",
            task_key="nlp",
            trials=[[Hypothesis(text="she was.", acoustic_score=0.0, ngram_score=0.0)]],
        )
        save_nbest(nbest, out_path)

    def fake_neural(nbest_path, out_path, preset, **kwargs):
        Path(out_path).write_text(
            json.dumps({"schema": "acorn_lm.rescored.v1", "decoded": ["she was."]})
        )

    monkeypatch.setattr("acorn.lm.runtime.run_kaldi_decode", fake_kaldi)
    monkeypatch.setattr("acorn.lm.runtime.run_neural_rescore", fake_neural)


def test_sequence_train_config_forbids_use_lm():
    with pytest.raises(ValidationError):
        SequenceTrainConfig(dataset_keys=["nlp21"], use_lm=True)


def test_runner_export_does_not_pass_use_lm():
    src = Path(__file__).resolve().parents[1] / "acorn" / "runners" / "sequence.py"
    assert "use_lm" not in src.read_text(encoding="utf-8")


def test_mocked_rescore_export_returns_named_metrics(monkeypatch, tmp_path):
    export_dir = _write_export(tmp_path / "run")
    (export_dir / "metrics.json").write_text(json.dumps({"cer_mean": 0.4, "mode": "sequence"}))
    job_dirs: list[Path] = []
    _patch_runtime_success(monkeypatch, tmp_path, job_dirs)
    report = rescore_export(export_dir, assume_yes=True, host_ram_bytes=72 * 1024**3)
    assert isinstance(report, dict)
    assert "ngram_wer" in report
    assert "lm_wer" in report
    assert "wer" not in report
    assert not (export_dir / "lm_metrics.json").exists()
    assert report["ngram_wer"] == 0.0
    assert report["lm_wer"] == 0.0
    metrics = json.loads((export_dir / "metrics.json").read_text())
    assert metrics["cer_mean"] == 0.4
    assert "wer" not in metrics
    assert job_dirs
    assert all(not p.exists() for p in job_dirs)


def test_export_all_sessions_use_lm_returns_lm_key(monkeypatch, tmp_path):
    job_dirs: list[Path] = []
    _patch_runtime_success(monkeypatch, tmp_path, job_dirs)
    monkeypatch.setattr(
        "acorn.eval.sequence.export.collect_final_eval_transcripts",
        lambda *a, **k: ["she was."],
    )
    out = tmp_path / "export"
    result = export_all_sessions(
        _DummyModel(),
        {"nlp21": _session()},
        torch.device("cpu"),
        use_lm=True,
        assume_yes=True,
    )
    assert "lm" in result
    assert "ngram_wer" in result["lm"]
    assert "sessions" in result
    assert "nlp21" in result["sessions"]
    assert not (out / "lm_metrics.json").exists()
    assert not (out / "nlp21_logits.pt").exists()
    assert all(not p.exists() for p in job_dirs)


def test_multi_session_rescore_keeps_named_keys(monkeypatch, tmp_path):
    export_dir = _write_export(tmp_path / "run", session_keys=("nlp21", "nlp10"))
    (export_dir / "metrics.json").write_text(json.dumps({"cer_mean": 0.4, "mode": "sequence"}))
    job_dirs: list[Path] = []
    _patch_runtime_success(monkeypatch, tmp_path, job_dirs)
    report = rescore_export(export_dir, assume_yes=True, host_ram_bytes=72 * 1024**3)
    assert "wer" not in report
    assert report["ngram_wer"] == {"nlp21": 0.0, "nlp10": 0.0}
    assert report["lm_wer"] == {"nlp21": 0.0, "nlp10": 0.0}
    assert len(report["sessions"]) == 2
    assert not (export_dir / "lm_metrics.json").exists()
    assert "wer" not in report
    metrics = json.loads((export_dir / "metrics.json").read_text())
    assert metrics["cer_mean"] == 0.4
