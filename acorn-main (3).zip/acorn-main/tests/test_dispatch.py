"""Dispatcher + runner isolation guardrails."""

from __future__ import annotations

from pathlib import Path

import numpy as np

import acorn
import acorn.runners
from acorn.runners.dispatch import train_model
from acorn.train.config import AdvConfig, TrainConfig
from acorn.train.sequence.config import SequenceTrainConfig

REPO = Path(__file__).resolve().parents[1]


def test_public_train_model_is_dispatcher():
    assert acorn.train_model is acorn.runners.train_model
    assert acorn.train_model is train_model


def test_dispatch_routes_by_config_class():
    orig_tba = train_model.registry[TrainConfig]
    orig_seq = train_model.registry[SequenceTrainConfig]
    orig_dict = train_model.registry[dict]
    train_model.register(TrainConfig, lambda cfg: {"family": "tba"})
    train_model.register(dict, lambda cfg: {"family": "tba"})
    train_model.register(SequenceTrainConfig, lambda cfg: {"family": "seq"})
    try:
        tba = TrainConfig(dataset_keys=["jango"])
        seq = SequenceTrainConfig(dataset_keys=["nlp21"])
        assert train_model(tba) == {"family": "tba"}
        assert train_model(seq) == {"family": "seq"}
        assert train_model({"dataset_keys": ["jango"]})["family"] == "tba"
    finally:
        train_model.register(TrainConfig, orig_tba)
        train_model.register(dict, orig_dict)
        train_model.register(SequenceTrainConfig, orig_seq)


def test_family_runners_do_not_reference_each_other():
    multi = (REPO / "acorn/runners/multi_session.py").read_text(encoding="utf-8")
    seq = (REPO / "acorn/runners/sequence.py").read_text(encoding="utf-8")
    assert "sequence" not in multi
    assert "multi_session" not in seq


def test_sequence_runner_consults_get_sequence_recipe(tmp_path, monkeypatch):
    from acorn.data.sequence.collate import SequenceSession, SequenceSplit
    from acorn.models.registry import (
        DEFAULT_SEQUENCE_RECIPE,
        SEQUENCE_RECIPE_REGISTRY,
        SequenceRecipeSpec,
        get_sequence_recipe,
        register_sequence_recipe,
    )
    from acorn.models.sequence.multi_task_model import SequenceMultiTaskModel
    from acorn.runners.sequence import train_sequence_model
    from acorn.train.sequence.ctc_trainer import CtcTrainer

    dummy_name = "offset36_ctc_test_dummy"
    register_sequence_recipe(
        SequenceRecipeSpec(
            name=dummy_name,
            display_name="test dummy CTC",
            multi_cls=SequenceMultiTaskModel,
            trainer_cls=CtcTrainer,
        )
    )
    called: list[str] = []
    real = get_sequence_recipe

    def spy(name: str = DEFAULT_SEQUENCE_RECIPE):
        called.append(name)
        return real(name)

    monkeypatch.setattr("acorn.runners.sequence.get_sequence_recipe", spy)

    rng = np.random.default_rng(0)
    f, t, n_cls = 6, 48, 5
    split = SequenceSplit(
        features=[rng.standard_normal((t, f)).astype(np.float32) for _ in range(3)],
        labels=[rng.integers(1, n_cls, size=4, dtype=np.int64) for _ in range(3)],
    )
    session = SequenceSession(
        session_key="nlp21",
        task_key="nlp",
        use_smooth=False,
        n_features=f,
        num_classes=n_cls,
        vocab=tuple(str(i) for i in range(n_cls)),
        blank_index=0,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )
    monkeypatch.setattr("acorn.runners.sequence.load_sequence_session", lambda *a, **k: session)
    try:
        cfg = SequenceTrainConfig(
            dataset_keys=["nlp21"],
            recipe=dummy_name,
            n_batch=1,
            batch_size=2,
            kernel=4,
            stride=2,
            hidden=8,
            layers=1,
            dropout=0.0,
            ceb_hidden=16,
            ceb_out=8,
            offset=2,
            cont_batch=8,
            periodic_eval_every=10,
            adv=AdvConfig(enabled=False),
            device="cpu",
        )
        result = train_sequence_model(cfg)
        assert called == [dummy_name]
        assert result.metrics["recipe"] == dummy_name
    finally:
        SEQUENCE_RECIPE_REGISTRY.pop(dummy_name, None)


def test_list_recipes_includes_both_families():
    from acorn.models.registry import list_recipes

    all_names = list_recipes()
    assert "offset36_gru" in all_names
    assert "offset36_gru_advdec" in all_names
    assert "offset36_ctc" in all_names
    assert "offset36_ctc" in list_recipes(label_format="sequence")
    assert "offset36_ctc" not in list_recipes(label_format="time_bin_aligned")
