"""Fail-fast import surface used by CI collection (no training, no data)."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]


def test_import_acorn_and_cebra_helper():
    import acorn
    import cebra.helper
    import cebra.io

    assert acorn.__version__
    assert hasattr(cebra.helper, "parse_version")


def test_import_py7zr_for_dataset_archives():
    import py7zr

    assert hasattr(py7zr, "SevenZipFile")


def test_import_vendored_xds():
    import acorn
    import xds

    assert acorn.__version__
    assert hasattr(xds, "lab_data")
    assert xds.__file__ is not None
    assert Path(xds.__file__).resolve().parent == _REPO_ROOT / "xds"


def test_vendored_xds_import_from_non_repo_cwd(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert Path.cwd() == tmp_path

    import acorn
    import xds

    assert acorn.__version__
    assert hasattr(xds, "lab_data")
    assert xds.__file__ is not None


def test_xds_is_not_a_namespace_package_without_acorn():
    """Repo-root-on-path ``import xds`` must be the loader, not PEP 420 over LICENSE/NOTICE."""
    proc = subprocess.run(
        [
            sys.executable,
            "-c",
            "from xds import lab_data; import xds; assert xds.__file__; raise SystemExit(0)",
        ],
        cwd=_REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stderr
