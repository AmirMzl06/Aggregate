"""Recipe registry + Protocol surface checks."""

import inspect

import pytest

from acorn.models.decoder import MonkeyDecoder
from acorn.models.decoder_adversarial import AdversarialMonkeyDecoder
from acorn.models.decoder_base import BaseGRUDecoder
from acorn.models.interfaces import DecoderModel, EncoderModel
from acorn.models.registry import (
    DEFAULT_RECIPE,
    RECIPE_REGISTRY,
    RecipeSpec,
    get_recipe,
    list_recipes,
)
from acorn.train.encoder_trainer import EncoderTrainer
from acorn.train.encoder_trainer_advdec import AdvDecEncoderTrainer


def _has_callable(cls, name: str) -> bool:
    return callable(getattr(cls, name, None))


def test_default_recipe_registered():
    assert DEFAULT_RECIPE == "offset36_gru"
    assert DEFAULT_RECIPE in RECIPE_REGISTRY
    assert DEFAULT_RECIPE in list_recipes()
    spec = get_recipe()
    assert spec.name == DEFAULT_RECIPE
    assert spec.multi_cls is not None
    assert spec.decoder_cls is MonkeyDecoder
    assert spec.encoder_trainer_cls is EncoderTrainer
    assert spec.decoder_kwargs is None
    assert spec.trainer_cls is EncoderTrainer
    assert isinstance(RecipeSpec.__dict__["trainer_cls"], property)


def test_offset36_cebra_recipe_registered():
    from acorn.models.cebra_fit_model import CebraFitModel
    from acorn.models.interfaces import EncoderModel
    from acorn.train.cebra_fit import CebraFitTrainer

    spec = get_recipe("offset36_cebra")
    assert spec.encoder_trainer_cls is CebraFitTrainer
    assert spec.trainer_cls is CebraFitTrainer
    multi = spec.build_multi(ceb_hidden=8, ceb_out=4)
    assert isinstance(multi, CebraFitModel)
    assert isinstance(multi, EncoderModel)


def test_offset36_gru_advdec_recipe_registered():
    assert "offset36_gru_advdec" in list_recipes()
    spec = get_recipe("offset36_gru_advdec")
    assert spec.decoder_cls is AdversarialMonkeyDecoder
    assert spec.encoder_trainer_cls is AdvDecEncoderTrainer
    assert spec.trainer_cls is AdvDecEncoderTrainer
    assert spec.decoder_kwargs == {"adv_eps": 0.1}


def test_every_recipe_builds_and_satisfies_encoder_surface():
    required_encoder = [
        "add_session",
        "encode",
        "encode_cebra_windows",
        "transform",
        "get_offset",
        "set_session_decoder",
        "session_decoder",
        "session_encoder",
        "encoder_parameters",
        "freeze_decoder",
        "unfreeze_encoder",
        "encoder_train",
        "decoder_train",
        "to",
        "eval",
    ]
    for name, spec in RECIPE_REGISTRY.items():
        multi = spec.build_multi(ceb_hidden=32, ceb_out=8)
        for method in required_encoder:
            assert _has_callable(multi, method), f"{name} missing {method}"
        assert isinstance(multi, EncoderModel), f"{name} does not satisfy EncoderModel"


def test_every_decoder_cls_satisfies_decoder_surface():
    required_decoder = ["fit", "score", "forward"]
    for name, spec in RECIPE_REGISTRY.items():
        for method in required_decoder:
            assert _has_callable(spec.decoder_cls, method), f"{name} decoder missing {method}"
        extra = dict(spec.decoder_kwargs or {})
        dec = spec.decoder_cls(ceb_out=8, hidden=16, layers=1, n_labels=2, n_train_steps=1, **extra)
        assert hasattr(dec, "best_epoch_")
        assert hasattr(dec, "best_val_r2_")
        assert isinstance(dec, DecoderModel), f"{name} decoder does not satisfy DecoderModel"


def test_get_recipe_unknown():
    with pytest.raises(KeyError, match="does_not_exist"):
        get_recipe("does_not_exist")


def test_get_recipe_family_errors():
    from acorn.models.registry import get_sequence_recipe

    with pytest.raises(KeyError) as exc_info:
        get_recipe("offset36_ctc")
    assert exc_info.value.args[0] == (
        "Recipe 'offset36_ctc' is registered for sequence training. "
        "Use get_sequence_recipe, not get_recipe."
    )
    with pytest.raises(KeyError) as exc_info:
        get_sequence_recipe("offset36_gru")
    assert exc_info.value.args[0] == (
        "Recipe 'offset36_gru' is registered for time-bin training. "
        "Use get_recipe, not get_sequence_recipe."
    )


def test_recipe_spec_build_signature():
    spec = get_recipe(DEFAULT_RECIPE)
    sig = inspect.signature(spec.build_multi)
    assert "ceb_hidden" in sig.parameters
    assert "ceb_out" in sig.parameters


def test_adversarial_decoder_is_sibling_not_child_of_default_decoder():
    assert issubclass(AdversarialMonkeyDecoder, BaseGRUDecoder)
    assert MonkeyDecoder not in AdversarialMonkeyDecoder.__mro__


def test_advdec_trainer_is_sibling_not_child_of_a_recipe_class():
    assert issubclass(AdvDecEncoderTrainer, EncoderTrainer)
    assert AdvDecEncoderTrainer.__mro__[1] is EncoderTrainer
