"""Device policy helpers: resolve, sklearn adapter, and CUDA activation."""

from __future__ import annotations

import pytest
import torch

from acorn.utils.device import (
    activate_torch_device,
    cebra_sklearn_device,
    resolve_device,
)

_NO_CUDA = (
    "device='cuda' was requested but torch.cuda.is_available() is False. "
    "Use device='cpu' or device='auto'."
)
_UNSUPPORTED_MPS = (
    "Unsupported device 'mps'. Use 'auto', 'cpu', or 'cuda'. Acorn does not support mps."
)
_REJECT_CUDA1 = (
    "Unsupported device 'cuda:1'. Acorn uses a single GPU. Use 'auto', 'cpu', or 'cuda'."
)


def test_resolve_auto_cuda(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    device = resolve_device("auto")
    assert device.type == "cuda"
    assert device.index == 0


def test_resolve_auto_cpu(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    device = resolve_device("auto")
    assert device == torch.device("cpu")


def test_resolve_cpu():
    device = resolve_device("CPU")
    assert device == torch.device("cpu")


def test_resolve_cuda_unindexed(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    device = resolve_device("cuda")
    assert device.type == "cuda"
    assert device.index == 0
    assert device == torch.device("cuda:0")


def test_resolve_cuda_unavailable_raises(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    with pytest.raises(ValueError) as exc_info:
        resolve_device("cuda")
    assert str(exc_info.value) == _NO_CUDA


def test_resolve_cuda0(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    device = resolve_device("CUDA:0")
    assert device == torch.device("cuda:0")
    assert device.index == 0


def test_resolve_cuda1_rejected(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(torch.cuda, "device_count", lambda: 2)
    with pytest.raises(ValueError) as exc_info:
        resolve_device("cuda:1")
    assert str(exc_info.value) == _REJECT_CUDA1


def test_resolve_cuda1_when_cuda_unavailable(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    with pytest.raises(ValueError) as exc_info:
        resolve_device("cuda:1")
    assert str(exc_info.value) == _REJECT_CUDA1


def test_resolve_mps_raises():
    with pytest.raises(ValueError) as exc_info:
        resolve_device("mps")
    assert str(exc_info.value) == _UNSUPPORTED_MPS


def test_resolve_torch_device_cuda0_passthrough(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    device = resolve_device(torch.device("cuda:0"))
    assert device == torch.device("cuda:0")
    assert device.index == 0


def test_resolve_torch_device_cuda1_rejected(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(torch.cuda, "device_count", lambda: 2)
    with pytest.raises(ValueError) as exc_info:
        resolve_device(torch.device("cuda:1"))
    assert "single GPU" in str(exc_info.value)


def test_cebra_sklearn_device_indexed_is_string():
    assert cebra_sklearn_device(torch.device("cuda:0")) == "cuda:0"


def test_cebra_sklearn_device_unindexed_cuda_passthrough():
    device = torch.device("cuda")
    assert cebra_sklearn_device(device) is device


def test_cebra_sklearn_device_cpu_passthrough():
    device = torch.device("cpu")
    assert cebra_sklearn_device(device) is device


def test_cebra_sklearn_device_rejects_str():
    with pytest.raises(TypeError) as exc_info:
        cebra_sklearn_device("cuda:0")  # type: ignore[arg-type]
    assert str(exc_info.value) == "cebra_sklearn_device requires a torch.device, not str"


def test_activate_torch_device_set_device_iff_indexed(monkeypatch):
    called: list[object] = []
    monkeypatch.setattr(torch.cuda, "set_device", lambda index: called.append(index))

    activate_torch_device(torch.device("cpu"))
    activate_torch_device(torch.device("cuda"))
    assert called == []

    activate_torch_device(torch.device("cuda:0"))
    assert called == [0]
    assert isinstance(called[0], int)
