"""Frozen cluster encoder-attack math (oneshot and cluster_pgd)."""

from __future__ import annotations

import torch
import torch.nn as nn


def reference_oneshot_init(reference: torch.Tensor, eps: float) -> torch.Tensor:
    x_adv = reference.clone().detach().permute(0, 2, 1)
    noise = torch.randn_like(x_adv)
    noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
    noise = noise / noise_norm
    x_adv = x_adv + eps * noise
    return x_adv.permute(0, 2, 1).detach()


def reference_cluster_pgd_init(reference: torch.Tensor, eps: float) -> torch.Tensor:
    x_adv = reference.clone().detach().permute(0, 2, 1)
    noise = torch.randn_like(x_adv)
    noise_norm = noise.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
    noise_normalized = noise / noise_norm
    noise_normalized *= torch.rand((noise.shape[0], noise.shape[1], 1), device=noise.device) * eps
    x_adv = x_adv + noise_normalized
    return x_adv.permute(0, 2, 1).detach()


def reference_cluster_pgd_step(x_adv, grad, reference, eps, alpha) -> torch.Tensor:
    grad = grad.permute(0, 2, 1)
    x_adv = x_adv.permute(0, 2, 1)
    grad_norm = grad.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
    x_adv = (x_adv + alpha * (grad / grad_norm)).detach()
    delta = x_adv - reference.permute(0, 2, 1)
    delta_norm = delta.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-12)
    scale = torch.clamp(eps / delta_norm, max=1.0)
    delta = delta * scale
    return (reference + delta.permute(0, 2, 1)).detach()


def reference_l2_attack_eval(
    x: torch.Tensor,
    y: torch.Tensor,
    model,
    decoder,
    session: str,
    epsilon: float = 0.05,
    num_steps: int = 10,
    adv_norm: str = "l2",
    device=None,
):
    """Cluster ``adv_utils.l2_attack_multi`` / ``multi_under_adv`` 10-step L2 (CPU)."""
    if epsilon <= 0:
        return x
    if device is None:
        device = x.device
    alpha = epsilon * 2 / num_steps
    model = model.to(device)
    decoder = decoder.to(device)
    model.eval()
    decoder.train()
    if hasattr(decoder, "gru") and decoder.gru is not None:
        decoder.gru.dropout = 0.0
    for p in model.parameters():
        p.requires_grad_(False)
    for p in decoder.parameters():
        p.requires_grad_(False)
    x_orig = x.detach().to(device)
    y = y.to(device)
    mse_loss = nn.MSELoss(reduction="mean")
    x_adv = x_orig.clone().detach().requires_grad_(True)
    view_shape = [x.size(0)] + [1] * (x.ndim - 1)
    for _ in range(num_steps):
        predictions = model.transform(x_adv, session)
        predictions, related_y = decoder.forward_window(predictions, y, device)
        loss = mse_loss(predictions, related_y)
        grad = torch.autograd.grad(loss, x_adv, retain_graph=False, create_graph=False)[0]
        with torch.no_grad():
            if adv_norm == "l2":
                grad_flat = grad.view(grad.size(0), -1)
                grad_norm = torch.norm(grad_flat, p=2, dim=1).clamp(min=1e-8)
                normalized_grad = grad / grad_norm.view(*view_shape)
                x_adv = x_adv + alpha * normalized_grad
                delta = x_adv - x_orig
                delta_flat = delta.view(delta.size(0), -1)
                delta_norm = torch.norm(delta_flat, p=2, dim=1)
                factor = torch.min(
                    torch.ones_like(delta_norm), epsilon / delta_norm.clamp(min=1e-8)
                )
                delta *= factor.view(*view_shape)
                x_adv = (x_orig + delta).detach().requires_grad_(True)
            else:
                raise NotImplementedError(adv_norm)
    return x_adv
