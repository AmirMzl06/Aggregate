"""AdversarialMonkeyDecoder PGD step vs snapshotted advdec logic."""

import copy

import torch
import torch.nn as nn
from torch import optim

from acorn.models.decoder_adversarial import AdversarialMonkeyDecoder
from acorn.models.decoder_base import sample_embedding_windows
from tests.reference_advdec import reference_advdec_decoder_pgd_after_clean


def test_adversarial_decoder_fit_smoke():
    torch.manual_seed(0)
    dec = AdversarialMonkeyDecoder(
        ceb_out=4,
        hidden=8,
        layers=1,
        dropout=0.0,
        n_labels=2,
        n_train_steps=3,
        batch_size=2,
        window_size=8,
        min_epochs=1,
        patience=10,
        adv_eps=0.1,
        device=torch.device("cpu"),
    )
    x = torch.randn(32, 4)
    y = torch.randn(32, 2)
    dec.fit(x, y, seed=0, use_val_checkpoint=False, n_train_steps=3)
    assert dec.best_epoch_ == 3
    pred = dec(x[:8].unsqueeze(0), torch.tensor([8]))
    assert pred.shape == (1, 8, 2)


def test_pgd_phase_matches_advdec_reference():
    """One clean+PGD step: ported class vs literal 489a733 PGD block."""
    torch.manual_seed(7)
    kwargs = dict(
        ceb_out=4,
        hidden=8,
        layers=1,
        dropout=0.0,
        n_labels=2,
        batch_size=3,
        window_size=6,
        adv_eps=0.1,
        device=torch.device("cpu"),
    )
    ported = AdversarialMonkeyDecoder(**kwargs)
    reference = AdversarialMonkeyDecoder(**kwargs)
    reference.load_state_dict(copy.deepcopy(ported.state_dict()))

    train_x = torch.randn(20, 4)
    train_y = torch.randn(20, 2)
    mse_fn = nn.MSELoss()

    torch.manual_seed(11)
    opt_p = optim.Adam(ported.parameters(), lr=1e-3, weight_decay=1e-5)
    ported._train_window_step(train_x, train_y, 6, torch.device("cpu"), opt_p, mse_fn)

    torch.manual_seed(11)
    opt_r = optim.Adam(reference.parameters(), lr=1e-3, weight_decay=1e-5)
    reference.train()
    x_batch, y_batch, lengths = sample_embedding_windows(
        train_x, train_y, 3, 6, torch.device("cpu")
    )
    pred = reference.forward(x_batch, lengths)
    loss = mse_fn(pred, y_batch)
    opt_r.zero_grad(set_to_none=True)
    loss.backward()
    nn.utils.clip_grad_norm_(reference.parameters(), 1.0)
    opt_r.step()
    reference_advdec_decoder_pgd_after_clean(
        reference, x_batch, y_batch, lengths, opt_r, mse_fn, eps=0.1
    )

    for k in ported.state_dict():
        assert torch.allclose(
            ported.state_dict()[k], reference.state_dict()[k], atol=1e-6, rtol=1e-5
        ), k
