"""Hippocampus joblib split: ``int(0.8 * T)`` and ``position[:, :2]``."""

from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np

from acorn.data.groups.hippo import HIPPO_HTTP_URLS, HIPPO_SPECS
from acorn.data.groups.hippo.load import load_hippo_session, split_hippo_arrays
from acorn.data.groups.normalize import zscore_spikes_independent
from acorn.data.registry import DATASET_REGISTRY


def test_hippo_specs_and_file_ids():
    assert set(HIPPO_SPECS) == {
        "hippo_achilles",
        "hippo_buddy",
        "hippo_cicero",
        "hippo_gatsby",
    }
    assert "40849463" in HIPPO_HTTP_URLS["achilles"]
    assert "40849460" in HIPPO_HTTP_URLS["buddy"]
    assert "40849457" in HIPPO_HTTP_URLS["cicero"]
    assert "40849454" in HIPPO_HTTP_URLS["gatsby"]
    for key, spec in HIPPO_SPECS.items():
        assert spec.dataset_group == "hippo"
        assert spec.file_type == "jl"
        assert spec.plot_type not in {"emg", "co_reach", "rt_reach"}
        assert spec.label_names == ("x", "y")
        assert spec.pos_dims == (0, 1)
        assert DATASET_REGISTRY[key] is spec or DATASET_REGISTRY[key].key == key


def test_split_hippo_arrays_keeps_full_t_and_xy():
    spikes = np.arange(10 * 3, dtype=np.float64).reshape(10, 3)
    position = np.column_stack(
        [
            np.arange(10, dtype=np.float64),
            np.arange(10, dtype=np.float64) * 2,
            np.arange(10, dtype=np.float64) * 3,
        ]
    )
    arrays = split_hippo_arrays(spikes, position)
    split_idx = int(0.8 * 10)
    assert split_idx == 8
    np.testing.assert_array_equal(arrays["train_x"], spikes[:8])
    np.testing.assert_array_equal(arrays["test_x"], spikes[8:])
    np.testing.assert_array_equal(arrays["train_y"], position[:8, :2])
    np.testing.assert_array_equal(arrays["test_y"], position[8:, :2])
    np.testing.assert_array_equal(arrays["full_x"], spikes)
    np.testing.assert_array_equal(arrays["full_y"], position[:, :2])
    assert arrays["train_y"].shape[1] == 2
    assert arrays["full_y"].shape[1] == 2


def test_load_hippo_session_from_tiny_jl(tmp_path):
    spikes = np.arange(10 * 2, dtype=np.float64).reshape(10, 2)
    position = np.column_stack(
        [
            np.arange(10, dtype=np.float64),
            np.arange(10, dtype=np.float64) + 1,
            np.full(10, 99.0),
        ]
    )
    spec = HIPPO_SPECS["hippo_achilles"]
    dest = tmp_path / "hippo" / "achilles.jl"
    dest.parent.mkdir(parents=True)
    joblib.dump({"spikes": spikes, "position": position}, dest)
    loaded = load_hippo_session(spec, assume_yes=True, data_dir=tmp_path, zscore=False)
    np.testing.assert_allclose(loaded["train_x"], spikes[:8])
    np.testing.assert_allclose(loaded["test_x"], spikes[8:])
    np.testing.assert_allclose(loaded["train_y"], position[:8, :2])
    np.testing.assert_allclose(loaded["full_x"], spikes)
    np.testing.assert_allclose(loaded["full_y"], position[:, :2])
    assert 99.0 not in loaded["full_y"]

    zscored = load_hippo_session(spec, assume_yes=True, data_dir=tmp_path, zscore=True)
    expect_train, expect_test = zscore_spikes_independent(spikes[:8], spikes[8:])
    np.testing.assert_allclose(zscored["train_x"], expect_train.astype(np.float32))
    np.testing.assert_allclose(zscored["test_x"], expect_test.astype(np.float32))
    np.testing.assert_allclose(zscored["full_x"], spikes.astype(np.float32))


def test_hippo_all_from_full_no_split_frac():
    from acorn.data.groups.hippo.load import hippo_all_from_full, load_hippo_session

    assert "split_frac" not in load_hippo_session.__code__.co_varnames
    spikes = np.arange(10 * 2, dtype=np.float64).reshape(10, 2)
    labels = np.arange(10 * 2, dtype=np.float64).reshape(10, 2)
    out = hippo_all_from_full(spikes, labels)
    assert out["train_x"].shape[0] == 10
    assert out["test_x"].shape[0] == 10


def test_ensure_hippo_jl_uses_cebra_downloader(tmp_path, monkeypatch):
    from acorn.data.groups.hippo import HIPPO_SPECS
    from acorn.data.groups.hippo.load import ensure_hippo_jl

    called = {}

    def fake_download(*, url, expected_checksum, location, file_name):
        called["url"] = url
        called["checksum"] = expected_checksum
        called["file_name"] = file_name
        dest = Path(location) / file_name
        dest.write_bytes(b"jl")
        return dest

    monkeypatch.setattr("cebra.data.assets.download_file_with_progress_bar", fake_download)
    path = ensure_hippo_jl(HIPPO_SPECS["hippo_achilles"], assume_yes=True, data_dir=tmp_path)
    assert path.name == "achilles.jl"
    assert path.read_bytes() == b"jl"
    assert "40849463" in called["url"]
    assert called["checksum"] == "c52f9b55cbc23c66d57f3842214058b8"
    assert called["file_name"] == "achilles.jl"


def test_hippo_sources_do_not_use_xds_day_split():
    root = Path(__file__).resolve().parents[1] / "acorn" / "data" / "groups" / "hippo"
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "load_day_split" not in text
        assert "brainsets" not in text
