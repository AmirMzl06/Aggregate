"""Unit tests for adversarial L2 helpers."""

import pytest
import torch

from acorn.train.adversarial import (
    l2_adv_cebra,
    l2_normalize,
    min_l2_distance_data,
    proj_l2_ball,
)
from tests.conftest import device_params


def test_l2_normalize_unit_norm():
    t = torch.randn(8, 4, 3)
    n = l2_normalize(t)
    norms = n.reshape(8, -1).norm(p=2, dim=1)
    assert torch.allclose(norms, torch.ones(8), atol=1e-5)


def test_proj_l2_ball_inside_unchanged():
    orig = torch.zeros(4, 5)
    adv = torch.ones(4, 5) * 0.01
    out = proj_l2_ball(adv, orig, epsilon=1.0)
    assert torch.allclose(out, adv, atol=1e-6)


def test_proj_l2_ball_clips_to_eps():
    orig = torch.zeros(2, 10)
    adv = torch.ones(2, 10) * 10.0
    eps = 0.5
    out = proj_l2_ball(adv, orig, epsilon=eps)
    delta = (out - orig).reshape(2, -1)
    norms = delta.norm(p=2, dim=1)
    assert torch.allclose(norms, torch.full((2,), eps), atol=1e-5)


def test_min_l2_distance_data_two_points():
    x = torch.tensor([[0.0, 0.0], [3.0, 4.0]])
    d = min_l2_distance_data(x)
    assert abs(d - 5.0) < 1e-5


class _FakeBatch:
    def __init__(self, x: torch.Tensor):
        self.reference = x
        self.positive = x.clone()
        self.negative = x.clone()


class _FakeModel:
    def __init__(self, device: torch.device):
        self.w = torch.nn.Parameter(torch.ones(1, device=device), requires_grad=True)

    def encode_cebra_windows(self, x, session_name):
        return x.reshape(x.size(0), -1).mean(dim=1, keepdim=True) * self.w


@pytest.mark.parametrize("device", device_params)
def test_l2_adv_cebra_calls_clip_grad_fn(device):
    called: list[int] = []
    x = torch.randn(2, 3, 4, device=device)
    model = _FakeModel(device)
    opt = torch.optim.SGD([model.w], lr=0.1)

    def _crit(r, p, n):
        return (r + p + n).pow(2).mean(), None, None

    l2_adv_cebra(
        model,
        opt,
        _FakeBatch(x),
        "s",
        _crit,
        0.1,
        2,
        adv_style="global",
        clip_grad_fn=lambda: called.append(1),
    )
    assert called == [1]
    assert model.w.device.type == device.type
