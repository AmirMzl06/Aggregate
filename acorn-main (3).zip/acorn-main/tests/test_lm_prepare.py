"""Kaldi job prep and channel permute."""

from __future__ import annotations

import json

import numpy as np
import torch

from acorn.lm.permute import permute_to_kaldi
from acorn.lm.prepare import prepare_kaldi_job
from acorn.lm.presets import original_preset
from acorn.lm.schema import load_session

NLP_VOCAB = ["<BLANK>", ">", ",", "?", "~", "'"] + [chr(ord("a") + i) for i in range(26)]


def _write_export(root, logits, label_ids, transcripts=None):
    root.mkdir(parents=True, exist_ok=True)
    dest = root / "nlp21_logits.pt"
    torch.save(
        {
            "logits": logits,
            "input_lengths": torch.tensor([t.shape[0] for t in logits], dtype=torch.long),
            "label_ids": label_ids,
            "dataset_key": "nlp21",
            "task_key": "nlp",
            "session_key": "nlp21",
            "vocab": NLP_VOCAB,
            "blank_index": 0,
            **({"transcripts": transcripts} if transcripts is not None else {}),
        },
        dest,
    )
    manifest = {
        "schema": "acorn.ctc_export.v1.1",
        "datasets": [
            {
                "dataset_key": "nlp21",
                "task_key": "nlp",
                "session_key": "nlp21",
                "vocab": NLP_VOCAB,
                "blank_index": 0,
                "path": dest.name,
                "has_transcripts": transcripts is not None,
            }
        ],
    }
    (root / "ctc_export_manifest.json").write_text(json.dumps(manifest, indent=2))
    return root


def test_prepare_writes_kaldi_job(tmp_path):
    logits = [torch.zeros(2, 32), torch.ones(3, 32)]
    labels = [torch.tensor([1]), torch.tensor([2, 3])]
    export = _write_export(tmp_path / "exp", logits, labels)
    session = load_session(export)
    dest = prepare_kaldi_job(session, tmp_path / "job", original_preset("nlp"))
    cfg = json.loads(dest.read_text())
    assert cfg["schema"] == "acorn_lm.kaldi_job.v1"
    assert cfg["n_trials"] == 2
    assert cfg["rescore"] is False
    loaded = np.load(tmp_path / "job" / "trials" / "000000.npy")
    assert loaded.shape == (2, 32)
    assert loaded.dtype == np.float32


def test_nlp_permute_is_identity():
    rng = np.random.default_rng(0)
    logits = rng.standard_normal((5, 32)).astype(np.float32)
    out = permute_to_kaldi(logits, "nlp")
    np.testing.assert_array_equal(out, logits)


def test_speech_blank_sil_phones():
    logits = np.arange(41, dtype=np.float32).reshape(1, 41)
    out = permute_to_kaldi(logits, "speech")
    assert out[0, 0] == 0
    assert out[0, 1] == 40
    np.testing.assert_array_equal(out[0, 2:], np.arange(1, 40, dtype=np.float32))
