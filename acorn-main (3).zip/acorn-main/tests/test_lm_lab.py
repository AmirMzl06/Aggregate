"""Real docker builds are lab-only; default pytest must skip this."""

from __future__ import annotations

import os

import pytest

from acorn.lm.docker_run import build_kaldi_image, build_neural_image


@pytest.mark.lab
@pytest.mark.skipif(not os.environ.get("ACORN_LAB"), reason="ACORN_LAB not set")
def test_real_docker_build_both_images():
    build_kaldi_image()
    build_neural_image()
