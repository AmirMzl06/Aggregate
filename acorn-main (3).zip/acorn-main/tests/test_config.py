"""Regression guards for TrainConfig defaults."""

from pathlib import Path

import pytest
from pydantic import BaseModel, ValidationError

from acorn.data.loader import DATA_DIR as LOADER_DATA_DIR
from acorn.data.registry import DatasetSpec
from acorn.models.registry import RecipeSpec
from acorn.train.config import (
    DEFAULT_DATASETS,
    N_BATCHES,
    N_DECODER_BATCHES,
    AdvConfig,
    TrainConfig,
)
from acorn.train.sequence.config import SequenceTrainConfig
from acorn.utils.constants import DATA_DIR


def test_data_dir_canonical():
    assert DATA_DIR == Path("./data")
    assert Path(LOADER_DATA_DIR) == Path("./data")


def test_train_config_defaults():
    cfg = TrainConfig(dataset_keys=["jango"])
    assert cfg.output_dir is None
    assert cfg.enc_lr == 3e-5
    assert cfg.batch_size == 256
    assert cfg.n_batch == 30000
    assert cfg.n_decoder_batches == 30000
    assert cfg.temperature == 0.4
    assert cfg.time_offset == 4
    assert cfg.window == 256
    assert cfg.offset == 4
    assert cfg.ceb_out == 64
    assert cfg.encoder_val_checkpoint is True
    assert cfg.decoder_val_checkpoint is True
    assert cfg.recipe == "offset36_gru"
    assert cfg.device == "auto"
    assert cfg.adv.enabled is True
    assert cfg.adv.style == "bin"
    assert cfg.adv.eps == 0.8
    assert cfg.adv.eps_mode == "fixed"
    assert cfg.adv.norm == "l2"
    assert cfg.adv.steps == 10
    assert cfg.adv.alpha is None
    assert cfg.assume_yes is False
    assert cfg.conditional == "time_delta"
    assert cfg.decoder_adv == "off"
    assert cfg.mlp_decoder is False
    assert cfg.full_session is False
    assert cfg.zscore is True


def test_adv_config_styles_include_oneshot_and_cluster_pgd():
    assert AdvConfig(style="oneshot").style == "oneshot"
    assert AdvConfig(style="cluster_pgd").style == "cluster_pgd"
    with pytest.raises(ValidationError):
        AdvConfig(style="pgd")
    cfg = TrainConfig(
        dataset_keys=["jango"],
        decoder_adv="oneshot",
        conditional="time",
    )
    d = cfg.to_legacy_dict()
    assert d["decoder_adv"] == "oneshot"
    assert d["conditional"] == "time"
    cfg2 = TrainConfig(dataset_keys=["jango"], conditional=None)
    assert cfg2.to_legacy_dict()["conditional"] is None


def test_module_level_batch_constants():
    assert N_BATCHES == 30000
    assert N_DECODER_BATCHES == 30000
    assert "jango" in DEFAULT_DATASETS
    assert "mihili_co" in DEFAULT_DATASETS
    assert "mihili_rt" in DEFAULT_DATASETS
    assert "pop" in DEFAULT_DATASETS


def test_legacy_dict_keys():
    cfg = TrainConfig(dataset_keys=["jango", "pop"])
    d = cfg.to_legacy_dict()
    assert d["batchSize"] == 256
    assert d["nBatch"] == 30000
    assert d["adv"] is True
    assert d["adv_style"] == "bin"
    assert d["enc_lr"] == 3e-5
    assert d["dataset_keys"] == ["jango", "pop"]
    assert d["recipe"] == "offset36_gru"
    assert d["device"] == "auto"
    assert d["assume_yes"] is False
    assert d["conditional"] == "time_delta"
    assert d["decoder_adv"] == "off"
    assert d["mlp_decoder"] is False
    assert d["full_session"] is False
    assert d["zscore"] is True
    assert d["output_dir"] is None


def test_public_specs_are_pydantic_models():
    assert issubclass(AdvConfig, BaseModel)
    assert issubclass(TrainConfig, BaseModel)
    assert issubclass(DatasetSpec, BaseModel)
    assert issubclass(RecipeSpec, BaseModel)
    assert issubclass(SequenceTrainConfig, BaseModel)
    with pytest.raises(ValidationError):
        TrainConfig(dataset_keys=["jango"], unknown_field=1)
    with pytest.raises(ValidationError):
        SequenceTrainConfig(dataset_keys=["nlp21"], ctc_weight=1.0)
    cfg = TrainConfig(dataset_keys=["jango"], adv={"enabled": False})
    assert isinstance(cfg.adv, AdvConfig)
    assert cfg.adv.enabled is False
    dumped = cfg.model_dump()
    assert dumped["dataset_keys"] == ["jango"]
    assert dumped["adv"]["enabled"] is False


def test_device_default_auto_on_both_configs():
    tba = TrainConfig(dataset_keys=["jango"])
    seq = SequenceTrainConfig(dataset_keys=["nlp21"])
    assert tba.device == "auto"
    assert seq.device == "auto"


def test_device_fold_cuda_n_and_rejects_torch_device():
    import torch

    cfg = TrainConfig(dataset_keys=["jango"], device="CUDA:0")
    assert cfg.device == "cuda"
    seq = SequenceTrainConfig(dataset_keys=["nlp21"], device="CUDA:0")
    assert seq.device == "cuda"
    with pytest.raises(ValidationError):
        TrainConfig(dataset_keys=["jango"], device=torch.device("cpu"))
    with pytest.raises(ValidationError):
        TrainConfig(dataset_keys=["jango"], device="cuda:1")


def test_time_bin_auto_does_not_brake_without_cuda(monkeypatch):
    import torch

    from acorn.runners.multi_session import train_model

    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)

    class LoaderConstructed(Exception):
        pass

    def _boom(*args, **kwargs):
        raise LoaderConstructed("loader constructed")

    monkeypatch.setattr("acorn.runners.multi_session.DatasetLoader", _boom)
    with pytest.raises(LoaderConstructed, match="loader constructed"):
        train_model(TrainConfig(dataset_keys=["jango"], device="auto"))


def test_time_bin_cpu_does_not_brake(monkeypatch):
    import torch

    from acorn.runners.multi_session import train_model

    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)

    class LoaderConstructed(Exception):
        pass

    def _boom(*args, **kwargs):
        raise LoaderConstructed("loader constructed")

    monkeypatch.setattr("acorn.runners.multi_session.DatasetLoader", _boom)
    with pytest.raises(LoaderConstructed, match="loader constructed"):
        train_model(TrainConfig(dataset_keys=["jango"], device="cpu"))


def test_build_cebra_train_dataset_sklearn_device_adapter(monkeypatch):
    import numpy as np
    import torch

    import cebra.integrations.sklearn.dataset as sk_ds
    from acorn.train.cebra_contrastive import build_cebra_train_dataset
    from acorn.utils.device import cebra_sklearn_device, resolve_device

    captured: list[object] = []

    class FakeSklearnDataset:
        def __init__(self, *args, device=None, **kwargs):
            captured.append(device)
            self.offset = None
            self.trial_ids = None

    monkeypatch.setattr(sk_ds, "SklearnDataset", FakeSklearnDataset)
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    x = np.zeros((8, 3), dtype=np.float64)
    y = np.zeros((8, 2), dtype=np.float64)
    offset = object()

    resolved = resolve_device("cuda")
    assert resolved == torch.device("cuda:0")
    assert cebra_sklearn_device(resolved) == "cuda:0"
    build_cebra_train_dataset(x, y, offset, resolved)
    assert captured[-1] == "cuda:0"

    indexed = torch.device("cuda:0")
    build_cebra_train_dataset(x, y, offset, indexed)
    assert captured[-1] == "cuda:0"

    unindexed = torch.device("cuda")
    build_cebra_train_dataset(x, y, offset, unindexed)
    assert captured[-1] is unindexed

    cpu = torch.device("cpu")
    build_cebra_train_dataset(x, y, offset, cpu)
    assert captured[-1] is cpu


def test_validate_dataset_keys_time_bin_messages():
    from acorn.data.dataset_keys import validate_dataset_keys
    from acorn.data.registry import DATASETS

    choices = list(DATASETS)
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["nope"], family="time_bin_aligned")
    assert str(exc_info.value) == f"Unknown dataset keys: ['nope']. Choices: {choices}"
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["nlp21"], family="time_bin_aligned")
    assert str(exc_info.value) == (
        "Dataset key 'nlp21' is registered for sequence training. "
        "Use SequenceTrainConfig, not time-bin training."
    )
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["jango", "nlp21"], family="time_bin_aligned")
    assert str(exc_info.value) == (
        f"Dataset list mixes time-bin and sequence keys: ['nlp21']. "
        f"Time-bin training only accepts: {choices}."
    )
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys([], family="time_bin_aligned")
    assert str(exc_info.value) == "No dataset keys given."
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["chewie_co"], family="time_bin_aligned")
    assert str(exc_info.value) == (f"Unknown dataset keys: ['chewie_co']. Choices: {choices}")


def test_validate_dataset_keys_sequence_messages():
    from acorn.data.dataset_keys import validate_dataset_keys
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    choices = list(SEQUENCE_DATASET_REGISTRY)
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["nope"], family="sequence")
    assert str(exc_info.value) == (f"Unknown sequence dataset keys: ['nope']. Choices: {choices}")
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["jango"], family="sequence")
    assert str(exc_info.value) == (
        "Dataset key 'jango' is registered for time-bin training. "
        "Use TrainConfig or examples/demo_time_bin.py, not sequence training."
    )
    with pytest.raises(ValueError) as exc_info:
        validate_dataset_keys(["nlp21", "jango"], family="sequence")
    assert str(exc_info.value) == (
        f"Dataset list mixes sequence and time-bin keys: ['jango']. "
        f"Sequence training only accepts: {choices}."
    )


def test_sequence_train_config_python_output_dir_not_prefixed():
    cfg = SequenceTrainConfig(dataset_keys=["nlp21"], output_dir="not_prefixed")
    assert cfg.output_dir == "not_prefixed"
    defaulted = SequenceTrainConfig(dataset_keys=["nlp21"])
    assert defaulted.output_dir is None
