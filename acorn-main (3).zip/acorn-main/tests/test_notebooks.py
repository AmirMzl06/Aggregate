"""Parse-only checks for published NLP21 notebooks."""

from __future__ import annotations

import json
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
_TRAIN = _REPO / "examples" / "notebooks" / "demo_nlp21.ipynb"
_LM = _REPO / "examples" / "notebooks" / "demo_nlp21_lm.ipynb"
_NEURAL_DECODER = "neural" + "Decoder"
_NOTEBOOK_ARGS = "notebook" + "_args"
_COLAB_NGRAM_REFUSE = "n-gram LM is not supported on Colab"
_ANON_CLONE = "git clone https://github.com/alijabbari00/acorn.git"
_COLAB_BADGE = "colab.research.google.com/assets/colab-badge"


def _src(path: Path) -> str:
    nb = json.loads(path.read_text(encoding="utf-8"))
    return "\n".join("".join(cell.get("source", [])) for cell in nb["cells"])


def test_train_notebook_two_paper_length_fits():
    src = _src(_TRAIN)
    assert src.count("train_model(") == 2
    assert "nlp21" in src
    assert "20000" in src
    assert "batch_size=16" in src
    assert "AdvConfig(enabled=False)" in src
    assert "n_batch=4" not in src
    assert ".pt" not in src
    assert "output_dir" not in src
    assert "metrics.json" not in src
    assert "result_acorn" in src
    assert "result_base" in src
    assert "result_cebra" not in src
    assert "nlp21_baseline" in src
    assert "nlp21_cebra" not in src
    assert "save_run" in src
    assert "SAVE_DIR" in src
    assert "CEBRA.load" not in src
    assert _NEURAL_DECODER not in src
    assert _NOTEBOOK_ARGS not in src
    assert 'run_line_magic("pip", "install -e .")' in src
    assert "pyproject.toml" in src
    assert _ANON_CLONE not in src
    assert _COLAB_BADGE not in src
    assert "git+https://" in src  # comment forbidding pip-from-git alone


def test_lm_notebook_ngram_stub_and_precomputed_plot():
    src = _src(_LM)
    assert "ACORN_NB_RUN_NGRAM" in src
    assert "if RUN_NGRAM:" in src
    assert "rescore_export" in src
    assert "TFGPT2LMHeadModel" in src
    assert "Hugging Face" in src
    assert "64 GiB" in src
    assert "GPT-2 XL" in src
    assert "40GB" not in src
    assert "350GB" not in src
    assert "does not ship an n-gram decoder" not in src
    assert _COLAB_NGRAM_REFUSE not in src
    assert _NEURAL_DECODER not in src
    assert _NOTEBOOK_ARGS not in src
    assert "demo_nlp21_lm.json" in src
    assert "demo_nlp21_lm.png" in src
    assert "20000" not in src
    assert 'run_line_magic("pip", "install -e .")' in src
    assert "pyproject.toml" in src
    assert _ANON_CLONE not in src
    assert _COLAB_BADGE not in src


def test_notebooks_are_nbformat4_ruff_source_lines():
    """Match ``ruff format`` notebook cells: mid-lines end with ``\\n``; last code line does not."""
    for path in (_TRAIN, _LM):
        nb = json.loads(path.read_text(encoding="utf-8"))
        assert nb["nbformat"] == 4
        for cell in nb["cells"]:
            src = cell.get("source", [])
            assert src, f"empty cell in {path}"
            assert all(line.endswith("\n") for line in src[:-1])
            if cell.get("cell_type") == "code":
                assert not src[-1].endswith("\n")
            else:
                assert src[-1].endswith("\n")
