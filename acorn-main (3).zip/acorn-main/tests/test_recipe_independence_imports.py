"""Deleting one recipe's decoder file must not prevent the other from loading."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _run_isolated(blocked_module: str, recipe_name: str) -> subprocess.CompletedProcess[str]:
    script = f"""
import sys
sys.modules[{blocked_module!r}] = None
from acorn.models.registry import get_recipe
spec = get_recipe({recipe_name!r})
assert spec.name == {recipe_name!r}
dec = spec.decoder_cls(ceb_out=4, hidden=8, layers=1, n_labels=2, n_train_steps=1)
print("ok", spec.name, type(dec).__name__)
"""
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(REPO_ROOT), env.get("PYTHONPATH", "")]).rstrip(
        os.pathsep
    )
    return subprocess.run(
        [sys.executable, "-c", script],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


def test_advdec_recipe_loads_without_default_decoder_module():
    result = _run_isolated("acorn.models.decoder", "offset36_gru_advdec")
    assert result.returncode == 0, result.stdout + result.stderr
    assert "offset36_gru_advdec" in result.stdout
    assert "AdversarialMonkeyDecoder" in result.stdout


def test_default_recipe_loads_without_advdec_decoder_module():
    result = _run_isolated("acorn.models.decoder_adversarial", "offset36_gru")
    assert result.returncode == 0, result.stdout + result.stderr
    assert "offset36_gru" in result.stdout
    assert "MonkeyDecoder" in result.stdout
