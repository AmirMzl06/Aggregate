"""Windowed R^2 evaluation sanity checks (CPU, synthetic)."""

import torch
import torch.nn as nn

from acorn.eval.windowed import _predict_stream_windowed, evaluate_r2


class _IdentityEncoder(nn.Module):
    def forward(self, x, lengths):
        return x, lengths


class _IdentityDecoder(nn.Module):
    def forward(self, embs, lengths=None):
        return embs


def test_evaluate_r2_perfect_predictor():
    enc = _IdentityEncoder()
    dec = _IdentityDecoder()
    # Labels equal neural features → identity encode/decode ⇒ R² = 1.
    x = torch.randn(512, 3)
    y = x.clone()
    r2 = evaluate_r2(enc, dec, x, y, device=torch.device("cpu"), window_size=128)
    assert abs(r2 - 1.0) < 1e-5


def test_evaluate_r2_window_64():
    enc = _IdentityEncoder()
    dec = _IdentityDecoder()
    x = torch.randn(256, 3)
    y = x.clone()
    r2 = evaluate_r2(enc, dec, x, y, device=torch.device("cpu"), window_size=64)
    assert abs(r2 - 1.0) < 1e-5


def test_predict_stream_covers_all_bins():
    enc = _IdentityEncoder()
    dec = _IdentityDecoder()
    t, d = 300, 2
    x = torch.randn(t, d)
    y = torch.randn(t, d)
    pred = _predict_stream_windowed(enc, dec, x, y, torch.device("cpu"), window_size=128)
    assert pred.shape == (t, d)
    assert torch.isfinite(torch.from_numpy(pred)).all()
