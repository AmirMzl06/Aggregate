"""Perich trial split / bin-window / 6-D concat math against a frozen fixture."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from acorn.data.groups.normalize import zscore_spikes_independent
from acorn.data.groups.perich import PERICH_DAYS, PERICH_SPECS, parse_perich_key, perich_key
from acorn.data.groups.perich.load import resolve_perich_nwb_path
from acorn.data.groups.perich.trials import (
    BinnedKinematics,
    TrialTable,
    arrays_from_valid_trials,
    extract_center_out_reaching_trials,
    extract_random_target_reaching_trials,
    get_trials_idx_by_trial,
    split_trials,
    stack_trial_bins,
)
from acorn.data.registry import DATASET_REGISTRY, get_dataset


def _tiny_dayk() -> BinnedKinematics:
    time_frame = np.arange(20, dtype=np.float64) * 0.05
    n_t = len(time_frame)
    spike_counts = np.arange(n_t * 2, dtype=np.float64).reshape(n_t, 2)
    curs_p = np.column_stack(
        [np.arange(n_t, dtype=np.float64), np.arange(n_t, dtype=np.float64) + 10]
    )
    curs_v = np.column_stack(
        [np.arange(n_t, dtype=np.float64) + 20, np.arange(n_t, dtype=np.float64) + 30]
    )
    curs_a = np.column_stack(
        [np.arange(n_t, dtype=np.float64) + 40, np.arange(n_t, dtype=np.float64) + 50]
    )
    return BinnedKinematics(
        time_frame=time_frame,
        spike_counts=spike_counts,
        curs_p=curs_p,
        curs_v=curs_v,
        curs_a=curs_a,
    )


def _valid_co_trials() -> TrialTable:
    # Four valid CO trials plus one failed trial that must be dropped before the split.
    go_cue = np.array([0.10, 0.35, 0.55, 0.75, 0.20], dtype=np.float64)
    stop = np.array([0.30, 0.50, 0.70, 0.90, 0.40], dtype=np.float64)
    start = np.array([0.00, 0.32, 0.52, 0.72, 0.00], dtype=np.float64)
    end = np.array([0.31, 0.51, 0.71, 0.91, 0.41], dtype=np.float64)
    return TrialTable(
        {
            "go_cue_time": go_cue,
            "stop_time": stop,
            "start": start,
            "end": end,
            "result": np.array(["R", "R", "R", "R", "F"], dtype=object),
            "target_id": np.array([0.0, 1.0, 2.0, 3.0, 4.0]),
            "is_valid": np.array([True, True, True, True, False]),
        }
    )


def test_perich_key_counts_match_days():
    assert sum(PERICH_DAYS.values()) == 111
    assert "J-RT" not in PERICH_DAYS
    assert len(PERICH_SPECS) == 111
    assert parse_perich_key("perich_c_co_1") == ("C-CO", 0)
    assert parse_perich_key("perich_m_rt_6") == ("M-RT", 5)
    assert perich_key("C-CO", 0) == "perich_c_co_1"
    assert get_dataset("perich_c_co_1").dataset_group == "perich"
    assert get_dataset("perich_c_rt_1").plot_type == "rt_reach"
    assert get_dataset("perich_j_co_1").plot_type == "co_reach"
    assert "perich_j_rt_1" not in DATASET_REGISTRY


def test_split_trials_is_contiguous_80_20():
    trials = _valid_co_trials().select_by_mask(_valid_co_trials().is_valid)
    train, valid, test = split_trials(trials, test_size=0.2, valid_size=0.0)
    assert len(trials) == 4
    assert len(train) == 3
    assert len(test) == 1
    assert len(valid) == 1
    np.testing.assert_array_equal(
        test.go_cue_time, train.go_cue_time[-1:] * 0 + trials.go_cue_time[-1]
    )
    np.testing.assert_array_equal(test.go_cue_time, np.array([0.75]))
    np.testing.assert_array_equal(train.go_cue_time, np.array([0.10, 0.35, 0.55]))
    np.testing.assert_array_equal(valid.go_cue_time, test.go_cue_time)


def test_co_bin_window_uses_gocue_and_stop_plus_pad():
    dayk = _tiny_dayk()
    trials = _valid_co_trials().select_by_mask(_valid_co_trials().is_valid)
    idx = get_trials_idx_by_trial(dayk.time_frame, trials, "gocue_time")
    t1, t2 = 0.10, 0.30 + 0.0008
    expected = np.where((dayk.time_frame > t1) & (dayk.time_frame < t2))[0]
    np.testing.assert_array_equal(idx[0], expected)
    assert np.any(np.isclose(dayk.time_frame[idx[0]], 0.30))
    assert not np.any(np.isclose(dayk.time_frame[idx[0]], 0.10))


def test_co_bin_window_aliases_go_cue_time_array_only():
    dayk = _tiny_dayk()
    go = np.array([0.10, 0.35, 0.55, 0.75], dtype=np.float64)
    cols = {
        "target_on_time": np.array([0.00, 0.32, 0.52, 0.72], dtype=np.float64),
        "stop_time": np.array([0.30, 0.50, 0.70, 0.90], dtype=np.float64),
        "start_time": np.array([0.00, 0.32, 0.52, 0.72], dtype=np.float64),
        "result": np.array(["R", "R", "R", "R"], dtype=object),
        "target_id": np.array([0.0, 1.0, 2.0, 3.0]),
        "go_cue_time_array": go.reshape(-1, 1),
    }
    assert "go_cue_time" not in cols
    trials = extract_center_out_reaching_trials(cols, cursor_t_end=10.0)
    np.testing.assert_array_equal(trials.go_cue_time, go)
    idx = get_trials_idx_by_trial(dayk.time_frame, trials, "gocue_time")
    expected = np.where((dayk.time_frame > 0.10) & (dayk.time_frame < 0.3008))[0]
    np.testing.assert_array_equal(idx[0], expected)


def test_rt_bin_window_uses_start_and_end_plus_pad():
    dayk = _tiny_dayk()
    trials = TrialTable(
        {
            "start": np.array([0.10], dtype=np.float64),
            "end": np.array([0.30], dtype=np.float64),
        }
    )
    idx = get_trials_idx_by_trial(dayk.time_frame, trials, "start")
    expected = np.where((dayk.time_frame > 0.10) & (dayk.time_frame < 0.3008))[0]
    np.testing.assert_array_equal(idx[0], expected)


def test_six_d_concat_and_vstack_match_fixture():
    dayk = _tiny_dayk()
    trials = _valid_co_trials().select_by_mask(_valid_co_trials().is_valid)
    train_x, train_y, test_x, test_y = arrays_from_valid_trials(dayk, trials, "gocue_time")
    train_trials, _, test_trials = split_trials(trials, test_size=0.2, valid_size=0.0)
    idx_train = get_trials_idx_by_trial(dayk.time_frame, train_trials, "gocue_time")
    idx_test = get_trials_idx_by_trial(dayk.time_frame, test_trials, "gocue_time")
    expected_train_x = np.vstack([dayk.spike_counts[n, :] for n in idx_train])
    expected_test_x = np.vstack([dayk.spike_counts[n, :] for n in idx_test])
    expected_train_y = np.vstack(
        [
            np.concatenate(
                [dayk.curs_p[n, :], dayk.curs_v[n, :], dayk.curs_a[n, :]],
                axis=1,
            )
            for n in idx_train
        ]
    )
    expected_test_y = np.vstack(
        [
            np.concatenate(
                [dayk.curs_p[n, :], dayk.curs_v[n, :], dayk.curs_a[n, :]],
                axis=1,
            )
            for n in idx_test
        ]
    )
    np.testing.assert_allclose(train_x, expected_train_x)
    np.testing.assert_allclose(test_x, expected_test_x)
    np.testing.assert_allclose(train_y, expected_train_y)
    np.testing.assert_allclose(test_y, expected_test_y)
    assert train_y.shape[1] == 6
    assert test_y.shape[1] == 6
    stacked = stack_trial_bins(dayk, train_trials, "gocue_time")
    np.testing.assert_allclose(stacked[0], expected_train_x)


def test_center_out_validity_drops_failures_and_short_trials():
    cols = {
        "target_on_time": np.array([0.0, 1.0, 2.0, 3.0], dtype=np.float64),
        "stop_time": np.array([0.8, 1.8, 2.2, 3.8], dtype=np.float64),
        "start_time": np.array([0.0, 1.0, 2.0, 3.0], dtype=np.float64),
        "result": np.array(["R", "F", "R", "R"], dtype=object),
        "target_id": np.array([0.0, 1.0, np.nan, 3.0]),
        "go_cue_time": np.array([0.2, 1.2, 2.1, 3.2], dtype=np.float64),
    }
    trials = extract_center_out_reaching_trials(cols, cursor_t_end=10.0)
    assert len(trials) == 4
    assert int(np.sum(trials.is_valid)) >= 1
    assert not bool(trials.is_valid[1])  # failed result
    assert not bool(trials.is_valid[2])  # nan target_id


def test_random_target_validity_requires_four_attempts():
    cols = {
        "start_time": np.array([0.0, 0.0], dtype=np.float64),
        "stop_time": np.array([3.0, 3.0], dtype=np.float64),
        "result": np.array(["R", "R"], dtype=object),
        "num_attempted": np.array([4, 3]),
    }
    trials = extract_random_target_reaching_trials(cols)
    np.testing.assert_array_equal(trials.is_valid, np.array([True, False]))


def test_missing_nwb_raises(tmp_path):
    spec = get_dataset("perich_c_co_1")
    with pytest.raises(FileNotFoundError, match="Missing NWB"):
        resolve_perich_nwb_path(spec, data_dir=tmp_path)


def test_perich_sources_do_not_import_brainsets():
    root = Path(__file__).resolve().parents[1] / "acorn" / "data" / "groups" / "perich"
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "brainsets" not in text
        assert "macorn_cluster" not in text
        assert "load_day_split" not in text


def test_zscore_independent_per_split_frozen_numbers():
    train = np.array([[0.0, 2.0], [2.0, 4.0]], dtype=np.float64)
    test = np.array([[10.0, 0.0], [12.0, 2.0]], dtype=np.float64)
    z_train, z_test = zscore_spikes_independent(train, test)
    expected_train = np.array(
        [
            [(0.0 - 1.0) / (1.0 + 1e-3), (2.0 - 3.0) / (1.0 + 1e-3)],
            [(2.0 - 1.0) / (1.0 + 1e-3), (4.0 - 3.0) / (1.0 + 1e-3)],
        ]
    )
    expected_test = np.array(
        [
            [(10.0 - 11.0) / (1.0 + 1e-3), (0.0 - 1.0) / (1.0 + 1e-3)],
            [(12.0 - 11.0) / (1.0 + 1e-3), (2.0 - 1.0) / (1.0 + 1e-3)],
        ]
    )
    np.testing.assert_allclose(z_train, expected_train)
    np.testing.assert_allclose(z_test, expected_test)
    # Independent: test is not scaled by the train mean.
    assert not np.allclose(
        (test - train.mean(0)) / (train.std(0) + 1e-3),
        z_test,
    )
