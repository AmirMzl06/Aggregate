"""Synthetic v1.1 transcript walkers + export length checks."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
import scipy.io as sio

from acorn.data.sequence.loaders.nlp10 import collect_nlp10_final_transcripts
from acorn.data.sequence.loaders.speech45 import collect_speech45_final_transcripts
from acorn.eval.sequence.export import SCHEMA, export_session_logits


def _write_nlp10_mat(path: Path, sentences: list[str], *, excluded=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    n = len(sentences)
    sio.savemat(
        path,
        {
            "intendedText": np.array(sentences, dtype=object).reshape(n, 1),
            "neuralActivityCube": np.zeros((n, 4, 2), dtype=np.float64),
            "numTimeBinsPerSentence": np.full((n, 1), 4, dtype=np.int64),
            "sentenceBlockNums": np.array([[1]] * n, dtype=np.int64),
            "excludedSentences": np.zeros((n, 1), dtype=np.int64)
            if excluded is None
            else np.array(excluded, dtype=np.int64).reshape(n, 1),
        },
    )


def test_nlp10_walker_order_and_filters(tmp_path):
    root = tmp_path / "nlp10"
    _write_nlp10_mat(root / "day0" / "sentences.mat", ["she was", "bad3", "ok"])
    _write_nlp10_mat(root / "day1" / "sentences.mat", ["fine"], excluded=[[1]])
    texts = collect_nlp10_final_transcripts(root)
    assert "she>was" in texts
    assert all("3" not in t and "5" not in t for t in texts)


def test_speech45_transcription_dataset_not_attr(tmp_path, monkeypatch):
    import h5py

    root = tmp_path / "speech45" / "hdf5_data_final" / "s1"
    root.mkdir(parents=True)
    with h5py.File(root / "data_train.hdf5", "w") as handle:
        g1 = handle.create_group("t1")
        g1.attrs["n_time_steps"] = 2
        g1.attrs["seq_len"] = 2
        g1.attrs["block_num"] = 1
        g1.create_dataset("input_features", data=np.zeros((2, 4), dtype=np.float32))
        g1.create_dataset("seq_class_ids", data=np.array([1, 2], dtype=np.int64))
        g1.create_dataset("transcription", data=np.array([ord("A"), 0, 0], dtype=np.int32))
        g2 = handle.create_group("t2")
        g2.attrs["n_time_steps"] = 2
        g2.attrs["seq_len"] = 2
        g2.attrs["block_num"] = 2
        g2.create_dataset("input_features", data=np.zeros((2, 4), dtype=np.float32))
        g2.create_dataset("seq_class_ids", data=np.array([1, 2], dtype=np.int64))
        g2.create_dataset("transcription", data=np.array([ord("B"), 0, 0], dtype=np.int32))
    texts = collect_speech45_final_transcripts(tmp_path / "speech45")
    assert texts == ["B"]


def test_export_transcripts_length_check(tmp_path):
    from acorn.data.sequence.collate import SequenceSession, SequenceSplit

    split = SequenceSplit(features=[np.zeros((2, 4), np.float32)], labels=[np.array([1])])
    session = SequenceSession(
        session_key="nlp10",
        task_key="nlp",
        use_smooth=False,
        n_features=4,
        num_classes=5,
        vocab=tuple(str(i) for i in range(5)),
        blank_index=0,
        train=split,
        periodic_eval=split,
        final_eval=split,
    )

    class DummyModel:
        def eval(self):
            return self

        def __call__(self, x, x_len, session_key):
            t = x.shape[1]
            return x.new_zeros(x.shape[0], t, 5), x_len

    with pytest.raises(ValueError, match="len\\(transcripts\\)"):
        export_session_logits(
            DummyModel(),
            session,
            device=__import__("torch").device("cpu"),
            transcripts=["one", "two"],
        )


def test_export_schema_is_v11(tmp_path):
    assert SCHEMA == "acorn.ctc_export.v1.1"
