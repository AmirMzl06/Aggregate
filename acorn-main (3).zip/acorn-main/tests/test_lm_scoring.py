"""Host WER/CER on n-best strings; mix formula."""

from __future__ import annotations

from acorn.lm.nbest import Hypothesis, NBest
from acorn.lm.presets import original_preset
from acorn.lm.scoring import comparability_for, first_best_text, mix_scores, score_ngram_metrics


def test_first_best_is_index_zero_not_min_acoustic():
    trial = [
        Hypothesis(text=" worse ", acoustic_score=0.0, ngram_score=0.0),
        Hypothesis(text=" better ", acoustic_score=-5.0, ngram_score=0.0),
    ]
    assert first_best_text(trial) == "worse"


def test_ngram_metrics_use_first_best():
    nbest = NBest(
        session_key="nlp10",
        task_key="nlp",
        trials=[
            [
                Hypothesis(text=" she > was .", acoustic_score=0.0, ngram_score=0.0),
                Hypothesis(text=" they > were .", acoustic_score=-9.0, ngram_score=0.0),
            ]
        ],
    )
    wer_first, _ = score_ngram_metrics(nbest, ["she>was~"], "nlp")
    nbest.trials[0] = list(reversed(nbest.trials[0]))
    wer_if_resorted, _ = score_ngram_metrics(nbest, ["she>was~"], "nlp")
    assert wer_first == 0.0
    assert wer_if_resorted == 1.0


def test_mix_alpha_one_ignores_ngram():
    hyps = [
        Hypothesis("bad", acoustic_score=0.0, ngram_score=100.0),
        Hypothesis("good", acoustic_score=0.0, ngram_score=-100.0),
    ]
    text, _conf = mix_scores(hyps, [0.0, 10.0], alpha=1.0, acoustic_scale=0.5)
    assert text == "good"


def test_paper_comparable_false_for_nlp_hf():
    ok, tag = comparability_for(original_preset("nlp"), neural_ran=True)
    assert ok is False
    assert tag == "recipe_match_only"


def test_paper_comparable_true_only_speech_5gram_opt():
    ok, tag = comparability_for(original_preset("speech"), neural_ran=True)
    assert ok is True
    assert tag == "fan_speech_lm_stack"
