"""Encoder trainer hook tests vs snapshotted advdec optimizer construction."""

import torch

from acorn.train.encoder_trainer import EncoderTrainer
from acorn.train.encoder_trainer_advdec import (
    ADAM_EPS,
    GRAD_CLIP_NORM,
    LR_END,
    WEIGHT_DECAY,
    AdvDecEncoderTrainer,
)
from tests.reference_advdec import reference_advdec_build_optimizer


def _dummy_trainer(cls, enc_lr: float = 0.02, n_batch: int = 100):
    return cls(
        model=None,
        bundles={},
        device=torch.device("cpu"),
        args={"enc_lr": enc_lr, "nBatch": n_batch},
    )


def test_default_trainer_is_adamw_no_scheduler():
    params = [torch.nn.Parameter(torch.randn(3, 3))]
    trainer = _dummy_trainer(EncoderTrainer, enc_lr=3e-5)
    opt = trainer.build_optimizer(params)
    assert isinstance(opt, torch.optim.AdamW)
    assert opt.param_groups[0]["lr"] == 3e-5
    assert opt.param_groups[0]["weight_decay"] == 0.01
    assert trainer.build_scheduler(opt, 100) is None


def test_advdec_optimizer_matches_reference():
    enc_lr = 0.02
    n_batches = 50
    p_new = torch.nn.Parameter(torch.ones(4, 4))
    p_ref = torch.nn.Parameter(torch.ones(4, 4))
    trainer = _dummy_trainer(AdvDecEncoderTrainer, enc_lr=enc_lr, n_batch=n_batches)
    opt = trainer.build_optimizer([p_new])
    sched = trainer.build_scheduler(opt, n_batches)
    ref_opt, ref_sched = reference_advdec_build_optimizer([p_ref], enc_lr, n_batches)

    assert type(opt) is type(ref_opt)
    assert opt.param_groups[0]["lr"] == ref_opt.param_groups[0]["lr"]
    assert (
        opt.param_groups[0]["weight_decay"]
        == ref_opt.param_groups[0]["weight_decay"]
        == WEIGHT_DECAY
    )
    assert opt.param_groups[0]["eps"] == ref_opt.param_groups[0]["eps"] == ADAM_EPS
    assert type(sched) is type(ref_sched)
    assert sched.start_factor == ref_sched.start_factor == 1.0
    assert abs(sched.end_factor - ref_sched.end_factor) < 1e-12
    assert abs(sched.end_factor - LR_END / enc_lr) < 1e-12
    assert sched.total_iters == ref_sched.total_iters == n_batches


def test_advdec_scheduler_steps_match_reference():
    enc_lr = 0.02
    n_batches = 10
    p_new = torch.nn.Parameter(torch.ones(2, 2))
    p_ref = torch.nn.Parameter(torch.ones(2, 2))
    trainer = _dummy_trainer(AdvDecEncoderTrainer, enc_lr=enc_lr, n_batch=n_batches)
    opt = trainer.build_optimizer([p_new])
    sched = trainer.build_scheduler(opt, n_batches)
    ref_opt, ref_sched = reference_advdec_build_optimizer([p_ref], enc_lr, n_batches)
    lrs, ref_lrs = [], []
    for _ in range(n_batches):
        lrs.append(opt.param_groups[0]["lr"])
        ref_lrs.append(ref_opt.param_groups[0]["lr"])
        sched.step()
        ref_sched.step()
    assert lrs == ref_lrs
    assert abs(lrs[0] - enc_lr) < 1e-12
    assert abs(opt.param_groups[0]["lr"] - LR_END) < 1e-6
    assert abs(ref_opt.param_groups[0]["lr"] - LR_END) < 1e-6


def test_advdec_clip_grad_is_norm_5():
    p = torch.nn.Parameter(torch.ones(3) * 10.0)
    p.grad = torch.ones(3) * 10.0
    trainer = _dummy_trainer(AdvDecEncoderTrainer)
    trainer.clip_grad([p])
    assert p.grad is not None
    assert abs(float(p.grad.norm()) - GRAD_CLIP_NORM) < 1e-5


def test_default_clip_grad_is_noop():
    p = torch.nn.Parameter(torch.ones(3) * 10.0)
    p.grad = torch.ones(3) * 10.0
    before = p.grad.clone()
    trainer = _dummy_trainer(EncoderTrainer)
    trainer.clip_grad([p])
    assert torch.equal(p.grad, before)


def test_advdec_one_adam_linearlr_step_matches_reference():
    torch.manual_seed(0)
    enc_lr = 0.02
    n_batches = 10
    prod = torch.nn.Linear(4, 4, bias=False)
    ref = torch.nn.Linear(4, 4, bias=False)
    ref.load_state_dict(prod.state_dict())
    x = torch.randn(3, 4)
    trainer = _dummy_trainer(AdvDecEncoderTrainer, enc_lr=enc_lr, n_batch=n_batches)
    prod_opt = trainer.build_optimizer(list(prod.parameters()))
    prod_sched = trainer.build_scheduler(prod_opt, n_batches)
    ref_opt, ref_sched = reference_advdec_build_optimizer(list(ref.parameters()), enc_lr, n_batches)

    prod.zero_grad(set_to_none=True)
    ref.zero_grad(set_to_none=True)
    prod(x).pow(2).mean().backward()
    ref(x).pow(2).mean().backward()
    for p in list(prod.parameters()) + list(ref.parameters()):
        p.grad.mul_(1e3)
    trainer.clip_grad(list(prod.parameters()))
    torch.nn.utils.clip_grad_norm_(list(ref.parameters()), GRAD_CLIP_NORM)
    prod_opt.step()
    ref_opt.step()
    prod_sched.step()
    ref_sched.step()
    for p_a, p_b in zip(prod.parameters(), ref.parameters(), strict=True):
        assert torch.allclose(p_a, p_b, atol=1e-5, rtol=1e-5)
    assert abs(prod_opt.param_groups[0]["lr"] - ref_opt.param_groups[0]["lr"]) < 1e-12
