"""Parse-only checks for newcomer demo notebooks (no training, no datasets)."""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path

import pytest

_REPO = Path(__file__).resolve().parents[1]
_NB_DIR = _REPO / "examples" / "notebooks"

_TRAINING = (
    "demo_perich_single.ipynb",
    "demo_perich_multi.ipynb",
    "demo_hippo_single.ipynb",
    "demo_hippo_multi.ipynb",
    "demo_macaque_multi.ipynb",
    "demo_macaque_multi_baseline.ipynb",
    "demo_macaque_iwj.ipynb",
    "demo_nlp21.ipynb",
    "demo_sequence_multi.ipynb",
)

_MACAQUE = (
    "demo_macaque_multi.ipynb",
    "demo_macaque_multi_baseline.ipynb",
    "demo_macaque_iwj.ipynb",
)

_PRIVATE_SNIPPETS = (
    "Offset36_multi",
    "init_loader",
    "l2_attack_single",
    "MonkeyDecoder(",
    "cebra.datasets.init",
    "utils.gru_decoder_monkey",
    "sys.path.append",
    "from loader import",
)

_BANNED_MARKDOWN = (
    r"\bjango\b",
    r"\bJango\b",
    r"\bmihili\b",
    r"\bMihili\b",
    r"\bPop\b",
    r"\bcluster\b",
    r"\bmacorn\b",
    r"\bmonkey_gru\b",
    r"\bmgd14\b",
    r"\bmgd15\b",
    r"\bspeech_gru\b",
    r"\bhossein\b",
    r"/data/",
    r"\btorch_brain\b",
    r"CEBRA-main-time",
    r"\brunai\b",
    r"\bHYPERS\b",
    r"\bWave\b",
    r"\bP-NB\b",
    r"\bour lab\b",
    r"we recorded",
)

_BANNED_ANYWHERE = (
    r"\bmacorn\b",
    r"\bmonkey_gru\b",
    r"\bmgd14\b",
    r"\bmgd15\b",
    r"\bspeech_gru\b",
    r"\bhossein\b",
    r"/data/",
    r"\btorch_brain\b",
    r"CEBRA-main-time",
    r"\brunai\b",
    r"\bHYPERS\b",
    r"\bour lab\b",
)


def _notebooks() -> list[Path]:
    return sorted(_NB_DIR.glob("*.ipynb"))


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _src(path: Path) -> str:
    nb = _load(path)
    return "\n".join("".join(cell.get("source", [])) for cell in nb["cells"])


def _code_src(path: Path) -> str:
    nb = _load(path)
    return "\n".join(
        "".join(cell.get("source", [])) for cell in nb["cells"] if cell.get("cell_type") == "code"
    )


def _markdown(path: Path) -> str:
    nb = _load(path)
    parts = []
    for cell in nb["cells"]:
        if cell.get("cell_type") == "markdown":
            parts.append("".join(cell.get("source", [])))
    return "\n".join(parts)


def _first_markdown(path: Path) -> str:
    nb = _load(path)
    cell = nb["cells"][0]
    return "".join(cell.get("source", []))


def _strip_magics(source: str) -> str:
    lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("%") or stripped.startswith("!"):
            continue
        lines.append(line)
    return "\n".join(lines)


def _kw_constants(call: ast.Call) -> dict:
    out = {}
    for kw in call.keywords:
        if kw.arg is None:
            continue
        if isinstance(kw.value, ast.Constant):
            out[kw.arg] = kw.value.value
        elif (
            kw.arg == "adv"
            and isinstance(kw.value, ast.Call)
            and getattr(kw.value.func, "id", None) == "AdvConfig"
        ):
            out.update(_kw_constants(kw.value))
    return out


def _train_configs(src: str) -> list[dict]:
    tree = ast.parse(_strip_magics(src))
    return [
        _kw_constants(node)
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "TrainConfig"
    ]


def test_notebook_dir_index_lists_every_demo():
    readme = (_NB_DIR / "README.md").read_text(encoding="utf-8")
    names = [path.name for path in _notebooks()]
    assert names, "expected demo notebooks"
    for name in names:
        assert name in readme
    for name in _TRAINING:
        assert name in readme
    assert "demo_nlp21_lm.ipynb" in readme
    assert (_NB_DIR / "__init__.py").is_file()
    assert "demo_macaque_iwj_baseline" not in readme
    assert not (_NB_DIR / "demo_macaque_iwj_baseline.ipynb").exists()


def test_notebooks_are_nbformat4_and_start_with_markdown():
    for path in _notebooks():
        nb = _load(path)
        assert nb["nbformat"] == 4, path.name
        assert nb["cells"], path.name
        assert nb["cells"][0].get("cell_type") == "markdown", path.name
        for cell in nb["cells"]:
            src = cell.get("source", [])
            assert src, f"empty cell in {path.name}"


def test_code_cells_compile_without_running():
    for path in _notebooks():
        nb = _load(path)
        for i, cell in enumerate(nb["cells"]):
            if cell.get("cell_type") != "code":
                continue
            source = _strip_magics("".join(cell.get("source", [])))
            if not source.strip():
                continue
            ast.parse(source)
            compile(source, f"{path.name}:{i}", "exec")


def test_training_notebooks_use_public_train_api():
    for name in _TRAINING:
        src = _src(_NB_DIR / name)
        assert "from acorn import" in src, name
        assert "train_model" in src, name
        assert "train_model(" in src, name
        assert "train_quietly" not in src, name
        assert "TrainConfig" in src or "SequenceTrainConfig" in src, name
        assert "assume_yes=True" in src, name


def test_time_bin_notebooks_have_resume_and_save_flags():
    for name in _TRAINING:
        if name == "demo_nlp21.ipynb":
            src = _src(_NB_DIR / name)
            assert "SAVE_DIR" in src
            continue
        src = _src(_NB_DIR / name)
        assert "RESUME_DIR = None" in src, name
        assert "SAVE_DIR" in src, name


def test_frozen_hypers_perich_single():
    src = _src(_NB_DIR / "demo_perich_single.ipynb")
    assert "dataset_keys=[DATASET_KEY]" in src or '"perich_m_rt_3"' in src
    assert "perich_m_rt_3" in src
    assert 'recipe="offset36_cebra"' in src
    assert "n_batch=2500" in src
    assert "n_batch=5000" in src
    assert "ceb_hidden=512" in src
    assert 'decoder_adv="pgd"' in src
    assert 'decoder_adv="off"' in src
    assert "mlp_decoder=True" in src
    assert "zscore=False" in src
    assert "enabled=False" in src
    assert 'style="cluster_pgd"' in src
    assert "noise_std = 0.75" in src
    assert "attack_eps = 0.5" in src


def test_frozen_hypers_perich_multi():
    src = _src(_NB_DIR / "demo_perich_multi.ipynb")
    assert "PERICH_KEYS" in src
    assert "n_batch=40000" in src
    assert 'recipe="offset36_gru"' in src
    assert 'style="cluster_pgd"' in src
    md = _markdown(_NB_DIR / "demo_perich_multi.ipynb")
    assert "adversarial contrastive training" in md.lower()
    assert "cluster" not in md.lower()


def test_frozen_hypers_hippo_single():
    src = _src(_NB_DIR / "demo_hippo_single.ipynb")
    assert "hippo_achilles" in src
    assert "mlp_decoder=True" in src
    assert "zscore=False" in src
    assert "enabled=False" in src
    assert "n_batch=2500" in src
    assert "n_batch=5000" in src
    assert "offset=1" in src
    assert 'decoder_adv="pgd"' in src
    assert "noise_std = 0.5" in src
    assert "attack_eps = 0.2" in src
    assert "cebra.datasets.init" not in src


def test_frozen_hypers_hippo_multi():
    src = _src(_NB_DIR / "demo_hippo_multi.ipynb")
    assert "HIPPO_KEYS" in src
    assert "n_batch=20000" in src
    assert 'recipe="offset36_gru"' in src
    assert "ceb_hidden=64" in src
    assert "offset=1" in src


def test_frozen_hypers_sequence_multi():
    name = "demo_sequence_multi.ipynb"
    src = _src(_NB_DIR / name)
    first = _first_markdown(_NB_DIR / name)
    assert 'recipe="offset36_ctc"' in src
    assert "n_batch=20000" in src
    assert "batch_size=16" in src
    assert "assume_yes=True" in src
    assert "SEQUENCE_KEYS" in src
    assert "COMPARE_BASELINE" in src
    assert "enabled=True" in src
    assert "enabled=False" in src
    assert "RESUME_DIR = None" in src
    assert "SAVE_DIR" in src
    assert "cer_mean" in src
    assert "per_dataset" in src
    assert "R²" in first
    assert "character error" in first.lower() or "CER" in first
    md = _markdown(_NB_DIR / name)
    assert "without adversarial training" in md.lower()
    assert "CEBRA" not in md
    assert '["nlp21", "nlp10"]' not in src
    assert "DRYAD_CLIENT_ID" in src
    assert "docs/data.md" in src


def test_frozen_hypers_macaque():
    for name in _MACAQUE:
        src = _src(_NB_DIR / name)
        assert 'recipe="offset36_gru_advdec"' in src, name
        assert "enc_lr=0.02" in src, name
        assert "batch_size=1024" in src, name
        assert "n_batch=30000" in src, name
        assert 'style="bin"' in src, name
        assert "eps=0.5" in src, name
        assert 'dataset_keys=["jango"' in src, name
        md = _markdown(_NB_DIR / name)
        if "iwj" in name:
            assert "IW-J" in md
        else:
            for paper in ("IW-J", "CO-M", "RT-M", "PG-P"):
                assert paper in md, name
        if "baseline" in name:
            assert "CEBRA" not in md
            assert "mlp_decoder=True" in src
            assert "zscore=False" in src
            assert "enabled=False" in src


def test_macaque_adv_flags_and_baseline_is_not_cebra():
    adv_multi = _src(_NB_DIR / "demo_macaque_multi.ipynb")
    adv_iwj = _src(_NB_DIR / "demo_macaque_iwj.ipynb")
    base_multi = _src(_NB_DIR / "demo_macaque_multi_baseline.ipynb")
    assert "enabled=True" in adv_multi
    assert "enabled=True" in adv_iwj
    assert "COMPARE_BASELINE" in adv_multi
    assert "COMPARE_BASELINE" in adv_iwj
    assert "mlp_decoder=True" in adv_multi
    assert "mlp_decoder=True" in adv_iwj
    assert "zscore=False" in adv_multi
    assert "zscore=False" in adv_iwj
    assert "enabled=False" in base_multi
    assert "AdvConfig(enabled=False" in adv_iwj
    assert "CEBRA" not in _markdown(_NB_DIR / "demo_macaque_multi_baseline.ipynb")
    assert "CEBRA" not in _markdown(_NB_DIR / "demo_macaque_iwj.ipynb")
    assert '"mihili_co"' in adv_multi
    assert '"mihili_rt"' in adv_multi
    assert '"pop"' in adv_multi
    assert 'dataset_keys=["jango"]' in adv_iwj


def test_cebra_no_adv_notebooks_mlp_zscore_off_acorn_keeps_gru():
    dual = {
        "demo_perich_single.ipynb",
        "demo_hippo_single.ipynb",
        "demo_macaque_iwj.ipynb",
        "demo_macaque_multi.ipynb",
    }
    names = (
        "demo_perich_single.ipynb",
        "demo_hippo_single.ipynb",
        "demo_macaque_iwj.ipynb",
        "demo_macaque_multi.ipynb",
        "demo_macaque_multi_baseline.ipynb",
    )
    for name in names:
        configs = _train_configs(_code_src(_NB_DIR / name))
        acorn = [cfg for cfg in configs if cfg.get("enabled") is True]
        baseline = [cfg for cfg in configs if cfg.get("enabled") is False]
        if name in dual:
            assert acorn, name
            assert baseline, name
        else:
            assert not acorn, name
            assert baseline, name
        for cfg in baseline:
            assert cfg.get("mlp_decoder") is True, name
            assert cfg.get("zscore") is False, name
        for cfg in acorn:
            assert cfg.get("mlp_decoder") is not True, name
            if name in {"demo_perich_single.ipynb", "demo_hippo_single.ipynb"}:
                assert cfg.get("zscore") is False, name
            else:
                assert cfg.get("zscore") is not False, name


def test_comparison_helper_uses_two_metric_dicts():
    src = (_NB_DIR / "nb_lib.py").read_text(encoding="utf-8")
    assert "def plot_acorn_vs_no_adv(" in src
    assert "metrics_acorn" in src
    assert "metrics_other" in src
    assert "0.572" not in src
    for name in ("demo_macaque_multi.ipynb", "demo_macaque_iwj.ipynb"):
        nb_src = _src(_NB_DIR / name)
        assert "COMPARE_BASELINE" in nb_src
        assert "plot_acorn_vs_no_adv" in nb_src
        assert "0.572" not in _markdown(_NB_DIR / name)


def test_markdown_avoids_banned_tokens():
    for path in list(_notebooks()) + [_NB_DIR / "README.md", _NB_DIR / "nb_lib.py"]:
        if path.suffix == ".ipynb":
            text = _markdown(path)
        else:
            text = path.read_text(encoding="utf-8")
        for pattern in _BANNED_MARKDOWN:
            if path.name == "nb_lib.py" and pattern in {r"\bjango\b", r"\bPop\b"}:
                continue
            assert re.search(pattern, text) is None, f"{path.name} matched {pattern}"


def test_notebooks_drop_private_loops_and_lab_tokens():
    for path in _notebooks():
        src = _src(path)
        for snippet in _PRIVATE_SNIPPETS:
            assert snippet not in src, f"{path.name} contains {snippet}"
        for pattern in _BANNED_ANYWHERE:
            assert re.search(pattern, src) is None, f"{path.name} matched {pattern}"
        assert "colab.research.google.com" not in src


def test_lm_notebook_keeps_optional_rescore_and_json_fallback():
    path = _NB_DIR / "demo_nlp21_lm.ipynb"
    src = _src(path)
    assert "ACORN_NB_RUN_NGRAM" in src
    assert "rescore_export" in src
    assert "demo_nlp21_lm.json" in src
    assert "demo_nlp21_lm.png" in src
    assert "png.is_file()" in src
    assert "DRYAD_CLIENT_ID" in src
    nb = _load(path)
    code = "\n\n".join(
        _strip_magics("".join(cell.get("source", [])))
        for cell in nb["cells"]
        if cell.get("cell_type") == "code"
    )
    tree = ast.parse(code)
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and (
            (isinstance(node.func, ast.Name) and node.func.id == "rescore_export")
            or (isinstance(node.func, ast.Attribute) and node.func.attr == "rescore_export")
        )
    ]
    assert calls
    assert "if RUN_NGRAM:" in src


def test_nb_lib_importable_without_gpu_or_data():
    from examples.notebooks.nb_lib import (
        PAPER_NAMES,
        chdir_repo_root,
        eval_scores_from_loaded,
        holdout_as_eval,
        macaque_day_scores,
        maybe_save_run,
        paper_label,
        try_load_run,
    )

    assert PAPER_NAMES["jango"] == "IW-J"
    assert paper_label("mihili_co") == "CO-M"
    assert paper_label("mihili_rt") == "RT-M"
    assert paper_label("pop") == "PG-P"
    assert try_load_run(None) is None
    maybe_save_run(None, None)
    metrics = {
        "per_dataset": {
            "jango": {"r2_holdout": 0.4, "r2_mean_other_days": 0.3},
            "pop": {"r2_holdout": 0.2, "r2_mean_other_days": 0.1},
        }
    }
    scores = macaque_day_scores(metrics)
    assert scores["IW-J"]["Day-0"] == 0.4
    clean_only = holdout_as_eval(metrics)
    assert clean_only["clean"]["jango"] == 0.4
    assert "noise" not in clean_only
    from_loaded = eval_scores_from_loaded({"metrics": {"demo_eval": {"clean": {"k": 1.0}}}})
    assert from_loaded["clean"]["k"] == 1.0
    root = chdir_repo_root(_REPO)
    assert (root / "pyproject.toml").is_file()
    text = (_NB_DIR / "nb_lib.py").read_text(encoding="utf-8")
    assert '"""' in text
    assert "display(" in text
    assert "from IPython.display import display as ipython_display" in text
    assert 'display = list(manifest.get("plot_channel_display")' in text


def test_perich_hippo_resume_uses_eval_helper():
    for name in (
        "demo_perich_single.ipynb",
        "demo_perich_multi.ipynb",
        "demo_hippo_single.ipynb",
        "demo_hippo_multi.ipynb",
    ):
        src = _src(_NB_DIR / name)
        assert "eval_scores_from_loaded" in src, name
        assert '["metrics"]["demo_eval"]' not in src, name


def test_eval_scores_from_loaded_without_demo_eval(tmp_path, capsys):
    from examples.notebooks.nb_lib import eval_scores_from_loaded, try_load_run

    metrics = {
        "per_dataset": {
            "perich_m_rt_3": {"r2_holdout": 0.5, "r2_mean_other_days": 0.4},
            "perich_c_co_1": {"r2_holdout": 0.6, "r2_mean_other_days": 0.3},
        }
    }
    (tmp_path / "metrics.json").write_text(json.dumps(metrics), encoding="utf-8")
    scores = eval_scores_from_loaded(try_load_run(tmp_path))
    assert scores["clean"]["perich_m_rt_3"] == 0.5
    assert "noise" not in scores
    assert "adv" not in scores
    out = capsys.readouterr().out
    assert "Noise and attack" in out


def test_eval_scores_from_loaded_with_demo_eval(tmp_path):
    from examples.notebooks.nb_lib import eval_scores_from_loaded, try_load_run

    metrics = {
        "r2_holdout": 0.9,
        "demo_eval": {
            "clean": {"k": 0.8},
            "noise": {"k": 0.5},
            "adv": {"k": 0.2},
        },
    }
    (tmp_path / "metrics.json").write_text(json.dumps(metrics), encoding="utf-8")
    scores = eval_scores_from_loaded(try_load_run(tmp_path))
    assert set(scores) >= {"clean", "noise", "adv"}
    assert scores["clean"]["k"] == 0.8


def test_plot_condition_bars_tolerates_missing_and_plots_three(tmp_path, monkeypatch):
    pytest.importorskip("matplotlib")
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    from examples.notebooks.nb_lib import (
        eval_scores_from_loaded,
        plot_condition_bars,
        plot_session_condition_bars,
        scores_for_key,
        try_load_run,
    )

    shown = []

    def _capture(fig):
        shown.append(fig)
        plt.close(fig)

    monkeypatch.setattr("examples.notebooks.nb_lib._show_figure", _capture)

    bare = {
        "per_dataset": {
            "perich_m_rt_3": {"r2_holdout": 0.5, "r2_mean_other_days": 0.4},
        }
    }
    (tmp_path / "metrics.json").write_text(json.dumps(bare), encoding="utf-8")
    clean_scores = eval_scores_from_loaded(try_load_run(tmp_path))
    assert plot_session_condition_bars(clean_scores, title="clean only") is None
    assert len(shown[-1].axes[0].containers) == 1
    assert (
        plot_condition_bars(
            {"ACORN": scores_for_key(clean_scores, "perich_m_rt_3")},
            title="clean method",
        )
        is None
    )
    assert len(shown[-1].axes[0].containers) == 1

    full = {
        "clean": {"k": 0.8},
        "noise": {"k": 0.5},
        "adv": {"k": 0.2},
    }
    assert plot_session_condition_bars(full, title="three") is None
    assert len(shown[-1].axes[0].containers) == 3
    assert (
        plot_condition_bars(
            {"ACORN": {"clean": 0.8, "noise": 0.5, "adv": 0.2}},
            title="three methods",
        )
        is None
    )
    assert len(shown[-1].axes[0].containers) == 3


def test_mean_eval_by_perich_task_groups_paper_tasks():
    from examples.notebooks.nb_lib import mean_eval_by_perich_task

    grouped = mean_eval_by_perich_task(
        {
            "clean": {
                "perich_c_co_1": 0.4,
                "perich_c_co_2": 0.6,
                "perich_m_rt_3": 0.5,
            },
            "noise": {
                "perich_c_co_1": 0.2,
                "perich_c_co_2": 0.4,
                "perich_m_rt_3": 0.1,
            },
            "adv": {
                "perich_c_co_1": 0.1,
                "perich_c_co_2": 0.3,
                "perich_m_rt_3": 0.0,
            },
        }
    )
    assert grouped["clean"]["C-CO"] == 0.5
    assert grouped["clean"]["M-RT"] == 0.5
    assert "perich_c_co_1" not in grouped["clean"]


def test_newcomer_voice_defines_terms_and_script_examples():
    hippo_md = _markdown(_NB_DIR / "demo_hippo_multi.ipynb")
    assert "R²" in hippo_md
    assert "encoder" in hippo_md.lower()
    assert "session" in hippo_md.lower()
    iwj_md = _markdown(_NB_DIR / "demo_macaque_iwj.ipynb")
    assert "overlay" not in iwj_md.lower()
    assert "Day-0" in iwj_md
    assert "Day-K" in iwj_md
    assert "R²" in iwj_md
    readme = (_NB_DIR / "README.md").read_text(encoding="utf-8")
    assert "Script-style overlays" not in readme
    assert "Script examples" in readme
    assert "matplotlib" in readme.lower()


def test_training_notebooks_define_r2_in_first_markdown():
    define = re.compile(r"how well|match between|how close", re.I)
    for name in _TRAINING:
        first = _first_markdown(_NB_DIR / name)
        assert "R²" in first, name
        assert define.search(first), name
        if "Day-0" in first or "Day-K" in first:
            assert "Day-0" in first and "Day-K" in first, name
            assert re.search(
                r"holdout|held-out|training day|later (day|session)",
                first,
                re.I,
            ), name


def test_nb_lib_comparison_bars_with_dummy_metrics():
    pytest.importorskip("matplotlib")
    import matplotlib

    matplotlib.use("Agg")
    from examples.notebooks.nb_lib import (
        plot_acorn_vs_no_adv,
        plot_behavior_traces,
        plot_grouped_bars,
        plot_macaque_day_bars,
    )

    metrics = {
        "per_dataset": {
            "jango": {"r2_holdout": 0.4, "r2_mean_other_days": 0.3},
            "pop": {"r2_holdout": 0.2, "r2_mean_other_days": 0.1},
        }
    }
    assert plot_grouped_bars({"IW-J": {"Day-0": 0.4, "Day-K": 0.3}}, title="dummy") is None
    assert plot_macaque_day_bars(metrics, title="dummy days") is None
    assert plot_acorn_vs_no_adv(metrics, None, title="dummy compare") is None
    assert plot_behavior_traces(None) is None
    src = (_NB_DIR / "nb_lib.py").read_text(encoding="utf-8")
    assert "display(" in src
    assert "from IPython.display import display as ipython_display" in src
    assert 'display = list(manifest.get("plot_channel_display")' in src


def test_rtm_reach_plot_uses_capped_holdout_trials(monkeypatch):
    pytest.importorskip("matplotlib")
    import matplotlib
    import numpy as np

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    from acorn.eval.plot_config import COM_N_SHOW
    from examples.notebooks.nb_lib import plot_behavior_traces

    shown = []

    def _capture(fig):
        shown.append(fig)
        plt.close(fig)

    monkeypatch.setattr("examples.notebooks.nb_lib._show_figure", _capture)

    rng = np.random.default_rng(0)
    holdout = [rng.normal(size=(12, 2)) for _ in range(10)]
    holdout_pred = [a + 4.0 for a in holdout]
    holdout_pred[3] = holdout[3].copy()
    holdout_pred[7] = holdout[7].copy()
    all_actual = holdout + holdout
    all_pred = holdout_pred + holdout_pred

    def _day(*, indices=None, include_all=True):
        day = {
            "actual_trials": np.array(holdout, dtype=object),
            "pred_trials": np.array(holdout_pred, dtype=object),
        }
        if include_all:
            day["all_actual_trials"] = np.array(all_actual, dtype=object)
            day["all_pred_trials"] = np.array(all_pred, dtype=object)
        if indices is not None:
            day["plot_trial_indices"] = np.asarray(indices, dtype=np.int32)
        return day

    rtm = {
        "manifest": {
            "dataset_key": "mihili_rt",
            "plot_type": "rt_reach",
            "pos_dims": [0, 1],
        },
        "day0": _day(indices=[3, 7, 0, 1, 2]),
        "dayk": _day(indices=[3, 7, 0, 1, 2]),
    }
    assert plot_behavior_traces({"mihili_rt": rtm}) is None
    assert len(shown[-1].axes[0].lines) == 10

    rtm_fallback = {
        "manifest": {
            "dataset_key": "mihili_rt",
            "plot_type": "rt_reach",
            "pos_dims": [0, 1],
        },
        "day0": _day(),
        "dayk": _day(),
    }
    assert plot_behavior_traces({"mihili_rt": rtm_fallback}) is None
    from acorn.eval.plot_config import RTM_TRIAL_INDICES

    n_ok = sum(1 for i in RTM_TRIAL_INDICES["day0"] if 0 <= i < len(holdout))
    assert len(shown[-1].axes[0].lines) == 2 * n_ok

    com = {
        "manifest": {
            "dataset_key": "mihili_co",
            "plot_type": "co_reach",
            "pos_dims": [0, 1],
        },
        "day0": _day(),
        "dayk": _day(),
    }
    assert plot_behavior_traces({"mihili_co": com}) is None
    assert len(shown[-1].axes[0].lines) == 2 * min(COM_N_SHOW, len(all_actual))


def test_plot_grouped_bars_publishes_image_png_mime():
    pytest.importorskip("matplotlib")
    pytest.importorskip("IPython")
    import matplotlib

    matplotlib.use("Agg")
    from IPython.core.interactiveshell import InteractiveShell
    from IPython.core.pylabtools import select_figure_formats
    from IPython.utils.capture import capture_output

    from examples.notebooks.nb_lib import plot_grouped_bars

    shell = InteractiveShell.instance()
    select_figure_formats(shell, {"png"})
    with capture_output(display=True) as captured:
        result = plot_grouped_bars({"IW-J": {"Day-0": 0.4, "Day-K": 0.3}}, title="mime")
    assert result is None
    mime_types = [
        key for output in captured.outputs for key in (getattr(output, "data", None) or {})
    ]
    assert "image/png" in mime_types
    png = next(
        (output.data["image/png"] for output in captured.outputs if "image/png" in output.data),
        "",
    )
    assert png


def test_show_figure_falls_back_to_plt_show_without_ipython(monkeypatch):
    pytest.importorskip("matplotlib")
    import sys

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    monkeypatch.setitem(sys.modules, "IPython", None)
    monkeypatch.setitem(sys.modules, "IPython.display", None)
    shown: list[str] = []
    monkeypatch.setattr(plt, "show", lambda *args, **kwargs: shown.append("show"))

    from examples.notebooks.nb_lib import plot_grouped_bars

    assert plot_grouped_bars({"A": {"x": 1.0}}, title="no-ipython") is None
    assert shown == ["show"]
    assert plt.get_fignums() == []


def test_notebooks_have_no_figure_repr_only_outputs():
    plot_call = re.compile(r"plot_[A-Za-z0-9_]+\(")
    for path in sorted(_NB_DIR.glob("demo_*.ipynb")):
        nb = _load(path)
        src = _src(path)
        if "plot_" in src:
            assert plot_call.search(src), path.name
        for cell in nb.get("cells") or []:
            for out in cell.get("outputs") or []:
                data = out.get("data") or {}
                has_image = "image/png" in data or "image/svg+xml" in data
                text = data.get("text/plain", "")
                if isinstance(text, list):
                    text = "".join(text)
                assert has_image or "Figure size" not in str(text), path.name


def test_old_nlp_paths_are_not_the_only_location():
    assert (_NB_DIR / "demo_nlp21.ipynb").is_file()
    assert (_NB_DIR / "demo_nlp21_lm.ipynb").is_file()
    assert not (_REPO / "examples" / "demo_nlp21.ipynb").exists()
    assert not (_REPO / "examples" / "demo_nlp21_lm.ipynb").exists()
