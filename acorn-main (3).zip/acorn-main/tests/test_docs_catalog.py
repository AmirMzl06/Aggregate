"""Docs catalog must match live list_datasets() / list_recipes()."""

from __future__ import annotations

from pathlib import Path

from acorn import list_datasets, list_recipes
from acorn.data.registry import get_dataset
from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

_REPO = Path(__file__).resolve().parents[1]
_GETTING_STARTED = _REPO / "docs" / "getting_started.md"
_CATALOG = _REPO / "docs" / "guides" / "datasets" / "index.md"


def _section(text: str, heading: str) -> str:
    marker = f"## {heading}"
    start = text.index(marker)
    rest = text[start + len(marker) :]
    nxt = rest.find("\n## ")
    return rest if nxt == -1 else rest[:nxt]


def test_grouped_catalog_matches_list_datasets():
    text = _CATALOG.read_text(encoding="utf-8")
    live = list_datasets()
    assert "demo" not in live
    for key in live:
        assert f"`{key}`" in text, key

    perich = _section(text, "Perich")
    hippo = _section(text, "Hippocampus")
    macaque = _section(text, "Macaque")
    b2t = _section(text, "Brain-to-text")
    for key in live:
        if key in SEQUENCE_DATASET_REGISTRY:
            assert f"`{key}`" in b2t, key
            continue
        group = get_dataset(key).dataset_group
        if group == "perich":
            assert f"`{key}`" in perich, key
        elif group == "hippo":
            assert f"`{key}`" in hippo, key
        elif group == "macaque":
            assert f"`{key}`" in macaque, key
        else:
            raise AssertionError(f"ungrouped key {key!r}")


def test_catalog_recipes_match_list_recipes():
    text = _section(_CATALOG.read_text(encoding="utf-8"), "Recipes")
    live = list_recipes()
    for name in live:
        assert f"`{name}`" in text, name
    assert live == sorted(live)


def test_getting_started_has_no_full_dump():
    text = _GETTING_STARTED.read_text(encoding="utf-8")
    catalog = str(list_datasets())
    assert catalog not in text
    assert "n_batch=4" not in text
    assert "```mermaid" not in text
    assert "demo" not in catalog


_DEMO_NOTEBOOKS = (
    "demo_nlp21_lm",
    "demo_perich_single",
    "demo_perich_multi",
    "demo_hippo_single",
    "demo_hippo_multi",
    "demo_macaque_iwj",
    "demo_macaque_multi",
    "demo_macaque_multi_baseline",
    "demo_nlp21",
    "demo_sequence_multi",
)


def test_demo_markdown_keeps_github_notebook_paths():
    pages = [
        _REPO / "docs" / "index.md",
        _REPO / "docs" / "demos" / "index.md",
        _REPO / "docs" / "demos" / "reaching.md",
        _REPO / "docs" / "demos" / "hippocampus.md",
        _REPO / "docs" / "demos" / "macaque.md",
        _REPO / "docs" / "demos" / "handwriting.md",
        _REPO / "docs" / "demos" / "multi-session.md",
        _REPO / "docs" / "start" / "index.md",
        _REPO / "docs" / "start" / "faq.md",
        _REPO / "docs" / "getting_started.md",
        _REPO / "docs" / "language_model.md",
    ]
    catalog = (_REPO / "docs" / "demos" / "index.md").read_text(encoding="utf-8")
    for name in _DEMO_NOTEBOOKS:
        assert f"](/examples/notebooks/{name}.ipynb)" in catalog, name
    assert "demo_macaque_iwj_baseline" not in catalog
    for path in pages:
        text = path.read_text(encoding="utf-8")
        if "demo_" not in text:
            continue
        assert "colab.research.google.com" not in text
        assert "](notebooks/demo_" not in text
        assert "../examples/notebooks/" not in text
        assert "](/demo_" not in text
        assert "demo_macaque_iwj_baseline" not in text


def test_docs_conf_renders_notebooks_offline_colab_opt_in():
    text = (_REPO / "docs" / "conf.py").read_text(encoding="utf-8")
    assert '"myst_nb"' in text
    assert 'nb_execution_mode = "off"' in text
    assert "ACORN_DOCS_COLAB" in text
    assert "Open in Colab" in text
    assert "_sanitize_notebook" in text
    assert "_is_tqdm_progress" in text
    assert '"myst_parser"' not in text
    assert "nb_mime_priority_overrides" in text
    assert '"image/png"' in text
    assert '("html", "text/plain", 0)' not in text
    assert "('html', 'text/plain', 0)" not in text
    assert "demo_macaque_iwj_baseline" not in text


def _conf_sanitize():
    """Load ``_sanitize_notebook`` without importing Sphinx."""
    import re

    src = (_REPO / "docs" / "conf.py").read_text(encoding="utf-8")
    start = src.index("_TQDM_LINE")
    end = src.index("\ndef _stage_notebooks")
    ns: dict = {"re": re}
    exec(src[start:end], ns)
    return ns["_sanitize_notebook"]


def test_sanitize_notebook_keeps_png_strips_figure_repr():
    from json import dumps, loads

    sanitize = _conf_sanitize()
    fig_only = {
        "cells": [
            {
                "cell_type": "code",
                "outputs": [
                    {
                        "output_type": "execute_result",
                        "data": {"text/plain": "[<Figure size 800x600 with 2 Axes>]"},
                        "metadata": {},
                    }
                ],
            }
        ]
    }
    assert sanitize(fig_only)["cells"][0]["outputs"] == []

    png_with_repr = {
        "cells": [
            {
                "cell_type": "code",
                "outputs": [
                    {
                        "output_type": "display_data",
                        "data": {
                            "image/png": ["iVBOR", "SUhEUg=="],
                            "text/plain": "<Figure size 800x600 with 2 Axes>",
                        },
                        "metadata": {},
                    },
                    {
                        "output_type": "stream",
                        "name": "stderr",
                        "text": ["train: 10%|█         | 1/10 [00:01<00:09, 1.00it/s]\n"],
                    },
                    {
                        "output_type": "stream",
                        "name": "stderr",
                        "text": ["train: 100%|██████████| 10/10 [00:10<00:00, 1.00it/s]\n"],
                    },
                ],
            }
        ]
    }
    dumped = loads(dumps(png_with_repr))
    kept = sanitize(dumped)["cells"][0]["outputs"]
    assert kept[0]["data"]["image/png"] == ["iVBOR", "SUhEUg=="]
    assert any(out.get("name") == "stderr" for out in kept)
    collapsed = [out for out in kept if out.get("name") == "stderr"]
    assert len(collapsed) == 1
    text = "".join(collapsed[0]["text"])
    assert "training progress: 2 updates" in text
