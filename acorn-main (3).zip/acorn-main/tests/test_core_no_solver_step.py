"""Core trainers other than CebraFitTrainer must not call Solver.step / CEBRA(."""

from __future__ import annotations

import ast
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
_OFF_SOLVER = (
    "acorn/train/encoder_trainer.py",
    "acorn/train/encoder_trainer_advdec.py",
    "acorn/train/sequence/ctc_trainer.py",
    "acorn/train/adversarial.py",
)


def test_core_no_solver_step():
    for rel in _OFF_SOLVER:
        text = (_REPO / rel).read_text(encoding="utf-8")
        assert "Solver.step" not in text
        assert "CEBRA(" not in text


def test_cebra_fit_trainer_calls_fit():
    text = (_REPO / "acorn/train/cebra_fit.py").read_text(encoding="utf-8")
    tree = ast.parse(text)
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    ]
    assert any(node.func.attr == "fit" for node in calls)
    assert "CEBRA(" in text


def test_no_cebra_main_time_tree():
    assert not (_REPO / "cebra_main_time").exists()
    assert not (_REPO / "CEBRA-main-time").exists()
