"""Tiny CPU bit-match tests for time-bin Offset36_multi vs frozen monkey_gru."""

from __future__ import annotations

import ast
from pathlib import Path

import torch
import torch.nn as nn

from acorn.eval.decoder_probe import evaluate_embedding_decoders, train_session_decoder
from acorn.eval.plot_export import export_plot_data
from acorn.models.decoder_base import BaseGRUDecoder
from acorn.models.encoder import MonkeyEncoder
from acorn.models.offset36_multi import Offset36_multi
from acorn.train.config import AdvConfig, TrainConfig
from acorn.train.encoder_trainer import EncoderTrainer
from acorn.utils.vendor_path import ensure_vendored_on_path
from tests.reference_monkey_gru import Offset36_multi as FrozenOffset36_multi
from tests.reference_monkey_gru import reference_monkey_gru_build_encoder_optimizer
from tests.test_plot_export import _FakeLoader, _IdentityDecoder, _IdentityEncoder
from tests.test_sequence_bitmatch import _copy_dropoutv2_into_multi

_REPO = Path(__file__).resolve().parents[1]


class _FakeEncoderModel(nn.Module):
    def transform(self, x, session_key):
        return x

    def set_session_decoder(self, session_key, decoder):
        self._decoders = {session_key: decoder}


def _tiny_offset36_pair(session: str = "sess", n_neurons: int = 6, hidden: int = 16, out: int = 8):
    ref = FrozenOffset36_multi(hidden, out)
    prod = Offset36_multi(hidden, out)
    ref.add_session(session, n_neurons, use_smooth=False)
    prod.add_session(session, n_neurons, use_smooth=False)
    prod.load_state_dict(ref.state_dict())
    return ref, prod


def test_acorn_offset36_multi_matches_frozen_monkey_gru_forward():
    torch.manual_seed(0)
    session = "sess"
    ref, prod = _tiny_offset36_pair(session)
    ref.eval()
    prod.eval()
    x = torch.randn(2, 6, 40)
    with torch.no_grad():
        y_ref = ref(x, session)
        y_prod = prod(x, session)
    assert y_prod.shape == y_ref.shape
    assert torch.allclose(y_prod, y_ref, atol=1e-5, rtol=1e-5)


def test_timebin_n1_trunk_matches_offset36_dropoutv2():
    ensure_vendored_on_path()
    import cebra

    torch.manual_seed(0)
    n_neurons, ceb_hidden, ceb_out = 6, 16, 8
    session_key = "s0"
    v2 = cebra.models.Offset36Dropoutv2(n_neurons, ceb_hidden, ceb_out)
    multi = Offset36_multi(ceb_hidden, ceb_out)
    sk = MonkeyEncoder._safe_key(session_key)
    multi.add_session(sk, n_neurons, use_smooth=False)
    _copy_dropoutv2_into_multi(v2, multi, session_key)
    multi.eval()
    v2.eval()
    x = torch.randn(2, n_neurons, 36)
    with torch.no_grad():
        got = multi(x, sk)
        ref = v2(x)
        if ref.dim() == 2:
            ref = ref.unsqueeze(-1)
        if got.dim() == 2:
            got = got.unsqueeze(-1)
    assert got.shape == ref.shape
    assert torch.allclose(got, ref, atol=1e-5, rtol=1e-5)


def test_offset36_gru_one_adamw_step_matches_frozen_monkey_gru():
    torch.manual_seed(0)
    session = "sess"
    ref, prod = _tiny_offset36_pair(session)
    ref.eval()
    prod.eval()
    x = torch.randn(2, 6, 36)
    args = {"enc_lr": 3e-5, "nBatch": 1}
    prod_opt = EncoderTrainer(None, {}, torch.device("cpu"), args).build_optimizer(
        list(prod.parameters())
    )
    assert EncoderTrainer(None, {}, torch.device("cpu"), args).build_scheduler(prod_opt, 1) is None
    ref_opt, ref_sched = reference_monkey_gru_build_encoder_optimizer(
        list(ref.parameters()),
        {
            "enc_optimizer": "adamw",
            "enc_lr": 3e-5,
            "enc_weight_decay": 0.01,
            "nBatch": 1,
        },
    )
    assert ref_sched is None
    assert isinstance(prod_opt, torch.optim.AdamW)
    assert isinstance(ref_opt, torch.optim.AdamW)

    prod.zero_grad(set_to_none=True)
    ref.zero_grad(set_to_none=True)
    prod(x, session).pow(2).mean().backward()
    ref(x, session).pow(2).mean().backward()
    prod_opt.step()
    ref_opt.step()
    for p_a, p_b in zip(prod.parameters(), ref.parameters(), strict=True):
        assert torch.allclose(p_a, p_b, atol=1e-5, rtol=1e-5)


def _module_constants(tree: ast.AST) -> dict[str, object]:
    out: dict[str, object] = {}
    for node in getattr(tree, "body", ()):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        try:
            out[target.id] = ast.literal_eval(node.value)
        except ValueError:
            continue
    return out


def _eval_expr(node: ast.AST, constants: dict[str, object]) -> object:
    if isinstance(node, ast.Call):
        return _literal_call_kwargs(node, constants)
    if isinstance(node, ast.Name) and node.id in constants:
        return constants[node.id]
    if isinstance(node, ast.Attribute):
        return None
    return ast.literal_eval(node)


def _literal_call_kwargs(node: ast.Call, constants: dict[str, object] | None = None) -> dict:
    constants = constants or {}
    out: dict = {}
    for kw in node.keywords:
        if kw.arg is None:
            continue
        out[kw.arg] = _eval_expr(kw.value, constants)
    return out


def test_offset36_gru_advdec_example_hypers_not_library_defaults():
    cfg = TrainConfig(dataset_keys=["jango"])
    assert cfg.recipe == "offset36_gru"
    assert cfg.enc_lr == 3e-5
    assert cfg.batch_size == 256
    assert cfg.window == 256

    tree = ast.parse((_REPO / "examples" / "offset36_gru_advdec.py").read_text(encoding="utf-8"))
    constants = _module_constants(tree)
    found = None
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "TrainConfig":
            found = _literal_call_kwargs(node, constants)
            break
    assert found is not None
    assert found["recipe"] == "offset36_gru_advdec"
    assert found["enc_lr"] == 0.02
    assert found["batch_size"] == 1024
    assert found["adv"]["eps"] == 0.5
    assert found["adv"]["style"] == "bin"
    assert AdvConfig(eps=0.5, style="bin").eps == 0.5


def test_train_session_decoder_window_64():
    model = _FakeEncoderModel()
    dec = train_session_decoder(
        model,
        "s",
        torch.randn(80, 8),
        torch.randn(80, 2),
        n_labels=2,
        device=torch.device("cpu"),
        n_steps=2,
        seed=0,
        use_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        window_size=64,
    )
    assert dec.window_size == 64


def test_evaluate_embedding_decoders_window_64():
    model = _FakeEncoderModel()
    bundles = {
        "s": {
            "train_x": torch.randn(80, 8),
            "train_y": torch.randn(80, 2),
            "test_x": torch.randn(40, 8),
            "test_y": torch.randn(40, 2),
            "n_labels": 2,
            "num_days": 1,
            "dataset_name": "fake",
            "use_smooth": True,
            "xds_smooth": False,
            "dayk_idx": 0,
        }
    }
    evaluate_embedding_decoders(
        model,
        loader=None,
        bundles=bundles,
        device=torch.device("cpu"),
        n_decoder_steps=2,
        seed=0,
        decoder_val_checkpoint=False,
        decoder_cls=BaseGRUDecoder,
        ceb_out=8,
        window_size=64,
    )
    assert model._decoders["s"].window_size == 64


def test_export_plot_data_forwards_window_64(monkeypatch):
    seen: list[int] = []

    def _fake_collect(encoder, decoder, trials, device, window_size=256):
        seen.append(window_size)
        n_labels = 7
        preds = [torch.zeros(256, n_labels).numpy() for _ in trials]
        actuals = [torch.zeros(256, n_labels).numpy() for _ in trials]
        return preds, actuals, 0.0, torch.zeros(n_labels).numpy()

    monkeypatch.setattr("acorn.eval.plot_export.collect_stream_trial_predictions", _fake_collect)
    monkeypatch.setattr(
        "acorn.eval.plot_export.load_day_trials",
        lambda *_a, **_k: (
            [(torch.zeros(256, 7), torch.zeros(256, 7))],
            [(torch.zeros(256, 7), torch.zeros(256, 7))],
            None,
            None,
            None,
            None,
        ),
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_with_test_trials",
        lambda *_a, **_k: None,
    )
    monkeypatch.setattr(
        "acorn.eval.plot_export._align_target_dirs_all_trials",
        lambda *_a, **_k: None,
    )
    export_plot_data(
        _IdentityEncoder(),
        _IdentityDecoder(),
        _FakeLoader([], []),
        "jango",
        "Jango_ISO_2015_raw",
        dayk_idx=1,
        device=torch.device("cpu"),
        xds_smooth=False,
        train_day=0,
        window_size=64,
    )
    assert seen
    assert all(value == 64 for value in seen)


def test_runner_forwards_window_and_has_no_sequence_substring():
    src = (_REPO / "acorn" / "runners" / "multi_session.py").read_text(encoding="utf-8")
    assert "sequence" not in src
    tree = ast.parse(src)
    eval_window = plot_window = None
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = getattr(node.func, "id", None)
        kws = {kw.arg: ast.unparse(kw.value) for kw in node.keywords if kw.arg}
        if name == "evaluate_embedding_decoders":
            eval_window = kws.get("window_size")
        if name == "export_plot_data":
            plot_window = kws.get("window_size")
    assert eval_window == "window_size"
    assert plot_window == "window_size"


def test_reference_monkey_gru_does_not_import_sibling_package():
    src = (_REPO / "tests" / "reference_monkey_gru.py").read_text(encoding="utf-8")
    assert "import monkey_gru" not in src
    assert "from monkey_gru" not in src
    assert "from utils.offset36_multi" not in src
    assert "macorn_cluster" not in src
