"""AMP helper: bf16 autocast on CUDA, disabled on CPU."""

from __future__ import annotations

from contextlib import nullcontext

import pytest
import torch

from acorn.utils.amp import amp_ctx
from tests.conftest import requires_cuda


def test_amp_ctx_cpu_is_disabled():
    ctx = amp_ctx(torch.device("cpu"))
    assert ctx._enabled is False
    x = torch.ones(2, dtype=torch.float32)
    with ctx:
        y = x + x
    assert y.dtype == torch.float32


def test_amp_ctx_cuda_requests_bf16(monkeypatch):
    called: dict = {}

    def _fake_autocast(device_type, dtype=None, enabled=True, **kwargs):
        called["device_type"] = device_type
        called["dtype"] = dtype
        called["enabled"] = enabled
        return nullcontext()

    monkeypatch.setattr(torch, "autocast", _fake_autocast)
    amp_ctx(torch.device("cuda"))
    assert called == {
        "device_type": "cuda",
        "dtype": torch.bfloat16,
        "enabled": True,
    }


@pytest.mark.gpu
@requires_cuda
@pytest.mark.skipif(not torch.cuda.is_bf16_supported(), reason="bf16 not supported")
def test_amp_ctx_cuda_matmul_is_bf16():
    a = torch.randn(8, 8, device="cuda", dtype=torch.float32)
    b = torch.randn(8, 8, device="cuda", dtype=torch.float32)
    with amp_ctx(torch.device("cuda")):
        c = a @ b
    assert c.dtype == torch.bfloat16
