"""P-05: Kaldi argv has no --gpus; neural --gpus only after NVIDIA probe."""

from __future__ import annotations

import importlib.util
import json
import math
import subprocess
from pathlib import Path

import pytest

from acorn.lm.docker_run import (
    build_kaldi_image,
    docker_has_nvidia_runtime,
    docker_kaldi_args,
    docker_neural_args,
    effective_memory_gib,
    hf_cache_dir,
    run_kaldi_decode,
)
from acorn.lm.errors import LmPrerequisiteError
from acorn.lm.presets import original_preset


def test_kaldi_args_cpu_memory_three_binds(tmp_path):
    job = tmp_path / "job"
    tlg = tmp_path / "tlg"
    out = tmp_path / "out" / "nbest.json"
    job.mkdir()
    tlg.mkdir()
    host = 16 * 1024**3
    cmd = docker_kaldi_args(
        job_dir=job,
        tlg_dir=tlg,
        out_path=out,
        preset=original_preset("nlp"),
        host_ram_bytes=host,
    )
    assert "--gpus" not in cmd
    assert "--rm" in cmd
    assert "--memory" in cmd
    mem_idx = cmd.index("--memory")
    cap = int(cmd[mem_idx + 1].rstrip("g"))
    assert cap == effective_memory_gib(original_preset("nlp"), host_ram_bytes=host)
    joined = " ".join(cmd)
    assert ":/job:ro" in joined
    assert ":/tlg:ro" in joined
    assert ":/out" in joined


def test_neural_args_gpus_only_when_requested(tmp_path):
    nbest = tmp_path / "nbest.json"
    nbest.write_text("{}")
    out = tmp_path / "out" / "rescored.json"
    hf = tmp_path / "hf"
    preset = original_preset("nlp")
    host = 72 * 1024**3
    without = docker_neural_args(
        nbest_path=nbest,
        out_path=out,
        preset=preset,
        gpus=False,
        host_ram_bytes=host,
        hf_home=hf,
    )
    assert "--gpus" not in without
    assert "--memory" in without
    assert "HF_HOME=/hf" in without
    cache_vol = f"{hf.expanduser().resolve()}:/hf"
    assert cache_vol in without
    assert ":/hf:ro" not in " ".join(without)
    with_gpu = docker_neural_args(
        nbest_path=nbest,
        out_path=out,
        preset=preset,
        gpus=True,
        host_ram_bytes=host,
        hf_home=hf,
    )
    assert with_gpu[with_gpu.index("--gpus") + 1] == "all"


def test_hf_cache_dir_expands_user(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HF_HOME", "~/hf-cache")
    got = hf_cache_dir()
    assert got == (tmp_path / "hf-cache").resolve()
    assert "~" not in str(got)


def test_neural_hf_home_tilde_bind_is_writable(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HF_HOME", "~/hf")
    nbest = tmp_path / "nbest.json"
    nbest.write_text("{}")
    cmd = docker_neural_args(
        nbest_path=nbest,
        out_path=tmp_path / "rescored.json",
        preset=original_preset("nlp"),
        gpus=False,
        host_ram_bytes=72 * 1024**3,
    )
    expected = f"{(tmp_path / 'hf').resolve()}:/hf"
    assert expected in cmd
    assert ":/hf:ro" not in " ".join(cmd)


def test_speech_neural_args_include_8bit(tmp_path):
    nbest = tmp_path / "nbest.json"
    nbest.write_text("{}")
    cmd = docker_neural_args(
        nbest_path=nbest,
        out_path=tmp_path / "rescored.json",
        preset=original_preset("speech"),
        gpus=True,
        host_ram_bytes=400 * 1024**3,
        hf_home=tmp_path / "hf",
    )
    assert "--load-in-8bit" in cmd
    assert "--gpus" in cmd


def test_memory_cap_ninety_percent_host():
    host = 16 * 1024**3
    cap = effective_memory_gib(original_preset("speech"), host_ram_bytes=host)
    assert cap == max(1, math.floor(0.9 * host / 1024**3))


def _run_failing_after_info(fail_sub: str):
    def fake_run(cmd, *args, **kwargs):
        cmd = list(cmd)
        if cmd[:2] == ["docker", "info"]:
            return subprocess.CompletedProcess(cmd, 0, stdout="{}", stderr="")
        raise subprocess.CalledProcessError(1, cmd if cmd else ["docker", fail_sub])

    return fake_run


def test_docker_build_failure_names_subcommand(monkeypatch):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr("acorn.lm.docker_run.subprocess.run", _run_failing_after_info("build"))
    with pytest.raises(LmPrerequisiteError, match=r"docker build") as exc:
        build_kaldi_image()
    assert "daemon" not in str(exc.value).lower()


def test_docker_run_failure_names_subcommand(monkeypatch, tmp_path):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr("acorn.lm.docker_run.subprocess.run", _run_failing_after_info("run"))
    job = tmp_path / "job"
    tlg = tmp_path / "tlg"
    job.mkdir()
    tlg.mkdir()
    with pytest.raises(LmPrerequisiteError, match=r"docker run") as exc:
        run_kaldi_decode(
            job,
            tlg,
            tmp_path / "nbest.json",
            original_preset("nlp"),
            host_ram_bytes=72 * 1024**3,
        )
    assert "daemon" not in str(exc.value).lower()


def _neural_worker():
    path = Path(__file__).resolve().parents[1] / "acorn" / "lm" / "sidecar" / "neural" / "worker.py"
    spec = importlib.util.spec_from_file_location("acorn_lm_neural_worker", path)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_gpt2_device_map_auto_when_cuda_without_8bit():
    worker = _neural_worker()
    gpu = worker.hf_load_kwargs(False, cuda_available=True)
    assert gpu["device_map"] == "auto"
    assert "load_in_8bit" not in gpu
    assert "cache_dir" not in gpu
    cpu = worker.hf_load_kwargs(False, cuda_available=False)
    assert "device_map" not in cpu
    assert "cache_dir" not in cpu
    eight = worker.hf_load_kwargs(True, cuda_available=False)
    assert eight["load_in_8bit"] is True
    assert eight["device_map"] == "auto"
    assert "cache_dir" not in eight


def test_neural_worker_omits_hf_cache_dir(monkeypatch, tmp_path):
    worker = _neural_worker()
    nbest = tmp_path / "nbest.json"
    nbest.write_text(
        json.dumps(
            {
                "schema": "acorn_lm.nbest.v1",
                "trials": [
                    {
                        "hypotheses": [
                            {"text": "hi", "acoustic_score": 0.0, "ngram_score": 0.0},
                        ]
                    }
                ],
            }
        )
    )
    out = tmp_path / "rescored.json"
    seen: dict[str, object] = {}

    def fake_scorer(*args, **kwargs):
        seen["args"] = args
        seen["kwargs"] = kwargs
        return lambda texts: [0.0] * len(texts)

    monkeypatch.delenv("HF_HOME", raising=False)
    monkeypatch.setattr(worker, "hf_scorer", fake_scorer)
    argv = [
        "--nbest",
        str(nbest),
        "--out",
        str(out),
        "--model",
        "gpt2-xl",
        "--alpha",
        "1.0",
        "--acoustic-scale",
        "0.5",
    ]
    worker.main(argv)
    assert seen["args"] == ("gpt2-xl", False)
    assert "cache_dir" not in seen["kwargs"]
    monkeypatch.setenv("HF_HOME", "/custom-hf")
    worker.main(argv)
    assert seen["args"] == ("gpt2-xl", False)
    assert "cache_dir" not in seen["kwargs"]


def test_docker_info_daemon_down_is_not_nvidia(monkeypatch):
    monkeypatch.setattr("acorn.lm.docker_run.shutil.which", lambda name: "/usr/bin/docker")

    def boom(*args, **kwargs):
        raise subprocess.CalledProcessError(1, ["docker", "info"])

    monkeypatch.setattr("acorn.lm.docker_run.subprocess.run", boom)
    with pytest.raises(LmPrerequisiteError, match="daemon") as exc:
        docker_has_nvidia_runtime()
    assert "NVIDIA" not in str(exc.value)
