"""Lock: core trainers/eval must not grow new run-artifact writers."""

from __future__ import annotations

import re
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
_SCAN_DIRS = (
    "acorn/runners",
    "acorn/train",
    "acorn/eval",
    "acorn/models",
    "acorn/lm",
)
_SUBSTRINGS = (
    "torch.save(",
    "append_history(",
    "metrics.json",
    "np.savez",
    "write_text",
    "write_bytes",
    "json.dump",
    "mkdir",
)
_OPEN_WRITE_RE = re.compile(r"open\([^)]*[\"']w")
# Docker temp staging, LM graph caches, and in-container sidecar IPC. Persistent
# run artifacts (checkpoint.pt, metrics.json, lm_metrics.json) are not allowed.
_ALLOWED = {
    "acorn/lm/docker_run.py",
    "acorn/lm/download.py",
    "acorn/lm/graphs.py",
    "acorn/lm/nbest.py",
    "acorn/lm/prepare.py",
    "acorn/lm/sidecar/kaldi/decode_worker.py",
    "acorn/lm/sidecar/neural/worker.py",
}


def test_no_new_core_run_artifact_writers():
    hits: list[str] = []
    for dirname in _SCAN_DIRS:
        root = _REPO / dirname
        for path in sorted(root.rglob("*.py")):
            rel = path.relative_to(_REPO).as_posix()
            if rel in _ALLOWED:
                continue
            text = path.read_text(encoding="utf-8")
            for needle in _SUBSTRINGS:
                if needle in text:
                    hits.append(f"{rel}: {needle}")
            if _OPEN_WRITE_RE.search(text):
                hits.append(f"{rel}: open(..., w)")
    assert hits == [], "new core writers:\n" + "\n".join(hits)
