"""Tiny CPU tests for generic Gaussian noise and consistency lists."""

from __future__ import annotations

import numpy as np
import torch

from acorn.eval.noise import add_gaussian_noise, score_under_gaussian_noise


class _Enc:
    training = False

    def eval(self):
        return self

    def train(self):
        return self

    def transform(self, x, session_key):
        return x


class _Dec:
    def score(self, emb, y, device):
        return float(emb.float().mean())


def test_add_gaussian_noise_iid():
    x = torch.zeros(8, 3)
    noisy = add_gaussian_noise(x, 0.5, seed=0)
    assert noisy.shape == x.shape
    assert not torch.allclose(noisy, x)


def test_score_under_gaussian_noise():
    score = score_under_gaussian_noise(
        _Enc(),
        _Dec(),
        torch.zeros(8, 3),
        torch.zeros(8, 2),
        0.1,
        session_key="s",
        device=torch.device("cpu"),
        seed=0,
    )
    assert isinstance(score, float)


def test_session_consistency_score_no_vstack(monkeypatch):
    from acorn.eval import consistency as cons

    captured = {}

    def _fake(**kwargs):
        captured.update(kwargs)
        return np.array([1.0]), [("a", "b")], ["a", "b"]

    monkeypatch.setattr(cons, "ensure_vendored_on_path", lambda: None)

    import sys
    import types

    fake_cebra = types.SimpleNamespace(
        sklearn=types.SimpleNamespace(metrics=types.SimpleNamespace(consistency_score=_fake))
    )
    monkeypatch.setitem(sys.modules, "cebra", fake_cebra)
    e1 = np.ones((4, 2))
    e2 = np.ones((5, 2))
    cons.session_consistency_score([e1, e2], [np.zeros(4), np.zeros(5)], dataset_ids=["a", "b"])
    assert captured["embeddings"][0].shape == (4, 2)
    assert captured["embeddings"][1].shape == (5, 2)
    assert captured["embeddings"][0].shape[0] != captured["embeddings"][1].shape[0]
