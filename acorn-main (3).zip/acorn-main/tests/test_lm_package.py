"""P-01: packaged sidecars, no host neural imports, no CLI extra."""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
_LM = _REPO / "acorn" / "lm"


def test_host_lm_py_has_no_transformers_import():
    for path in _LM.glob("*.py"):
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            assert "transformers" not in line, f"{path}: {line}"


def test_packaged_dockerfiles_present():
    kaldi = files("acorn.lm") / "sidecar" / "kaldi" / "Dockerfile"
    neural = files("acorn.lm") / "sidecar" / "neural" / "Dockerfile"
    assert kaldi.is_file()
    assert neural.is_file()
    kaldi_text = kaldi.read_text(encoding="utf-8")
    assert "ubuntu:22.04" in kaldi_text
    assert "python3.9" in kaldi_text
    assert "https://bootstrap.pypa.io/pip/3.9/get-pip.py" in kaldi_text
    assert "gnupg" in kaldi_text
    assert "archives.boost.io" in kaldi_text
    assert "boostorg.jfrog.io" in kaldi_text
    assert "torch==1.13.1+cpu" in kaldi_text
    assert "8d87b947" in kaldi_text
    assert "runtime/server/x86" in kaldi_text
    assert "runtime/core" in kaldi_text
    assert "srilm-1.7.3" in kaldi_text
    neural_text = neural.read_text(encoding="utf-8")
    assert "transformers==4.44.2" in neural_text
    assert "accelerate==0.34.2" in neural_text
    assert "bitsandbytes==0.43.3" in neural_text
    assert "torch==2.4.1" in neural_text


def test_pyproject_has_no_lm_extra_or_scripts():
    text = (_REPO / "pyproject.toml").read_text(encoding="utf-8")
    assert "[project.scripts]" not in text
    assert "lm = [" not in text
    assert "[lm]" not in text
    assert "sidecar/kaldi/Dockerfile" in text
    assert "sidecar/neural/Dockerfile" in text


def test_init_does_not_export_lm():
    import acorn

    assert "rescore_export" not in acorn.__all__
    assert not hasattr(acorn, "rescore_export")
    from acorn.eval import sequence as seq

    assert "rescore_export" not in seq.__all__
    assert "LmPrerequisiteError" not in seq.__all__
