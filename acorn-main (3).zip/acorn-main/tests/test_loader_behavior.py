"""Black-box pins of DatasetLoader / EMG preprocessing (must stay identical across refactors)."""

from __future__ import annotations

import hashlib
from datetime import datetime

import numpy as np
import pytest

from acorn.data.loader import DatasetLoader, emg_preprocessing

_JANGO_HASH = "f9c23f8a31b5d2c9430168d9b34773634d5c60bfeb4fedac546d827412b31558"
_OTHER_HASH = "5e9e24778ba306e266162d69d18c9c37792dc04b57c2e4ab04c41a5b705274f4"


@pytest.fixture
def isolated_loader(tmp_path):
    DatasetLoader.reset()
    loader = DatasetLoader(
        data_root_dir=str(tmp_path / "data"),
        cache_dir=str(tmp_path / "cache"),
    )
    yield loader
    DatasetLoader.reset()


def _names_hash(names: list[str]) -> str:
    return hashlib.sha256(",".join(names).encode()).hexdigest()


def test_emg_preprocessing_drops_bad_channels_and_clips():
    emg_names = [
        "EMG_ECRb",
        "EMG_ECRl",
        "EMG_ECU",
        "EMG_EDCr",
        "EMG_FCR",
        "EMG_FCU",
        "EMG_FDP",
        "EMG_NOISE",
    ]
    rng = np.random.default_rng(0)
    trial_a = rng.random((10, 8)).astype(np.float64)
    trial_b = rng.random((12, 8)).astype(np.float64)
    trial_a[0, 0] = 1.0e6  # outlier on a kept channel
    trials = [trial_a.copy(), trial_b.copy()]

    good = [
        "EMG_ECRb",
        "EMG_ECRl",
        "EMG_ECU",
        "EMG_EDCr",
        "EMG_FCR",
        "EMG_FCU",
        "EMG_FDP",
    ]
    idx = [emg_names.index(x) for x in good]
    selected = [t[:, idx].copy() for t in trials]
    concat = np.concatenate(selected)
    outlier = np.mean(concat, axis=0) + 6 * np.std(concat, axis=0)
    clipped = [np.clip(s, a_min=None, a_max=outlier) for s in selected]
    baseline = np.percentile(concat, 2, axis=0)
    peak = np.percentile(concat - baseline, 90, axis=0)
    expected = [(c - baseline) / peak for c in clipped]

    out, names = emg_preprocessing(trials, emg_names)
    assert names == good
    assert len(out) == 2
    assert out[0].shape == (10, 7)
    assert out[1].shape == (12, 7)
    np.testing.assert_allclose(out[0], expected[0])
    np.testing.assert_allclose(out[1], expected[1])


def test_unit_names_jango_vs_other_are_pinned(isolated_loader):
    jango = isolated_loader.get_all_unit_names("Jango_ISO_2015_raw")
    other = isolated_loader.get_all_unit_names("Mihili_CO_2014_raw")
    assert len(jango) == 96
    assert len(other) == 96
    assert jango[0] == "elec93" and jango[-1] == "elec9"
    assert other[0] == "elec78" and other[-1] == "elec9"
    assert _names_hash(jango) == _JANGO_HASH
    assert _names_hash(other) == _OTHER_HASH
    # startswith("Jango") is the branch, not exact dataset-name equality.
    assert isolated_loader.get_all_unit_names("JangoX") == jango
    assert isolated_loader.get_all_unit_names("Pop_PG_2021") == other


def test_spike_zero_padding_places_known_units(isolated_loader):
    names = isolated_loader.get_all_unit_names("Jango_ISO_2015_raw")
    spike = [np.ones((5, 2), dtype=np.float64)]
    out = isolated_loader.spike_zero_padding("Jango_ISO_2015_raw", [names[0], names[3]], spike)
    assert out[0].shape == (5, 96)
    np.testing.assert_array_equal(out[0][:, 0], 1.0)
    np.testing.assert_array_equal(out[0][:, 3], 1.0)
    np.testing.assert_array_equal(out[0][:, 1], 0.0)


def test_window_concatenated_trials_drops_remainder():
    x = [np.ones((3, 2)), np.ones((5, 2))]
    y = [np.zeros((3, 1)), np.zeros((5, 1))]
    xw, yw = DatasetLoader.window_concatenated_trials(x, y, 4)
    assert len(xw) == 2
    assert xw[0].shape == (4, 2)
    assert yw[1].shape == (4, 1)
    with pytest.raises(ValueError, match="Not enough bins"):
        DatasetLoader.window_concatenated_trials(x, y, 16)


def test_cache_filename_and_roundtrip(isolated_loader, tmp_path):
    fn = isolated_loader._get_cache_filename("Jango_ISO_2015_raw", 0, "gocue_time", 0.05)
    assert fn == "Jango_ISO_2015_raw_0_gocue_time_0p0500.npz"
    fn_ns = isolated_loader._get_cache_filename(
        "Jango_ISO_2015_raw", 0, "gocue_time", 0.05, xds_smooth=False
    )
    assert fn_ns.endswith("_xdsnosmooth.npz")
    fn_w = isolated_loader._get_cache_filename(
        "Jango_ISO_2015_raw", 0, "fixed_window", 0.05, trial_window_size=256
    )
    assert fn_w.endswith("_w256.npz")

    cache_path = str(tmp_path / "cache" / "roundtrip.npz")
    x = np.arange(12, dtype=np.float32).reshape(6, 2)
    y = np.arange(6, dtype=np.float32).reshape(6, 1)
    isolated_loader._save_to_disk_cache(cache_path, x, y)
    loaded = isolated_loader._load_from_disk_cache(cache_path)
    assert loaded is not None
    np.testing.assert_array_equal(loaded[0], x)
    np.testing.assert_array_equal(loaded[1], y)

    x_list = [x[:3], x[3:]]
    y_list = [y[:3], y[3:]]
    isolated_loader._save_trials_to_disk_cache(cache_path, x_list, y_list)
    trials = isolated_loader._load_trials_from_disk_cache(cache_path)
    assert trials is not None
    assert len(trials[0]) == 2
    np.testing.assert_array_equal(trials[0][0], x_list[0])


def test_parse_session_date(isolated_loader):
    assert isolated_loader.parse_session_date("Jango_20150101_iso.mat") == datetime(2015, 1, 1)
    with pytest.raises(ValueError, match="No YYYYMMDD"):
        isolated_loader.parse_session_date("no_date_here.mat")


def test_loader_mismatch_raises(tmp_path):
    DatasetLoader.reset()
    DatasetLoader(data_root_dir=str(tmp_path / "a"), cache_dir=str(tmp_path / "ca"))
    with pytest.raises(RuntimeError) as exc_info:
        DatasetLoader(data_root_dir=str(tmp_path / "b"), cache_dir=str(tmp_path / "ca"))
    msg = str(exc_info.value)
    assert "data_root_dir" in msg
    assert "DatasetLoader.reset()" in msg
    assert "ACORN_DATA_DIR" in msg
    DatasetLoader.reset()


def test_loader_reset_allows_new_root(tmp_path):
    DatasetLoader.reset()
    first = DatasetLoader(data_root_dir=str(tmp_path / "a"), cache_dir=str(tmp_path / "c"))
    DatasetLoader.reset()
    second = DatasetLoader(data_root_dir=str(tmp_path / "b"), cache_dir=str(tmp_path / "c"))
    assert first is not second
    assert second.data_root_dir == str((tmp_path / "b").resolve())
    DatasetLoader.reset()


def test_loader_equivalent_normalized_paths_same_instance(tmp_path):
    DatasetLoader.reset()
    root = tmp_path / "data"
    cache = tmp_path / "cache"
    first = DatasetLoader(data_root_dir=str(root), cache_dir=str(cache))
    second = DatasetLoader(data_root_dir=str(root / "."), cache_dir=str(cache))
    assert first is second
    DatasetLoader.reset()


def test_download_from_drive_decline_skips_gdown(isolated_loader, monkeypatch):
    from acorn.data.consent import DownloadDeclined

    called: list[int] = []
    monkeypatch.setattr("acorn.data.loader.gdown.download", lambda *a, **k: called.append(1))
    monkeypatch.setattr("builtins.input", lambda *_a, **_k: "n")
    with pytest.raises(DownloadDeclined):
        isolated_loader.download_from_drive("Jango_ISO_2015_raw")
    assert called == []


def test_download_from_drive_env_skips_input(isolated_loader, monkeypatch):
    monkeypatch.setenv("ACORN_DOWNLOAD_YES", "1")
    monkeypatch.setattr(
        "builtins.input",
        lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("input")),
    )
    monkeypatch.setattr("acorn.data.loader.gdown.download", lambda *a, **k: None)
    isolated_loader.download_from_drive("Jango_ISO_2015_raw")


def test_prepare_dataset_nonempty_skips_download(isolated_loader, monkeypatch):
    from pathlib import Path

    name = "Jango_ISO_2015_raw"
    dest = isolated_loader.get_dataset_folder(name)
    Path(dest).mkdir(parents=True, exist_ok=True)
    (Path(dest) / "day0.mat").write_text("x")

    def _boom(*args, **kwargs):
        raise AssertionError("download")

    monkeypatch.setattr(isolated_loader, "download_from_drive", _boom)
    assert isolated_loader.prepare_dataset(name) == dest


def test_missing_day_file_named_error(isolated_loader):
    from pathlib import Path

    name = "Jango_ISO_2015_raw"
    dest = isolated_loader.get_dataset_folder(name)
    Path(dest).mkdir(parents=True, exist_ok=True)
    (Path(dest) / "day0.mat").write_text("x")
    with pytest.raises(FileNotFoundError, match="day_num=1"):
        isolated_loader.get_dataset_day_filename(1, name)
