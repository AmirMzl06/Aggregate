"""Frozen reference algorithms for B2T sequence-format bit-match tests.

Ports of Unfolder length math, get_batch, and combined-loss
PGD around commit 3bb618b. Not imported by production code.
"""

from __future__ import annotations

import torch

from acorn.train.adversarial import init_adv_noise, pgd_step
from acorn.train.sequence.get_batch import get_batch
from acorn.utils.amp import amp_ctx


def reference_unfold_tensor_length(t: int, kernel: int = 32, stride: int = 4) -> int:
    return (t - kernel) // stride + 1


def reference_unfold_ctc_length(length: int, kernel: int = 32, stride: int = 4) -> int:
    return int((length - kernel) / stride)


def reference_ctc_adv_alpha(eps: float) -> float:
    return eps / 5.0


def reference_get_batch(x, x_len, batch_size, offset):
    """Exact live-recipe get_batch: random_offset=True, random_dir=True."""
    bsz, _t, _f = x.shape
    device = x.device
    ref_batch_idx = torch.randint(0, bsz, (batch_size,), device=device)
    max_times = torch.clamp(x_len[ref_batch_idx] - offset - 1, min=1)
    ref_time_idx = torch.randint(offset, torch.max(max_times).item(), (batch_size,), device=device)
    ref_time_idx = torch.min(ref_time_idx, max_times - 1)
    add_offset = torch.randint(
        1, offset + 1, (len(ref_batch_idx),), device=device, dtype=torch.long
    )
    dir_val = torch.randint(0, 2, add_offset.shape, device=device) * 2 - 1
    add_offset = add_offset * dir_val
    pos_time_idx = torch.clamp(
        ref_time_idx + add_offset,
        min=torch.zeros_like(x_len[ref_batch_idx] - 1),
        max=x_len[ref_batch_idx] - 1,
    )
    neg_batch_idx = torch.randint(0, bsz, (len(ref_batch_idx),), device=device)
    neg_max_times = x_len[neg_batch_idx]
    neg_time_idx = torch.randint(
        0, torch.max(neg_max_times).item(), (len(ref_batch_idx),), device=device
    )
    neg_time_idx = torch.min(neg_time_idx, neg_max_times - 1)
    return (
        x[ref_batch_idx, ref_time_idx],
        x[ref_batch_idx, pos_time_idx],
        x[neg_batch_idx, neg_time_idx],
        ref_batch_idx,
        ref_time_idx,
        pos_time_idx,
        neg_batch_idx,
        neg_time_idx,
    )


def reference_clean_and_pgd_step(
    model,
    optimizer,
    x: torch.Tensor,
    y: torch.Tensor,
    x_len: torch.Tensor,
    y_len: torch.Tensor,
    session_key: str,
    ctc_criterion,
    infonce_criterion,
    *,
    cont_batch: int,
    offset: int,
    adv_eps: float,
    adv_steps: int,
    alpha: float | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Port of combined-loss PGD (l2 / bin, live flags).

    Independent of ``CtcTrainer._clean_step`` / ``l2_adv_ctc``. Mutates ``model``
    and ``optimizer``. Returns ``(clean_loss, x_adv, adv_loss)``.
    """
    device = x.device
    step_alpha = reference_ctc_adv_alpha(adv_eps) if alpha is None else alpha
    with amp_ctx(device):
        pred, lengths = model(x, x_len, session_key)
        embeddings, emb_lengths = model.get_cebra_embs()
        ctc_loss = ctc_criterion(pred.log_softmax(2).permute(1, 0, 2), y, lengths, y_len)
        triples = get_batch(embeddings, emb_lengths, cont_batch, offset)
        reference, positive, negative = triples[0], triples[1], triples[2]
        infonce_loss, _, _ = infonce_criterion(reference, positive, negative)
        loss = ctc_loss + infonce_loss
    optimizer.zero_grad(set_to_none=True)
    if torch.isfinite(loss):
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
    index_triples = triples[3:]
    ref_batch_idx, ref_time_idx, pos_time_idx, neg_batch_idx, neg_time_idx = index_triples

    x_adv = init_adv_noise(x, adv_eps, "bin", device)
    x_adv.requires_grad_(True)
    for _ in range(adv_steps):
        with amp_ctx(device):
            pred_adv, lengths = model(x_adv, x_len, session_key)
            embeddings_adv, _emb_lengths = model.get_cebra_embs()
            ctc_loss_adv = ctc_criterion(
                pred_adv.log_softmax(2).permute(1, 0, 2), y, lengths, y_len
            )
            reference = embeddings_adv[ref_batch_idx, ref_time_idx]
            positive = embeddings_adv[ref_batch_idx, pos_time_idx].detach()
            negative = embeddings_adv[neg_batch_idx, neg_time_idx].detach()
            loss_contrastive_adv, _, _ = infonce_criterion(reference, positive, negative)
            loss_adv = loss_contrastive_adv + ctc_loss_adv
        (grad_x,) = torch.autograd.grad(loss_adv, x_adv, retain_graph=False, create_graph=False)
        x_adv = pgd_step(x_adv, grad_x, x, adv_eps, step_alpha, "bin")
        x_adv.requires_grad_(True)

    x_adv.requires_grad_(False)
    optimizer.zero_grad(set_to_none=True)
    with amp_ctx(device):
        pred_adv, lengths = model(x_adv, x_len, session_key)
        embeddings_adv, _emb_lengths = model.get_cebra_embs()
        ctc_loss_adv = ctc_criterion(pred_adv.log_softmax(2).permute(1, 0, 2), y, lengths, y_len)
        reference = embeddings_adv[ref_batch_idx, ref_time_idx]
        positive = embeddings_adv[ref_batch_idx, pos_time_idx]
        negative = embeddings_adv[neg_batch_idx, neg_time_idx]
        loss_contrastive_adv, _, _ = infonce_criterion(reference, positive, negative)
        loss_adv = loss_contrastive_adv + ctc_loss_adv
    if torch.isfinite(loss_adv):
        loss_adv.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
    return loss.detach(), x_adv.detach(), loss_adv.detach()
