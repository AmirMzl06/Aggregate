"""Shape / offset smoke tests for encoder and decoder (CPU, tiny dims)."""

import torch

from acorn.models.decoder import MonkeyDecoder
from acorn.models.encoder import MonkeyEncoder
from acorn.models.multi_session import MultiSessionModel


def test_encoder_offset_is_18_18():
    enc = MonkeyEncoder(ceb_hidden=32, ceb_out=8)
    enc.add_session("jango", num_neurons=16, use_smooth=False)
    off = enc.get_offset()
    assert off.left == 18 and off.right == 18


def test_encoder_cebra_windows_shape():
    enc = MonkeyEncoder(ceb_hidden=32, ceb_out=8)
    enc.add_session("jango", num_neurons=16, use_smooth=False)
    x = torch.randn(4, 16, 36)  # (B, neurons, 36)
    out = enc.encode_cebra_windows(x, "jango")
    assert out.shape == (4, 8)


def test_encoder_encode_preserves_length():
    enc = MonkeyEncoder(ceb_hidden=32, ceb_out=8)
    enc.add_session("jango", num_neurons=16, use_smooth=False)
    t = 64
    x = torch.randn(2, t, 16)
    lengths = torch.tensor([t, t], dtype=torch.long)
    embs, out_lens = enc.encode(x, lengths, "jango")
    assert embs.shape == (2, t, 8)
    assert torch.equal(out_lens, lengths)


def test_decoder_forward_shape():
    dec = MonkeyDecoder(ceb_out=8, hidden=16, layers=1, dropout=0.0, n_labels=2, use_gru=True)
    embs = torch.randn(3, 20, 8)
    lengths = torch.tensor([20, 20, 20], dtype=torch.long)
    pred = dec(embs, lengths)
    assert pred.shape == (3, 20, 2)


def test_multi_session_add_and_transform():
    model = MultiSessionModel(ceb_hidden=32, ceb_out=8)
    model.add_session("jango", num_neurons=16, n_labels=2, use_smooth=False)
    x = torch.randn(40, 16)
    out = model.transform(x, "jango")
    assert out.shape == (40, 8)
