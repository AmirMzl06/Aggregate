"""Public package API + DATA_DIR override smoke tests."""

import importlib
from pathlib import Path

import acorn
from acorn import list_datasets, list_recipes
from acorn.utils import constants as constants_mod


def test_public_exports():
    assert hasattr(acorn, "TrainConfig")
    assert hasattr(acorn, "TrainResult")
    assert hasattr(acorn, "AdvConfig")
    assert hasattr(acorn, "train_model")
    assert hasattr(acorn, "SequenceTrainConfig")
    assert hasattr(acorn, "DEFAULT_SEQUENCE_RECIPE")
    assert acorn.DEFAULT_SEQUENCE_RECIPE == "offset36_ctc"
    assert hasattr(acorn, "DATASET_REGISTRY")
    assert hasattr(acorn, "RECIPE_REGISTRY")
    assert hasattr(acorn, "SequenceTrainConfig")
    assert hasattr(acorn, "DEFAULT_SEQUENCE_RECIPE")
    assert acorn.DEFAULT_SEQUENCE_RECIPE == "offset36_ctc"
    assert "TrainResult" in acorn.__all__
    assert "train" not in acorn.__all__
    assert "resolve_device" not in acorn.__all__
    from acorn.data.registry import DATASETS
    from acorn.data.sequence.registry import SEQUENCE_DATASET_REGISTRY

    seq = [key for key, spec in SEQUENCE_DATASET_REGISTRY.items() if not spec.demo_only]
    assert list_datasets() == sorted(set(DATASETS) | set(seq))
    assert "perich_c_co_1" in list_datasets()
    assert "hippo_achilles" in list_datasets()
    assert "chewie_co" not in list_datasets()
    assert "register_sequence_recipe" in acorn.__all__
    assert "set_seed" in acorn.__all__
    assert hasattr(acorn, "set_seed")
    assert "get_logger" in acorn.__all__
    assert "set_verbosity" in acorn.__all__
    assert hasattr(acorn, "get_logger")
    assert hasattr(acorn, "set_verbosity")
    assert "get_sequence_dataset" in acorn.__all__
    assert "SequenceDatasetSpec" in acorn.__all__
    assert "SEQUENCE_DATASET_REGISTRY" in acorn.__all__
    assert "offset36_gru" in list_recipes()
    assert "offset36_gru_advdec" in list_recipes()
    assert "offset36_ctc" in list_recipes()
    assert "offset36_cebra" in list_recipes()
    assert "offset36_ctc" in list_recipes()
    assert isinstance(acorn.__version__, str)
    assert acorn.__version__


def test_data_dir_env_override(monkeypatch):
    monkeypatch.setenv("ACORN_DATA_DIR", "/tmp/custom_monkey_data")
    importlib.reload(constants_mod)
    assert str(constants_mod.DATA_DIR) == "/tmp/custom_monkey_data"
    monkeypatch.delenv("ACORN_DATA_DIR", raising=False)
    importlib.reload(constants_mod)
    assert constants_mod.DATA_DIR == Path("./data")


def test_import_acorn_does_not_mkdir_data_root(tmp_path, monkeypatch):
    monkeypatch.delenv("ACORN_DATA_DIR", raising=False)
    monkeypatch.chdir(tmp_path)
    importlib.reload(constants_mod)
    assert not Path("data").exists()
    assert constants_mod.DATA_DIR == Path("./data")


def test_submodule_exports_match_top_level():
    import acorn.data as data
    import acorn.eval.sequence as eval_sequence
    import acorn.models as models
    import acorn.train as train

    assert hasattr(models, "register_sequence_recipe")
    assert hasattr(models, "SequenceRecipeSpec")
    assert hasattr(data, "list_datasets")
    assert hasattr(data, "SequenceSession")
    assert hasattr(eval_sequence, "export_all_sessions")
    assert hasattr(eval_sequence, "evaluate_sequence_sessions")
    assert hasattr(train, "TrainConfig")
    assert hasattr(train, "TrainResult")
    assert hasattr(train, "AdvConfig")
    assert hasattr(train, "SequenceTrainConfig")
    assert hasattr(train, "set_seed")
    assert "TrainConfig" in train.__all__
    assert "TrainResult" in train.__all__
    assert "AdvConfig" in train.__all__
    assert "SequenceTrainConfig" in train.__all__
    assert "set_seed" in train.__all__
