"""Frozen vendored adv_alternate=True Solver.step body (rotate + unpermuted global L2)."""

from __future__ import annotations

import torch

import cebra.data
from cebra.solver.base import _l2_normalize, _proj_l2_ball, _rand_radius_like


def reference_alternate_step(solver, batch: cebra.data.Batch) -> dict:
    solver.optimizer.zero_grad()
    with torch.autocast(device_type=batch.reference.device.type, dtype=torch.bfloat16):
        pred = solver._inference(batch)
        loss, align, uniform = solver.criterion(pred.reference, pred.positive, pred.negative)
    loss.backward()
    solver.optimizer.step()

    if solver.training_mode == "adversarial":
        if solver.perturbed == "ref":
            x_base = batch.reference
        elif solver.perturbed == "pos":
            x_base = batch.positive
        elif solver.perturbed == "neg":
            x_base = batch.negative
        else:
            raise ValueError(f"Unknown perturbed value: {solver.perturbed}")
        if solver.attack_norm in {"linf", "l2"}:
            solver.optimizer.zero_grad()
            adv_epsilon = solver.adv_epsilon
            adv_alpha = solver.adv_alpha
            adv_steps = solver.adv_steps
            adv_aggregate = solver.adv_aggregate
            adv_traj = [] if adv_aggregate else None
            x_adv = x_base.clone().detach()
            noise = _l2_normalize(torch.randn_like(x_adv))
            noise *= _rand_radius_like(x_adv) * adv_epsilon
            x_adv = (x_base + noise).clone().detach().requires_grad_(True)
            for _ in range(adv_steps):
                if solver.attack_norm == "l2" and x_adv.grad is not None:
                    x_adv.grad.zero_()
                adv_batch = cebra.data.Batch(
                    reference=x_adv if solver.perturbed == "ref" else batch.reference,
                    positive=x_adv if solver.perturbed == "pos" else batch.positive,
                    negative=x_adv if solver.perturbed == "neg" else batch.negative,
                )
                with torch.autocast(device_type=x_adv.device.type, dtype=torch.bfloat16):
                    adv_output = solver._inference(adv_batch)
                    adv_loss = solver.criterion(
                        adv_output.reference, adv_output.positive, adv_output.negative
                    )[0]
                (grad_x,) = torch.autograd.grad(
                    adv_loss, x_adv, retain_graph=False, create_graph=False
                )
                with torch.no_grad():
                    x_adv += adv_alpha * _l2_normalize(grad_x)
                    x_adv = _proj_l2_ball(x_adv, x_base, adv_epsilon)
                    x_adv.requires_grad = True
                    if adv_traj is not None:
                        adv_traj.append(x_adv.detach())
            adv_inputs = [x_adv.detach()] if adv_traj is None else adv_traj
            weights = [1.0] if adv_traj is None else [1.0 / len(adv_inputs)] * len(adv_inputs)
            adv_loss_total = 0.0
            for i, x_i in enumerate(adv_inputs):
                adv_batch = cebra.data.Batch(
                    reference=x_i if solver.perturbed == "ref" else batch.reference,
                    positive=x_i if solver.perturbed == "pos" else batch.positive,
                    negative=x_i if solver.perturbed == "neg" else batch.negative,
                )
                with torch.autocast(device_type=x_i.device.type, dtype=torch.bfloat16):
                    output = solver._inference(adv_batch)
                    loss_i, _, _ = solver.criterion(
                        output.reference, output.positive, output.negative
                    )
                adv_loss_total = adv_loss_total + weights[i] * loss_i
            adv_loss_total.backward()
            solver.optimizer.step()

    solver.history.append(loss.item())
    stats = dict(
        pos=align.item(),
        neg=uniform.item(),
        total=loss.item(),
        temperature=solver.criterion.temperature,
    )
    for k, v in stats.items():
        solver.log[k].append(v)
    return stats
