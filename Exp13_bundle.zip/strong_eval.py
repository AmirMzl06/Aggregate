#!/usr/bin/env python3
"""Exp10a: stronger-attack check of the saved models (no training).

Every robustness number so far comes from decoder-targeted d'-APGD with 20 steps and one
warm-started restart per budget. This script re-evaluates the SAVED encoder + decoder checkpoints
with a stronger attack (default: 100 APGD steps and 3 restarts per budget; the extra restarts
start at random points of radius eps/2 and the per-window worst case is kept), with the same two
metrics (reference = Ledoit-Wolf x Welch, isotropic) fitted on the same training split, the same
budgets, decoder and evaluation seed. The DDN margins are skipped (only the robust-R2 curves and
the half-damage thresholds are recomputed).

If the advantage of the noise-aware models over PGD6 were gradient masking, it would shrink
under the stronger attack. The summary therefore compares, model by model, the original (v1)
and the strong half-damage thresholds, and the paired ratios to PGD6 under both attacks.

Layout read (as written by the Exp5/6/8/9 runners):
    <results-dir>/<SOURCE>/<SESSION>/seed<SEED>/models/<ARM>_encoder.pt and _decoder.pt
    <results-dir>/<SOURCE>/<SESSION>/seed<SEED>/robust_eval/<ARM>.json      (v1)
Written:
    .../robust_eval_<tag>/<ARM>.json, <results-dir>/STRONG_EVAL_<tag>/ (CSVs and SUMMARY.txt)

Usage (keep this script next to Acorn-dprime and dprime_exp9.py; re-running skips finished
models, so an interrupted run can simply be started again):
    python -u strong_eval.py --results-dir . --gpu-workers 4
    python -u strong_eval.py --results-dir . --dry-run            # the models it would evaluate
    python -u strong_eval.py --results-dir . --summarize-only     # tables from what is done
"""
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import torch

import dprime_exp9 as runner

SESSIONS = runner.SESSIONS
# Source folder -> (CEBRA mode, arms re-evaluated by default).
SOURCES: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "DPRIME_EXP5": ("time_only", ("PGD_L2_EPS6", "MADRY_SP_D8", "MADRY_SPDIFF_D8")),
    "DPRIME_EXP6": ("time_only", ("PGD_L2_EPS6", "MADRY_SP_D8", "MADRY_SPDIFF_D8",
                                  "MADRY_SP_D8_POOL")),
    "DPRIME_SUPERVISED_PERICH_EXP8": ("supervised", ("PGD_L2_EPS6", "MADRY_SP_D8",
                                                     "MADRY_SPDIFF_D8", "MADRY_SP_D8_POOL",
                                                     "MADRY_SPREG_D8")),
    "DPRIME_EXP9_AUTOSIG_SUPERVISED": ("supervised", ("MADRY_SPDIFF_AUTOSIG", "MADRY_SP_AUTOSIG",
                                                      "MADRY_SPREG_AUTOSIG",
                                                      "MADRY_SP_AUTOSIG_POOL")),
    "DPRIME_EXP9_AUTOSIG_TIMEONLY": ("time_only", ("MADRY_SPDIFF_AUTOSIG", "MADRY_SP_AUTOSIG",
                                                   "MADRY_SP_AUTOSIG_POOL")),
}
SHORT = {"CLEAN": "CLEAN", "PGD_L2_EPS3": "PGD3", "PGD_L2_EPS6": "PGD6",
         "PGD_L2_EPS12": "PGD12", "MADRY_ISO_D8": "ISO8", "MADRY_SP_D8": "SP8",
         "MADRY_SPDIFF_D8": "DIFF8", "MADRY_SP_D8_POOL": "POOL8", "MADRY_SPREG_D8": "REG8",
         "MADRY_SPDIFF_AUTOSIG": "DIFF_AUTO", "MADRY_SP_AUTOSIG": "SP_AUTO",
         "MADRY_SPREG_AUTOSIG": "REG_AUTO", "MADRY_SP_AUTOSIG_POOL": "POOL_AUTO",
         "MADRY_SP_D8_SIGPROJ": "SP8_SIGPROJ"}
CLIPPED = 0.5 + 1e-6


def find_jobs(args) -> List[Dict[str, object]]:
    """Every saved model of the selected sources, sessions, seeds and arms."""
    jobs = []
    for source, (mode, default_arms) in SOURCES.items():
        if args.sources and source not in args.sources:
            continue
        arms = tuple(args.arms) if args.arms else default_arms
        for session in args.sessions:
            for seed_dir in sorted((args.results_dir / source / session).glob("seed*")):
                seed = int(seed_dir.name[4:])
                if args.seeds and seed not in args.seeds:
                    continue
                for arm in arms:
                    encoder = seed_dir / "models" / f"{arm}_encoder.pt"
                    decoder = seed_dir / "models" / f"{arm}_decoder.pt"
                    if not (encoder.is_file() and decoder.is_file()):
                        continue
                    jobs.append({"source": source, "mode": mode, "session": session,
                                 "seed": seed, "arm": arm, "root": str(seed_dir),
                                 "out": str(seed_dir / f"robust_eval_{args.tag}" / f"{arm}.json")})
    return jobs


def evaluate_job(cebra, job, args) -> None:
    from cebra.dprime.evaluation import evaluate_decoding

    root = Path(job["root"])
    v1_path = root / "robust_eval" / f"{job['arm']}.json"
    v1 = json.loads(v1_path.read_text(encoding="utf-8")) if v1_path.is_file() else None
    epsilons = (v1 or {}).get("settings", {}).get("epsilons") or args.eval_epsilons
    x_train, x_valid, _, y_valid = runner.load_data(args.data_dir / f"{job['session']}.npz")
    # Checkpoints written by our own fork and runners (not an untrusted download).
    encoder = cebra.CEBRA.load(str(root / "models" / f"{job['arm']}_encoder.pt"),
                               backend="sklearn", weights_only=False)
    decoder = runner.TwoLayerMLP(runner.LATENT_DIM, y_valid.shape[1]).to(
        torch.device(encoder.device_))
    path = root / "models" / f"{job['arm']}_decoder.pt"
    try:
        state = torch.load(path, map_location=encoder.device_, weights_only=True)
    except TypeError:
        state = torch.load(path, map_location=encoder.device_)
    decoder.load_state_dict(state)
    begin = time.monotonic()
    robust = evaluate_decoding(encoder, decoder, x_train, x_valid, y_valid, epsilons=epsilons,
                               metrics=("reference", "isotropic"), steps=args.steps,
                               batch_size=args.eval_batch_size, shift_threshold=0.5,
                               contrastive=False, residuals="whole", labels_train=None,
                               seed=int(job["seed"]) + 200_000, restarts=args.restarts,
                               margins=False)
    if v1 is not None and abs(float(robust["clean_r2"]) - float(v1["clean_r2"])) > 5e-4:
        raise RuntimeError(f"Clean R2 {robust['clean_r2']:.6f} differs from the original "
                           f"evaluation {v1['clean_r2']:.6f}: wrong data or checkpoint")
    robust.update(source=job["source"], mode=job["mode"], session=job["session"],
                  seed=job["seed"], arm=job["arm"], strong_seconds=round(time.monotonic() - begin, 1))
    runner.atomic_write_json(Path(job["out"]), robust)


def worker(args) -> int:
    shard, count = (int(v) for v in args._shard.split("/"))
    jobs = [job for i, job in enumerate(find_jobs(args)) if i % count == shard]
    cebra = runner.load_fork(args.fork_dir)
    torch.set_num_threads(args.cpu_threads)
    log = args.results_dir / f"STRONG_EVAL_{args.tag}" / f"worker{shard}.log.jsonl"
    log.parent.mkdir(parents=True, exist_ok=True)
    failures = 0
    for job in jobs:
        if Path(job["out"]).is_file() and not args.overwrite:
            continue
        label = f"{job['source']} {job['session']} seed{job['seed']} {job['arm']}"
        begin = time.monotonic()
        entry = {"job": label, "status": "ok", "error": ""}
        try:
            evaluate_job(cebra, job, args)
        except Exception as exc:  # record and continue with the next model
            failures += 1
            entry.update(status="error", error=f"{type(exc).__name__}: {exc}")
            traceback.print_exc()
        entry["seconds"] = round(time.monotonic() - begin, 1)
        with log.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        print(f"[shard {shard}] {entry['status'].upper()} {label} ({entry['seconds']}s)", flush=True)
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    return 1 if failures else 0


def orchestrate(args) -> int:
    jobs = find_jobs(args)
    pending = [job for job in jobs if args.overwrite or not Path(job["out"]).is_file()]
    print(f"{len(jobs)} saved models found, {len(pending)} to evaluate "
          f"(steps={args.steps}, restarts={args.restarts}, tag={args.tag})", flush=True)
    if pending:
        tokens = runner.gpu_tokens(args.gpu_workers)
        processes = []
        for shard, token in enumerate(tokens):
            cmd = [sys.executable, "-u", str(Path(__file__).resolve()), "--_worker",
                   "--_shard", f"{shard}/{len(tokens)}"] + forward_args(args)
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=token)
            for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
                env[key] = str(args.cpu_threads)
            log = args.results_dir / f"STRONG_EVAL_{args.tag}" / f"worker{shard}.out"
            log.parent.mkdir(parents=True, exist_ok=True)
            processes.append((subprocess.Popen(cmd, env=env, stdout=log.open("w"),
                                               stderr=subprocess.STDOUT), log))
            print(f"[GPU {token}] shard {shard} started, log={log}", flush=True)
        for process, log in processes:
            process.wait()
            print(f"shard log {log}: exit {process.returncode}", flush=True)
    return summarize(args)


def forward_args(args) -> List[str]:
    out = ["--results-dir", str(args.results_dir.resolve()), "--data-dir",
           str(args.data_dir.resolve()), "--fork-dir", str(args.fork_dir.resolve()),
           "--steps", str(args.steps), "--restarts", str(args.restarts), "--tag", args.tag,
           "--eval-batch-size", str(args.eval_batch_size), "--cpu-threads", str(args.cpu_threads),
           "--sessions", *args.sessions,
           "--eval-epsilons", *[str(v) for v in args.eval_epsilons]]
    if args.sources:
        out += ["--sources", *args.sources]
    if args.arms:
        out += ["--arms", *args.arms]
    if args.seeds:
        out += ["--seeds", *[str(v) for v in args.seeds]]
    if args.overwrite:
        out.append("--overwrite")
    return out


# ----------------------------------------------------------------------------- summary
def summarize(args) -> int:
    import pandas as pd

    rows = []
    for job in find_jobs(args):
        root = Path(job["root"])
        v1_path = root / "robust_eval" / f"{job['arm']}.json"
        strong_path = Path(job["out"])
        if not (v1_path.is_file() and strong_path.is_file()):
            continue
        v1 = json.loads(v1_path.read_text(encoding="utf-8"))
        strong = json.loads(strong_path.read_text(encoding="utf-8"))
        row = {k: job[k] for k in ("source", "mode", "session", "seed", "arm")}
        row["short"] = SHORT.get(job["arm"], job["arm"])
        row["clean_r2"] = v1["clean_r2"]
        for metric, key in (("reference", "ref"), ("isotropic", "iso")):
            row[f"{key}_half_v1"] = v1[metric]["eps_at_half_r2"]
            row[f"{key}_half_strong"] = strong[metric]["eps_at_half_r2"]
            row[f"{key}_r2_eps1_v1"] = _r2_at(v1[metric]["robust_r2"], 1.0)
            row[f"{key}_r2_eps1_strong"] = _r2_at(strong[metric]["robust_r2"], 1.0)
        rows.append(row)
    out_dir = args.results_dir / f"STRONG_EVAL_{args.tag}"
    out_dir.mkdir(parents=True, exist_ok=True)
    if not rows:
        print("No model has both evaluations yet.")
        return 0
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "strong_vs_v1.csv", index=False)

    lines = [f"STRONGER-ATTACK CHECK (steps={args.steps}, restarts={args.restarts}) - "
             f"{len(df)} models with both evaluations", "",
             "How to read: the half-damage thresholds drop under the stronger attack (it can only",
             "be stronger). Gradient masking would show as a larger drop for the noise-aware",
             "models than for PGD6, i.e. a paired ratio to PGD6 that shrinks from v1 to strong.", ""]
    by_arm = []
    for (mode, short), g in df.groupby(["mode", "short"]):
        by_arm.append({
            "mode": mode, "arm": short, "models": len(g),
            "ref_half_v1": g.ref_half_v1.mean(), "ref_half_strong": g.ref_half_strong.mean(),
            "ref_drop_median": float(np.median(g.ref_half_strong / g.ref_half_v1)),
            "iso_half_v1": g.iso_half_v1.mean(), "iso_half_strong": g.iso_half_strong.mean(),
            "iso_drop_median": float(np.median(g.iso_half_strong / g.iso_half_v1)),
            "clipped_v1": int((g.ref_half_v1 <= CLIPPED).sum()),
            "clipped_strong": int((g.ref_half_strong <= CLIPPED).sum()),
        })
    by_arm = pd.DataFrame(by_arm)
    by_arm.to_csv(out_dir / "summary_by_arm.csv", index=False)
    lines += ["Per arm: mean half-damage thresholds and median ratio strong / v1", by_arm.round(3).to_string(index=False), ""]

    paired = []
    base = df[df.short == "PGD6"].set_index(["mode", "session", "seed"])
    base = base[~base.index.duplicated(keep="first")]
    for (mode, short), g in df[df.short != "PGD6"].groupby(["mode", "short"]):
        key = list(zip(g["mode"], g.session, g.seed))
        b = base.reindex(key)
        ok = b.ref_half_v1.notna().values
        if not ok.any():
            continue
        g, b = g[ok], b[ok]
        entry = {"mode": mode, "arm": short, "pairs": int(ok.sum())}
        for key_, name in (("ref", "reference"), ("iso", "isotropic")):
            for version in ("v1", "strong"):
                ratio = g[f"{key_}_half_{version}"].values / b[f"{key_}_half_{version}"].values
                logs = pd.Series(np.log(ratio), index=g.session.values).groupby(level=0).mean()
                entry[f"{key_}_ratio_{version}"] = float(np.exp(logs.mean()))
                entry[f"{key_}_sessions_won_{version}"] = f"{int((logs > 0).sum())}/{len(logs)}"
        paired.append(entry)
    paired = pd.DataFrame(paired)
    paired.to_csv(out_dir / "paired_vs_pgd6.csv", index=False)
    lines += ["Paired with PGD6 (same mode, session, seed): geometric-mean ratio of the half-damage "
              "thresholds over sessions, and sessions won, under the original (v1) and the strong "
              "attack", paired.round(3).to_string(index=False) if len(paired)
              else "(no PGD6 model with both evaluations yet)"]
    text = "\n".join(lines) + "\n"
    (out_dir / "SUMMARY.txt").write_text(text, encoding="utf-8")
    print(text)
    return 0


def _r2_at(curve, eps: float) -> Optional[float]:
    for point in curve:
        if math.isclose(float(point["epsilon"]), eps):
            return float(point["r2"])
    return None


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--results-dir", type=Path, default=Path("."),
                   help="Folder holding DPRIME_EXP5, DPRIME_EXP6, DPRIME_SUPERVISED_PERICH_EXP8 "
                        "and the DPRIME_EXP9_AUTOSIG_* folders")
    p.add_argument("--data-dir", type=Path, default=runner.DEFAULT_DATA_DIR)
    p.add_argument("--fork-dir", type=Path, default=runner.DEFAULT_FORK_DIR)
    p.add_argument("--sources", nargs="+", choices=tuple(SOURCES), default=None)
    p.add_argument("--sessions", nargs="+", default=list(SESSIONS))
    p.add_argument("--seeds", nargs="+", type=int, default=None)
    p.add_argument("--arms", nargs="+", default=None, help="Override the default arms of every source")
    p.add_argument("--steps", type=int, default=100, help="APGD steps per budget (v1: 20)")
    p.add_argument("--restarts", type=int, default=3, help="Restarts per budget (v1: 1)")
    p.add_argument("--tag", default="strong", help="Output suffix: robust_eval_<tag>/")
    p.add_argument("--eval-batch-size", type=int, default=512)
    p.add_argument("--eval-epsilons", nargs="+", type=float, default=[0.5, 1.0, 2.0, 4.0, 8.0, 16.0],
                   help="Used only when a model has no v1 evaluation to copy the budgets from")
    p.add_argument("--gpu-workers", type=int, default=4)
    p.add_argument("--cpu-threads", type=int, default=2)
    p.add_argument("--overwrite", action="store_true", help="Re-evaluate finished models")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--summarize-only", action="store_true")
    p.add_argument("--_worker", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--_shard", default="0/1", help=argparse.SUPPRESS)
    return p


def main() -> int:
    args = build_parser().parse_args()
    if args.steps < 1 or args.restarts < 1:
        raise ValueError("--steps and --restarts must be >= 1")
    if not args.tag.replace("_", "").replace("-", "").isalnum() or args.tag == "v1":
        raise ValueError("--tag must be a short alphanumeric label other than v1")
    if args._worker:
        return worker(args)
    if args.dry_run:
        jobs = find_jobs(args)
        done = sum(Path(job["out"]).is_file() for job in jobs)
        counts: Dict[Tuple[str, str], int] = {}
        for job in jobs:
            counts[(job["source"], job["arm"])] = counts.get((job["source"], job["arm"]), 0) + 1
        for (source, arm), n in sorted(counts.items()):
            print(f"{source:32s} {arm:24s} {n:3d} models")
        print(f"{len(jobs)} models, {done} already evaluated with tag {args.tag!r}")
        return 0
    if args.summarize_only:
        return summarize(args)
    return orchestrate(args)


if __name__ == "__main__":
    raise SystemExit(main())
