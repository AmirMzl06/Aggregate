"""Tests of cebra.dprime.attacks (d′-PGD, APGD, DDN, L∞ PGD)."""

import math

import pytest
import torch

from cebra.dprime import attacks

B, C, T = 48, 5, 12


class ToyColoring:
    """δ = A z over channels, z of shape (B, C, T), d′ = ‖z‖."""

    def __init__(self, a):
        self.a = a

    def init_z(self, x0):
        return torch.zeros_like(x0)

    def color(self, z):
        return torch.einsum("ij,bjt->bit", self.a, z)

    def dprime(self, z):
        return z.flatten(1).norm(dim=1)

    def random_z(self, x0, radius, generator=None):
        z = torch.randn(x0.shape, generator=generator)
        radius = torch.as_tensor(radius, dtype=z.dtype).reshape(-1, 1, 1)
        return z / z.flatten(1).norm(dim=1).view(-1, 1, 1) * radius


@pytest.fixture()
def problem():
    torch.manual_seed(0)
    a = torch.randn(C, C) + 3 * torch.eye(C)
    x0 = torch.randn(B, C, T)
    w = torch.randn(C, T)
    return ToyColoring(a), x0, w, torch.einsum("ij,it->jt", a, w).norm()


@pytest.mark.parametrize("optimizer", ["apgd", "pgd"])
def test_linear_loss_reaches_analytic_optimum(problem, optimizer):
    coloring, x0, w, scale = problem
    loss = lambda x: (x * w).flatten(1).sum(1)
    eps = torch.rand(B) * 2
    eps[:4] = 0.0
    x_adv, info = attacks.dprime_pgd(loss, x0, coloring, eps, steps=20, optimizer=optimizer)
    gain = loss(x_adv) - loss(x0)
    # max over ‖z‖ ≤ ε of w·(A z) = ε ‖Aᵀ w‖
    assert torch.allclose(gain[4:], eps[4:] * scale, rtol=1e-3)
    assert bool((info["dprime"] <= eps + 1e-5).all())
    assert torch.equal(x_adv[:4], x0[:4])
    assert bool(info["accepted"].all())


def test_restarts_never_decrease_the_loss(problem):
    coloring, x0, w, _ = problem
    loss = lambda x: torch.sin((x * w).flatten(1).sum(1))  # non-convex
    one, _ = attacks.dprime_pgd(loss, x0, coloring, 1.0, steps=5, restarts=1)
    three, _ = attacks.dprime_pgd(loss, x0, coloring, 1.0, steps=5, restarts=3,
                                  generator=torch.Generator().manual_seed(0))
    assert bool((loss(three) >= loss(one) - 1e-6).all())


class BoxGuard:
    """Rejects perturbations with ‖δ‖∞ > t; penalty = relu(‖δ‖∞ − t)²."""

    def __init__(self, t):
        self.t = t

    def check(self, x0, x_adv):
        ok = (x_adv - x0).abs().flatten(1).amax(1) <= self.t
        return ok, {"box": ok}

    def soft_penalty(self, x0, x_adv):
        return torch.relu((x_adv - x0).abs().flatten(1).amax(1) - self.t)**2


def test_backtracking_keeps_guards_and_final_reject(problem):
    coloring, x0, w, _ = problem
    loss = lambda x: (x * w).flatten(1).sum(1)
    guard = BoxGuard(0.05)
    x_adv, info = attacks.dprime_pgd(loss, x0, coloring, 2.0, steps=10, guards=guard,
                                     guard_mode="backtrack", max_backtrack=4)
    accepted = info["accepted"]
    assert bool(guard.check(x0[accepted], x_adv[accepted])[0].all())
    assert torch.equal(x_adv[~accepted], x0[~accepted])
    # "final": no backtracking, so with a large budget every sample is rejected -> x0.
    x_final, info_final = attacks.dprime_pgd(loss, x0, coloring, 2.0, steps=10, guards=guard,
                                             guard_mode="final")
    assert not bool(info_final["accepted"].any())
    assert torch.equal(x_final, x0)
    assert info_final["guard_failures"]["box"] == B


def test_soft_penalty_reduces_violation(problem):
    coloring, x0, w, _ = problem
    loss = lambda x: (x * w).flatten(1).sum(1)
    guard = BoxGuard(0.05)
    plain, _ = attacks.dprime_pgd(loss, x0, coloring, 2.0, steps=20, guards=guard,
                                  guard_mode="off")
    soft, _ = attacks.dprime_pgd(loss, x0, coloring, 2.0, steps=20, guards=guard,
                                 guard_mode="off", soft_penalty_weight=1e4)
    assert float(guard.soft_penalty(x0, soft).mean()) < float(guard.soft_penalty(x0, plain).mean())


def test_ddn_recovers_linear_boundary_distance(problem):
    coloring, x0, w, scale = problem
    margin = torch.rand(B) * 2 + 0.2
    b = -(x0 * w).flatten(1).sum(1) - margin * scale
    b[:3] += 10 * scale  # these three start on the adversarial side
    score = lambda x: (x * w).flatten(1).sum(1) + b
    distance, success = attacks.min_norm_ddn(lambda x: score(x) > 0, score, x0, coloring,
                                             steps=200, init_epsilon=1.0)
    assert bool(success.all())
    assert torch.all(distance[:3] == 0)
    assert torch.allclose(distance[3:], margin[3:], rtol=0.05)


def test_ddn_scale_free_search_reaches_far_boundaries(problem):
    # Margins of 20-40 d′: with the image-style absolute step the norm can only grow by
    # 1.05 per step and the direction barely turns, so many windows are "never broken";
    # relative steps with a fast initial growth find the boundary.
    coloring, x0, w, scale = problem
    margin = torch.rand(B) * 20 + 20
    b = -(x0 * w).flatten(1).sum(1) - margin * scale
    score = lambda x: (x * w).flatten(1).sum(1) + b
    plain, _ = attacks.min_norm_ddn(lambda x: score(x) > 0, score, x0, coloring, steps=60,
                                    init_epsilon=1.0)
    scale_free, success = attacks.min_norm_ddn(lambda x: score(x) > 0, score, x0, coloring,
                                               steps=60, init_epsilon=1.0, relative_step=True,
                                               growth=0.3)
    assert not bool(torch.isfinite(plain).any())
    assert bool(success.all())
    assert torch.allclose(scale_free, margin, rtol=0.05)


def test_warm_start_and_returned_z(problem):
    coloring, x0, w, scale = problem
    loss = lambda x: (x * w).flatten(1).sum(1)
    _, small = attacks.dprime_pgd(loss, x0, coloring, 1.0, steps=10)
    assert torch.allclose(coloring.dprime(small["z"]), small["dprime"])
    # From the optimum of a smaller ball, zero steps keep that point (projected, feasible).
    x_adv, warm = attacks.dprime_pgd(loss, x0, coloring, 2.0, steps=0, z_init=small["z"])
    assert torch.allclose(x_adv, x0 + coloring.color(small["z"]), atol=1e-5)
    assert torch.allclose(warm["loss_start"], loss(x_adv), atol=1e-4)
    _, shrunk = attacks.dprime_pgd(loss, x0, coloring, 0.5, steps=0, z_init=small["z"])
    assert bool((shrunk["dprime"] <= 0.5 + 1e-5).all())


def test_linf_pgd_box(problem):
    _, x0, w, _ = problem
    loss = lambda x: (x * w).flatten(1).sum(1)
    x_adv = attacks.linf_pgd(loss, x0, 0.3, steps=5)
    assert bool(((x_adv - x0).abs() <= 0.3 + 1e-6).all())
    # The sign of w is the optimal L∞ direction: the box corner is reached.
    assert torch.allclose(loss(x_adv) - loss(x0), torch.full((B,), 0.3 * float(w.abs().sum())),
                          rtol=1e-3)


def test_apgd_checkpoints_schedule():
    assert attacks.apgd_checkpoints(100) == [22, 41, 58, 70, 80, 87, 93, 99]
    assert all(0 < w <= 10 for w in attacks.apgd_checkpoints(10))
