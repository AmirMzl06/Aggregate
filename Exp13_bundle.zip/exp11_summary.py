#!/usr/bin/env python3
"""Exp11 summary: the frozen rules on 20 unseen Perich sessions, and the pre-registered test.

Keep next to dprime_exp9.py. Reads <root>/summary.csv (or summary_<tag>.csv) and
<root>/PREDICTIONS.csv of the two new-session suites and prints:
  1  per arm: runs, failures, median clean R2 and eps1/2 (reference metric), and the paired
     comparison with PGD_L2_EPS6 (same session and seed): wins and the median ratio;
  2  the pre-registered test: accuracy of predicted_broken (x_beh >= the Exp10b boundary) for
     the decoder failures (eps1/2 at the smallest evaluation budget), and the AUCs of x_beh,
     x_sig and the nominal budget on the new sessions;
  3  the failure rate in bins of x_beh, and the sessions where a prediction was wrong.
The merged table (one row per run, with its prediction) is written to <root>/EXP11_RUNS.csv.

    python exp11_summary.py                       # both suites, default folders
    python exp11_summary.py --sup PATH --time PATH --tag v1 > exp11_report.txt
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
CLIPPED_HALF = 0.5 + 1e-6  # eps1/2 at the smallest evaluation budget: broken already at d' = 0.5
BASELINE = "PGD_L2_EPS6"
SHORT = {"PGD_L2_EPS6": "PGD6", "MADRY_SPDIFF_D8": "DIFF8", "MADRY_SP_D8": "SP8",
         "MADRY_SP_AUTOSIG": "SP_AUTOSIG", "MADRY_SPDIFF_AUTOSIG": "DIFF_AUTOSIG",
         "MADRY_SP_AUTOSIG_POOL": "POOL_AUTOSIG", "MADRY_SPDIFF_AUTOBEH": "DIFF_AUTOBEH",
         "MADRY_SP_AUTOBEH": "SP_AUTOBEH", "MADRY_SP_AUTOBEH_POOL": "POOL_AUTOBEH",
         "MADRY_SPREG_AUTOBEH": "REG_AUTOBEH"}


def auc(negative: np.ndarray, positive: np.ndarray) -> float:
    """P(positive > negative) + 0.5 P(tie) (Mann-Whitney)."""
    if len(negative) == 0 or len(positive) == 0:
        return float("nan")
    values = np.concatenate([negative, positive])
    ranks = pd.Series(values).rank().to_numpy()
    rank_sum = ranks[len(negative):].sum()
    return float((rank_sum - len(positive) * (len(positive) + 1) / 2)
                 / (len(negative) * len(positive)))


def load(root: Path, tag: str, censor_at: float) -> pd.DataFrame:
    name = "summary.csv" if tag == "v1" else f"summary_{tag}.csv"
    runs = pd.read_csv(root / name)
    predictions = pd.read_csv(root / "PREDICTIONS.csv")
    predictions = predictions.rename(columns={"arm": "experiment"})
    keep = ["session", "experiment", "neurons", "n_train", "behaviour_r2", "eps_beh", "budget",
            "x_sig", "x_beh", "predicted_broken"]
    runs = runs.drop(columns=[c for c in ("eps_beh",) if c in runs.columns])
    runs = runs.merge(predictions[keep], on=["session", "experiment"], how="left")
    runs["ok"] = runs.status == "success"
    # No eps1/2 on the evaluation grid: still above half the clean R2 at the largest budget.
    runs["censored"] = runs.ok & runs.ref_half.isna()
    runs.loc[runs.censored, "ref_half"] = censor_at
    runs["broken"] = runs.ref_half.astype(float) <= CLIPPED_HALF
    runs["short"] = runs.experiment.map(SHORT).fillna(runs.experiment)
    runs.to_csv(root / "EXP11_RUNS.csv", index=False)
    return runs


def arm_table(runs: pd.DataFrame) -> pd.DataFrame:
    ok = runs[runs.ok]
    base = ok[ok.experiment == BASELINE].set_index(["session", "seed"])
    rows = []
    for arm, d in ok.groupby("experiment", sort=False):
        row = {"arm": SHORT.get(arm, arm), "runs": len(d),
               "errors": int((~runs[runs.experiment == arm].ok).sum()),
               "broken": int(d.broken.sum()), "censored": int(d.censored.sum()),
               "sessions_broken": int(d.groupby("session").broken.any().sum()),
               "r2_med": d.r2.median(), "half_med": d.ref_half.median(),
               "budget_med": d.budget.median()}
        if arm != BASELINE and len(base):
            paired = d.set_index(["session", "seed"]).join(base[["ref_half", "r2"]],
                                                           rsuffix="_pgd", how="inner")
            ratio = paired.ref_half / paired.ref_half_pgd
            row.update(pairs=len(paired), wins=int((ratio > 1).sum()),
                       ratio_med=ratio.median(),
                       ratio_gmean=float(np.exp(np.log(ratio).mean())) if len(ratio) else np.nan,
                       r2_minus_pgd=(paired.r2 - paired.r2_pgd).median())
        rows.append(row)
    return pd.DataFrame(rows)


def prediction_test(runs: pd.DataFrame, mode: str) -> str:
    d = runs[runs.ok & runs.x_beh.notna()].copy()
    if d.empty:
        return "  (no runs with a pre-registered x_beh)"
    lines = []
    predicted = d.predicted_broken.astype(str).str.lower() == "true"
    observed = d.broken.to_numpy()
    tp = int((predicted & observed).sum())
    fp = int((predicted & ~observed).sum())
    fn = int((~predicted & observed).sum())
    tn = int((~predicted & ~observed).sum())
    lines.append(f"  runs {len(d)}: broken {int(observed.sum())}; predicted broken "
                 f"{int(predicted.sum())}")
    lines.append(f"  confusion (pred/obs): TP {tp}  FP {fp}  FN {fn}  TN {tn}  "
                 f"accuracy {(tp + tn) / len(d):.3f}")
    nominal = d.budget.astype(float)
    for name, values in (("x_beh", d.x_beh), ("x_sig", d.x_sig), ("budget (nominal)", nominal)):
        v = values.astype(float).to_numpy()
        lines.append(f"  AUC {name:16s} {auc(v[~observed], v[observed]):.3f}")
    bins = [0, 0.3, 0.4, 0.5, 0.6, 0.8, math.inf]
    d["x_bin"] = pd.cut(d.x_beh.astype(float), bins, right=False)
    table = d.groupby("x_bin", observed=True).broken.agg(["count", "sum"])
    lines.append("  failures by x_beh bin: " + "; ".join(
        f"{interval}: {int(r['sum'])}/{int(r['count'])}" for interval, r in table.iterrows()))
    wrong = d[predicted != observed]
    if len(wrong):
        lines.append("  wrong predictions (session arm seed x_beh ref_half):")
        for _, r in wrong.sort_values(["session", "experiment", "seed"]).iterrows():
            lines.append(f"    {r.session:8s} {r.short:13s} {int(r.seed)} x_beh={r.x_beh:.3f} "
                         f"ref_half={r.ref_half:.3f}")
    return "\n".join(lines)


def session_table(runs: pd.DataFrame) -> pd.DataFrame:
    ok = runs[runs.ok]
    first = ok.groupby("session")[["neurons", "n_train", "behaviour_r2"]].first()
    half = ok.pivot_table(index="session", columns="short", values="ref_half", aggfunc="median")
    return first.join(half).round(3)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--sup", type=Path, default=ROOT / "DPRIME_EXP11_NEWSESS_SUPERVISED")
    p.add_argument("--time", type=Path, default=ROOT / "DPRIME_EXP11_NEWSESS_TIMEONLY")
    p.add_argument("--tag", default="v1")
    p.add_argument("--censor-at", type=float, default=16.0,
                   help="eps1/2 of runs that never fall to half R2 (the largest evaluation budget)")
    args = p.parse_args()
    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 30)
    pd.set_option("display.max_rows", 200)
    for mode, root in (("supervised", args.sup), ("time_only", args.time)):
        print(f"\n===== {mode}: {root}")
        if not (root / "PREDICTIONS.csv").is_file():
            print("  missing (no PREDICTIONS.csv)")
            continue
        runs = load(root, args.tag, args.censor_at)
        print(f"sessions {runs.session.nunique()}, seeds {sorted(runs.seed.unique())}, runs "
              f"{len(runs)} ({int((~runs.ok).sum())} errors)")
        print("\n1  arms (ref_half = eps1/2 in the reference metric; ratio/wins: paired with PGD6)")
        print(arm_table(runs).round(3).to_string(index=False))
        print("\n2/3  pre-registered failure prediction (x_beh >= boundary)")
        print(prediction_test(runs, mode))
        print("\n4  median ref_half per session")
        print(session_table(runs).to_string())
        errors = runs[~runs.ok]
        if len(errors):
            print("\nerrors:")
            for _, r in errors.iterrows():
                print(f"  {r.session} {r.experiment} {r.seed}: {str(r.error)[:160]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
