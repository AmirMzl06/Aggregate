#!/usr/bin/env python3
"""Structure of the candidate external datasets (no training, read-only; nothing is unpickled).

Finds folders whose name matches a known dataset (Area2_Bump, Allen VBN, RatInABox, hippocampus,
NLB, DANDI ...) under the given roots (default /data/hossein), lists their files by type and
prints the arrays of one example file per type (npz keys, NWB/HDF5 datasets, MAT variables, CSV
header). Paste the output into result.txt so the loaders can be written for the real files.

    python inspect_datasets.py /data/hossein ~
"""
import os, sys, glob
KEYS = ("area2", "allen", "vbn", "ratinabox", "hippocamp", "achilles", "buzsaki", "nlb", "rtt", "maze",
        "dandi", "odoherty", "sabes", "neuropixel", "000127", "000128", "000129", "000130", "000138")
roots = sys.argv[1:] or ["/data/hossein"]
def show_file(path):
    ext = path.lower().rsplit(".", 1)[-1]
    try:
        if ext == "npz":
            import numpy as np
            with np.load(path, allow_pickle=False) as f:
                for k in f.files:
                    print(f"        {k}: {f[k].shape} {f[k].dtype}")
        elif ext in ("nwb", "h5", "hdf5"):
            import h5py
            with h5py.File(path, "r") as f:
                shown = []
                def visit(name, obj):
                    if len(shown) < 60 and name.count("/") <= 3 and isinstance(obj, h5py.Dataset):
                        shown.append(name)
                        print(f"        {name}: {obj.shape} {obj.dtype}")
                f.visititems(visit)
        elif ext == "mat":
            import scipy.io
            for name, shape, kind in scipy.io.whosmat(path):
                print(f"        {name}: {shape} {kind}")
        elif ext in ("csv", "tsv", "txt"):
            with open(path, errors="replace") as f:
                print("        " + f.readline().strip()[:200])
    except Exception as exc:
        print(f"        (could not read: {type(exc).__name__}: {exc})")
for root in roots:
    for dirpath, dirnames, filenames in os.walk(root):
        if dirpath[len(root):].count(os.sep) >= 4:
            dirnames[:] = []
        if not any(k in os.path.basename(dirpath).lower() for k in KEYS):
            continue
        files = sorted(glob.glob(os.path.join(dirpath, "**", "*"), recursive=True))
        files = [f for f in files if os.path.isfile(f)]
        size = sum(os.path.getsize(f) for f in files) / 1e9
        print(f"\n{dirpath}  ({len(files)} files, {size:.2f} GB)")
        exts = {}
        for f in files:
            exts.setdefault(f.rsplit(".", 1)[-1].lower() if "." in os.path.basename(f) else "-", []).append(f)
        for ext, group in sorted(exts.items()):
            print(f"    .{ext}: {len(group)} files, e.g. {os.path.relpath(group[0], dirpath)}")
            if ext in ("npz", "nwb", "h5", "hdf5", "mat", "csv"):
                show_file(group[0])
        dirnames[:] = []  # one report per matched folder
