#!/usr/bin/env python3
"""Exp10b: is the supervised training budget referenced to the behavioural signal? (no training)

Exp9: AUTO_SIG, eps = min((2D)^(1/4), 0.24 * eps_sig), rescued behaviour-supervised SP in four of
the five sessions where SP8 broke, but not M-RT3 (budget 8.24, still broken). In the same session
SP_AUTO is robust in time-only CEBRA, and REG8 / REG_AUTO (behaviour-linear variance removed from
the metric) are robust in supervised CEBRA. Hypothesis: a time-contrastive encoder keeps all the
slow structure of the activity, so eps_sig (all slow signal) is its scale; a behaviour-supervised
encoder keeps the BEHAVIOURAL signal, whose separation eps_beh can be much smaller than eps_sig when
much of the slow activity is not behavioural. Then, in supervised CEBRA,
x_beh = eps_train / eps_beh(M_train) should separate the broken runs (SP8 in five sessions, SP_AUTO
in M-RT3, REG8 in four) from the robust ones better than x_sig = eps_train / eps_sig, and M-RT3
should have an unusually small eps_beh / eps_sig.

    eps_beh(M)^2 = 2 sum_ij (Sigma_t^-1)_ij g_|i-j|,
    g_k = tr(Sigma_s^-1 sym Cov(xhat_{t+k}, x_t)),

with xhat the activity predicted from the behaviour around t (lags -8..8 bins), by ridge regression
on the behaviour (linear) and on the behaviour plus random Fourier features of it (nonlinear),
cross-fitted over five contiguous blocks. The cross-covariance of the held-out prediction with the
observed activity is free of the noise (the noise of a block is independent of its prediction), so
eps_beh is not inflated by noise; an imperfect prediction makes it conservative (smaller).

Runs read (v1 evaluations and training reports): DPRIME_SUPERVISED_PERICH_EXP8,
DPRIME_EXP9_AUTOSIG_SUPERVISED (supervised), DPRIME_EXP5, DPRIME_EXP6, DPRIME_EXP9_AUTOSIG_TIMEONLY
(time-only, the contrast: there eps_sig should do at least as well). CLEAN and the projected
SP8_SIGPROJ attack are excluded. The noise models are the fork's own (Acorn-dprime noise.py).

Usage (CPU, a few minutes; keep next to signal_budget_tests.py and the fork):
    python behaviour_budget_tests.py --results-dir . \
        --data-dir /data/hossein/mm_project/perich_data_valid_final_raw \
        --fork-dir ./Acorn-dprime --out-dir ./BEHAVIOUR_BUDGET_TESTS
Outputs: session_behaviour.csv, runs_behaviour.csv, tests_behaviour.csv, SUMMARY_BEH.txt.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import warnings
from pathlib import Path
from typing import Dict, Sequence, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))

import signal_budget_tests as sbt  # sets the BLAS thread defaults before numpy

import numpy as np
import pandas as pd

SOURCES = (("DPRIME_SUPERVISED_PERICH_EXP8", "supervised"),
           ("DPRIME_EXP9_AUTOSIG_SUPERVISED", "supervised"),
           ("DPRIME_EXP5", "time_only"), ("DPRIME_EXP6", "time_only"),
           ("DPRIME_EXP9_AUTOSIG_TIMEONLY", "time_only"))
SHORT = {**sbt.SHORT, "MADRY_SP_D8_POOL": "POOL8", "MADRY_SPDIFF_AUTOSIG": "DIFF_AUTO",
         "MADRY_SP_AUTOSIG": "SP_AUTO", "MADRY_SPREG_AUTOSIG": "REG_AUTO",
         "MADRY_SP_AUTOSIG_POOL": "POOL_AUTO", "MADRY_SP_D8_SIGPROJ": "SP8_SIGPROJ"}
EXCLUDED = {"CLEAN", "MADRY_SP_D8_SIGPROJ"}
REFERENCES = ("sig", "beh_lin", "beh_nl")
PREDICTORS = ("x_nominal", "x_blind", "x_sig", "x_beh_lin", "x_beh_nl")


# ----------------------------------------------------------------------------- behaviour model
def lag_embed(y: np.ndarray, lags: Sequence[int]) -> np.ndarray:
    """Standardised behaviour at t + lag for every lag (edges repeated)."""
    z = (y - y.mean(axis=0)) / np.where(y.std(axis=0) > 0, y.std(axis=0), 1.0)
    index = np.arange(len(z))
    return np.concatenate([z[np.clip(index + lag, 0, len(z) - 1)] for lag in lags], axis=1)


def fourier_features(features: np.ndarray, count: int, rng: np.random.Generator) -> np.ndarray:
    """Random Fourier features of a Gaussian kernel (median-distance bandwidth)."""
    sample = features[rng.choice(len(features), min(1500, len(features)), replace=False)]
    squared = (sample**2).sum(axis=1)
    distances = np.sqrt(np.maximum(squared[:, None] + squared[None, :] - 2 * sample @ sample.T, 0))
    bandwidth = max(float(np.median(distances[np.triu_indices(len(sample), 1)])), 1e-6)
    omega = rng.normal(size=(features.shape[1], count)) / bandwidth
    phase = rng.uniform(0, 2 * np.pi, count)
    return np.sqrt(2.0 / count) * np.cos(features @ omega + phase)


def cross_fitted(features: np.ndarray, x: np.ndarray, folds: int,
                 alphas: Sequence[float]) -> Tuple[np.ndarray, float, float]:
    """Held-out ridge predictions of x from the features over contiguous blocks.

    The ridge penalty alpha * mean diag(F'F) is chosen from ``alphas`` by the pooled held-out R2.
    Returns (prediction, R2, alpha).
    """
    edges = np.linspace(0, len(x), folds + 1).astype(int)
    best = (-np.inf, None, None)
    sst = float(((x - x.mean(axis=0))**2).sum())
    for alpha in alphas:
        prediction = np.empty_like(x)
        for start, stop in zip(edges[:-1], edges[1:]):
            train = np.ones(len(x), dtype=bool)
            train[start:stop] = False
            f_mean, x_mean = features[train].mean(axis=0), x[train].mean(axis=0)
            f = features[train] - f_mean
            gram = f.T @ f
            ridge = alpha * float(np.trace(gram)) / gram.shape[0]
            beta = np.linalg.solve(gram + ridge * np.eye(gram.shape[0]), f.T @ (x[train] - x_mean))
            prediction[start:stop] = (features[start:stop] - f_mean) @ beta + x_mean
        r2 = 1.0 - float(((x - prediction)**2).sum()) / sst
        if r2 > best[0]:
            best = (r2, prediction, alpha)
    return best[1], best[0], best[2]


def behaviour_traces(x: np.ndarray, prediction: np.ndarray, spatial_cov: np.ndarray,
                     max_lag: int) -> np.ndarray:
    """g_k = tr(Sigma_s^-1 sym Cov(xhat_{t+k}, x_t)), k = 0..max_lag."""
    root = sbt.inverse_sqrt(spatial_cov)
    w = (x - x.mean(axis=0)) @ root
    v = (prediction - prediction.mean(axis=0)) @ root
    n = len(w)
    return np.array([0.5 * (np.einsum("ij,ij->", v[k:], w[:n - k])
                            + np.einsum("ij,ij->", w[k:], v[:n - k])) / (n - k)
                     for k in range(max_lag + 1)])


def separation(traces: np.ndarray, temporal_cov: np.ndarray) -> float:
    """sqrt(2 sum_ij (Sigma_t^-1)_ij g_|i-j|) (NaN if not positive)."""
    window_len = len(temporal_cov)
    lags = np.abs(np.subtract.outer(np.arange(window_len), np.arange(window_len)))
    value = 2.0 * float(np.sum(np.linalg.inv(temporal_cov) * traces[:window_len][lags]))
    return math.sqrt(value) if value > 0 else float("nan")


# ----------------------------------------------------------------------------- stage 1
def fit_metrics(noise, x: np.ndarray, y: np.ndarray, window_len: int):
    covs = {}
    for name, (residuals, estimator, temporal) in sbt.METRICS.items():
        labels = y if residuals == "regression" else None
        model, _ = noise.fit_noise_model(x, labels,
                                         label_kind="continuous" if labels is not None else None,
                                         window_len=window_len, residual_mode=residuals,
                                         spatial_estimator=estimator, temporal_method=temporal,
                                         kronecker_channels=0)
        covs[name] = (model.spatial_cov, model.temporal_cov)
    covs["raw"] = (np.eye(x.shape[1]), np.eye(window_len))
    return covs


def session_statistics(noise, x: np.ndarray, y: np.ndarray, args) -> Dict[str, float]:
    window_len = args.window_len
    rng = np.random.default_rng(args.seed)
    covs = fit_metrics(noise, x, y, window_len)
    features = lag_embed(y, args.lags)
    alphas = (1e-3, 1e-2, 1e-1, 1.0)
    predictions = {}
    predictions["beh_lin"], r2_lin, alpha_lin = cross_fitted(features, x, args.folds, alphas)
    rich = np.concatenate([features, fourier_features(features, args.rff, rng)], axis=1)
    predictions["beh_nl"], r2_nl, alpha_nl = cross_fitted(rich, x, args.folds, alphas)
    n_time, channels = x.shape
    dim = channels * window_len
    row = {"n_ch": channels, "n_time": n_time, "eps_blind_theory": (2.0 * dim)**0.25,
           "sigma_bar": math.sqrt(float(covs["iso"][0][0, 0])),
           "r2_activity_from_behaviour_lin": r2_lin, "r2_activity_from_behaviour_nl": r2_nl,
           "ridge_alpha_lin": alpha_lin, "ridge_alpha_nl": alpha_nl}
    centred = x - x.mean(axis=0)
    for name, (spatial, temporal) in covs.items():
        traces = sbt.lag_traces(centred @ sbt.inverse_sqrt(spatial), max(window_len - 1, 1))
        row[f"eps_sig_{name}"] = sbt.signal_separation(traces, temporal, 1)
        for ref in ("beh_lin", "beh_nl"):
            traces = behaviour_traces(x, predictions[ref], spatial, window_len - 1)
            row[f"eps_{ref}_{name}"] = separation(traces, temporal)
            row[f"ratio_{ref}_{name}"] = row[f"eps_{ref}_{name}"] / row[f"eps_sig_{name}"]
    return row


def stage1(args, noise) -> pd.DataFrame:
    rows = []
    for session in args.sessions:
        if not (args.data_dir / f"{session}.npz").is_file():
            warnings.warn(f"{session}: no data file; skipped.")
            continue
        x, y, _ = sbt.load_session(args.data_dir, session)
        row = session_statistics(noise, x, y, args)
        row["session"] = session
        rows.append(row)
        print(f"{session}: eps_sig sp {row['eps_sig_sp']:.2f}  eps_beh sp lin "
              f"{row['eps_beh_lin_sp']:.2f} nl {row['eps_beh_nl_sp']:.2f} "
              f"(ratio nl {row['ratio_beh_nl_sp']:.2f}; R2 x|y nl {row['r2_activity_from_behaviour_nl']:.3f})",
              flush=True)
    table = pd.DataFrame(rows).set_index("session")
    table.to_csv(args.out_dir / "session_behaviour.csv")
    return table


# ----------------------------------------------------------------------------- stage 2
def parse_runs(results_dir: Path, sessions: Sequence[str]) -> pd.DataFrame:
    rows = []
    for source, mode in SOURCES:
        for session in sessions:
            for seed_dir in sorted((results_dir / source / session).glob("seed*")):
                for path in sorted((seed_dir / "robust_eval").glob("*.json")):
                    arm = path.stem
                    if arm in EXCLUDED:
                        continue
                    evaluation = json.loads(path.read_text())
                    row = {"mode": mode, "source": source, "session": session,
                           "seed": int(seed_dir.name[4:]), "arm": arm, "short": SHORT.get(arm, arm),
                           "clean_r2": evaluation["clean_r2"],
                           "ref_half": evaluation["reference"]["eps_at_half_r2"],
                           "iso_half": evaluation["isotropic"]["eps_at_half_r2"]}
                    row.update(sbt.training_info(seed_dir / "reports" / f"{arm}.json", arm))
                    row["pool_budgets"] = None
                    report_path = seed_dir / "reports" / f"{arm}.json"
                    if row.get("metric") == "pool" and report_path.is_file():
                        report = json.loads(report_path.read_text())
                        pool = (report.get("epsilon") or {}).get("pool")
                        budgets = ([m["budget"] for m in pool] if pool
                                   else [row["eps_train"], row["eps_train"]])
                        row["pool_budgets"] = json.dumps(budgets)
                    rows.append(row)
    runs = pd.DataFrame(rows)
    if runs.empty:
        raise FileNotFoundError(f"No evaluated runs under {results_dir}")
    duplicated = runs.duplicated(["mode", "session", "seed", "arm"], keep=False)
    if duplicated.any():
        raise ValueError("Duplicate runs:\n" + runs[duplicated].to_string())
    for column in ("loss_gain",):
        if column not in runs:
            runs[column] = np.nan
    return runs


def add_predictors(runs: pd.DataFrame, sig: pd.DataFrame) -> pd.DataFrame:
    runs = runs[runs.session.isin(sig.index) & runs.metric.notna()].copy()
    runs = runs[runs.metric != "other"]
    out = {name: np.full(len(runs), np.nan) for name in PREDICTORS}
    for i, (_, run) in enumerate(runs.iterrows()):
        s = sig.loc[run.session]
        eps = float(run.eps_train)
        nominal = eps / s.sigma_bar if run.metric == "raw" else eps
        out["x_nominal"][i] = nominal
        out["x_blind"][i] = nominal / s.eps_blind_theory
        for ref in REFERENCES:
            if run.metric == "pool":
                b0, b1 = json.loads(run.pool_budgets)
                value = math.sqrt((b0 / s[f"eps_{ref}_sp"]) * (b1 / s[f"eps_{ref}_iso"]))
            else:
                value = eps / s[f"eps_{ref}_{run.metric}"]
            out[f"x_{ref}"][i] = value
    for name, values in out.items():
        runs[name] = values
    runs["failed_decoder"] = runs.ref_half <= sbt.CLIPPED_HALF
    gain = runs.loss_gain.astype(float)
    runs["failed_any"] = runs.failed_decoder | (gain >= sbt.SATURATED_GAIN).fillna(False)
    return runs


def tests(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    # Supervised training never saturates (loss gain < 2), so only the decoder outcome there.
    for mode, outcomes in (("supervised", ("failed_decoder",)),
                           ("time_only", ("failed_decoder", "failed_any"))):
        for outcome in outcomes:
            d = runs[runs["mode"] == mode]
            failed = d[outcome].astype(bool).values
            for predictor in PREDICTORS:
                v = d[predictor].values.astype(float)
                keep = np.isfinite(v) & (v > 0)
                c, j = sbt.youden(v[keep], failed[keep])
                accuracy, (lo, hi) = sbt.loso_threshold(v[keep], failed[keep], d.session.values[keep])
                rows.append({"mode": mode, "outcome": outcome, "predictor": predictor,
                             "n_runs": int(keep.sum()), "n_failed": int(failed[keep].sum()),
                             "auc": sbt.auc(failed[keep], v[keep]), "c_star": c,
                             "loso_accuracy": accuracy, "loso_c_min": lo, "loso_c_max": hi})
    return pd.DataFrame(rows)


def session_table(runs: pd.DataFrame, sig: pd.DataFrame) -> pd.DataFrame:
    sup = runs[runs["mode"] == "supervised"]
    table = sig[["eps_sig_sp", "eps_beh_lin_sp", "eps_beh_nl_sp", "ratio_beh_lin_sp",
                 "ratio_beh_nl_sp", "r2_activity_from_behaviour_nl"]].copy()
    for short in ("SP8", "SP_AUTO", "REG8", "REG_AUTO", "DIFF8", "DIFF_AUTO", "POOL8", "POOL_AUTO",
                  "PGD6"):
        g = sup[sup.short == short].groupby("session").failed_decoder.sum()
        table[f"broken_{short}"] = g.reindex(table.index).astype("Int64")  # <NA>: no runs
    auto = sup[sup.short == "SP_AUTO"].groupby("session")[["eps_train", "x_sig", "x_beh_nl"]].mean()
    table = table.join(auto.add_prefix("SP_AUTO_"))
    return table


def rule_preview(sig: pd.DataFrame) -> Tuple[float, pd.DataFrame]:
    """eps_beh rule calibrated like AUTO_SIG: x*_beh = mean over sessions of 8 / eps_beh_nl(diff)."""
    x_star = float(np.mean(8.0 / sig.eps_beh_nl_diff))
    preview = pd.DataFrame(index=sig.index)
    for metric in ("sp", "diff", "reg", "iso"):
        preview[f"{metric}_beh_rule"] = np.minimum(sig.eps_blind_theory,
                                                    x_star * sig[f"eps_beh_nl_{metric}"])
        preview[f"{metric}_sig_rule"] = np.minimum(sig.eps_blind_theory, 0.24 * sig[f"eps_sig_{metric}"])
    return x_star, preview


GUIDE = """How to read (the behaviour-referenced hypothesis is supported if):
  1  M-RT3 has the smallest (or an unusually small) eps_beh / eps_sig for the SP metric;
  2  in SUPERVISED CEBRA, x_beh (lin and/or nl) has a higher AUC and LOSO accuracy for the broken
     decoders than x_sig, and SP_AUTO in M-RT3 has a larger x_beh than SP_AUTO in the four sessions
     it rescued (C-RT6, T-RT4, J-CO0, T-RT1);
  3  in TIME-ONLY CEBRA, x_sig does at least as well as x_beh (the time-contrastive encoder keeps
     all slow structure);
  4  the eps_beh rule would give supervised SP in M-RT3 a budget well below 8.24, while the budgets
     of the rescued sessions stay near the ones that worked (3.7-5.8).
"""


def write_summary(path: Path, sig, test_table, sessions, x_star, preview) -> None:
    out = ["BEHAVIOUR-REFERENCED TRAINING BUDGET - RETROSPECTIVE TEST (no training)", "", GUIDE,
           "Per session: signal separation (SP metric), behavioural part (lin / nl), and broken "
           "supervised decoders (out of 3 seeds) per arm",
           sessions.round(3).to_string(), "",
           "Rank of the eps_beh_nl / eps_sig ratio (SP metric), smallest first: "
           + ", ".join(sig.ratio_beh_nl_sp.sort_values().index), "",
           "Separation of the broken runs (AUC; c*: broken when x >= c*; LOSO accuracy)",
           test_table.round(3).to_string(index=False), "",
           f"Preview: eps_beh rule calibrated on DIFF8 like AUTO_SIG, x*_beh = {x_star:.3f}; budgets "
           "per session (min with (2D)^(1/4)) next to the AUTO_SIG ones",
           preview.round(2).to_string()]
    path.write_text("\n".join(out) + "\n")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--fork-dir", type=Path, default=Path("Acorn-dprime"))
    p.add_argument("--data-dir", type=Path, default=Path("/data/hossein/mm_project/perich_data_valid_final_raw"))
    p.add_argument("--results-dir", type=Path, default=Path("."))
    p.add_argument("--out-dir", type=Path, default=Path("BEHAVIOUR_BUDGET_TESTS"))
    p.add_argument("--sessions", nargs="+", default=list(sbt.SESSIONS))
    p.add_argument("--window-len", type=int, default=36)
    p.add_argument("--lags", nargs="+", type=int, default=[-8, -4, 0, 4, 8],
                   help="Behaviour lags (bins) of the encoding model")
    p.add_argument("--rff", type=int, default=400, help="Random Fourier features (nonlinear model)")
    p.add_argument("--folds", type=int, default=5)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--skip-stage1", action="store_true", help="Reuse <out-dir>/session_behaviour.csv")
    return p


def main() -> int:
    args = build_parser().parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    noise = sbt.load_noise_module(args.fork_dir)
    if args.skip_stage1:
        sig = pd.read_csv(args.out_dir / "session_behaviour.csv").set_index("session")
    else:
        sig = stage1(args, noise)
    runs = add_predictors(parse_runs(args.results_dir, args.sessions), sig)
    runs.to_csv(args.out_dir / "runs_behaviour.csv", index=False)
    test_table = tests(runs)
    test_table.to_csv(args.out_dir / "tests_behaviour.csv", index=False)
    sessions = session_table(runs, sig)
    sessions.to_csv(args.out_dir / "sessions_behaviour_outcomes.csv")
    x_star, preview = rule_preview(sig)
    preview.to_csv(args.out_dir / "rule_preview.csv")
    write_summary(args.out_dir / "SUMMARY_BEH.txt", sig, test_table, sessions, x_star, preview)
    print((args.out_dir / "SUMMARY_BEH.txt").read_text())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
