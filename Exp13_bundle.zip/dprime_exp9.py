#!/usr/bin/env python3
"""Exp9 / Exp11: robust-overfitting tests, signal- and behaviour-referenced budgets, new sessions.

Keep this runner NEXT TO the Acorn-dprime fork (not inside it). The protocol is the one of
Exp5/6b (time-only) and Exp8 (behaviour-supervised): same encoder, decoder, attacks and held-out
evaluation (reference = Ledoit-Wolf x Welch and isotropic metrics on label-free whole residuals).
Unlike the earlier runners, one call runs a whole suite: every (session, seed, arm) job is queued
across the GPU workers, and each (session, seed) gets its own folder
<output-root>/<SESSION>/seed<SEED>/ with the usual models/, reports/, robust_eval/, records/ ...

Suites (``--list`` shows them; every default can be overridden on the command line):
  e1            supervised; the five shortest recordings (J-CO0, C-RT6, M-RT3, T-RT4, T-RT1);
                iterations scaled to 340 epochs (round(340 * n_train / batch), as C-CO12/13 at
                3,000 iterations); arms MADRY_SP_D8 and PGD_L2_EPS6. Exp8 broke SP8 in exactly
                these sessions at 536-1,610 epochs. Prediction: no longer brittle.
  e2            supervised; C-CO12 truncated to its first 9,174 training bins (the size of M-RT3)
                at 3,000 iterations (670 epochs); SP8 and PGD6. Prediction: brittle.
  e2b           supervised; C-CO12 complete at 6,000 iterations (668 epochs); SP8 and PGD6.
                Together with e2: number of epochs versus amount of data.
  autosig-sup   supervised; nine sessions; 3,000 iterations (paired with Exp8); auto_sig arms
                MADRY_SPDIFF_AUTOSIG, MADRY_SP_AUTOSIG, MADRY_SPREG_AUTOSIG, MADRY_SP_AUTOSIG_POOL,
                and the mechanism test MADRY_SP_D8_SIGPROJ: SP8 (same metric and budget) with the
                attack restricted to nuisance directions (adv_dprime_signal_projection="jnd": the
                signal modes detectable within a window are projected out). E1/E2/E2b showed that
                SP8's supervised failure is a property of the session, not of the training length;
                if SIGPROJ is robust where SP8 broke, the cause is the direction of the training
                perturbations (along the behavioural signal), not their size.
  autosig-time  time-only; nine sessions; 3,000 iterations (paired with Exp5/6b); auto_sig arms
                MADRY_SPDIFF_AUTOSIG, MADRY_SP_AUTOSIG, MADRY_SP_AUTOSIG_POOL.
  newsess-sup   Exp11, supervised; 20 Perich sessions never used before, drawn at random from
                the .npz files of --data-dir (the nine sessions of Exp5-10 excluded; seeded and
                stored in DPRIME_EXP11_SESSIONS.json, so both new-session suites and every resume
                use the same ones); 3,000 iterations; the frozen rules on unseen data: PGD6, DIFF8,
                SP8, SP_AUTO (auto_sig), and the behaviour-referenced DIFF/SP/POOL_AUTOBEH.
  newsess-time  Exp11, time-only; the same 20 sessions; PGD6, DIFF8 and the label-free auto_sig
                arms DIFF/SP/POOL_AUTOSIG.
  control-sup   Exp12, supervised; the same new sessions; the matched control
                MADRY_SPDIFF_D8_RAND: DIFF8 (same metric, same budget, same update) with a uniformly
                random direction on the d' sphere instead of the attack (fork option
                adv_dprime_optimizer="random"): what the noise-aware geometry buys without the
                adversary. Paired by (session, seed) with DIFF8 of newsess-sup.
  control-time  Exp12, time-only; the same control, paired with DIFF8 of newsess-time.
  gauss-sup     Exp13, supervised; the same new sessions; covariance-matched noise augmentation
                MADRY_SPDIFF_GAUSS: the random direction of the control at the natural noise scale
                eps = sqrt(C * T) (one extra draw of the noise of the DIFF metric, ~46 d' for 60
                neurons) instead of eps = 8; and CLEAN (no perturbation) on the new sessions.
                Paired with DIFF8 / PGD6 of newsess-sup.
  gauss-time    Exp13, time-only; the same two arms, paired with newsess-time.
  custom        anything: --mode, --arms, --sessions, --seeds, --max-iterations or --epochs,
                --train-bins and --output-root (all earlier arms are in the catalogue).

Pre-registration (newsess suites): before any job starts (also with --dry-run) the coordinator
computes, for every new session and arm, the training budget each rule will use and the ratios
x_sig = eps / eps_sig and x_beh = eps / eps_beh of the training metric, and writes them with the
predicted decoder failures (supervised: x_beh >= 0.50, the Exp10 boundary; time-only, tentative:
x_beh >= 0.81) to <output-root>/PREDICTIONS.csv / .json. An existing file is never overwritten.

auto_sig (fork option adv_dprime_epsilon="auto_sig") sets the training budget from the training
data alone: eps = min((2D)^(1/4), 0.24 * eps_sig(M)), where eps_sig is the typical d' distance
between the signal parts of two windows in the training metric M. auto_beh (supervised only:
it uses the training labels) references the behavioural signal instead:
eps = max(1, min((2D)^(1/4), 0.363 * eps_beh(M))) (see DPRIME_DESIGN.md).

With --train-bins the encoder and decoder are trained on the first N training bins only; the
evaluation metrics are still fitted on the complete training split, so every robustness value is
in the same units as the untruncated runs of that session. Validation data are never truncated.

Examples (4 GPUs):
    python -u dprime_exp9.py --suite e1 --gpu-workers 4
    python -u dprime_exp9.py --suite e2 --gpu-workers 4
    python -u dprime_exp9.py --suite e2b --gpu-workers 4
    python -u dprime_exp9.py --suite autosig-sup --gpu-workers 4
    python -u dprime_exp9.py --suite autosig-time --gpu-workers 4
    python -u dprime_exp9.py --suite newsess-sup --dry-run   # choose the sessions, pre-register
    python -u dprime_exp9.py --suite newsess-sup --gpu-workers 4
    python -u dprime_exp9.py --suite newsess-time --gpu-workers 4
    python -u dprime_exp9.py --suite e1 --dry-run          # the planned jobs and iterations
Evaluation options (fork v5): --eval-refine K bisects the half-R2 crossing K times (one more
attack per step; below the smallest budget it first halves the budget down to 1/16 of it, so
floor values become measurements); --eval-kappa adds eps_beh of the training recording in each
evaluation metric and kappa = eps1/2 / eps_beh; --no-eval-margins skips the DDN margins. Exp12
re-evaluates the saved Exp11 models with them (no training) under a new tag:
    python -u dprime_exp9.py --suite newsess-sup --random-sessions 10 --eval-only --eval-tag v2 \
        --eval-refine 4 --eval-kappa --no-eval-margins --gpu-workers 4
Re-running with --resume skips finished jobs. Exp11 summary (both suites, with the test of the
pre-registered predictions): python exp11_summary.py
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import inspect
import io
import json
import math
import os
import queue
import random
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

sys.dont_write_bytecode = True

import numpy as np
import torch
from sklearn.metrics import r2_score
from torch import nn

ROOT = Path(__file__).resolve().parent
DEFAULT_FORK_DIR = ROOT / "Acorn-dprime"
DEFAULT_DATA_DIR = Path("/data/hossein/mm_project/perich_data_valid_final_raw/")
SESSIONS = ("C-CO12", "C-CO13", "C-RT13", "C-RT6", "M-CO9", "M-RT3", "T-RT1", "T-RT4", "J-CO0")
SHORT_SESSIONS = ("J-CO0", "C-RT6", "M-RT3", "T-RT4", "T-RT1")
SEEDS = (42, 43, 44)
MODES = ("time_only", "supervised")

PGD_EPS = 3.0  # placeholder adv_epsilon of the d' arms (as in Exp5-8)
ATTACK_STEPS = 10
LATENT_DIM = 64
HIDDEN = 64
BATCH_SIZE = 2048
MAX_ITER = 3000
TEMPERATURE = 0.4
ARCH = "offset36-model-more-dropout"
DEVICE = "cuda_if_available"
WINDOW = 36

MLP_EPOCHS = 2500
MLP_HIDDEN = 64
MLP_DROP = 0.4
MLP_LR = 1e-3
EVAL_BATCH_SIZE = 8192

# auto_sig settings of this experiment (fork defaults; written into every arm explicitly).
SIG_FRACTION = 0.24
SIG_LAG = 1
SIG_CAP = "blind"
# auto_beh settings (fork defaults, frozen after Exp10).
BEH_FRACTION = 0.363
BEH_LAGS = (-8, -4, 0, 4, 8)
BEH_FEATURES = 400
JND = 1.0  # fork default adv_dprime_jnd: the floor of the auto_beh budget
# Runner-level budget of the natural-noise control: eps = sqrt(C * T), the d' of one draw of the
# training metric's own noise (set per session in encoder_config; the fork sees a number).
NOISE_SCALE = "noise_scale"
# Pre-registered failure boundaries of eps / eps_beh (Exp10b: supervised c* = 0.505; time-only
# 0.81 from ten failures only, tentative).
FAIL_X_BEH = {"supervised": 0.50, "time_only": 0.81}
DEFAULT_SELECTION_FILE = ROOT / "DPRIME_EXP11_SESSIONS.json"


@dataclass(frozen=True)
class Experiment:
    name: str
    overrides: Dict[str, Any] = field(default_factory=dict)
    supervised_only: bool = False

    @property
    def dprime(self) -> bool:
        return self.overrides.get("adv_epsilon_mode") == "dprime"

    @property
    def auto_sig(self) -> bool:
        return self.overrides.get("adv_dprime_epsilon") == "auto_sig"

    @property
    def auto_beh(self) -> bool:
        return self.overrides.get("adv_dprime_epsilon") == "auto_beh"


def catalogue() -> List[Experiment]:
    """Every arm of Exp5-8 (identical overrides) plus the auto_sig arms of Exp9."""
    common = dict(
        adv_epsilon_mode="dprime", adv_dprime_layer="stationary",
        adv_dprime_residuals="whole", adv_dprime_spatial="ledoit_wolf",
        adv_dprime_temporal="welch", adv_dprime_optimizer="apgd",
        adv_dprime_restarts=1, adv_dprime_objective="madry",
        adv_dprime_instance_adaptive=False, adv_dprime_guards=(),
        adv_dprime_guard_mode="off", adv_dprime_warmup=0.0,
        adv_dprime_curriculum=0.0,
    )
    iso = dict(adv_dprime_spatial="isotropic", adv_dprime_temporal="white")
    spatial = dict(adv_dprime_temporal="white")
    sig = dict(adv_dprime_epsilon="auto_sig", adv_dprime_sig_fraction=SIG_FRACTION,
               adv_dprime_sig_lag=SIG_LAG, adv_dprime_sig_cap=SIG_CAP)
    beh = dict(adv_dprime_epsilon="auto_beh", adv_dprime_beh_fraction=BEH_FRACTION,
               adv_dprime_beh_lags=BEH_LAGS, adv_dprime_beh_features=BEH_FEATURES,
               adv_dprime_sig_cap=SIG_CAP)

    def arm(name: str, supervised_only: bool = False, **kw) -> Experiment:
        return Experiment(name, {**common, **kw}, supervised_only)

    def pgd(eps: float) -> Experiment:
        return Experiment(f"PGD_L2_EPS{eps:g}", {
            "training_mode": "adversarial", "adv_epsilon_mode": "constant",
            "attack_norm": "l2", "adv_epsilon": eps, "adv_alpha": eps / 5.0,
        })

    arms = [
        Experiment("CLEAN", {"training_mode": "standard"}),
        pgd(3.0), pgd(6.0), pgd(12.0),
        arm("MADRY_ISO_D8", adv_dprime_epsilon=8.0, **iso),
        arm("MADRY_ISO_D16", adv_dprime_epsilon=16.0, **iso),
        arm("MADRY_SP_D4", adv_dprime_epsilon=4.0, **spatial),
        arm("MADRY_SP_D8", adv_dprime_epsilon=8.0, **spatial),
        arm("MADRY_SP_D16", adv_dprime_epsilon=16.0, **spatial),
        arm("MADRY_NA_D4", adv_dprime_epsilon=4.0),
        arm("MADRY_SPDIFF_D8", adv_dprime_epsilon=8.0, adv_dprime_residuals="difference",
            **spatial),
        arm("MADRY_SP_D8_POOL", adv_dprime_epsilon=8.0, adv_dprime_cov_pool=("isotropic",),
            **spatial),
        arm("MADRY_SPREG_D8", True, adv_dprime_epsilon=8.0, adv_dprime_residuals="regression",
            **spatial),
        arm("MADRY_SP_AUTOBLIND", adv_dprime_epsilon="auto_blind", adv_dprime_warmup=0.1,
            **spatial),
        # Exp9: the signal-referenced budget, one arm per noise model.
        arm("MADRY_SP_AUTOSIG", **sig, **spatial),
        arm("MADRY_SPDIFF_AUTOSIG", adv_dprime_residuals="difference", **sig, **spatial),
        arm("MADRY_SP_AUTOSIG_POOL", adv_dprime_cov_pool=("isotropic",), **sig, **spatial),
        arm("MADRY_SPREG_AUTOSIG", True, adv_dprime_residuals="regression", **sig, **spatial),
        # Exp9 mechanism test: SP8 with the attack restricted to nuisance directions (the signal
        # modes detectable within a window are projected out; same metric and budget as SP8).
        arm("MADRY_SP_D8_SIGPROJ", adv_dprime_epsilon=8.0, adv_dprime_signal_projection="jnd",
            **spatial),
        # Exp11: the behaviour-referenced budget (needs the labels of a supervised fit).
        arm("MADRY_SP_AUTOBEH", True, **beh, **spatial),
        arm("MADRY_SPDIFF_AUTOBEH", True, adv_dprime_residuals="difference", **beh, **spatial),
        arm("MADRY_SP_AUTOBEH_POOL", True, adv_dprime_cov_pool=("isotropic",), **beh, **spatial),
        arm("MADRY_SPREG_AUTOBEH", True, adv_dprime_residuals="regression", **beh, **spatial),
        # Exp12 control: DIFF8 with a random direction on the d' sphere instead of the attack.
        arm("MADRY_SPDIFF_D8_RAND", adv_dprime_epsilon=8.0, adv_dprime_residuals="difference",
            adv_dprime_optimizer="random", **spatial),
        # Exp13 control: covariance-matched noise augmentation at the natural noise scale.
        arm("MADRY_SPDIFF_GAUSS", adv_dprime_epsilon=NOISE_SCALE,
            adv_dprime_residuals="difference", adv_dprime_optimizer="random", **spatial),
    ]
    assert len(arms) == len({e.name for e in arms})
    return arms


SUITES: Dict[str, Dict[str, Any]] = {
    "e1": dict(mode="supervised", arms=("MADRY_SP_D8", "PGD_L2_EPS6"), sessions=SHORT_SESSIONS,
               max_iterations=None, epochs=340.0, train_bins=None,
               output="DPRIME_EXP9_E1_EPOCHS340"),
    "e2": dict(mode="supervised", arms=("MADRY_SP_D8", "PGD_L2_EPS6"), sessions=("C-CO12",),
               max_iterations=MAX_ITER, epochs=None, train_bins=9174,
               output="DPRIME_EXP9_E2_TRUNC9174"),
    "e2b": dict(mode="supervised", arms=("MADRY_SP_D8", "PGD_L2_EPS6"), sessions=("C-CO12",),
                max_iterations=6000, epochs=None, train_bins=None,
                output="DPRIME_EXP9_E2B_ITER6000"),
    "autosig-sup": dict(mode="supervised",
                        arms=("MADRY_SPDIFF_AUTOSIG", "MADRY_SP_AUTOSIG", "MADRY_SPREG_AUTOSIG",
                              "MADRY_SP_AUTOSIG_POOL", "MADRY_SP_D8_SIGPROJ"),
                        sessions=SESSIONS, max_iterations=MAX_ITER, epochs=None, train_bins=None,
                        output="DPRIME_EXP9_AUTOSIG_SUPERVISED"),
    "autosig-time": dict(mode="time_only",
                         arms=("MADRY_SPDIFF_AUTOSIG", "MADRY_SP_AUTOSIG",
                               "MADRY_SP_AUTOSIG_POOL"),
                         sessions=SESSIONS, max_iterations=MAX_ITER, epochs=None,
                         train_bins=None, output="DPRIME_EXP9_AUTOSIG_TIMEONLY"),
    "newsess-sup": dict(mode="supervised",
                        arms=("PGD_L2_EPS6", "MADRY_SPDIFF_D8", "MADRY_SP_D8", "MADRY_SP_AUTOSIG",
                              "MADRY_SPDIFF_AUTOBEH", "MADRY_SP_AUTOBEH", "MADRY_SP_AUTOBEH_POOL"),
                        sessions="random", max_iterations=MAX_ITER, epochs=None, train_bins=None,
                        output="DPRIME_EXP11_NEWSESS_SUPERVISED"),
    "newsess-time": dict(mode="time_only",
                         arms=("PGD_L2_EPS6", "MADRY_SPDIFF_D8", "MADRY_SPDIFF_AUTOSIG",
                               "MADRY_SP_AUTOSIG", "MADRY_SP_AUTOSIG_POOL"),
                         sessions="random", max_iterations=MAX_ITER, epochs=None,
                         train_bins=None, output="DPRIME_EXP11_NEWSESS_TIMEONLY"),
    "control-sup": dict(mode="supervised", arms=("MADRY_SPDIFF_D8_RAND",), sessions="random",
                        max_iterations=MAX_ITER, epochs=None, train_bins=None,
                        output="DPRIME_EXP12_CONTROL_SUPERVISED"),
    "control-time": dict(mode="time_only", arms=("MADRY_SPDIFF_D8_RAND",), sessions="random",
                         max_iterations=MAX_ITER, epochs=None, train_bins=None,
                         output="DPRIME_EXP12_CONTROL_TIMEONLY"),
    "gauss-sup": dict(mode="supervised", arms=("MADRY_SPDIFF_GAUSS", "CLEAN"), sessions="random",
                      max_iterations=MAX_ITER, epochs=None, train_bins=None,
                      output="DPRIME_EXP13_GAUSS_SUPERVISED"),
    "gauss-time": dict(mode="time_only", arms=("MADRY_SPDIFF_GAUSS", "CLEAN"), sessions="random",
                       max_iterations=MAX_ITER, epochs=None, train_bins=None,
                       output="DPRIME_EXP13_GAUSS_TIMEONLY"),
    "custom": dict(mode=None, arms=(), sessions=SESSIONS, max_iterations=MAX_ITER, epochs=None,
                   train_bins=None, output=None),
}


@dataclass(frozen=True)
class Plan:
    suite: str
    mode: str
    arms: Tuple[Experiment, ...]
    sessions: Tuple[str, ...]
    seeds: Tuple[int, ...]
    max_iterations: Optional[int]
    epochs: Optional[float]
    train_bins: Optional[int]
    output_root: Path


def resolve_plan(args) -> Plan:
    suite = SUITES[args.suite]
    mode = args.mode or suite["mode"]
    if mode not in MODES:
        raise ValueError(f"--mode must be one of {MODES} (required with --suite custom)")
    names = tuple(args.arms) if args.arms else tuple(suite["arms"])
    if not names:
        raise ValueError("No arms: pass --arms (required with --suite custom); see --list")
    by_name = {e.name: e for e in catalogue()}
    unknown = sorted(set(names) - set(by_name))
    if unknown:
        raise ValueError(f"Unknown arms {unknown}; see --list")
    arms = tuple(by_name[n] for n in names)
    if mode == "time_only":
        bad = [e.name for e in arms if e.supervised_only]
        if bad:
            raise ValueError(f"{bad} need behaviour labels (regression residuals or auto_beh): "
                             "supervised only")
    epochs = args.epochs if args.epochs is not None else suite["epochs"]
    max_iterations = (args.max_iterations if args.max_iterations is not None
                      else suite["max_iterations"])
    if epochs is not None and args.max_iterations is not None:
        raise ValueError("Give either --epochs or --max-iterations, not both")
    if epochs is not None:
        max_iterations = None
        if not np.isfinite(epochs) or epochs <= 0:
            raise ValueError("--epochs must be > 0")
    elif max_iterations is None or max_iterations < 1:
        raise ValueError("--max-iterations must be >= 1")
    train_bins = args.train_bins if args.train_bins is not None else suite["train_bins"]
    if train_bins is not None and train_bins < 4 * WINDOW:
        raise ValueError(f"--train-bins must be at least {4 * WINDOW}")
    if args.sessions:
        sessions = tuple(args.sessions)
    elif suite["sessions"] == "random":
        sessions = tuple(select_sessions(args))
    else:
        sessions = tuple(suite["sessions"])
    seeds = tuple(args.seeds) if args.seeds else SEEDS
    output = args.output_root or (ROOT / suite["output"] if suite["output"] else None)
    if output is None:
        raise ValueError("--output-root is required with --suite custom")
    return Plan(args.suite, mode, arms, sessions, seeds, max_iterations, epochs, train_bins,
                Path(output))


def iterations_for(plan: Plan, n_train: int, batch_size: int) -> int:
    """Fixed iterations, or the iterations that make ``epochs`` passes over the training bins."""
    if plan.epochs is None:
        return int(plan.max_iterations)
    return max(1, int(round(plan.epochs * n_train / batch_size)))


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def load_fork(fork_dir: Path, exp: Optional[Experiment] = None, needs_eval_options: bool = False):
    package = fork_dir / "cebra" / "__init__.py"
    if not package.is_file():
        raise FileNotFoundError(f"Expected fork at {fork_dir}. Place this runner next to "
                                "Acorn-dprime or set --fork-dir PATH.")
    for key in list(sys.modules):
        if key == "cebra" or key.startswith("cebra."):
            del sys.modules[key]
    sys.path.insert(0, str(fork_dir.resolve()))
    import cebra

    actual = Path(cebra.__file__).resolve()
    if not str(actual).startswith(str(fork_dir.resolve()) + os.sep):
        raise RuntimeError(f"Wrong CEBRA imported: {actual}")
    params = inspect.signature(cebra.CEBRA.__init__).parameters
    required = {
        "training_mode", "adv_epsilon", "adv_alpha", "adv_steps", "attack_norm",
        "adv_epsilon_mode", "adv_dprime_epsilon", "adv_dprime_layer",
        "adv_dprime_optimizer", "adv_dprime_instance_adaptive", "adv_dprime_temporal",
        "adv_dprime_spatial", "adv_dprime_guards", "adv_dprime_objective",
        "adv_dprime_cov_pool",
    }
    if exp is not None:  # every setting of the arm must exist in this fork
        required |= {k for k in exp.overrides if k.startswith("adv_")}
    missing = sorted(required - set(params))
    if missing:
        raise RuntimeError(f"This fork lacks Acorn-dprime parameters: {missing}")
    from cebra.dprime.noise import RESIDUAL_MODES, SPATIAL_ESTIMATORS
    from cebra.dprime.training import AUTO_MODES
    if ("auto_blind" not in AUTO_MODES or "difference" not in RESIDUAL_MODES
            or "regression" not in RESIDUAL_MODES or "isotropic" not in SPATIAL_ESTIMATORS):
        raise RuntimeError("Wrong fork: auto_blind, difference/regression residuals or the "
                           "isotropic geometry missing")
    mode = (exp.overrides.get("adv_dprime_epsilon") if exp is not None else None)
    if isinstance(mode, str) and mode not in AUTO_MODES and mode != NOISE_SCALE:
        raise RuntimeError(f"This fork has no adv_dprime_epsilon={mode!r}; use the newest fork")
    from cebra.dprime import training
    optimizer = exp.overrides.get("adv_dprime_optimizer") if exp is not None else None
    if optimizer is not None and optimizer not in getattr(training, "OPTIMIZERS", ("apgd", "pgd")):
        raise RuntimeError(f"This fork has no adv_dprime_optimizer={optimizer!r}; use the newest "
                           "fork")
    from cebra.dprime import evaluation
    if not callable(getattr(evaluation, "evaluate_decoding", None)):
        raise RuntimeError("Fork lacks evaluate_decoding")
    if needs_eval_options:
        params = inspect.signature(evaluation.evaluate_decoding).parameters
        if not {"refine", "behaviour_train", "margins"} <= set(params):
            raise RuntimeError("This fork's evaluate_decoding lacks refine / behaviour_train; "
                               "use the newest fork")
    return cebra


def load_data(data_path: Path):
    if not data_path.is_file():
        raise FileNotFoundError(f"No session file at: {data_path}")
    with np.load(data_path, allow_pickle=False) as f:
        x_train, x_valid, y_train, y_valid = (
            np.asarray(f[k], dtype=np.float32)
            for k in ("train_data", "valid_data", "train_label", "valid_label"))
    if y_train.ndim == 1:
        y_train = y_train[:, None]
    if y_valid.ndim == 1:
        y_valid = y_valid[:, None]
    for key, arr in (("train_data", x_train), ("valid_data", x_valid),
                     ("train_label", y_train), ("valid_label", y_valid)):
        if arr.ndim != 2 or 0 in arr.shape or not np.isfinite(arr).all():
            raise ValueError(f"Invalid shape / nonfinite {key}: {arr.shape}")
    if x_train.shape[1] != x_valid.shape[1] or y_train.shape[1] != y_valid.shape[1]:
        raise ValueError("Train/valid feature or label dimensions differ")
    if len(x_train) != len(y_train) or len(x_valid) != len(y_valid):
        raise ValueError("Neural data and decoder labels have different lengths")
    if min(len(x_train), len(x_valid)) < WINDOW:
        raise ValueError("The offset36 model needs at least 36 bins in each split")
    for name, x in (("train_data", x_train), ("valid_data", x_valid)):
        if np.any(x < 0) or not np.array_equal(x, np.rint(x)):
            raise ValueError(f"{name} must be RAW nonnegative integer spike counts")
    return tuple(np.ascontiguousarray(a) for a in (x_train, x_valid, y_train, y_valid))


def select_sessions(args) -> List[str]:
    """The new sessions of Exp11, drawn once and stored (every later call returns the same).

    All ``*.npz`` of --data-dir except the nine sessions of Exp5-10, in a seeded random order;
    the first ``--random-sessions`` that load (raw integer counts, labels) and have at least
    ``--min-train-bins`` training bins and ``--min-channels`` neurons are chosen. The choice, the
    rejected sessions with their reason and the SHA-256 of every chosen file go to
    ``--selection-file``. A smaller --random-sessions later takes the first ones of the stored
    list (the same sessions a smaller draw with this seed would have chosen).
    """
    path = Path(args.selection_file)
    if path.is_file():
        stored = json.loads(path.read_text(encoding="utf-8"))
        if int(stored["selection_seed"]) != args.selection_seed:
            raise ValueError(f"{path} was drawn with --selection-seed {stored['selection_seed']}; "
                             "use another --selection-file for a new draw")
        if args.random_sessions > len(stored["chosen"]):
            raise ValueError(f"{path} holds {len(stored['chosen'])} sessions, --random-sessions "
                             f"asks for {args.random_sessions}; use another --selection-file")
        if Path(stored["data_dir"]) != args.data_dir.resolve():
            print(f"WARNING: {path} was drawn from {stored['data_dir']}", flush=True)
        return list(stored["chosen"][:args.random_sessions])
    if args.random_sessions < 1:
        raise ValueError("--random-sessions must be at least 1")
    candidates = sorted(f.stem for f in args.data_dir.glob("*.npz") if f.stem not in SESSIONS)
    order = np.random.default_rng(args.selection_seed).permutation(len(candidates))
    chosen, rejected, info = [], [], []
    for index in order:
        name = candidates[int(index)]
        try:
            x_train, x_valid, y_train, _ = load_data(args.data_dir / f"{name}.npz")
        except Exception as exc:  # unusable file: record why
            rejected.append({"session": name, "reason": f"{type(exc).__name__}: {exc}"})
            continue
        if len(x_train) < args.min_train_bins or x_train.shape[1] < args.min_channels:
            rejected.append({"session": name, "reason": f"{len(x_train)} training bins, "
                             f"{x_train.shape[1]} neurons"})
            continue
        chosen.append(name)
        info.append({"session": name, "n_train": int(len(x_train)), "n_valid": int(len(x_valid)),
                     "neurons": int(x_train.shape[1]), "label_dims": int(y_train.shape[1]),
                     "sha256": file_sha256(args.data_dir / f"{name}.npz")})
        if len(chosen) == args.random_sessions:
            break
    if len(chosen) < args.random_sessions:
        raise RuntimeError(f"Only {len(chosen)} usable new sessions in {args.data_dir} "
                           f"({len(candidates)} candidates; rejected: {rejected})")
    atomic_write_json(path, {
        "created_utc": now_utc(), "data_dir": str(args.data_dir.resolve()),
        "selection_seed": args.selection_seed, "n": args.random_sessions,
        "min_train_bins": args.min_train_bins, "min_channels": args.min_channels,
        "excluded_known": list(SESSIONS), "candidates": len(candidates),
        "chosen": chosen, "chosen_info": info, "rejected": rejected})
    print(f"Chose {len(chosen)} new sessions out of {len(candidates)} candidates -> {path}",
          flush=True)
    return chosen


def _metric_members(exp: Experiment, x: np.ndarray, y: np.ndarray, noise):
    """(Σ_s, Σ_t) of every pool member of the arm's training metric, fitted as the fork fits it
    (identity in spike counts for the PGD arms, as in Exp10b; None for CLEAN)."""
    o = exp.overrides
    if not exp.dprime:
        if o.get("training_mode") == "standard":
            return None
        return [(np.eye(x.shape[1]), np.eye(WINDOW))]
    residuals = o["adv_dprime_residuals"]
    labels = y if residuals == "regression" else None
    model, _ = noise.fit_noise_model(x, labels,
                                     label_kind="continuous" if labels is not None else None,
                                     window_len=WINDOW, residual_mode=residuals,
                                     spatial_estimator=o["adv_dprime_spatial"],
                                     temporal_method=o["adv_dprime_temporal"],
                                     cov_pool=o.get("adv_dprime_cov_pool"), kronecker_channels=0)
    return [(model.spatial_cov_of(k), model.temporal_cov) for k in range(model.pool_size)]


def _rule_budgets(exp: Experiment, eps_sig, eps_beh, blind: float, channels: int):
    """The training budget of every pool member, as the fork sets it (None: not known before
    training, e.g. auto / auto_blind, or an auto_sig run that will stop for lack of signal)."""
    o = exp.overrides
    if not exp.dprime:
        return [float(o["adv_epsilon"])]
    rule = o.get("adv_dprime_epsilon")
    if rule == NOISE_SCALE:
        return [math.sqrt(channels * WINDOW)] * len(eps_sig)
    if not isinstance(rule, str):
        return [float(rule)] * len(eps_sig)
    cap = blind if (o.get("adv_dprime_sig_cap") or "none") == "blind" else np.inf
    if rule == "auto_sig":
        if not all(np.isfinite(eps_sig)):
            return None
        return [min(o.get("adv_dprime_sig_fraction", SIG_FRACTION) * value, cap)
                for value in eps_sig]
    if rule == "auto_beh":
        fraction = o.get("adv_dprime_beh_fraction", BEH_FRACTION)
        return [JND if not np.isfinite(value) else max(JND, min(fraction * value, cap))
                for value in eps_beh]
    return None


PREDICTION_FIELDS = ["session", "arm", "mode", "neurons", "n_train", "behaviour_r2", "eps_sig",
                     "eps_beh", "eps_blind_cap", "budget", "pool_budgets", "x_sig", "x_beh",
                     "predicted_broken", "registered_utc"]


def write_predictions(args, plan: Plan) -> Path:
    """Pre-register, before training, the budgets and the predicted decoder failures.

    Rows are only ever added: a (session, arm) already in PREDICTIONS.csv is kept unchanged, so a
    later call with more arms or sessions registers just the new pairs.
    """
    root = plan.output_root.resolve()
    path = root / "PREDICTIONS.csv"
    rows = list(csv.DictReader(path.open(encoding="utf-8"))) if path.is_file() else []
    done = {(row["session"], row["arm"]) for row in rows}
    todo = [(session, [e for e in plan.arms if (session, e.name) not in done])
            for session in plan.sessions]
    todo = [(session, arms) for session, arms in todo if arms]
    if not todo:
        print(f"Pre-registered predictions already in {path} (kept unchanged)", flush=True)
        return path
    load_fork(args.fork_dir)
    from cebra.dprime import calibration, noise
    threshold = FAIL_X_BEH[plan.mode]
    stamp = now_utc()
    for session, arms in todo:
        # float32 as in the fork (CEBRA.fit stores the data as float32 tensors).
        x, _, y, _ = load_data(args.data_dir / f"{session}.npz")
        prediction, model = calibration.behaviour_prediction(x, y, lags=BEH_LAGS,
                                                             features=BEH_FEATURES, seed=0)
        blind = calibration.eps_energy_detector(x.shape[1], WINDOW)
        for exp in arms:
            row = dict.fromkeys(PREDICTION_FIELDS)
            row.update(session=session, arm=exp.name, mode=plan.mode, neurons=int(x.shape[1]),
                       n_train=int(len(x)), behaviour_r2=model["r2"], eps_blind_cap=blind,
                       registered_utc=stamp)
            members = _metric_members(exp, x, y, noise)
            if members is not None:
                eps_sig = [calibration.eps_signal(x, a, b, SIG_LAG) for a, b in members]
                eps_beh = [calibration.eps_behaviour(x, prediction, a, b) for a, b in members]
                row.update(eps_sig=eps_sig[0], eps_beh=eps_beh[0])
                budgets = _rule_budgets(exp, eps_sig, eps_beh, blind, x.shape[1])
                if budgets is not None:
                    row.update(budget=budgets[0],
                               pool_budgets=json.dumps(budgets) if len(budgets) > 1 else None)
                    # Pool arms: the geometric mean over the members (as in Exp10b).
                    with np.errstate(divide="ignore", invalid="ignore"):
                        row["x_sig"] = float(np.exp(np.mean(np.log(np.divide(budgets, eps_sig)))))
                        row["x_beh"] = float(np.exp(np.mean(np.log(np.divide(budgets, eps_beh)))))
                    if np.isfinite(row["x_beh"]):
                        row["predicted_broken"] = bool(row["x_beh"] >= threshold)
            rows.append(row)
        print(f"pre-registered {session}: behaviour R2 {model['r2']:.3f}", flush=True)
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=PREDICTION_FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    atomic_write_text(path, stream.getvalue())
    meta_path = root / "PREDICTIONS.json"
    meta = (json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.is_file()
            else {"suite": plan.suite, "mode": plan.mode, "registrations": []})
    meta["rule"] = (f"predicted_broken = eps_train / eps_beh(M_train) >= {threshold} (Exp10b "
                    "boundary; pool arms: geometric mean over the members; PGD: identity metric "
                    "in spike counts)")
    meta["registrations"].append({
        "registered_utc": stamp, "fork_dir": str(args.fork_dir.resolve()),
        "fork_fingerprints": _fingerprints(args.fork_dir, FORK_TRAIN_FILES),
        "pairs": [[session, e.name] for session, arms in todo for e in arms]})
    atomic_write_json(meta_path, meta)
    print(f"Pre-registered predictions -> {path}", flush=True)
    return path


def training_split(arrays, train_bins: Optional[int]):
    """The (x, y) the encoder and decoder are trained on: the first ``train_bins`` bins."""
    x_train, _, y_train, _ = arrays
    if train_bins is None:
        return x_train, y_train
    if train_bins > len(x_train):
        raise ValueError(f"--train-bins {train_bins} exceeds the {len(x_train)} training bins")
    return np.ascontiguousarray(x_train[:train_bins]), np.ascontiguousarray(y_train[:train_bins])


def encoder_config(exp: Experiment, mode: str, iterations: int, batch_size: int, device: str,
                   seed: int, pgd_eps: float, channels: Optional[int] = None) -> Dict[str, Any]:
    config = {
        "model_architecture": ARCH,
        "batch_size": batch_size,
        "temperature": TEMPERATURE,
        "time_offsets": 1,
        "max_iterations": iterations,
        "output_dimension": LATENT_DIM,
        "num_hidden_units": HIDDEN,
        "learning_rate": 3e-4,
        "temperature_mode": "constant",
        "training_mode": "adversarial",
        "adv_epsilon": pgd_eps,
        "adv_alpha": pgd_eps / 5.0,
        "adv_steps": ATTACK_STEPS,
        "attack_norm": "l2",  # A placeholder ignored by d' training.
        "adv_dprime_seed": seed,
        "device": device,
        "verbose": False,
    }
    if mode == "supervised":
        config.update(conditional="time_delta", hybrid=False)  # as Exp8
    config.update(exp.overrides)
    if config.get("adv_dprime_epsilon") == NOISE_SCALE:
        if channels is None:
            raise ValueError(f"{exp.name} needs the number of channels for its noise-scale budget")
        config["adv_dprime_epsilon"] = math.sqrt(channels * WINDOW)
    return config


class TwoLayerMLP(nn.Module):
    def __init__(self, dim: int, out: int):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(dim, MLP_HIDDEN), nn.LayerNorm(MLP_HIDDEN), nn.ReLU(),
                                 nn.Dropout(MLP_DROP), nn.Linear(MLP_HIDDEN, out))

    def forward(self, x):
        return self.net(x)


def train_decoder(z_train, y_train, seed: int, device, epochs: int):
    seed_all(seed)
    decoder = TwoLayerMLP(z_train.shape[1], y_train.shape[1]).to(device)
    opt = torch.optim.Adam(decoder.parameters(), lr=MLP_LR)
    criterion = nn.MSELoss()
    z = torch.as_tensor(z_train, dtype=torch.float32, device=device)
    y = torch.as_tensor(y_train, dtype=torch.float32, device=device)
    decoder.train()
    for epoch in range(epochs):
        opt.zero_grad(set_to_none=True)
        loss = criterion(decoder(z), y)
        if not torch.isfinite(loss).item():
            raise FloatingPointError(f"Nonfinite decoder loss at epoch {epoch + 1}")
        loss.backward()
        opt.step()
    return decoder


def predict_decoder(decoder, embeddings):
    decoder.eval()
    device = next(decoder.parameters()).device
    preds = []
    with torch.inference_mode():
        for first in range(0, len(embeddings), EVAL_BATCH_SIZE):
            z = torch.as_tensor(embeddings[first:first + EVAL_BATCH_SIZE], dtype=torch.float32,
                                device=device)
            preds.append(decoder(z).cpu().numpy())
    return np.concatenate(preds, axis=0)


def epsilon_summary(report: Optional[Dict[str, Any]]) -> str:
    if not report:
        return "no-dprime-report"
    e = report.get("epsilon", {}) or {}
    t = report.get("training", {}) or {}
    parts = [f"source={e.get('source')}", f"eps_star={e.get('eps_star')}",
             f"binding={e.get('binding')}", f"final_epsilon={t.get('final_epsilon')}",
             f"mean_dprime={t.get('mean_dprime')}"]
    if e.get("source") in ("auto_sig", "auto_beh"):
        parts += [f"eps_sig={e.get('eps_sig')}", f"x_train={e.get('x_train')}",
                  f"eps_cap={e.get('eps_cap')}"]
        if e.get("source") == "auto_beh":
            parts += [f"eps_beh={e.get('eps_beh')}",
                      f"behaviour_r2={(e.get('behaviour_model') or {}).get('r2')}"]
        if e.get("pool"):
            parts.append("pool_budgets=" + ",".join(f"{m['budget']:.3f}" for m in e["pool"]))
    return " ".join(parts)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def atomic_write_text(path: Path, content: str) -> None:
    """Commit one entire file; readers see either the old or the new version."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def atomic_write_json(path: Path, payload: Dict[str, Any]) -> None:
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False,
                                       sort_keys=True) + "\n")


def _atomic_save(path: Path, save) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".pt", dir=path.parent)
    os.close(fd)
    try:
        save(tmp)
        if not Path(tmp).is_file() or Path(tmp).stat().st_size == 0:
            raise RuntimeError(f"Saving {path.name} produced an empty file")
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def session_root(plan: Plan, session: str, seed: int) -> Path:
    return plan.output_root.resolve() / session / f"seed{seed}"


def _checkpoint_paths(root: Path, name: str) -> Tuple[Path, Path, Path]:
    return (root / "models" / f"{name}_encoder.pt", root / "models" / f"{name}_decoder.pt",
            root / "training" / f"{name}.json")


def record_path(root: Path, name: str) -> Path:
    if not name.replace("_", "").isalnum():
        raise ValueError(f"Unsafe experiment name: {name!r}")
    return root / "records" / f"{name}.json"


def read_record(root: Path, name: str):
    path = record_path(root, name)
    if not path.is_file():
        return None
    obj = json.loads(path.read_text(encoding="utf-8"))
    if obj.get("experiment") != name:
        raise RuntimeError(f"Mismatched record in {path}")
    return obj


def evaluation_dir(root: Path, area: str, tag: str) -> Path:
    return root / (area if tag == "v1" else f"{area}_{tag}")


def record_files(root: Path, tag: str) -> List[Path]:
    """The record files of one folder (nested records/records/ by record_path, as in Exp5-8)."""
    return sorted(record_path(evaluation_dir(root, "records", tag), "x").parent.glob("*.json"))


def _score(encoder, decoder, x_valid, y_valid) -> float:
    z = np.asarray(encoder.transform(x_valid), dtype=np.float32)
    if len(z) != len(x_valid) or not np.isfinite(z).all():
        raise ValueError("Invalid encoder validation embedding/alignment")
    predictions = predict_decoder(decoder, z)
    if predictions.shape != y_valid.shape or not np.isfinite(predictions).all():
        raise ValueError("Invalid decoder validation predictions")
    result = float(np.atleast_1d(r2_score(y_valid, predictions, multioutput="raw_values")).mean())
    if not np.isfinite(result):
        raise ValueError("Non-finite clean R2")
    return result


def _validate_training_report(exp: Experiment, report: Optional[Dict[str, Any]]) -> None:
    if not exp.dprime:
        return
    realized = (report or {}).get("training", {}).get("realized")
    if not isinstance(realized, dict) or any(k not in realized for k in
                                             ("raw_l2", "dprime_reference", "dprime_isotropic",
                                              "loss_gain")):
        raise RuntimeError("Missing training.realized diagnostics in the d' report")
    eps = (report or {}).get("epsilon", {}) or {}
    if exp.name == "MADRY_SP_AUTOBLIND" and eps.get("binding") not in ("blind_det", "nn"):
        raise RuntimeError(f"Expected auto_blind calibration binding, got {eps!r}")
    if exp.auto_sig and (eps.get("source") != "auto_sig" or not eps.get("eps_star")):
        raise RuntimeError(f"Expected an auto_sig budget in the report, got {eps!r}")
    if exp.auto_beh and (eps.get("source") != "auto_beh" or not eps.get("eps_star")):
        raise RuntimeError(f"Expected an auto_beh budget in the report, got {eps!r}")
    if (exp.overrides.get("adv_dprime_signal_projection") is not None
            and not (report or {}).get("signal_projection")):
        raise RuntimeError("Expected the signal_projection section in the d' report")


@dataclass
class Job:
    session: str
    seed: int
    exp: Experiment
    root: Path


def _new_train(cebra, job: Job, plan: Plan, arrays, iterations: int, args):
    _, x_valid, _, y_valid = arrays
    x_fit, y_fit = training_split(arrays, plan.train_bins)
    seed_all(job.seed)
    encoder = cebra.CEBRA(**encoder_config(job.exp, plan.mode, iterations, args.batch_size,
                                           args.device, job.seed, args.epsilon,
                                           channels=x_fit.shape[1]))
    if plan.mode == "supervised":
        # Behaviour-supervised encoder (Exp8): fit(X, y); validation labels never enter fit().
        encoder.fit(x_fit, y_fit)
        if len(getattr(encoder, "label_types_", [])) != 1:
            raise RuntimeError("Encoder did not register exactly one continuous behaviour label")
    else:
        encoder.fit(x_fit)  # time-only encoder: never pass behavioural labels to fit()
    report = getattr(encoder, "dprime_report_", None)
    _validate_training_report(job.exp, report)
    z_fit = np.asarray(encoder.transform(x_fit), dtype=np.float32)
    if len(z_fit) != len(x_fit) or not np.isfinite(z_fit).all():
        raise ValueError("Invalid encoder training embedding/alignment")
    decoder = train_decoder(z_fit, y_fit, job.seed + 100_000, torch.device(encoder.device_),
                            args.mlp_epochs)
    value = _score(encoder, decoder, x_valid, y_valid)

    ep, dp, mp = _checkpoint_paths(job.root, job.exp.name)
    _atomic_save(ep, lambda tmp: encoder.save(tmp, backend="sklearn"))
    _atomic_save(dp, lambda tmp: torch.save(decoder.state_dict(), tmp))
    if report is not None:  # reports first; the metadata is the final commit
        atomic_write_json(job.root / "reports" / f"{job.exp.name}.json", report)
    meta = {
        "experiment": job.exp.name, "session": job.session, "seed": job.seed,
        "mode": plan.mode, "suite": plan.suite, "iterations": iterations,
        "train_bins_used": int(len(x_fit)),
        "epochs_effective": iterations * args.batch_size / len(x_fit),
        "clean_r2": value, "epsilon_summary": epsilon_summary(report),
        "encoder_path": str(ep), "decoder_path": str(dp),
        "encoder_sha256": file_sha256(ep), "decoder_sha256": file_sha256(dp),
        "finished_utc": now_utc(), "stage": "trained",
    }
    atomic_write_json(mp, meta)
    print(f"CHECKPOINT {job.exp.name}: clean R2={value:.6f} at {ep}", flush=True)
    return encoder, decoder, meta, report


def _restore_train(cebra, job: Job, plan: Plan, arrays, iterations: int):
    _, x_valid, _, y_valid = arrays
    ep, dp, mp = _checkpoint_paths(job.root, job.exp.name)
    meta = json.loads(mp.read_text(encoding="utf-8"))
    expected = {"experiment": job.exp.name, "session": job.session, "seed": job.seed,
                "mode": plan.mode, "iterations": iterations}
    if any(meta.get(k) != v for k, v in expected.items()):
        raise RuntimeError(f"Checkpoint metadata mismatch for {job.exp.name}: {meta}")
    if file_sha256(ep) != meta["encoder_sha256"] or file_sha256(dp) != meta["decoder_sha256"]:
        raise RuntimeError(f"Checkpoint hash mismatch for {job.exp.name}; refusing corrupted files")
    # Checkpoints written by our own fork in this runner (not an untrusted download).
    encoder = cebra.CEBRA.load(str(ep), backend="sklearn", weights_only=False)
    decoder = TwoLayerMLP(LATENT_DIM, y_valid.shape[1]).to(torch.device(encoder.device_))
    try:
        state = torch.load(dp, map_location=encoder.device_, weights_only=True)
    except TypeError:
        state = torch.load(dp, map_location=encoder.device_)
    decoder.load_state_dict(state)
    value = _score(encoder, decoder, x_valid, y_valid)
    if abs(value - float(meta["clean_r2"])) > 0.0005:
        raise RuntimeError(f"Restored checkpoint changed R2: {value} vs {meta['clean_r2']}")
    report_path = job.root / "reports" / f"{job.exp.name}.json"
    report = (json.loads(report_path.read_text(encoding="utf-8")) if report_path.is_file()
              else getattr(encoder, "dprime_report_", None))
    _validate_training_report(job.exp, report)
    if report is not None and not report_path.is_file():
        atomic_write_json(report_path, report)
    return encoder, decoder, meta, report


def run_one(cebra, job: Job, plan: Plan, arrays, args):
    encoder = decoder = None
    x_fit, _ = training_split(arrays, plan.train_bins)
    iterations = iterations_for(plan, len(x_fit), args.batch_size)
    try:
        ep, dp, mp = _checkpoint_paths(job.root, job.exp.name)
        if mp.is_file() and ep.is_file() and dp.is_file():
            print(f"REUSE {job.exp.name}: loading saved encoder and decoder", flush=True)
            encoder, decoder, meta, report = _restore_train(cebra, job, plan, arrays, iterations)
        elif args.eval_only:
            raise FileNotFoundError(f"Cannot --eval-only: no checkpoint for {job.exp.name} ({mp})")
        else:
            print(f"TRAIN {job.exp.name}: session={job.session} seed={job.seed} mode={plan.mode} "
                  f"iterations={iterations} train_bins={len(x_fit)}", flush=True)
            encoder, decoder, meta, report = _new_train(cebra, job, plan, arrays, iterations, args)

        x_train, x_valid, y_train, y_valid = arrays
        from cebra.dprime.evaluation import evaluate_decoding
        # The reference and isotropic metrics: label-free whole residuals of the COMPLETE
        # training split for every model (also the truncated ones), as in Exp5-8. The options
        # of fork v5 are passed only when used, so the default call is the Exp5-11 one.
        extra = {}
        if args.eval_refine:
            extra["refine"] = args.eval_refine
        if args.eval_kappa:  # eps_beh of the complete training split (labels of the training split)
            extra["behaviour_train"] = y_train
        if args.no_eval_margins:
            extra["margins"] = False
        if args.eval_restarts > 1:
            extra["restarts"] = args.eval_restarts
        robust = evaluate_decoding(
            encoder, decoder, x_train, x_valid, y_valid,
            epsilons=args.eval_epsilons, metrics=("reference", "isotropic"),
            steps=args.eval_steps, batch_size=args.eval_batch_size,
            margin_windows=args.eval_margin_windows, margin_steps=args.eval_margin_steps,
            shift_threshold=args.eval_shift_threshold,
            contrastive=(plan.mode == "time_only" and not args.no_contrastive_margin),
            residuals="whole", labels_train=None, seed=job.seed + 200_000, **extra)
        if abs(float(robust["clean_r2"]) - float(meta["clean_r2"])) > 0.0005:
            raise RuntimeError(f"Clean R2 mismatch: training={meta['clean_r2']:.6f}, "
                               f"evaluator={robust['clean_r2']:.6f}; alignment mismatch")
        return float(meta["clean_r2"]), report, robust, meta
    finally:
        del encoder, decoder
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


# Training fingerprints are separate from evaluator fingerprints (--eval-only stays possible).
FORK_TRAIN_FILES = (
    "cebra/distributions/base.py", "cebra/dprime/training.py", "cebra/dprime/noise.py",
    "cebra/dprime/attacks.py", "cebra/dprime/calibration.py",
    "cebra/integrations/sklearn/cebra.py", "cebra/solver/base.py",
)
FORK_EVAL_FILES = FORK_TRAIN_FILES + ("cebra/dprime/evaluation.py",)


def _fingerprints(fork_dir: Path, paths: Tuple[str, ...]) -> dict:
    return {rel: file_sha256(fork_dir / rel) for rel in paths}


def config_manifest(args, plan: Plan, session: str, seed: int, n_train: int) -> dict:
    """Training settings of one (session, seed) folder: every arm valid for the mode is listed,
    so arms can be added to the folder later with the same manifest."""
    data_path = (args.data_dir / f"{session}.npz").resolve()
    used = n_train if plan.train_bins is None else plan.train_bins
    iterations = iterations_for(plan, used, args.batch_size)
    return json.loads(json.dumps({
        "schema": "exp9-v1", "mode": plan.mode,
        "fit_call": ("CEBRA.fit(x_train, y_train), conditional=time_delta, hybrid=False"
                     if plan.mode == "supervised" else "CEBRA.fit(x_train)"),
        "fork_dir": str(args.fork_dir.resolve()),
        "fork_fingerprints": _fingerprints(args.fork_dir, FORK_TRAIN_FILES),
        "data_path": str(data_path), "data_sha256": file_sha256(data_path),
        "session": session, "seed": seed, "epsilon": args.epsilon,
        "batch_size": args.batch_size, "max_iterations": plan.max_iterations,
        "epochs": plan.epochs, "iterations": iterations,
        "train_bins": plan.train_bins, "n_train_full": n_train, "n_train_used": used,
        "epochs_effective": iterations * args.batch_size / used,
        "mlp_epochs": args.mlp_epochs, "architecture": ARCH, "latent_dim": LATENT_DIM,
        "hidden": HIDDEN, "temperature": TEMPERATURE, "attack_steps": ATTACK_STEPS,
        "experiments": [{"name": e.name, "overrides": e.overrides} for e in catalogue()
                        if plan.mode == "supervised" or not e.supervised_only],
    }, sort_keys=True))


def eval_manifest(args, plan: Plan) -> dict:
    contrastive = plan.mode == "time_only" and not args.no_contrastive_margin
    return json.loads(json.dumps({
        "schema": "exp9-eval-v1", "eval_tag": args.eval_tag, "mode": plan.mode,
        "fork_dir": str(args.fork_dir.resolve()),
        "fork_fingerprints": _fingerprints(args.fork_dir, FORK_EVAL_FILES),
        "evaluation": {
            "epsilons": args.eval_epsilons, "steps": args.eval_steps,
            "batch_size": args.eval_batch_size, "margin_windows": args.eval_margin_windows,
            "margin_steps": args.eval_margin_steps, "shift_threshold": args.eval_shift_threshold,
            "contrastive": contrastive, "residuals": "whole", "labels_train": None,
            "metrics_fitted_on": "complete training split", "evaluation_seed_offset": 200_000,
            **({"refine": args.eval_refine} if args.eval_refine else {}),
            **({"kappa_behaviour": "training labels"} if args.eval_kappa else {}),
            **({"margins": False} if args.no_eval_margins else {}),
            **({"restarts": args.eval_restarts} if args.eval_restarts > 1 else {}),
        },
    }, sort_keys=True))


def prepare_folder(args, plan: Plan, session: str, seed: int) -> Path:
    """Create or check the manifests of one (session, seed) folder (coordinator only)."""
    root = session_root(plan, session, seed)
    for area in ("models", "training", "reports"):
        (root / area).mkdir(parents=True, exist_ok=True)
    for area in ("records", "logs", "robust_eval"):
        evaluation_dir(root, area, args.eval_tag).mkdir(parents=True, exist_ok=True)
    x_train = load_data(args.data_dir / f"{session}.npz")[0]
    manifest = config_manifest(args, plan, session, seed, len(x_train))
    path = root / "run_config.json"
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != manifest:
            if not args.eval_only:
                raise RuntimeError(f"Training configuration or fork changed in {root}. Use a NEW "
                                   "--output-root for training, or --eval-only --eval-tag v2.")
            print(f"WARNING: {root}: fork/config differs from the saved models; --eval-only "
                  "evaluates the original checkpoints.", flush=True)
    else:
        if args.eval_only:
            raise RuntimeError(f"--eval-only needs an existing run_config.json in {root}")
        if any((root / "models").glob("*.pt")):
            raise RuntimeError(f"Unmanifested model checkpoints in {root}; use a new folder")
        atomic_write_json(path, manifest)
    e_path = root / f"evaluation_config_{args.eval_tag}.json"
    e_manifest = eval_manifest(args, plan)
    if e_path.exists():
        if json.loads(e_path.read_text(encoding="utf-8")) != e_manifest:
            raise RuntimeError(f"Evaluation configuration changed for tag {args.eval_tag!r} in "
                               f"{root}; choose a NEW --eval-tag.")
    else:
        if any(evaluation_dir(root, "records", args.eval_tag).glob("*.json")):
            raise RuntimeError(f"Evaluation records without config in {root}; use a new --eval-tag")
        atomic_write_json(e_path, e_manifest)
    return root


def worker_run(args, plan: Plan, job: Job) -> int:
    """Exactly one physical GPU visible to this process."""
    begin = time.monotonic()
    rdir = evaluation_dir(job.root, "records", args.eval_tag)
    edir = evaluation_dir(job.root, "robust_eval", args.eval_tag)
    base = {"experiment": job.exp.name, "session": job.session, "seed": job.seed,
            "mode": plan.mode, "suite": plan.suite, "status": "error", "r2": None,
            "gpu_slot": args._gpu_slot,
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            "started_utc": now_utc(), "error": ""}
    try:
        if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
            raise RuntimeError("Worker must see exactly one CUDA GPU")
        torch.set_num_threads(args.cpu_threads)
        cebra = load_fork(args.fork_dir, job.exp,
                          needs_eval_options=bool(args.eval_refine or args.eval_kappa
                                                  or args.no_eval_margins
                                                  or args.eval_restarts > 1))
        arrays = load_data(args.data_dir / f"{job.session}.npz")
        value, report, robust, meta = run_one(cebra, job, plan, arrays, args)
        rpath = edir / f"{job.exp.name}.json"
        atomic_write_json(rpath, robust)
        base.update(r2=float(value), robust_eval_path=str(rpath),
                    ref_half=robust["reference"]["eps_at_half_r2"],
                    iso_half=robust["isotropic"]["eps_at_half_r2"],
                    iterations=meta["iterations"], train_bins_used=meta["train_bins_used"],
                    epochs_effective=meta["epochs_effective"],
                    encoder_path=meta["encoder_path"], decoder_path=meta["decoder_path"],
                    epsilon_summary=meta.get("epsilon_summary", ""))
        for key, metric in (("ref", "reference"), ("iso", "isotropic")):
            entry = robust[metric]
            if "half_r2_refined" in entry:
                base[f"{key}_half_refined"] = entry["eps_at_half_r2_refined"]
                base[f"{key}_status"] = entry["half_r2_refined"]["status"]
            if "eps_beh" in entry:
                base[f"{key}_eps_beh"] = entry["eps_beh"]
                base[f"{key}_kappa"] = entry["kappa"]
        if job.exp.dprime:
            realized = report["training"]["realized"]
            epsilon = report.get("epsilon", {}) or {}
            projection = (report.get("signal_projection") or {}).get("members") or [{}]
            base.update(eps_star=epsilon.get("eps_star"), eps_source=epsilon.get("source"),
                        eps_sig=epsilon.get("eps_sig"), x_train=epsilon.get("x_train"),
                        eps_beh=epsilon.get("eps_beh"), eps_binding=epsilon.get("binding"),
                        signal_modes_removed=projection[0].get("removed"),
                        loss_gain_median=realized["loss_gain"]["median"],
                        raw_l2_median=realized["raw_l2"]["median"],
                        dprime_reference_median=realized["dprime_reference"]["median"])
        base["status"] = "success"
        print(f"{job.session} seed{job.seed} {job.exp.name}: R2={value:.6f} "
              f"ref_half={base['ref_half']}", flush=True)
        if args.report_eps:
            print(f"{job.exp.name} budget: {base['epsilon_summary']}", flush=True)
    except BaseException as exc:
        base["status"] = "error"
        base["error"] = f"{type(exc).__name__}: {exc}"
        traceback.print_exc()
    finally:
        base["elapsed_seconds"] = round(time.monotonic() - begin, 3)
        base["finished_utc"] = now_utc()
        atomic_write_json(record_path(rdir, job.exp.name), base)
    return 0 if base["status"] == "success" else 1


SUMMARY_FIELDS = ["session", "seed", "experiment", "status", "r2", "ref_half", "iso_half",
                  "ref_half_refined", "iso_half_refined", "ref_status", "iso_status",
                  "ref_eps_beh", "iso_eps_beh", "ref_kappa", "iso_kappa",
                  "iterations", "train_bins_used", "epochs_effective", "eps_source", "eps_star",
                  "eps_sig", "eps_beh", "eps_binding", "x_train", "signal_modes_removed",
                  "loss_gain_median", "raw_l2_median",
                  "dprime_reference_median", "elapsed_seconds", "error"]


def write_snapshots(plan: Plan, tag: str) -> Path:
    """results.csv / .txt per (session, seed) folder and one summary.csv for the whole suite."""
    rows = []
    for session in plan.sessions:
        for seed in plan.seeds:
            root = session_root(plan, session, seed)
            files = record_files(root, tag)
            if not files:
                continue
            local, lines = [], []
            for path in files:
                record = json.loads(path.read_text(encoding="utf-8"))
                row = {k: record.get(k, "") for k in SUMMARY_FIELDS}
                row.update(session=session, seed=seed, experiment=record.get("experiment"))
                local.append(row)
                lines.append(f"{row['experiment']}: R2 = {row['r2']} ref_half = {row['ref_half']}"
                             if record.get("status") == "success"
                             else f"{row['experiment']}: ERROR: {record.get('error')}")
            stream = io.StringIO()
            writer = csv.DictWriter(stream, fieldnames=SUMMARY_FIELDS)
            writer.writeheader()
            writer.writerows(local)
            suffix = "" if tag == "v1" else f"_{tag}"
            atomic_write_text(root / f"results{suffix}.csv", stream.getvalue())
            atomic_write_text(root / f"results{suffix}.txt", "\n".join(lines) + "\n")
            rows += local
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=SUMMARY_FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    path = plan.output_root.resolve() / ("summary.csv" if tag == "v1" else f"summary_{tag}.csv")
    atomic_write_text(path, stream.getvalue())
    return path


def gpu_tokens(workers: int) -> List[str]:
    if workers < 1:
        raise ValueError("--gpu-workers must be at least 1")
    if not torch.cuda.is_available():
        raise RuntimeError("No CUDA GPU available")
    count = torch.cuda.device_count()
    if count < workers:
        raise RuntimeError(f"Requested {workers} GPU workers but only {count} CUDA devices visible")
    visibility = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if visibility and visibility != "-1":
        tokens = [s.strip() for s in visibility.split(",") if s.strip()]
        if len(tokens) < workers:
            raise RuntimeError(f"CUDA_VISIBLE_DEVICES={visibility!r} has fewer than {workers} entries")
        return tokens[:workers]
    return [str(i) for i in range(workers)]


def plan_jobs(plan: Plan) -> List[Job]:
    return [Job(session, seed, exp, session_root(plan, session, seed))
            for session in plan.sessions for seed in plan.seeds for exp in plan.arms]


def worker_command(args, plan: Plan, job: Job, slot: int) -> List[str]:
    cmd = [sys.executable, "-u", str(Path(__file__).resolve()), "--_worker",
           "--suite", "custom", "--mode", plan.mode, "--arms", job.exp.name,
           "--sessions", job.session, "--seeds", str(job.seed),
           "--output-root", str(plan.output_root.resolve()), "--_gpu_slot", str(slot),
           "--fork-dir", str(args.fork_dir.resolve()), "--data-dir", str(args.data_dir.resolve()),
           "--epsilon", str(args.epsilon), "--batch-size", str(args.batch_size),
           "--mlp-epochs", str(args.mlp_epochs), "--device", args.device,
           "--cpu-threads", str(args.cpu_threads), "--eval-steps", str(args.eval_steps),
           "--eval-batch-size", str(args.eval_batch_size),
           "--eval-margin-windows", str(args.eval_margin_windows),
           "--eval-margin-steps", str(args.eval_margin_steps),
           "--eval-shift-threshold", str(args.eval_shift_threshold),
           "--eval-epsilons", *[str(v) for v in args.eval_epsilons], "--eval-tag", args.eval_tag]
    cmd += (["--epochs", repr(plan.epochs)] if plan.epochs is not None
            else ["--max-iterations", str(plan.max_iterations)])
    if plan.train_bins is not None:
        cmd += ["--train-bins", str(plan.train_bins)]
    if args.eval_refine:
        cmd += ["--eval-refine", str(args.eval_refine)]
    if args.eval_restarts > 1:
        cmd += ["--eval-restarts", str(args.eval_restarts)]
    for flag, on in (("--eval-only", args.eval_only), ("--no-contrastive-margin",
                     args.no_contrastive_margin), ("--report-eps", args.report_eps),
                     ("--eval-kappa", args.eval_kappa), ("--no-eval-margins", args.no_eval_margins)):
        if on:
            cmd.append(flag)
    return cmd


def orchestrate(args, plan: Plan) -> int:
    jobs = plan_jobs(plan)
    if SUITES[plan.suite]["sessions"] == "random" and not args.no_predictions:
        write_predictions(args, plan)
    for session in plan.sessions:
        for seed in plan.seeds:
            prepare_folder(args, plan, session, seed)
    pending = []
    for job in jobs:
        record = read_record(evaluation_dir(job.root, "records", args.eval_tag), job.exp.name)
        if record is not None and not args.resume:
            raise RuntimeError(f"Records already exist ({job.session} seed{job.seed} "
                               f"{job.exp.name}); add --resume or use a fresh --eval-tag")
        if not (record is not None and record.get("status") == "success"):
            pending.append(job)
    write_snapshots(plan, args.eval_tag)
    if not pending:
        print(f"All {len(jobs)} jobs already successful (tag={args.eval_tag})", flush=True)
        return 0
    tokens = gpu_tokens(args.gpu_workers)
    todo: "queue.Queue[Job]" = queue.Queue()
    for job in pending:
        todo.put(job)
    print(f"[EXP9 {plan.suite}] runner={Path(__file__).resolve()} fork={args.fork_dir.resolve()}",
          flush=True)
    print(f"{len(pending)}/{len(jobs)} jobs on {args.gpu_workers} GPUs; mode={plan.mode}; "
          f"output={plan.output_root.resolve()}", flush=True)
    lock = threading.Lock()
    failures: List[str] = []

    def gpu_loop(slot: int, token: str):
        while True:
            try:
                job = todo.get_nowait()
            except queue.Empty:
                return
            label = f"{job.session} seed{job.seed} {job.exp.name}"
            rdir = evaluation_dir(job.root, "records", args.eval_tag)
            log = evaluation_dir(job.root, "logs", args.eval_tag) / f"{job.exp.name}.log"
            env = dict(os.environ)
            env["CUDA_VISIBLE_DEVICES"] = token
            for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                        "NUMEXPR_NUM_THREADS"):
                env[key] = str(args.cpu_threads)
            with lock:
                print(f"[GPU {slot}] START {label}", flush=True)
            try:
                with log.open("w", encoding="utf-8") as f:
                    result = subprocess.run(worker_command(args, plan, job, slot), env=env,
                                            stdout=f, stderr=subprocess.STDOUT, check=False)
                record = read_record(rdir, job.exp.name)
                if record is None:
                    record = dict(experiment=job.exp.name, session=job.session, seed=job.seed,
                                  status="error", r2=None,
                                  error=f"Worker exited {result.returncode}; see {log}")
                    atomic_write_json(record_path(rdir, job.exp.name), record)
                if result.returncode != 0 and record["status"] == "success":
                    record.update(status="error", error=f"Worker exited {result.returncode}")
                    atomic_write_json(record_path(rdir, job.exp.name), record)
            except Exception as exc:
                record = dict(experiment=job.exp.name, session=job.session, seed=job.seed,
                              status="error", r2=None,
                              error=f"Coordinator {type(exc).__name__}: {exc}")
                atomic_write_json(record_path(rdir, job.exp.name), record)
            with lock:
                write_snapshots(plan, args.eval_tag)
                if record["status"] == "success":
                    print(f"[GPU {slot}] DONE {label}: R2={record['r2']:.6f} "
                          f"ref_half={record.get('ref_half')} ({record.get('elapsed_seconds')}s)",
                          flush=True)
                else:
                    failures.append(label)
                    print(f"[GPU {slot}] FAILED {label}: {record.get('error')} [log={log}]",
                          flush=True)
            todo.task_done()

    threads = [threading.Thread(target=gpu_loop, args=(i, tokens[i]))
               for i in range(args.gpu_workers)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    summary = write_snapshots(plan, args.eval_tag)
    print(f"Finished: {len(pending) - len(failures)}/{len(pending)} successful; summary={summary}",
          flush=True)
    return 1 if failures else 0


def show_plan(args, plan: Plan) -> None:
    print(f"suite={plan.suite} mode={plan.mode} output={plan.output_root}")
    if SUITES[plan.suite]["sessions"] == "random" and not args.sessions:
        print(f"sessions drawn at random (seed {args.selection_seed}), stored in "
              f"{Path(args.selection_file).resolve()}")
    print(f"arms={[e.name for e in plan.arms]} seeds={list(plan.seeds)}")
    for session in plan.sessions:
        path = args.data_dir / f"{session}.npz"
        try:
            with np.load(path, allow_pickle=False) as f:
                n_train = int(f["train_data"].shape[0])
        except (OSError, KeyError) as exc:
            print(f"  {session}: data not readable ({type(exc).__name__})")
            continue
        used = n_train if plan.train_bins is None else min(plan.train_bins, n_train)
        iterations = iterations_for(plan, used, args.batch_size)
        print(f"  {session}: n_train={n_train} used={used} iterations={iterations} "
              f"epochs={iterations * args.batch_size / used:.0f}")
    print(f"{len(plan_jobs(plan))} jobs")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--suite", choices=tuple(SUITES), default="custom")
    p.add_argument("--mode", choices=MODES, default=None, help="Overrides the suite's mode")
    p.add_argument("--arms", nargs="+", default=None, help="Overrides the suite's arms")
    p.add_argument("--sessions", nargs="+", default=None, help="Overrides the suite's sessions")
    p.add_argument("--seeds", nargs="+", type=int, default=None, help="Default: 42 43 44")
    p.add_argument("--max-iterations", type=int, default=None,
                   help="Fixed number of iterations (overrides the suite)")
    p.add_argument("--epochs", type=float, default=None,
                   help="Iterations = round(epochs * n_train / batch_size) per session")
    p.add_argument("--train-bins", type=int, default=None,
                   help="Train on the first N training bins only")
    p.add_argument("--random-sessions", type=int, default=20,
                   help="newsess suites: number of new sessions drawn from --data-dir")
    p.add_argument("--selection-seed", type=int, default=2026)
    p.add_argument("--selection-file", type=Path, default=DEFAULT_SELECTION_FILE,
                   help="Where the drawn sessions are stored (shared by the newsess suites)")
    p.add_argument("--min-train-bins", type=int, default=2000)
    p.add_argument("--min-channels", type=int, default=10)
    p.add_argument("--no-predictions", action="store_true",
                   help="newsess suites: skip the pre-registered predictions")
    p.add_argument("--output-root", type=Path, default=None,
                   help="Results folder (default: the suite's DPRIME_EXP9_* folder)")
    p.add_argument("--list", action="store_true", help="List the suites and arms and exit")
    p.add_argument("--dry-run", action="store_true", help="Print the planned jobs and exit")
    p.add_argument("--fork-dir", type=Path, default=DEFAULT_FORK_DIR)
    p.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    p.add_argument("--epsilon", type=float, default=PGD_EPS,
                   help="Placeholder adv_epsilon of the d' arms (as in Exp5-8)")
    p.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    p.add_argument("--mlp-epochs", type=int, default=MLP_EPOCHS)
    p.add_argument("--device", default=DEVICE)
    p.add_argument("--eval-epsilons", nargs="+", type=float, default=[0.5, 1.0, 2.0, 4.0, 8.0, 16.0])
    p.add_argument("--eval-steps", type=int, default=20)
    p.add_argument("--eval-batch-size", type=int, default=512)
    p.add_argument("--eval-margin-windows", type=int, default=1024)
    p.add_argument("--eval-margin-steps", type=int, default=100)
    p.add_argument("--eval-shift-threshold", type=float, default=0.5)
    p.add_argument("--no-contrastive-margin", action="store_true",
                   help="Time-only: skip the contrastive DDN margin")
    p.add_argument("--eval-refine", type=int, default=0,
                   help="Bisection steps of the half-R2 crossing (fork v5; 0: off)")
    p.add_argument("--eval-kappa", action="store_true",
                   help="Also report eps_beh and kappa = eps1/2 / eps_beh per metric (fork v5)")
    p.add_argument("--no-eval-margins", action="store_true",
                   help="Skip the DDN decoding / contrastive margins")
    p.add_argument("--eval-restarts", type=int, default=1,
                   help="APGD restarts per budget (stronger-attack audit; 1: as Exp5-12)")
    p.add_argument("--report-eps", action="store_true", help="Print the budget of every run")
    p.add_argument("--gpu-workers", type=int, default=2)
    p.add_argument("--cpu-threads", type=int, default=2)
    p.add_argument("--eval-only", action="store_true",
                   help="Require existing checkpoints; reevaluate without retraining")
    p.add_argument("--eval-tag", default="v1")
    p.add_argument("--resume", action="store_true", help="Skip successful jobs")
    p.add_argument("--_worker", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--_gpu_slot", type=int, default=-1, help=argparse.SUPPRESS)
    return p


def main() -> int:
    args = build_parser().parse_args()
    if args.list:
        for name, suite in SUITES.items():
            policy = (f"{suite['epochs']:g} epochs" if suite["epochs"]
                      else f"{suite['max_iterations']} iterations")
            sessions = (f"random {args.random_sessions}" if suite["sessions"] == "random"
                        else len(suite["sessions"]))
            print(f"{name:13s} mode={suite['mode']} {policy} train_bins={suite['train_bins']} "
                  f"arms={list(suite['arms'])} sessions={sessions} output={suite['output']}")
        print("arms:")
        for e in catalogue():
            print(f"  {e.name}{' (supervised only)' if e.supervised_only else ''}")
        return 0
    plan = resolve_plan(args)
    if args.dry_run:
        show_plan(args, plan)
        if SUITES[plan.suite]["sessions"] == "random" and not args.no_predictions:
            write_predictions(args, plan)
        return 0
    if args.batch_size < 1 or args.mlp_epochs < 1:
        raise ValueError("Batch size and MLP epochs must be >= 1")
    if (args.eval_steps < 1 or args.eval_batch_size < 1 or args.eval_margin_windows < 1
            or args.eval_margin_steps < 1):
        raise ValueError("Evaluation steps, batch size and margin controls must be positive")
    if (not args.eval_epsilons or any(not np.isfinite(e) or e < 0 for e in args.eval_epsilons)
            or len(set(args.eval_epsilons)) != len(args.eval_epsilons)
            or args.eval_epsilons != sorted(args.eval_epsilons)):
        raise ValueError("--eval-epsilons must be unique sorted nonnegative numbers")
    if not np.isfinite(args.eval_shift_threshold) or args.eval_shift_threshold <= 0:
        raise ValueError("--eval-shift-threshold must be finite and > 0")
    if args.eval_refine < 0:
        raise ValueError("--eval-refine must be >= 0")
    if args.eval_restarts < 1:
        raise ValueError("--eval-restarts must be >= 1")
    if args.cpu_threads < 1:
        raise ValueError("--cpu-threads must be at least 1")
    if args.device not in ("cuda_if_available", "cuda", "cuda:0"):
        raise ValueError("With one-GPU workers, --device must be cuda_if_available, cuda or cuda:0")
    if not args.eval_tag.replace("_", "").replace("-", "").isalnum() or len(args.eval_tag) > 48:
        raise ValueError("--eval-tag must be a short alphanumeric/-/_ label")
    for session in plan.sessions:
        if not (args.data_dir / f"{session}.npz").is_file():
            raise FileNotFoundError(f"No data for {session} in {args.data_dir}")
    if args._worker:
        jobs = plan_jobs(plan)
        if len(jobs) != 1:
            raise ValueError("A worker runs exactly one (session, seed, arm) job")
        return worker_run(args, plan, jobs[0])
    return orchestrate(args, plan)


if __name__ == "__main__":
    raise SystemExit(main())
