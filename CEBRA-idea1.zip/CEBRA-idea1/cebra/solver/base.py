#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""This package contains abstract base classes for different solvers.

Solvers are used to package models, criterions and optimizers and implement training
loops. When subclassing abstract solvers, in the simplest case only the
:py:meth:`Solver._inference` needs to be overridden.

For more complex use cases, the :py:meth:`Solver.step` and
:py:meth:`Solver.fit` method can be overridden to
implement larger changes to the training loop.

Adversarial training (ACORN)
----------------------------

This fork adds a configurable PGD attack to the training loop. The attack is
controlled by the following solver attributes (all of them are plain dataclass
fields and can therefore be forwarded from :py:class:`cebra.CEBRA`):

``training_mode``
    ``"clean"`` (default) or ``"adversarial"``.
``attack_norm``
    ``"linf"`` or ``"l2"``.
``adv_epsilon`` / ``adv_alpha`` / ``adv_steps``
    Perturbation budget, PGD step size, and number of ascent steps.
``attack_target``
    Which view(s) of the contrastive triplet are perturbed. One of
    ``"reference"``, ``"positive"``, ``"negative"``, ``"ref_positive"``,
    ``"ref_negative"``, ``"pos_negative"``, ``"all"``.
``adv_restarts``
    Number of independent random initialisations (multi-start PGD). The
    candidate with the highest InfoNCE loss is used for the adversarial update.
``adv_best_iterate``
    If ``True``, the strongest iterate along the PGD trajectory is used instead
    of the last one.
``adv_budget_mode``
    ``"per_view"`` (each attacked view gets its own full epsilon) or
    ``"shared"`` (the budget is split so that the *joint* perturbation stays
    inside a single epsilon-ball).
``adv_random_start``
    Whether PGD starts from a random point inside the epsilon-ball.
``adv_eval_mode``
    If ``True``, the encoder is switched to ``eval()`` while crafting the
    attack. This avoids polluting BatchNorm running statistics and removes
    dropout noise from the inner maximisation.
"""

import abc
import contextlib
import copy
import math
import numbers
import os
from typing import Callable, Dict, List, Literal, Optional, Sequence, Tuple

import literate_dataclasses as dataclasses
import torch

import cebra
import cebra.data
import cebra.io
import cebra.models
from cebra.solver.util import Meter
from cebra.solver.util import ProgressBar

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor):
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1),
                      device=t.device,
                      dtype=t.dtype)


def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
    """Project adv back to the closed L2 ball of radius ε around orig."""
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta


def _scale_negative_gradient(embedding: torch.Tensor,
                             scale: float) -> torch.Tensor:
    """Keep negative embeddings unchanged and scale their backward gradient.

    Used only by the outer adversarial training loss, never by PGD. Scaling
    after the encoder preserves gradients through the reference and positive
    branches of a shared model, and leaves criterion parameters unaffected.
    """
    if scale == 1.0:
        return embedding
    detached = embedding.detach()
    if scale == 0.0:
        return detached
    return detached + scale * (embedding - detached)


def _validate_negative_grad_scale(scale):
    if (isinstance(scale, bool) or not isinstance(scale, numbers.Real) or
            not 0.0 <= scale <= 1.0):
        raise ValueError(
            "adv_negative_grad_scale must be a finite real number in [0, 1], "
            f"got {scale!r}.")


def clone_batch(batch):
    """Shallow-copy a batch container and clone/detach its tensor fields."""
    # 1) shallow-copy the Batch container
    new_batch = copy.copy(batch)

    # 2) for each tensor attribute in the batch, clone & detach
    tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
    for field in tensor_fields:
        tensor = getattr(batch, field, None)
        if isinstance(tensor, torch.Tensor):
            setattr(new_batch, field, tensor.clone().detach())

    return new_batch


def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
    """
    Shuffle the second (M) dimension of a 3D tensor.

    Parameters:
        data (torch.Tensor): Input tensor of shape [N, M, D].

    Returns:
        torch.Tensor: Tensor with shuffled M dimension.
    """
    N, M, D = data.size()
    perm_M = torch.randperm(M, device=data.device)
    return data[:, perm_M, :]


# ----------------------------------------------------------------------
# Adversarial attack helpers
# ----------------------------------------------------------------------

#: Mapping from the ``attack_target`` configuration string to the batch views
#: that are perturbed by the PGD attack.
ATTACK_TARGETS: Dict[str, Tuple[str, ...]] = {
    "reference": ("reference",),
    "positive": ("positive",),
    "negative": ("negative",),
    "ref_positive": ("reference", "positive"),
    "ref_negative": ("reference", "negative"),
    "pos_negative": ("positive", "negative"),
    "all": ("reference", "positive", "negative"),
}

#: Aliases so that a few natural spellings also work.
_TARGET_ALIASES = {
    "ref": "reference",
    "pos": "positive",
    "neg": "negative",
    "ref+pos": "ref_positive",
    "ref+neg": "ref_negative",
    "pos+neg": "pos_negative",
    "reference_positive": "ref_positive",
    "reference_negative": "ref_negative",
    "positive_negative": "pos_negative",
    "ref_pos_neg": "all",
}


def _normalize_attack_target(target: str) -> str:
    if not isinstance(target, str):
        raise ValueError(
            f"attack_target must be a string, got {type(target)}. "
            f"Valid values: {sorted(ATTACK_TARGETS)}.")
    key = target.strip().lower()
    key = _TARGET_ALIASES.get(key, key)
    if key not in ATTACK_TARGETS:
        raise ValueError(
            f"Unknown attack_target={target!r}. Valid values are "
            f"{sorted(ATTACK_TARGETS)} (aliases: {sorted(_TARGET_ALIASES)}).")
    return key


def _as_batch_list(batch) -> Tuple[List["cebra.data.Batch"], bool]:
    """Normalise single-session / multi-session batches to a list.

    Returns:
        The list of batches, and a flag whether the original input was a list.
    """
    if isinstance(batch, (list, tuple)):
        return list(batch), True
    return [batch], False


def _rebuild_batch(batches: Sequence["cebra.data.Batch"], is_list: bool,
                   replacements: Dict[Tuple[int, str], torch.Tensor]):
    """Build new batch object(s) with some views replaced.

    ``index`` and ``index_reversed`` are preserved, which is required for the
    multi-session solvers (they use ``index_reversed`` to mix positives).
    """
    rebuilt = []
    for i, batch in enumerate(batches):
        rebuilt.append(
            cebra.data.Batch(
                reference=replacements.get((i, "reference"), batch.reference),
                positive=replacements.get((i, "positive"), batch.positive),
                negative=replacements.get((i, "negative"), batch.negative),
                index=batch.index,
                index_reversed=batch.index_reversed,
            ))
    return rebuilt if is_list else rebuilt[0]


@dataclasses.dataclass
class Solver(abc.ABC, cebra.io.HasDevice):
    """Solver base class.

    A solver contains helper methods for bundling a model, criterion and optimizer.

    Attributes:
        model: The encoder for transforming reference, positive and negative samples.
        criterion: The criterion computed from the similarities between positive pairs
            and negative pairs. The criterion can have trainable parameters on its own.
        optimizer: A PyTorch optimizer for updating model and criterion parameters.
        history: Deprecated since 0.0.2. Use :py:attr:`log`.
        decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
            decoding. See the arguments of :py:meth:`fit`.
        log: The logs recorded during training, typically contains the ``total`` loss as well
            as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
            criterions in CEBRA, also contains the value of the ``temperature``.
        tqdm_on: Use ``tqdm`` for showing a progress bar during training.
        training_mode: The training mode, either "clean" or "adversarial".
        adv_epsilon: The maximum perturbation allowed for adversarial training.
        adv_alpha: The step size for adversarial training.
        adv_steps: The number of PGD steps (inner maximisation).
        attack_norm: The norm used for adversarial training, either "l2" or "linf".
        attack_target: Which view(s) of the contrastive triplet are perturbed.
            One of ``"reference"``, ``"positive"``, ``"negative"``,
            ``"ref_positive"``, ``"ref_negative"``, ``"pos_negative"``, ``"all"``.
        adv_restarts: Number of independent random initialisations for
            multi-start PGD. The strongest candidate is used for training.
        adv_best_iterate: Use the strongest iterate along the PGD trajectory
            instead of the last one.
        adv_budget_mode: ``"per_view"`` gives every attacked view its own
            epsilon; ``"shared"`` splits one joint epsilon-ball between them.
        adv_random_start: Initialise PGD at a random point inside the ball.
        adv_eval_mode: Put the encoder in ``eval()`` mode while crafting the
            attack (no dropout noise / no BatchNorm statistics pollution).
        adv_clip_min: Optional lower bound the adversarial samples are clamped
            to, e.g. ``0.0`` for data normalised to ``[0, 1]``. ``None``
            (default) only enforces the epsilon-ball, not the data domain.
        adv_clip_max: Optional upper bound, see ``adv_clip_min``.
        adv_negative_grad_scale: Gradient multiplier in [0, 1] for the negative
            embedding branch of the outer adversarial update. 0 detaches that
            branch; 1 preserves the original behavior. Does not change the
            clean update, PGD, or the forward loss. Applies independently of
            attack_target, including both objectives in hybrid training.
    """

    model: torch.nn.Module
    criterion: torch.nn.Module
    optimizer: torch.optim.Optimizer
    history: List = dataclasses.field(default_factory=list)
    decode_history: List = dataclasses.field(default_factory=list)
    log: Dict = dataclasses.field(default_factory=lambda: ({
        "pos": [],
        "neg": [],
        "total": [],
        "temperature": []
    }))
    tqdm_on: bool = True

    # --- adversarial training -------------------------------------------
    training_mode: str = "clean"
    adv_epsilon: float = 0.05
    adv_alpha: float = 0.01
    adv_steps: int = 10
    attack_norm: str = "linf"
    attack_target: str = "reference"
    adv_restarts: int = 1
    adv_best_iterate: bool = False
    adv_budget_mode: str = "per_view"
    adv_random_start: bool = True
    adv_eval_mode: bool = False
    adv_clip_min: Optional[float] = None
    adv_clip_max: Optional[float] = None
    adv_negative_grad_scale: float = 1.0

    def __post_init__(self):
        cebra.io.HasDevice.__init__(self)
        self.best_loss = float("inf")
        self.last_attack_info = None
        _validate_negative_grad_scale(self.adv_negative_grad_scale)
        if self.training_mode == "adversarial":
            self._validate_attack_config()

    # ------------------------------------------------------------------
    # configuration
    # ------------------------------------------------------------------
    def _validate_attack_config(self):
        _validate_negative_grad_scale(self.adv_negative_grad_scale)
        self.attack_target = _normalize_attack_target(self.attack_target)
        if self.attack_norm not in ("linf", "l2"):
            raise ValueError(
                f"attack_norm must be 'linf' or 'l2', got {self.attack_norm!r}.")
        if self.adv_budget_mode not in ("per_view", "shared"):
            raise ValueError(
                "adv_budget_mode must be 'per_view' or 'shared', got "
                f"{self.adv_budget_mode!r}.")
        if int(self.adv_restarts) < 1:
            raise ValueError(
                f"adv_restarts must be >= 1, got {self.adv_restarts}.")
        if int(self.adv_steps) < 0:
            raise ValueError(f"adv_steps must be >= 0, got {self.adv_steps}.")

    @property
    def attack_views(self) -> Tuple[str, ...]:
        """The batch views that the configured attack perturbs."""
        return ATTACK_TARGETS[_normalize_attack_target(self.attack_target)]

    def _view_epsilon(self, num_views: int) -> float:
        """Per-view perturbation budget.

        Note:
            Under the L-infinity norm the joint ball of radius ``eps`` in the
            concatenated input space is *exactly* the product of the per-view
            balls of radius ``eps``, so ``"shared"`` and ``"per_view"`` coincide.
            The two modes only differ for the L2 norm, where the joint budget is
            split as ``eps / sqrt(k)``.
        """
        epsilon = float(self.adv_epsilon)
        if num_views <= 1 or self.adv_budget_mode == "per_view":
            return epsilon
        if self.attack_norm == "l2":
            return epsilon / math.sqrt(num_views)
        return epsilon

    @contextlib.contextmanager
    def _attack_model_mode(self):
        """Optionally switch the encoder to eval mode during the attack."""
        if not self.adv_eval_mode:
            yield
            return
        was_training = bool(getattr(self.model, "training", False))
        self.model.eval()
        try:
            yield
        finally:
            if was_training:
                self.model.train()

    # ------------------------------------------------------------------
    # serialisation
    # ------------------------------------------------------------------
    def state_dict(self) -> dict:
        """Return a dictionary fully describing the current solver state.

        Returns:
            State dictionary, including the state dictionary of the models and
            optimizer. Also contains the training history and the CEBRA version
            the model was trained with.
        """

        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "loss": torch.tensor(self.history),
            "decode": self.decode_history,
            "criterion": self.criterion.state_dict(),
            "version": cebra.__version__,
            "log": self.log,
        }

    def load_state_dict(self, state_dict: dict, strict: bool = True):
        """Update the solver state with the given state_dict.

        Args:
            state_dict: Dictionary with parameters for the `model`, `optimizer`,
                and the past loss history for the solver.
            strict: Make sure all states can be loaded. Set to `False` to allow
                to partially load the state for all given keys.
        """

        def _contains(key):
            if key in state_dict:
                return True
            elif strict:
                raise KeyError(
                    f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
                )
            return False

        def _get(key):
            return state_dict.get(key)

        if _contains("model"):
            self.model.load_state_dict(_get("model"))
        if _contains("criterion"):
            self.criterion.load_state_dict(_get("criterion"))
        if _contains("optimizer"):
            self.optimizer.load_state_dict(_get("optimizer"))
        # TODO(stes): This will be deprecated at some point; the "log" attribute
        # holds the same information.
        if _contains("loss"):
            self.history = _get("loss").cpu().numpy().tolist()
        if _contains("decode"):
            self.decode_history = _get("decode")
        if _contains("log"):
            self.log = _get("log")

    @property
    def num_parameters(self) -> int:
        """Total number of parameters in the encoder and criterion."""
        return sum(p.numel() for p in self.parameters())

    def parameters(self):
        """Iterate over all parameters."""
        for parameter in self.model.parameters():
            yield parameter

        for parameter in self.criterion.parameters():
            yield parameter

    def _get_loader(self, loader):
        return ProgressBar(
            loader,
            "tqdm" if self.tqdm_on else "off",
        )

    def fit(
            self,
            loader: cebra.data.Loader,
            valid_loader: cebra.data.Loader = None,
            *,
            save_frequency: int = None,
            valid_frequency: int = None,
            decode: bool = False,
            logdir: str = None,
            save_hook: Callable[[int, "Solver"], None] = None,
    ):
        """Train model for the specified number of steps.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            valid_loader: Data loader used for validation of the model.
            save_frequency: If not `None`, the frequency for automatically saving model checkpoints
                to `logdir`.
            valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
            logdir:  The logging directory for writing model checkpoints. The checkpoints
                can be read again using the `solver.load` function, or manually via loading the
                state dict.

        TODO:
            * Refine the API here. Drop the validation entirely, and implement this via a hook?
        """

        self.to(loader.device)

        iterator = self._get_loader(loader)
        self.model.train()
        for num_steps, batch in iterator:
            stats = self.step(batch)
            iterator.set_description(stats)

            if save_frequency is None:
                continue
            save_model = num_steps % save_frequency == 0
            run_validation = (valid_loader
                              is not None) and (num_steps % valid_frequency
                                                == 0)
            if run_validation:
                validation_loss = self.validation(valid_loader)
                if self.best_loss is None or validation_loss < self.best_loss:
                    self.best_loss = validation_loss
                    self.save(logdir, "checkpoint_best.pth")
            if save_model:
                if decode:
                    self.decode_history.append(
                        self.decoding(loader, valid_loader))
                if save_hook is not None:
                    save_hook(num_steps, self)
                if logdir is not None:
                    self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

    # ------------------------------------------------------------------
    # losses
    # ------------------------------------------------------------------
    def _attack_loss(self, batch) -> torch.Tensor:
        """Scalar objective that the inner maximisation ascends.

        Subclasses with a different ``_inference`` signature (e.g. the
        multi-objective solvers) override this method.
        """
        prediction = self._inference(batch)
        loss, _, _ = self.criterion(prediction.reference, prediction.positive,
                                    prediction.negative)
        return loss

    def _training_loss(
        self, batch, *, negative_grad_scale: float = 1.0
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Forward pass + criterion used for the parameter updates.

        Args:
            negative_grad_scale: Backward multiplier for negative embeddings.
                The clean update uses 1; the adversarial update passes the
                configured adv_negative_grad_scale.

        Returns:
            The differentiable loss and a dictionary of scalar statistics.
        """
        prediction = self._inference(batch)
        negative = _scale_negative_gradient(prediction.negative,
                                             negative_grad_scale)
        loss, align, uniform = self.criterion(prediction.reference,
                                              prediction.positive,
                                              negative)
        stats = {
            "pos": align.item(),
            "neg": uniform.item(),
            "total": loss.item(),
            "temperature": self.criterion.temperature,
        }
        return loss, stats

    # ------------------------------------------------------------------
    # PGD attack
    # ------------------------------------------------------------------
    def _clip_domain(self, x: torch.Tensor) -> torch.Tensor:
        """Clamp to the valid data range, if one was configured."""
        if self.adv_clip_min is None and self.adv_clip_max is None:
            return x
        return x.clamp(min=self.adv_clip_min, max=self.adv_clip_max)

    def _init_perturbed(self, orig: torch.Tensor,
                        epsilon: float) -> torch.Tensor:
        """Random initialisation inside the epsilon-ball around ``orig``."""
        if not self.adv_random_start:
            return orig.clone().detach()
        if self.attack_norm == "linf":
            noise = torch.empty_like(orig).uniform_(-epsilon, epsilon)
        else:
            noise = _l2_normalize(torch.randn_like(orig))
            noise = noise * _rand_radius_like(orig) * epsilon
        return self._clip_domain(orig + noise).detach()

    def _pgd_step(self, x: torch.Tensor, grad: torch.Tensor,
                  orig: torch.Tensor, epsilon: float) -> torch.Tensor:
        """One projected gradient ascent step."""
        if self.attack_norm == "linf":
            x = x + self.adv_alpha * grad.sign()
            x = torch.max(torch.min(x, orig + epsilon), orig - epsilon)
        else:
            x = x + self.adv_alpha * _l2_normalize(grad)
            x = _proj_l2_ball(x, orig, epsilon)
        return self._clip_domain(x)

    def pgd_attack(self, batch, loss_fn: Optional[Callable] = None):
        """Craft adversarial samples for the configured views.

        Implements multi-start PGD with optional best-iterate selection:

        .. math::

            x^{*} = \\arg\\max_{r = 1..R,\\; t = 0..K}
                    L_\\mathrm{InfoNCE}\\bigl(x_t^{(r)}\\bigr)

        Args:
            batch: A :py:class:`cebra.data.Batch` (single session) or a list of
                batches (multi session).
            loss_fn: Objective to maximise. Defaults to :py:meth:`_attack_loss`.

        Returns:
            A tuple ``(adv_batch, info)`` where ``adv_batch`` has the same type
            as ``batch`` with the attacked views replaced by detached
            adversarial tensors, and ``info`` is a dictionary describing the
            attack (selected loss, restart/iterate index and the number of
            forward/backward passes that were spent).
        """
        if loss_fn is None:
            loss_fn = self._attack_loss

        self._validate_attack_config()

        batches, is_list = _as_batch_list(batch)
        for element in batches:
            element.to(self.device)

        views = self.attack_views
        keys = [(i, view) for i in range(len(batches)) for view in views]
        # NOTE: the budget is split over every attacked *tensor*, which for
        # multi-session training is (num_sessions x num_views), not num_views.
        epsilon = self._view_epsilon(len(keys))

        origs: Dict[Tuple[int, str], torch.Tensor] = {}
        for key in keys:
            index, view = key
            tensor = getattr(batches[index], view)
            if not isinstance(tensor, torch.Tensor):
                raise ValueError(
                    f"{type(self).__name__}: cannot attack the {view!r} view, "
                    f"which is a {type(tensor).__name__} and not a tensor. "
                    f"The multi-objective batches of newer CEBRA versions keep "
                    f"a list of positives; those need a dedicated attack.")
            if not torch.is_floating_point(tensor):
                raise ValueError(
                    f"{type(self).__name__}: cannot attack the {view!r} view, "
                    f"which holds a {tensor.dtype} tensor. Adversarial "
                    f"training requires a solver whose batches carry the raw "
                    f"signal (e.g. 'single-session'), not index tensors "
                    f"(e.g. 'single-session-full').")
            origs[key] = tensor.detach()

        restarts = max(1, int(self.adv_restarts))
        steps = max(0, int(self.adv_steps))
        # The last iterate only has to be scored explicitly if several
        # candidates compete. With a single restart and best-iterate selection
        # disabled the attack is exactly the classic "use x_K" PGD and costs
        # the same as before this change.
        evaluate_final = bool(self.adv_best_iterate) or restarts > 1

        best_value = -math.inf
        best_state: Optional[Dict[Tuple[int, str], torch.Tensor]] = None
        best_restart = -1
        best_iterate = -1
        num_forward = 0
        num_backward = 0

        with torch.enable_grad(), self._attack_model_mode():
            for restart in range(restarts):
                current = {
                    key: self._init_perturbed(origs[key],
                                              epsilon).requires_grad_(True)
                    for key in keys
                }

                for step_index in range(steps):
                    loss = loss_fn(_rebuild_batch(batches, is_list, current))
                    num_forward += 1

                    if self.adv_best_iterate:
                        value = loss.detach().item()
                        if value > best_value:
                            best_value = value
                            best_restart = restart
                            best_iterate = step_index
                            best_state = {
                                key: current[key].detach().clone()
                                for key in keys
                            }

                    grads = torch.autograd.grad(
                        loss,
                        [current[key] for key in keys],
                        retain_graph=False,
                        create_graph=False,
                        allow_unused=True,
                    )
                    num_backward += 1

                    with torch.no_grad():
                        updated = {}
                        for key, grad in zip(keys, grads):
                            x = current[key].detach()
                            if grad is None:
                                updated[key] = x
                            else:
                                updated[key] = self._pgd_step(
                                    x, grad, origs[key], epsilon)
                    current = {
                        key: updated[key].requires_grad_(True) for key in keys
                    }
                    del loss, grads

                if evaluate_final:
                    with torch.no_grad():
                        loss = loss_fn(
                            _rebuild_batch(batches, is_list, current))
                    num_forward += 1
                    value = loss.detach().item()
                    if value > best_value:
                        best_value = value
                        best_restart = restart
                        best_iterate = steps
                        best_state = {
                            key: current[key].detach().clone() for key in keys
                        }
                    del loss
                else:
                    best_value = float("nan")
                    best_restart = restart
                    best_iterate = steps
                    best_state = {
                        key: current[key].detach().clone() for key in keys
                    }

        # Safety net: if every candidate scored as NaN (e.g. a diverging
        # learnable temperature), no comparison ever succeeded. Fall back to the
        # last iterate rather than crashing or silently training on clean data.
        if best_state is None:
            best_state = {key: current[key].detach().clone() for key in keys}

        adv_batch = _rebuild_batch(batches, is_list, best_state)
        info = {
            "adv_target": self.attack_target,
            "adv_views": views,
            "adv_epsilon_view": epsilon,
            "adv_loss": best_value,
            "adv_restart": best_restart,
            "adv_iterate": best_iterate,
            "adv_forward": num_forward,
            "adv_backward": num_backward,
        }
        self.last_attack_info = info
        return adv_batch, info

    # ------------------------------------------------------------------
    # training step
    # ------------------------------------------------------------------
    def step(self, batch: cebra.data.Batch) -> dict:
        """One training iteration.

        In ``clean`` mode this is a single contrastive update. In
        ``adversarial`` mode the clean update is followed by a PGD attack and a
        second update on the adversarial batch (two ``optimizer.step()`` calls
        per iteration, which is intentional and matches the original ACORN
        implementation).
        """
        # ------------------------------------------------------------
        # 1) ordinary contrastive update
        # ------------------------------------------------------------
        self.optimizer.zero_grad()
        loss, stats = self._training_loss(batch)
        loss.backward()
        self.optimizer.step()

        # ------------------------------------------------------------
        # 2) adversarial update (optional)
        # ------------------------------------------------------------
        if self.training_mode == "adversarial":
            adv_batch, info = self.pgd_attack(batch)

            self.optimizer.zero_grad()
            adv_loss, adv_stats = self._training_loss(
                adv_batch,
                negative_grad_scale=self.adv_negative_grad_scale,
            )
            adv_loss.backward()
            self.optimizer.step()

            stats["adv"] = adv_stats["total"]
            stats["adv_gain"] = adv_stats["total"] - stats["total"]
            stats["adv_iterate"] = float(info["adv_iterate"])
            stats["adv_restart"] = float(info["adv_restart"])
            stats["adv_negative_grad_scale"] = float(
                self.adv_negative_grad_scale)

        # ------------------------------------------------------------
        # 3) logging
        # ------------------------------------------------------------
        self.history.append(stats["total"])
        for key, value in stats.items():
            self.log.setdefault(key, []).append(value)
        return stats

    def validation(self,
                   loader: cebra.data.Loader,
                   session_id: Optional[int] = None):
        """Compute score of the model on data.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            session_id: The session ID, an integer between 0 and the number of sessions in the
                multisession model, set to None for single session.

        Returns:
            Loss averaged over iterations on data batch.
        """
        assert (session_id is None) or (session_id == 0)
        iterator = self._get_loader(loader)
        total_loss = Meter()
        self.model.eval()
        for _, batch in iterator:
            prediction = self._inference(batch)
            loss, _, _ = self.criterion(prediction.reference,
                                        prediction.positive,
                                        prediction.negative)
            total_loss.add(loss.item())
        return total_loss.average

    @torch.no_grad()
    def decoding(self, train_loader, valid_loader):
        """Deprecated since 0.0.2."""
        train_x = self.transform(train_loader.dataset[torch.arange(
            len(train_loader.dataset.neural))])
        train_y = train_loader.dataset.index
        valid_x = self.transform(valid_loader.dataset[torch.arange(
            len(valid_loader.dataset.neural))])
        valid_y = valid_loader.dataset.index
        decode_metric = train_loader.dataset.decode(
            train_x.cpu().numpy(),
            train_y.cpu().numpy(),
            valid_x.cpu().numpy(),
            valid_y.cpu().numpy(),
        )
        return decode_metric

    @torch.no_grad()
    def transform(self, inputs: torch.Tensor) -> torch.Tensor:
        """Compute the embedding.

        This function by default only applies the ``forward`` function
        of the given model, after switching it into eval mode.

        Args:
            inputs: The input signal

        Returns:
            The output embedding.

        TODO:
            * Remove eval mode
        """

        self.model.eval()
        return self.model(inputs)

    @abc.abstractmethod
    def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
        """Given a batch of input examples, return the model outputs.

        TODO: make this a public function?

        Args:
            batch: The input data, not necessarily aligned across the batch
                dimension. This means that ``batch.index`` specifies the map
                between reference/positive samples, if not equal ``None``.

        Returns:
            Processed batch of data. While the input data might not be aligned
            across the sample dimensions, the output data should be aligned and
            ``batch.index`` should be set to ``None``.
        """
        raise NotImplementedError

    def load(self, logdir, filename="checkpoint.pth"):
        """Load the experiment from its checkpoint file.

        Args:
            filename (str): Checkpoint name for loading the experiment.
        """

        savepath = os.path.join(logdir, filename)
        if not os.path.exists(savepath):
            print("Did not find a previous experiment. Starting from scratch.")
            return
        checkpoint = torch.load(savepath, map_location=self.device)
        self.load_state_dict(checkpoint, strict=True)

    def save(self, logdir, filename="checkpoint_last.pth"):
        """Save the model and optimizer params.

        Args:
            logdir: Logging directory for this model.
            filename: Checkpoint name for saving the experiment.
        """
        if not os.path.exists(os.path.dirname(logdir)):
            os.makedirs(logdir)
        savepath = os.path.join(logdir, filename)
        torch.save(
            self.state_dict(),
            savepath,
        )


@dataclasses.dataclass
class MultiobjectiveSolver(Solver):
    """Train models to satisfy multiple learning objectives.

    This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
    or "hybrid" training.

    Attributes:
        model: A multi-objective CEBRA model
        optimizer: The optimizer used for training.
        num_behavior_features: The feature dimension for the features dedicated
            to satisfy the behavior contrastive objective. The remainder is used
            for time contrastive learning.
        renormalize_features: If ``True``, normalize the behavior and time
            contrastive features individually before computing similarity scores.
    """

    num_behavior_features: int = 3
    renormalize_features: bool = False
    output_mode: Literal["overlapping", "separate"] = "overlapping"

    @property
    def num_time_features(self):
        return self.num_total_features - self.num_behavior_features

    @property
    def num_total_features(self):
        return self.model.num_output

    def __post_init__(self):
        super().__post_init__()
        self._check_dimensions()
        self.model = cebra.models.MultiobjectiveModel(
            self.model,
            dimensions=(self.num_behavior_features, self.model.num_output),
            renormalize=self.renormalize_features,
            output_mode=self.output_mode,
        )

    def _check_dimensions(self):
        """Check the feature dimensions for behavior/time contrastive learning.

        Raises:
            ValueError: If feature dimensions are larger than the model features,
                or not sufficiently large for renormalization.
        """
        if self.output_mode == "separate":
            if self.num_behavior_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
            if self.num_time_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
        if self.renormalize_features:
            if self.num_behavior_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_behavior_features'."
                )
            if self.num_time_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_time_features'."
                )

    # ------------------------------------------------------------------
    # losses: the hybrid solvers return a (behavior, time) tuple from
    # ``_inference``, so both the training loss and the attack objective are
    # the sum of the two InfoNCE terms.
    # ------------------------------------------------------------------
    def _attack_loss(self, batch) -> torch.Tensor:
        prediction_behavior, prediction_time = self._inference(batch)
        behavior_loss, _, _ = self.criterion(
            prediction_behavior.reference,
            prediction_behavior.positive,
            prediction_behavior.negative,
        )
        time_loss, _, _ = self.criterion(
            prediction_time.reference,
            prediction_time.positive,
            prediction_time.negative,
        )
        return behavior_loss + time_loss

    def _training_loss(
        self, batch, *, negative_grad_scale: float = 1.0
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        prediction_behavior, prediction_time = self._inference(batch)

        behavior_loss, behavior_align, behavior_uniform = self.criterion(
            prediction_behavior.reference,
            prediction_behavior.positive,
            _scale_negative_gradient(prediction_behavior.negative,
                                     negative_grad_scale),
        )
        time_loss, time_align, time_uniform = self.criterion(
            prediction_time.reference,
            prediction_time.positive,
            _scale_negative_gradient(prediction_time.negative,
                                     negative_grad_scale),
        )

        loss = behavior_loss + time_loss
        stats = {
            "behavior_pos": behavior_align.item(),
            "behavior_neg": behavior_uniform.item(),
            "behavior_total": behavior_loss.item(),
            "time_pos": time_align.item(),
            "time_neg": time_uniform.item(),
            "time_total": time_loss.item(),
            "total": loss.item(),
            "temperature": self.criterion.temperature,
        }
        return loss, stats




# #
# # CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# # © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# # Source code:
# # https://github.com/AdaptiveMotorControlLab/CEBRA
# #
# # Please see LICENSE.md for the full license document:
# # https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
# #
# # Licensed under the Apache License, Version 2.0 (the "License");
# # you may not use this file except in compliance with the License.
# # You may obtain a copy of the License at
# #
# # http://www.apache.org/licenses/LICENSE-2.0
# #
# # Unless required by applicable law or agreed to in writing, software
# # distributed under the License is distributed on an "AS IS" BASIS,
# # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# # See the License for the specific language governing permissions and
# # limitations under the License.
# #
# """This package contains abstract base classes for different solvers.

# Solvers are used to package models, criterions and optimizers and implement training
# loops. When subclassing abstract solvers, in the simplest case only the
# :py:meth:`Solver._inference` needs to be overridden.

# For more complex use cases, the :py:meth:`Solver.step` and
# :py:meth:`Solver.fit` method can be overridden to
# implement larger changes to the training loop.
# """

# import abc
# import copy
# import os
# from typing import Callable, Dict, List, Literal, Optional

# import literate_dataclasses as dataclasses
# # ----------------------------------------------------------------------
# # Helpers
# # ----------------------------------------------------------------------
# import torch

# import cebra
# import cebra.data
# import cebra.io
# import cebra.models
# from cebra.solver.util import Meter
# from cebra.solver.util import ProgressBar


# def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
#     """Per-sample L2 normalisation (zero vectors stay zero)."""
#     flat = t.reshape(t.size(0), -1)
#     norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
#     return t / norm.view(-1, *([1] * (t.dim() - 1)))


# def _rand_radius_like(t: torch.Tensor):
#     """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
#     return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


# def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
#     """Project adv back to the closed L2 ball of radius ε around orig."""
#     delta = adv - orig
#     flat = delta.reshape(delta.size(0), -1)
#     norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
#     factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
#     delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
#     return orig + delta


# #

# # positive_perm= shuffle_and_permute(batch.positive)
# # anchor_perm= shuffle_and_permute(batch.reference)
# # negative_perm= shuffle_and_permute(batch.negative)


# # copied_data = copy.deepcopy(batch)#batch.clone().detach()
# # copied_data.positive = torch.randn_like(batch.positive).cuda() #positive_perm
# # copied_data.reference = torch.randn_like(batch.reference).cuda() #anchor_perm
# # copied_data.negative = torch.randn_like(batch.negative).cuda() #negative_perm


# # prediction_fix = self._inference(batch)

# # prediction_perm= self._inference(copied_data)

# # x_perm_ = torch.cat([prediction_perm.reference,prediction_perm.positive, prediction_perm.negative], dim=0)
# # x_fix= torch.cat([prediction_fix.reference,prediction_fix.positive, prediction_fix.negative], dim=0)

# # self.optimizer.zero_grad()

# # cos_raw    = torch.nn.functional.cosine_similarity(x_perm_,x_fix)
# # L_cos      = torch.log((2 + cos_raw) / 2).mean()  # log version
# # # print(L_cos.item())
# # L_cos.backward()
# # self.optimizer.step()


# # fake_data=torch.randn_like(batch.positive).cuda()


# # self.optimizer.zero_grad()

# # positive_perm= shuffle_and_permute(batch.positive)
# # anchor_perm= shuffle_and_permute(batch.reference)
# # fake_data=torch.randn_like(batch.positive).cuda()


# # x_perm_ = torch.cat([anchor_perm,positive_perm, batch.negative], dim=0)

# # idx = torch.randperm(x_perm_.size(0))[:positive_perm.size(0)]


# # permed_data_negative   = x_perm_[idx]

# # fake_batch = cebra.data.Batch(
# #                 reference=batch.reference,
# #                 positive=batch.positive,
# #                 negative=batch.negative
# #             )
# # fake_prediction = self._inference(fake_batch)
# # loss, align, uniform= self.criterion(fake_prediction.reference,
# #                                       fake_prediction.positive,
# #                                       fake_prediction.negative)
# # loss.backward()
# # self.optimizer.step()


# def clone_batch(batch):
#     # 1) shallow-copy the Batch container
#     new_batch = copy.copy(batch)

#     # 2) for each tensor attribute in the batch, clone & detach
#     #    adjust this list to match the actual fields in your Batch
#     tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
#     for field in tensor_fields:
#         tensor = getattr(batch, field, None)
#         if isinstance(tensor, torch.Tensor):
#             # clone and detach so it shares neither data nor grad
#             setattr(new_batch, field, tensor.clone().detach())
#         # if the field can be a list/tuple of tensors, you could also do:
#         # elif (isinstance(tensor, (list, tuple)) and
#         #       all(isinstance(t, torch.Tensor) for t in tensor)):
#         #     cloned = [t.clone().detach() for t in tensor]
#         #     setattr(new_batch, field, type(tensor)(cloned))

#     return new_batch


# def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
#     """
#     Shuffle the second (M) and third (D) dimensions of a 3D tensor independently.

#     Parameters:
#         data (torch.Tensor): Input tensor of shape [N, M, D].

#     Returns:
#         torch.Tensor: Tensor with shuffled M and D dimensions.
#     """
#     N, M, D = data.size()

#     # Create random permutations for the second and third dimensions
#     perm_M = torch.randperm(M)
#     # perm_D = torch.randperm(D)

#     # Permute the second dimension (axis=1) first, then the third dimension (axis=2)
#     shuffled_data = data[:, perm_M.cuda(), :]

#     return shuffled_data


# @dataclasses.dataclass
# class Solver(abc.ABC, cebra.io.HasDevice):
#     """Solver base class.

#     A solver contains helper methods for bundling a model, criterion and optimizer.

#     Attributes:
#         model: The encoder for transforming reference, positive and negative samples.
#         criterion: The criterion computed from the similarities between positive pairs
#             and negative pairs. The criterion can have trainable parameters on its own.
#         optimizer: A PyTorch optimizer for updating model and criterion parameters.
#         history: Deprecated since 0.0.2. Use :py:attr:`log`.
#         decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
#             decoding. See the arguments of :py:meth:`fit`.
#         log: The logs recorded during training, typically contains the ``total`` loss as well
#             as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
#             criterions in CEBRA, also contains the value of the ``temperature``.
#         tqdm_on: Use ``tqdm`` for showing a progress bar during training.
#         training_mode: The training mode, either "clean" or "adversarial".
#         adv_epsilon: The maximum perturbation allowed for adversarial training.
#         adv_alpha: The step size for adversarial training.
#         adv_steps: The number of steps for adversarial training.
#         attack_norm: The norm used for adversarial training, either "l2" or "linf".
#     """

#     model: torch.nn.Module
#     criterion: torch.nn.Module
#     optimizer: torch.optim.Optimizer
#     history: List = dataclasses.field(default_factory=list)
#     decode_history: List = dataclasses.field(default_factory=list)
#     log: Dict = dataclasses.field(default_factory=lambda: ({
#         "pos": [],
#         "neg": [],
#         "total": [],
#         "temperature": []
#     }))
#     tqdm_on: bool = True
#     training_mode: str = "clean"
#     adv_epsilon: float = 0.05
#     adv_alpha: float = 0.01
#     adv_steps: int = 10
#     attack_norm: str = "linf"

#     def __post_init__(self):
#         cebra.io.HasDevice.__init__(self)
#         self.best_loss = float("inf")

#     def state_dict(self) -> dict:
#         """Return a dictionary fully describing the current solver state.

#         Returns:
#             State dictionary, including the state dictionary of the models and
#             optimizer. Also contains the training history and the CEBRA version
#             the model was trained with.
#         """

#         return {
#             "model": self.model.state_dict(),
#             "optimizer": self.optimizer.state_dict(),
#             "loss": torch.tensor(self.history),
#             "decode": self.decode_history,
#             "criterion": self.criterion.state_dict(),
#             "version": cebra.__version__,
#             "log": self.log,
#         }

#     def load_state_dict(self, state_dict: dict, strict: bool = True):
#         """Update the solver state with the given state_dict.

#         Args:
#             state_dict: Dictionary with parameters for the `model`, `optimizer`,
#                 and the past loss history for the solver.
#             strict: Make sure all states can be loaded. Set to `False` to allow
#                 to partially load the state for all given keys.
#         """

#         def _contains(key):
#             if key in state_dict:
#                 return True
#             elif strict:
#                 raise KeyError(
#                     f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
#                 )
#             return False

#         def _get(key):
#             return state_dict.get(key)

#         if _contains("model"):
#             self.model.load_state_dict(_get("model"))
#         if _contains("criterion"):
#             self.criterion.load_state_dict(_get("criterion"))
#         if _contains("optimizer"):
#             self.optimizer.load_state_dict(_get("optimizer"))
#         # TODO(stes): This will be deprecated at some point; the "log" attribute
#         # holds the same information.
#         if _contains("loss"):
#             self.history = _get("loss").cpu().numpy().tolist()
#         if _contains("decode"):
#             self.decode_history = _get("decode")
#         if _contains("log"):
#             self.log = _get("log")

#     @property
#     def num_parameters(self) -> int:
#         """Total number of parameters in the encoder and criterion."""
#         return sum(p.numel() for p in self.parameters())

#     def parameters(self):
#         """Iterate over all parameters."""
#         for parameter in self.model.parameters():
#             yield parameter

#         for parameter in self.criterion.parameters():
#             yield parameter

#     def _get_loader(self, loader):
#         return ProgressBar(
#             loader,
#             "tqdm" if self.tqdm_on else "off",
#         )

#     def fit(
#             self,
#             loader: cebra.data.Loader,
#             valid_loader: cebra.data.Loader = None,
#             *,
#             save_frequency: int = None,
#             valid_frequency: int = None,
#             decode: bool = False,
#             logdir: str = None,
#             save_hook: Callable[[int, "Solver"], None] = None,
#     ):
#         """Train model for the specified number of steps.

#         Args:
#             loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
#                 Each batch contains reference, positive and negative input samples.
#             valid_loader: Data loader used for validation of the model.
#             save_frequency: If not `None`, the frequency for automatically saving model checkpoints
#                 to `logdir`.
#             valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
#             logdir:  The logging directory for writing model checkpoints. The checkpoints
#                 can be read again using the `solver.load` function, or manually via loading the
#                 state dict.

#         TODO:
#             * Refine the API here. Drop the validation entirely, and implement this via a hook?
#         """

#         self.to(loader.device)

#         iterator = self._get_loader(loader)
#         self.model.train()
#         for num_steps, batch in iterator:
#             stats = self.step(batch)
#             iterator.set_description(stats)

#             if save_frequency is None:
#                 continue
#             save_model = num_steps % save_frequency == 0
#             run_validation = (valid_loader
#                               is not None) and (num_steps % valid_frequency
#                                                 == 0)
#             if run_validation:
#                 validation_loss = self.validation(valid_loader)
#                 if self.best_loss is None or validation_loss < self.best_loss:
#                     self.best_loss = validation_loss
#                     self.save(logdir, "checkpoint_best.pth")
#             if save_model:
#                 if decode:
#                     self.decode_history.append(
#                         self.decoding(loader, valid_loader))
#                 if save_hook is not None:
#                     save_hook(num_steps, self)
#                 if logdir is not None:
#                     self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

#     # ----------------------------------------------------------------------
#     # Drop-in replacement for Solver.step
#     # ----------------------------------------------------------------------
#     def step(self, batch: cebra.data.Batch) -> dict:
#         # ------------------------------------------------------------
#         # 1) ordinary contrastive update
#         # ------------------------------------------------------------
#         self.optimizer.zero_grad()
#         pred = self._inference(batch)
#         loss, align, uniform = self.criterion(
#             pred.reference, pred.positive, pred.negative
#         )
#         loss.backward()
#         self.optimizer.step()
#         # print(self.training_mode, self.attack_norm)
#         if self.training_mode == "adversarial":
#             if self.attack_norm == "linf":
#                 self.optimizer.zero_grad()

#                 adv_epsilon = self.adv_epsilon
#                 adv_alpha = self.adv_alpha
#                 adv_steps = self.adv_steps

#                 self.optimizer.zero_grad()

#                 # Create adversarial examples
#                 # x_adv = batch.reference.clone().detach()

#                 perturb = torch.empty_like(batch.reference) \
#                     .uniform_(-self.adv_epsilon, self.adv_epsilon)
#                 x_adv = (batch.reference + perturb).clone()

#                 x_adv.requires_grad = True

#                 for _ in range(self.adv_steps):
#                     if x_adv.grad is not None:
#                         x_adv.grad.zero_()

#                     with torch.enable_grad():
#                         # Forward pass with adversarial examples
#                         adv_batch = cebra.data.Batch(
#                             reference=x_adv,
#                             positive=batch.positive,
#                             negative=batch.negative
#                         )
#                         adv_output = self._inference(adv_batch)
#                         loss, _, _ = self.criterion(adv_output.reference,
#                                                     adv_output.positive,
#                                                     adv_output.negative)

#                     grad_x, = torch.autograd.grad(
#                         loss, x_adv,
#                         retain_graph=False,
#                         create_graph=False
#                     )

#                     with torch.no_grad():
#                         grad_sign = grad_x.sign()
#                         x_adv = x_adv + self.adv_alpha * grad_sign
#                         x_adv = torch.max(torch.min(x_adv, batch.reference + self.adv_epsilon),
#                                           batch.reference - self.adv_epsilon)
#                         x_adv.requires_grad = True

#                 # Final forward pass with adversarial examples
#                 adv_batch = cebra.data.Batch(
#                     reference=x_adv,
#                     positive=batch.positive,
#                     negative=batch.negative
#                 )
#                 output = self._inference(adv_batch)
#                 loss, _, _ = self.criterion(output.reference,
#                                             output.positive,
#                                             output.negative)
#                 loss.backward()
#                 self.optimizer.step()
#             elif self.attack_norm == "l2":
#                 self.optimizer.zero_grad()

#                 adv_eps, adv_alpha, adv_steps = self.adv_epsilon, self.adv_alpha, self.adv_steps

#                 x_adv = batch.reference.clone().detach()
#                 noise = _l2_normalize(torch.randn_like(x_adv))
#                 noise *= _rand_radius_like(x_adv) * adv_eps
#                 x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

#                 for _ in range(adv_steps):
#                     if x_adv.grad is not None:
#                         x_adv.grad.zero_()

#                     adv_b = cebra.data.Batch(reference=x_adv,
#                                              positive=batch.positive,
#                                              negative=batch.negative)
#                     adv_out = self._inference(adv_b)
#                     adv_loss, _, _ = self.criterion(
#                         adv_out.reference, adv_out.positive, adv_out.negative
#                     )
#                     grad_x, = torch.autograd.grad(
#                         adv_loss, x_adv,
#                         retain_graph=False,
#                         create_graph=False
#                     )

#                     with torch.no_grad():
#                         x_adv += adv_alpha * _l2_normalize(grad_x)
#                         x_adv = _proj_l2_ball(x_adv, batch.reference, adv_eps)
#                         x_adv.requires_grad = True

#                 adv_b = cebra.data.Batch(reference=x_adv,
#                                          positive=batch.positive,
#                                          negative=batch.negative)
#                 out = self._inference(adv_b)
#                 loss3, _, _ = self.criterion(out.reference, out.positive, out.negative)
#                 loss3.backward()
#                 self.optimizer.step()

#         self.history.append(loss.item())
#         stats = dict(
#             pos=align.item(),
#             neg=uniform.item(),
#             total=loss.item(),
#             temperature=self.criterion.temperature,
#         )
#         for k, v in stats.items():
#             self.log[k].append(v)
#         return stats

#     # ------------------------------------------------------------
#     # 6) logging
#     # ------------------------------------------------------------

#     def validation(self,
#                    loader: cebra.data.Loader,
#                    session_id: Optional[int] = None):
#         """Compute score of the model on data.

#         Args:
#             loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
#                 Each batch contains reference, positive and negative input samples.
#             session_id: The session ID, an integer between 0 and the number of sessions in the
#                 multisession model, set to None for single session.

#         Returns:
#             Loss averaged over iterations on data batch.
#         """
#         assert (session_id is None) or (session_id == 0)
#         iterator = self._get_loader(loader)
#         total_loss = Meter()
#         self.model.eval()
#         for _, batch in iterator:
#             prediction = self._inference(batch)
#             loss, _, _ = self.criterion(prediction.reference,
#                                         prediction.positive,
#                                         prediction.negative)
#             total_loss.add(loss.item())
#         return total_loss.average

#     @torch.no_grad()
#     def decoding(self, train_loader, valid_loader):
#         """Deprecated since 0.0.2."""
#         train_x = self.transform(train_loader.dataset[torch.arange(
#             len(train_loader.dataset.neural))])
#         train_y = train_loader.dataset.index
#         valid_x = self.transform(valid_loader.dataset[torch.arange(
#             len(valid_loader.dataset.neural))])
#         valid_y = valid_loader.dataset.index
#         decode_metric = train_loader.dataset.decode(
#             train_x.cpu().numpy(),
#             train_y.cpu().numpy(),
#             valid_x.cpu().numpy(),
#             valid_y.cpu().numpy(),
#         )
#         return decode_metric

#     @torch.no_grad()
#     def transform(self, inputs: torch.Tensor) -> torch.Tensor:
#         """Compute the embedding.

#         This function by default only applies the ``forward`` function
#         of the given model, after switching it into eval mode.

#         Args:
#             inputs: The input signal

#         Returns:
#             The output embedding.

#         TODO:
#             * Remove eval mode
#         """

#         self.model.eval()
#         return self.model(inputs)

#     @abc.abstractmethod
#     def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
#         """Given a batch of input examples, return the model outputs.

#         TODO: make this a public function?

#         Args:
#             batch: The input data, not necessarily aligned across the batch
#                 dimension. This means that ``batch.index`` specifies the map
#                 between reference/positive samples, if not equal ``None``.

#         Returns:
#             Processed batch of data. While the input data might not be aligned
#             across the sample dimensions, the output data should be aligned and
#             ``batch.index`` should be set to ``None``.
#         """
#         raise NotImplementedError

#     def load(self, logdir, filename="checkpoint.pth"):
#         """Load the experiment from its checkpoint file.

#         Args:
#             filename (str): Checkpoint name for loading the experiment.
#         """

#         savepath = os.path.join(logdir, filename)
#         if not os.path.exists(savepath):
#             print("Did not find a previous experiment. Starting from scratch.")
#             return
#         checkpoint = torch.load(savepath, map_location=self.device)
#         self.load_state_dict(checkpoint, strict=True)

#     def save(self, logdir, filename="checkpoint_last.pth"):
#         """Save the model and optimizer params.

#         Args:
#             logdir: Logging directory for this model.
#             filename: Checkpoint name for saving the experiment.
#         """
#         if not os.path.exists(os.path.dirname(logdir)):
#             os.makedirs(logdir)
#         savepath = os.path.join(logdir, filename)
#         torch.save(
#             self.state_dict(),
#             savepath,
#         )


# @dataclasses.dataclass
# class MultiobjectiveSolver(Solver):
#     """Train models to satisfy multiple learning objectives.

#     This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
#     or "hybrid" training.

#     Attributes:
#         model: A multi-objective CEBRA model
#         optimizer: The optimizer used for training.
#         num_behavior_features: The feature dimension for the features dedicated
#             to satisfy the behavior contrastive objective. The remainder is used
#             for time contrastive learning.
#         renormalize_features: If ``True``, normalize the behavior and time
#             contrastive features individually before computing similarity scores.
#     """

#     num_behavior_features: int = 3
#     renormalize_features: bool = False
#     output_mode: Literal["overlapping", "separate"] = "overlapping"

#     @property
#     def num_time_features(self):
#         return self.num_total_features - self.num_behavior_features

#     @property
#     def num_total_features(self):
#         return self.model.num_output

#     def __post_init__(self):
#         super().__post_init__()
#         self._check_dimensions()
#         self.model = cebra.models.MultiobjectiveModel(
#             self.model,
#             dimensions=(self.num_behavior_features, self.model.num_output),
#             renormalize=self.renormalize_features,
#             output_mode=self.output_mode,
#         )

#     def _check_dimensions(self):
#         """Check the feature dimensions for behavior/time contrastive learning.

#         Raises:
#             ValueError: If feature dimensions are larger than the model features,
#                 or not sufficiently large for renormalization.
#         """
#         if self.output_mode == "separate":
#             if self.num_behavior_features >= self.num_total_features:
#                 raise ValueError(
#                     "For multi-objective training, the number of features for "
#                     f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
#                     f"than the total feature dimension ({self.num_total_features})."
#                 )
#             if self.num_time_features >= self.num_total_features:
#                 raise ValueError(
#                     "For multi-objective training, the number of features for "
#                     f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
#                     f"than the total feature dimension ({self.num_total_features})."
#                 )
#         if self.renormalize_features:
#             if self.num_behavior_features < 2:
#                 raise ValueError(
#                     "When renormalizing the features, the feature dimension needs "
#                     "to be at least 2 for behavior. "
#                     "Check the values of 'renormalize_features' and 'num_behavior_features'."
#                 )
#             if self.num_time_features < 2:
#                 raise ValueError(
#                     "When renormalizing the features, the feature dimension needs "
#                     "to be at least 2 for behavior. "
#                     "Check the values of 'renormalize_features' and 'num_time_features'."
#                 )

#     def step(self, batch: cebra.data.Batch) -> dict:
#         """Perform a single gradient update with multiple objectives.

#         Args:
#             batch: The input samples

#         Returns:
#             Dictionary containing training metrics.
#         """
#         self.optimizer.zero_grad()
#         prediction_behavior, prediction_time = self._inference(batch)

#         behavior_loss, behavior_align, behavior_uniform = self.criterion(
#             prediction_behavior.reference,
#             prediction_behavior.positive,
#             prediction_behavior.negative,
#         )

#         time_loss, time_align, time_uniform = self.criterion(
#             prediction_time.reference,
#             prediction_time.positive,
#             prediction_time.negative,
#         )

#         loss = behavior_loss + time_loss
#         loss.backward()
#         self.optimizer.step()
#         self.history.append(loss.item())

#         # 2) ---------------- adversarial branch (optional) ----------------------
#         if self.training_mode == "adversarial":
#             if self.attack_norm == "linf":
#                 # We perturb only the reference view

#                 perturb = torch.empty_like(batch.reference) \
#                     .uniform_(-self.adv_epsilon, self.adv_epsilon)
#                 x_adv = (batch.reference + perturb).clone()

#                 # x_adv = batch.reference.detach().clone()
#                 x_adv.requires_grad_(True)

#                 for _ in range(self.adv_steps):
#                     if x_adv.grad is not None:
#                         x_adv.grad.zero_()

#                     adv_batch = cebra.data.Batch(
#                         reference=x_adv,
#                         positive=batch.positive,
#                         negative=batch.negative,
#                     )

#                     adv_pred_beh, adv_pred_time = self._inference(adv_batch)
#                     adv_beh_loss, _, _ = self.criterion(
#                         adv_pred_beh.reference,
#                         adv_pred_beh.positive,
#                         adv_pred_beh.negative,
#                     )
#                     adv_time_loss, _, _ = self.criterion(
#                         adv_pred_time.reference,
#                         adv_pred_time.positive,
#                         adv_pred_time.negative,
#                     )
#                     adv_loss = adv_beh_loss + adv_time_loss
#                     adv_loss.backward()

#                     with torch.no_grad():
#                         # PGD update + projection to ε-ball
#                         grad_sign = x_adv.grad.sign()
#                         x_adv.add_(self.adv_alpha * grad_sign)
#                         x_adv.clamp_(batch.reference - self.adv_epsilon,
#                                      batch.reference + self.adv_epsilon)

#                 # final update with fixed adversarial examples
#                 self.optimizer.zero_grad()
#                 adv_batch = cebra.data.Batch(
#                     reference=x_adv.detach(),
#                     positive=batch.positive,
#                     negative=batch.negative,
#                 )
#                 adv_pred_beh, adv_pred_time = self._inference(adv_batch)
#                 adv_beh_loss, _, _ = self.criterion(
#                     adv_pred_beh.reference,
#                     adv_pred_beh.positive,
#                     adv_pred_beh.negative,
#                 )
#                 adv_time_loss, _, _ = self.criterion(
#                     adv_pred_time.reference,
#                     adv_pred_time.positive,
#                     adv_pred_time.negative,
#                 )
#                 adv_total_loss = adv_beh_loss + adv_time_loss
#                 adv_total_loss.backward()
#                 self.optimizer.step()
#             elif self.attack_norm == "l2":
#                 self.optimizer.zero_grad()

#                 adv_eps, adv_alpha, adv_steps = self.adv_epsilon, self.adv_alpha, self.adv_steps

#                 x_adv = batch.reference.clone().detach()
#                 noise = _l2_normalize(torch.randn_like(x_adv))
#                 noise *= _rand_radius_like(x_adv) * adv_eps
#                 x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

#                 for _ in range(adv_steps):
#                     if x_adv.grad is not None:
#                         x_adv.grad.zero_()

#                     adv_b = cebra.data.Batch(reference=x_adv,
#                                              positive=batch.positive,
#                                              negative=batch.negative)
#                     adv_out, _ = self._inference(adv_b)
#                     adv_loss, _, _ = self.criterion(
#                         adv_out.reference, adv_out.positive, adv_out.negative
#                     )
#                     adv_loss.backward()

#                     with torch.no_grad():
#                         x_adv += adv_alpha * _l2_normalize(x_adv.grad)
#                         x_adv = _proj_l2_ball(x_adv, batch.reference, adv_eps)
#                         x_adv.requires_grad = True

#                 adv_b = cebra.data.Batch(reference=x_adv,
#                                          positive=batch.positive,
#                                          negative=batch.negative)
#                 out, _ = self._inference(adv_b)
#                 loss3, _, _ = self.criterion(out.reference, out.positive, out.negative)
#                 loss3.backward()
#                 self.optimizer.step()

#         self.history.append(loss.item())
#         return dict(
#             behavior_pos=behavior_align.item(),
#             behavior_neg=behavior_uniform.item(),
#             behavior_total=behavior_loss.item(),
#             time_pos=time_align.item(),
#             time_neg=time_uniform.item(),
#             time_total=time_loss.item(),
#         )



# #
# # CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# # © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# # Source code:
# # https://github.com/AdaptiveMotorControlLab/CEBRA
# #
# # Please see LICENSE.md for the full license document:
# # https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
# #
# # Licensed under the Apache License, Version 2.0 (the "License");
# # you may not use this file except in compliance with the License.
# # You may obtain a copy of the License at
# #
# # http://www.apache.org/licenses/LICENSE-2.0
# #
# # Unless required by applicable law or agreed to in writing, software
# # distributed under the License is distributed on an "AS IS" BASIS,
# # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# # See the License for the specific language governing permissions and
# # limitations under the License.
# #
# """This package contains abstract base classes for different solvers.

# Solvers are used to package models, criterions and optimizers and implement training
# loops. When subclassing abstract solvers, in the simplest case only the
# :py:meth:`Solver._inference` needs to be overridden.

# For more complex use cases, the :py:meth:`Solver.step` and
# :py:meth:`Solver.fit` method can be overridden to
# implement larger changes to the training loop.
# """

# import abc
# import os
# import warnings
# from typing import Callable, Dict, List, Literal, Optional, Tuple, Union

# import literate_dataclasses as dataclasses
# import torch
# import torch.nn.functional as F
# from torch.utils.data import DataLoader
# from torch.utils.data import Dataset

# import cebra
# import cebra.data
# import cebra.io
# import cebra.models
# from cebra.solver.util import Meter
# from cebra.solver.util import ProgressBar


# def _check_indices(batch_start_idx: int, batch_end_idx: int,
#                    offset: cebra.data.Offset, num_samples: int):
#     """Check that indices in a batch are in a correct range.

#     First and last index must be positive integers, smaller than
#     the total length of inputs in the dataset, the first index
#     must be smaller than the last and the batch size cannot be
#     smaller than the offset of the model.

#     Args:
#         batch_start_idx: Index of the first sample in the batch.
#         batch_end_idx: Index of the first sample in the batch.
#         offset: Model offset.
#         num_samples: Total number of samples in the input.
#     """

#     if batch_start_idx < 0 or batch_end_idx < 0:
#         raise ValueError(
#             f"batch_start_idx ({batch_start_idx}) and batch_end_idx ({batch_end_idx}) must be positive integers."
#         )
#     if batch_start_idx > batch_end_idx:
#         raise ValueError(
#             f"batch_start_idx ({batch_start_idx}) cannot be greater than batch_end_idx ({batch_end_idx})."
#         )
#     if batch_end_idx > num_samples:
#         raise ValueError(
#             f"batch_end_idx ({batch_end_idx}) cannot exceed the length of inputs ({num_samples})."
#         )

#     batch_size_length = batch_end_idx - batch_start_idx
#     if batch_size_length <= len(offset):
#         raise ValueError(
#             f"The batch has length {batch_size_length} which "
#             f"is smaller or equal than the required offset length {len(offset)}."
#             f"Either choose a model with smaller offset or the batch should contain 3 times more samples."
#         )


# def _add_batched_zero_padding(batched_data: torch.Tensor,
#                               offset: cebra.data.Offset, batch_start_idx: int,
#                               batch_end_idx: int,
#                               num_samples: int) -> torch.Tensor:
#     """Add zero padding to the input data before inference.

#     Args:
#         batched_data: Data to apply the inference on.
#         offset: Offset of the model to consider when padding.
#         batch_start_idx: Index of the first sample in the batch.
#         batch_end_idx: Index of the first sample in the batch.
#         num_samples (int): Total number of samples in the data.

#     Returns:
#         The padded batch.
#     """
#     if batch_start_idx > batch_end_idx:
#         raise ValueError(
#             f"batch_start_idx ({batch_start_idx}) cannot be greater than batch_end_idx ({batch_end_idx})."
#         )
#     if batch_start_idx < 0 or batch_end_idx < 0:
#         raise ValueError(
#             f"batch_start_idx ({batch_start_idx}) and batch_end_idx ({batch_end_idx}) must be positive integers."
#         )

#     reversed_dims = torch.arange(batched_data.ndim - 1, -1, -1)

#     if batch_start_idx == 0:  # First batch
#         batched_data = F.pad(batched_data.permute(*reversed_dims),
#                              (offset.left, 0),
#                              'replicate').permute(*reversed_dims)
#     elif batch_end_idx == num_samples:  # Last batch
#         batched_data = F.pad(batched_data.permute(*reversed_dims),
#                              (0, offset.right - 1),
#                              'replicate').permute(*reversed_dims)

#     return batched_data


# def _get_batch(inputs: torch.Tensor, offset: Optional[cebra.data.Offset],
#                batch_start_idx: int, batch_end_idx: int,
#                pad_before_transform: bool) -> torch.Tensor:
#     """Get a batch of samples between the `batch_start_idx` and `batch_end_idx`.

#     Args:
#         inputs: Input data.
#         offset: Model offset.
#         batch_start_idx: Index of the first sample in the batch.
#         batch_end_idx: Index of the last sample in the batch.
#         pad_before_transform: If True zero-pad the batched data.

#     Returns:
#         The batch.
#     """
#     if offset is None:
#         raise ValueError("offset cannot be null.")

#     if batch_start_idx == 0:  # First batch
#         indices = batch_start_idx, (batch_end_idx + offset.right - 1)
#     elif batch_end_idx == len(inputs):  # Last batch
#         indices = (batch_start_idx - offset.left), batch_end_idx
#     else:
#         indices = batch_start_idx - offset.left, batch_end_idx + offset.right - 1

#     _check_indices(indices[0], indices[1], offset, len(inputs))
#     batched_data = inputs[slice(*indices)]

#     if pad_before_transform:
#         batched_data = _add_batched_zero_padding(
#             batched_data=batched_data,
#             offset=offset,
#             batch_start_idx=batch_start_idx,
#             batch_end_idx=batch_end_idx,
#             num_samples=len(inputs))

#     return batched_data


# def _inference_transform(model: cebra.models.Model,
#                          inputs: torch.Tensor) -> torch.Tensor:
#     """Compute the embedding on the inputs using the model provided.

#     Args:
#         model: Model to use for inference.
#         inputs: Data.

#     Returns:
#         The embedding.
#     """
#     inputs = inputs.float().to(next(model.parameters()).device)

#     if isinstance(model, cebra.models.ConvolutionalModelMixin):
#         # Fully convolutional evaluation, switch (T, C) -> (1, C, T)
#         inputs = inputs.transpose(1, 0).unsqueeze(0)
#         output = model(inputs).squeeze(0).transpose(1, 0)
#     else:
#         output = model(inputs)
#     return output


# def _not_batched_transform(
#     model: cebra.models.Model,
#     inputs: torch.Tensor,
#     pad_before_transform: bool,
#     offset: cebra.data.datatypes.Offset,
# ) -> torch.Tensor:
#     """Compute the embedding.

#     Args:
#         model: The model to use for inference.
#         inputs: Input data.
#         pad_before_transform: If True, the input data is zero padded before inference.
#         offset: Model offset.

#     Returns:
#         torch.Tensor: The (potentially) padded data.

#     Raises:
#         ValueError: If add_padding is True and offset is not provided.
#     """
#     if pad_before_transform:
#         inputs = F.pad(inputs.T, (offset.left, offset.right - 1), 'replicate').T
#     output = _inference_transform(model, inputs)
#     return output


# def _batched_transform(model: cebra.models.Model, inputs: torch.Tensor,
#                        batch_size: int, pad_before_transform: bool,
#                        offset: cebra.data.datatypes.Offset) -> torch.Tensor:
#     """Compute the embedding on batched inputs.

#     Args:
#         model: The model to use for inference.
#         inputs: Input data.
#         batch_size: Integer corresponding to the batch size.
#         pad_before_transform: If True, the input data is zero padded before inference.
#         offset: Model offset.

#     Returns:
#         The embedding.
#     """

#     class IndexDataset(Dataset):

#         def __init__(self, inputs):
#             self.inputs = inputs

#         def __len__(self):
#             return len(self.inputs)

#         def __getitem__(self, idx):
#             return idx

#     index_dataset = IndexDataset(inputs)
#     index_dataloader = DataLoader(index_dataset, batch_size=batch_size)

#     if len(index_dataloader) < 2:
#         raise ValueError(
#             f"Number of batches must be greater than 1, you can use transform "
#             f"without batching instead, got {len(index_dataloader)}.")

#     output = []
#     for batch_idx, index_batch in enumerate(index_dataloader):
#         # NOTE(celia): This is to prevent that adding the offset to the
#         # penultimate batch for larger offset make the batch_end_idx larger
#         # than the input length, while we also don't want to drop the last
#         # samples that do not fit in a complete batch.
#         if batch_idx == (len(index_dataloader) - 2):
#             # penultimate batch, last complete batch
#             last_batch = index_batch
#             continue
#         if batch_idx == (len(index_dataloader) - 1):
#             # last batch, incomplete
#             index_batch = torch.cat((last_batch, index_batch), dim=0)

#             if index_batch[-1] + 1 != len(inputs):
#                 raise ValueError(
#                     f"Last batch index {index_batch[-1]} + 1 should be equal to the length of inputs {len(inputs)}."
#                 )

#         # Batch start and end so that `batch_size` size with the last batch including 2 batches
#         batch_start_idx, batch_end_idx = index_batch[0], index_batch[-1] + 1
#         batched_data = _get_batch(inputs=inputs,
#                                   offset=offset,
#                                   batch_start_idx=batch_start_idx,
#                                   batch_end_idx=batch_end_idx,
#                                   pad_before_transform=pad_before_transform)

#         output_batch = _inference_transform(model, batched_data)
#         output.append(output_batch)

#     output = torch.cat(output, dim=0)
#     return output


# @dataclasses.dataclass
# class Solver(abc.ABC, cebra.io.HasDevice):
#     """Solver base class.

#     A solver contains helper methods for bundling a model, criterion and optimizer.

#     Attributes:
#         model: The encoder for transforming reference, positive and negative samples.
#         criterion: The criterion computed from the similarities between positive pairs
#             and negative pairs. The criterion can have trainable parameters on its own.
#         optimizer: A PyTorch optimizer for updating model and criterion parameters.
#         history: Deprecated since 0.0.2. Use :py:attr:`log`.
#         decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
#             decoding. See the arguments of :py:meth:`fit`.
#         log: The logs recorded during training, typically contains the ``total`` loss as well
#             as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
#             criterions in CEBRA, also contains the value of the ``temperature``.
#         tqdm_on: Use ``tqdm`` for showing a progress bar during training.
#     """

#     model: torch.nn.Module
#     criterion: torch.nn.Module
#     optimizer: torch.optim.Optimizer
#     history: List = dataclasses.field(default_factory=list)
#     decode_history: List = dataclasses.field(default_factory=list)
#     log: Dict = dataclasses.field(default_factory=lambda: ({
#         "pos": [],
#         "neg": [],
#         "total": [],
#         "temperature": []
#     }))
#     tqdm_on: bool = True

#     def __post_init__(self):
#         cebra.io.HasDevice.__init__(self)
#         self.best_loss = float("inf")

#     def state_dict(self) -> dict:
#         """Return a dictionary fully describing the current solver state.

#         Returns:
#             State dictionary, including the state dictionary of the models and
#             optimizer. Also contains the training history and the CEBRA version
#             the model was trained with.
#         """

#         state_dict = {
#             "model": self.model.state_dict(),
#             "optimizer": self.optimizer.state_dict(),
#             "loss": torch.tensor(self.history),
#             "decode": self.decode_history,
#             "criterion": self.criterion.state_dict(),
#             "version": cebra.__version__,
#             "log": self.log,
#         }

#         if hasattr(self, "n_features"):
#             state_dict["n_features"] = self.n_features
#         if hasattr(self, "num_sessions"):
#             state_dict["num_sessions"] = self.num_sessions

#         return state_dict

#     def load_state_dict(self, state_dict: dict, strict: bool = True):
#         """Update the solver state with the given state_dict.

#         Args:
#             state_dict: Dictionary with parameters for the `model`, `optimizer`,
#                 and the past loss history for the solver.
#             strict: Make sure all states can be loaded. Set to `False` to allow
#                 to partially load the state for all given keys.
#         """

#         def _contains(key):
#             if key in state_dict:
#                 return True
#             elif strict:
#                 raise KeyError(
#                     f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
#                 )
#             return False

#         def _get(key):
#             return state_dict.get(key)

#         if _contains("model"):
#             self.model.load_state_dict(_get("model"))
#         if _contains("criterion"):
#             self.criterion.load_state_dict(_get("criterion"))
#         if _contains("optimizer"):
#             self.optimizer.load_state_dict(_get("optimizer"))
#         # TODO(stes): This will be deprecated at some point; the "log" attribute
#         # holds the same information.
#         if _contains("loss"):
#             self.history = _get("loss").cpu().numpy().tolist()
#         if _contains("decode"):
#             self.decode_history = _get("decode")
#         if _contains("log"):
#             self.log = _get("log")

#         # Not defined if the model was saved before being fitted.
#         if "n_features" in state_dict:
#             self.n_features = _get("n_features")
#         if "num_sessions" in state_dict:
#             self.num_sessions = _get("num_sessions")

#     @property
#     def num_parameters(self) -> int:
#         """Total number of parameters in the encoder and criterion."""
#         return sum(p.numel() for p in self.parameters())

#     def parameters(self, session_id: Optional[int] = None):
#         """Iterate over all parameters of the model.

#         Args:
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.

#         Yields:
#             The parameters of the model.
#         """
#         for parameter in self.model.parameters():
#             yield parameter

#         for parameter in self.criterion.parameters():
#             yield parameter

#     def _get_loader(self, loader):
#         return ProgressBar(
#             loader,
#             "tqdm" if self.tqdm_on else "off",
#         )

#     @abc.abstractmethod
#     def _set_fitted_params(self, loader: cebra.data.Loader):
#         """Set parameters once the solver is fitted.

#         Args:
#             loader: Loader used to fit the solver.
#         """

#         raise NotImplementedError

#     def fit(
#         self,
#         loader: cebra.data.Loader,
#         valid_loader: cebra.data.Loader = None,
#         *,
#         save_frequency: int = None,
#         valid_frequency: int = None,
#         decode: bool = False,
#         logdir: str = None,
#         save_hook: Callable[[int, "Solver"], None] = None,
#     ):
#         """Train model for the specified number of steps.

#         Args:
#             loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
#                 Each batch contains reference, positive and negative input samples.
#             valid_loader: Data loader used for validation of the model.
#             save_frequency: If not `None`, the frequency for automatically saving model checkpoints
#                 to `logdir`.
#             valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
#             logdir:  The logging directory for writing model checkpoints. The checkpoints
#                 can be read again using the `solver.load` function, or manually via loading the
#                 state dict.

#         TODO:
#             * Refine the API here. Drop the validation entirely, and implement this via a hook?
#         """
#         self._set_fitted_params(loader)
#         self.to(loader.device)

#         iterator = self._get_loader(loader)
#         self.model.train()
#         for num_steps, batch in iterator:
#             stats = self.step(batch)
#             iterator.set_description(stats)

#             if save_frequency is None:
#                 continue
#             save_model = num_steps % save_frequency == 0
#             run_validation = (valid_loader
#                               is not None) and (num_steps % valid_frequency
#                                                 == 0)
#             if run_validation:
#                 validation_loss = self.validation(valid_loader)
#                 if self.best_loss is None or validation_loss < self.best_loss:
#                     self.best_loss = validation_loss
#                     self.save(logdir, "checkpoint_best.pth")
#             if save_model:
#                 if decode:
#                     self.decode_history.append(
#                         self.decoding(loader, valid_loader))
#                 if save_hook is not None:
#                     save_hook(num_steps, self)
#                 if logdir is not None:
#                     self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

#     def step(self, batch: cebra.data.Batch) -> dict:
#         """Perform a single gradient update.

#         Args:
#             batch: The input samples

#         Returns:
#             Dictionary containing training metrics.
#         """
#         self.optimizer.zero_grad()
#         prediction = self._inference(batch)
#         loss, align, uniform = self.criterion(prediction.reference,
#                                               prediction.positive,
#                                               prediction.negative)

#         loss.backward()
#         self.optimizer.step()
#         self.history.append(loss.item())
#         stats = dict(
#             pos=align.item(),
#             neg=uniform.item(),
#             total=loss.item(),
#             temperature=self.criterion.temperature,
#         )
#         for key, value in stats.items():
#             self.log[key].append(value)
#         return stats

#     def validation(self,
#                    loader: cebra.data.Loader,
#                    session_id: Optional[int] = None):
#         """Compute score of the model on data.

#         Args:
#             loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
#                 Each batch contains reference, positive and negative input samples.
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.

#         Returns:
#             Loss averaged over iterations on data batch.
#         """
#         if session_id is not None and session_id != 0:
#             raise ValueError(
#                 f"session_id should be set to None or 0, got {session_id}")

#         iterator = self._get_loader(loader)
#         total_loss = Meter()
#         self.model.eval()
#         for _, batch in iterator:
#             prediction = self._inference(batch)
#             loss, _, _ = self.criterion(prediction.reference,
#                                         prediction.positive,
#                                         prediction.negative)
#             total_loss.add(loss.item())
#         return total_loss.average

#     @torch.no_grad()
#     def decoding(self, train_loader, valid_loader):
#         """Deprecated since 0.0.2."""
#         train_x = self.transform(train_loader.dataset[torch.arange(
#             len(train_loader.dataset.neural))])
#         train_y = train_loader.dataset.index
#         valid_x = self.transform(valid_loader.dataset[torch.arange(
#             len(valid_loader.dataset.neural))])
#         valid_y = valid_loader.dataset.index
#         decode_metric = train_loader.dataset.decode(
#             train_x.cpu().numpy(),
#             train_y.cpu().numpy(),
#             valid_x.cpu().numpy(),
#             valid_y.cpu().numpy(),
#         )
#         return decode_metric

#     def _check_is_inputs_valid(self, inputs: torch.Tensor, session_id: int):
#         """Check that the inputs can be inferred using the selected model.

#         Note: This method checks that the number of neurons in the input is
#         similar to the input dimension to the selected model.

#         Args:
#             inputs: Data to infer using the selected model.
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.
#         """
#         if isinstance(inputs, list):
#             raise ValueError(
#                 "Inputs to transform() should be the data for a single session, but received a list."
#             )
#         elif not isinstance(inputs, torch.Tensor):
#             raise ValueError(
#                 f"Inputs should be a torch.Tensor, not {type(inputs)}.")

#     @abc.abstractmethod
#     def _check_is_session_id_valid(self, session_id: Optional[int] = None):
#         """Check that the session ID provided is valid for the solver instance.

#         Args:
#             session_id: The session ID to check.
#         """
#         raise NotImplementedError

#     def _select_model(
#         self, inputs: Union[torch.Tensor,
#                             List[torch.Tensor]], session_id: Optional[int]
#     ) -> Tuple[Union[List[torch.nn.Module], torch.nn.Module],
#                cebra.data.datatypes.Offset]:
#         """ Select the model based on the input dimension and session ID.

#         Args:
#             inputs: Data to infer using the selected model.
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.

#         Returns:
#             The model (first returns) and the offset of the model (second returns).
#         """
#         model = self._get_model(session_id=session_id)
#         offset = model.get_offset()

#         self._check_is_inputs_valid(inputs, session_id=session_id)
#         return model, offset

#     @abc.abstractmethod
#     def _get_model(self,
#                    session_id: Optional[int] = None) -> cebra.models.Model:
#         """Get the model to use for inference.

#         Args:
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.

#         Returns:
#             The model.
#         """
#         raise NotImplementedError

#     def _check_is_fitted(self):
#         """Check if the model is fitted.

#         If the model is fitted, the solver should have a `n_features` attribute.

#         Raises:
#             ValueError: If the model is not fitted.
#         """
#         if not hasattr(self, "n_features"):
#             raise ValueError(
#                 f"This {type(self).__name__} instance is not fitted yet. Call 'fit' with "
#                 "appropriate arguments before using this estimator.")

#     @torch.no_grad()
#     def transform(self,
#                   inputs: torch.Tensor,
#                   pad_before_transform: Optional[bool] = True,
#                   session_id: Optional[int] = None,
#                   batch_size: Optional[int] = None) -> torch.Tensor:
#         """Compute the embedding.

#         This function by default only applies the ``forward`` function
#         of the given model, after switching it into eval mode.

#         Args:
#             inputs: The input signal (T, N).
#             pad_before_transform: If ``False``, no padding is applied to the input
#                 sequence and the output sequence will be smaller than the input
#                 sequence due to the receptive field of the model. If the
#                 input sequence is ``n`` steps long, and a model with receptive
#                 field ``m`` is used, the output sequence would  only be
#                 ``n-m+1`` steps long.
#             session_id: The session ID, an :py:class:`int` between 0 and
#                 the number of sessions -1 for multisession, and set to
#                 ``None`` for single session.
#             batch_size: If not None, batched inference will not be applied.

#         Returns:
#             The output embedding.
#         """
#         self._check_is_fitted()
#         model, offset = self._select_model(inputs, session_id)

#         if len(offset) < 2 and pad_before_transform:
#             pad_before_transform = False

#         model.eval()
#         return self._transform(model=model,
#                                inputs=inputs,
#                                pad_before_transform=pad_before_transform,
#                                offset=offset,
#                                batch_size=batch_size)

#     @torch.no_grad()
#     def _transform(self, model: cebra.models.Model, inputs: torch.Tensor,
#                    pad_before_transform: bool,
#                    offset: cebra.data.datatypes.Offset,
#                    batch_size: Optional[int]) -> torch.Tensor:
#         """Compute the embedding on the inputs using the model provided.

#         Args:
#             model: Model to use for inference.
#             inputs: Data.
#             pad_before_transform: If True zero-pad the batched data.
#             offset: Offset of the model to consider when padding.
#             batch_size: If not None, batched inference will not be applied.

#         Returns:
#             The embedding.
#         """
#         if batch_size is not None and inputs.shape[0] > int(
#                 batch_size * 2) and not (isinstance(
#                     self._get_model(0), cebra.models.ResampleModelMixin)):
#             # NOTE(celia): resampling models are not supported for batched inference.
#             output = _batched_transform(
#                 model=model,
#                 inputs=inputs,
#                 offset=offset,
#                 batch_size=batch_size,
#                 pad_before_transform=pad_before_transform,
#             )
#         else:
#             output = _not_batched_transform(
#                 model=model,
#                 inputs=inputs,
#                 offset=offset,
#                 pad_before_transform=pad_before_transform)
#         return output

#     @abc.abstractmethod
#     def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
#         """Given a batch of input examples, return the model outputs.

#         Args:
#             batch: The input data, not necessarily aligned across the batch
#                 dimension. This means that ``batch.index`` specifies the map
#                 between reference/positive samples, if not equal ``None``.

#         Returns:
#             Processed batch of data. While the input data might not be aligned
#             across the sample dimensions, the output data should be aligned and
#             ``batch.index`` should be set to ``None``.
#         """
#         raise NotImplementedError

#     def load(self, logdir: str, filename: str = "checkpoint.pth"):
#         """Load the experiment from its checkpoint file.

#         Args:
#             logdir: Logging directory.
#             filename: Checkpoint name for loading the experiment.
#         """

#         savepath = os.path.join(logdir, filename)
#         if not os.path.exists(savepath):
#             print("Did not find a previous experiment. Starting from scratch.")
#             return
#         checkpoint = torch.load(savepath, map_location=self.device)
#         self.load_state_dict(checkpoint, strict=True)

#         n_features = self.n_features
#         self.n_features = ([
#             session_n_features for session_n_features in n_features
#         ] if isinstance(n_features, list) else n_features)

#     def save(self, logdir: str, filename: str = "checkpoint_last.pth"):
#         """Save the model and optimizer params.

#         Args:
#             logdir: Logging directory for this model.
#             filename: Checkpoint name for saving the experiment.
#         """
#         if not os.path.exists(os.path.dirname(logdir)):
#             os.makedirs(logdir)
#         savepath = os.path.join(logdir, filename)
#         torch.save(
#             self.state_dict(),
#             savepath,
#         )


# @dataclasses.dataclass
# class MultiobjectiveSolver(Solver):
#     """Train models to satisfy multiple learning objectives.

#     This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
#     or "hybrid" training.

#     Attributes:
#         model: A multi-objective CEBRA model
#         optimizer: The optimizer used for training.
#         num_behavior_features: The feature dimension for the features dedicated
#             to satisfy the behavior contrastive objective. The remainder is used
#             for time contrastive learning.
#         renormalize_features: If ``True``, normalize the behavior and time
#             contrastive features individually before computing similarity scores.
#         ignore_deprecation_warning: If ``True``, suppress the deprecation warning.

#     Note:
#         This solver will be deprecated in a future version. Please use the functionality in
#         :py:mod:`cebra.solver.multiobjective` instead, which provides more versatile
#         multi-objective training capabilities. Instantiation of this solver will raise a
#         deprecation warning.
#     """

#     num_behavior_features: int = 3
#     renormalize_features: bool = False
#     output_mode: Literal["overlapping", "separate"] = "overlapping"
#     ignore_deprecation_warning: bool = False

#     @property
#     def num_time_features(self):
#         return self.num_total_features - self.num_behavior_features

#     @property
#     def num_total_features(self):
#         return self.model.num_output

#     def __post_init__(self):
#         super().__post_init__()
#         if not self.ignore_deprecation_warning:
#             warnings.warn(
#                 "MultiobjectiveSolver is deprecated since CEBRA 0.6.0 and will be removed in a future version. "
#                 "Use the new functionality in cebra.solver.multiobjective instead, which is more versatile. "
#                 "If you see this warning when using the scikit-learn interface, no action is required.",
#                 DeprecationWarning,
#                 stacklevel=2)
#         self._check_dimensions()
#         self.model = cebra.models.MultiobjectiveModel(
#             self.model,
#             dimensions=(self.num_behavior_features, self.model.num_output),
#             renormalize=self.renormalize_features,
#             output_mode=self.output_mode,
#         )

#     def _check_dimensions(self):
#         """Check the feature dimensions for behavior/time contrastive learning.

#         Raises:
#             ValueError: If feature dimensions are larger than the model features,
#                 or not sufficiently large for renormalization.
#         """
#         if self.output_mode == "separate":
#             if self.num_behavior_features >= self.num_total_features:
#                 raise ValueError(
#                     "For multi-objective training, the number of features for "
#                     f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
#                     f"than the total feature dimension ({self.num_total_features})."
#                 )
#             if self.num_time_features >= self.num_total_features:
#                 raise ValueError(
#                     "For multi-objective training, the number of features for "
#                     f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
#                     f"than the total feature dimension ({self.num_total_features})."
#                 )
#         if self.renormalize_features:
#             if self.num_behavior_features < 2:
#                 raise ValueError(
#                     "When renormalizing the features, the feature dimension needs "
#                     "to be at least 2 for behavior. "
#                     "Check the values of 'renormalize_features' and 'num_behavior_features'."
#                 )
#             if self.num_time_features < 2:
#                 raise ValueError(
#                     "When renormalizing the features, the feature dimension needs "
#                     "to be at least 2 for behavior. "
#                     "Check the values of 'renormalize_features' and 'num_time_features'."
#                 )

#     def step(self, batch: cebra.data.Batch) -> dict:
#         """Perform a single gradient update with multiple objectives.

#         Args:
#             batch: The input samples

#         Returns:
#             Dictionary containing training metrics.
#         """
#         self.optimizer.zero_grad()
#         prediction_behavior, prediction_time = self._inference(batch)

#         behavior_loss, behavior_align, behavior_uniform = self.criterion(
#             prediction_behavior.reference,
#             prediction_behavior.positive,
#             prediction_behavior.negative,
#         )

#         time_loss, time_align, time_uniform = self.criterion(
#             prediction_time.reference,
#             prediction_time.positive,
#             prediction_time.negative,
#         )

#         loss = behavior_loss + time_loss
#         loss.backward()
#         self.optimizer.step()
#         self.history.append(loss.item())
#         return dict(
#             behavior_pos=behavior_align.item(),
#             behavior_neg=behavior_uniform.item(),
#             behavior_total=behavior_loss.item(),
#             time_pos=time_align.item(),
#             time_neg=time_uniform.item(),
#             time_total=time_loss.item(),
#         )


# class AuxiliaryVariableSolver(Solver):

#     @torch.no_grad()
#     def transform(self,
#                   inputs: torch.Tensor,
#                   pad_before_transform: bool = True,
#                   session_id: Optional[int] = None,
#                   batch_size: Optional[int] = None,
#                   use_reference_model: bool = False) -> torch.Tensor:
#         """Compute the embedding.
#         This function by default use ``model`` that was trained to encode the positive
#         and negative samples. To use ``reference_model`` instead of ``model``
#         ``use_reference_model`` should be equal ``True``.
#         Args:
#             inputs: The input signal
#             use_reference_model: Flag for using ``reference_model``
#         Returns:
#             The output embedding.
#         """
#         self._check_is_fitted()
#         model, offset = self._select_model(
#             inputs, session_id, use_reference_model=use_reference_model)

#         if len(offset) < 2 and pad_before_transform:
#             pad_before_transform = False

#         model.eval()
#         return self._transform(model=model,
#                                inputs=inputs,
#                                pad_before_transform=pad_before_transform,
#                                offset=offset,
#                                batch_size=batch_size)
