#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""This package contains abstract base classes for different solvers.

Solvers are used to package models, criterions and optimizers and implement training
loops. When subclassing abstract solvers, in the simplest case only the
:py:meth:`Solver._inference` needs to be overridden.

For more complex use cases, the :py:meth:`Solver.step` and
:py:meth:`Solver.fit` method can be overridden to
implement larger changes to the training loop.
"""

import abc
import copy
import os
from typing import Callable, Dict, List, Literal, Optional

import literate_dataclasses as dataclasses
# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
import torch

import cebra
import cebra.data
import cebra.io
import cebra.models
from cebra.solver.util import Meter
from cebra.solver.util import ProgressBar


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor):
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
    """Project adv back to the closed L2 ball of radius ε around orig."""
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta


def _proj_l2_ball_scaled(adv: torch.Tensor, orig: torch.Tensor, epsilon):
    """Project ``adv`` back into an L2 budget around ``orig``.

    ``epsilon`` may be a scalar or a per-neuron tensor broadcastable against
    ``adv`` (shape ``(1, n_neurons, 1)`` etc.). With a scalar budget this is
    identical to :py:func:`_proj_l2_ball` (a plain L2 ball). With a per-neuron
    budget the constraint becomes the ellipsoid ``sum_j (delta_j / eps_j)^2 <=
    1``: perturbations are whitened by the per-neuron budget, projected onto the
    unit ball, then un-whitened. If all ``eps_j`` are equal this reduces exactly
    to the original sphere, so nothing changes for the constant mode.
    """
    delta = adv - orig
    scaled = delta / epsilon  # broadcast; whitened perturbation
    flat = scaled.reshape(scaled.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > 1.0, norm, torch.ones_like(norm))
    scaled = scaled / factor.view(-1, *([1] * (scaled.dim() - 1)))
    return orig + scaled * epsilon


#

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# negative_perm= shuffle_and_permute(batch.negative)


# copied_data = copy.deepcopy(batch)#batch.clone().detach()
# copied_data.positive = torch.randn_like(batch.positive).cuda() #positive_perm
# copied_data.reference = torch.randn_like(batch.reference).cuda() #anchor_perm
# copied_data.negative = torch.randn_like(batch.negative).cuda() #negative_perm


# prediction_fix = self._inference(batch)

# prediction_perm= self._inference(copied_data)

# x_perm_ = torch.cat([prediction_perm.reference,prediction_perm.positive, prediction_perm.negative], dim=0)
# x_fix= torch.cat([prediction_fix.reference,prediction_fix.positive, prediction_fix.negative], dim=0)

# self.optimizer.zero_grad()

# cos_raw    = torch.nn.functional.cosine_similarity(x_perm_,x_fix)
# L_cos      = torch.log((2 + cos_raw) / 2).mean()  # log version
# # print(L_cos.item())
# L_cos.backward()
# self.optimizer.step()


# fake_data=torch.randn_like(batch.positive).cuda()


# self.optimizer.zero_grad()

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# fake_data=torch.randn_like(batch.positive).cuda()


# x_perm_ = torch.cat([anchor_perm,positive_perm, batch.negative], dim=0)

# idx = torch.randperm(x_perm_.size(0))[:positive_perm.size(0)]


# permed_data_negative   = x_perm_[idx]

# fake_batch = cebra.data.Batch(
#                 reference=batch.reference,
#                 positive=batch.positive,
#                 negative=batch.negative
#             )
# fake_prediction = self._inference(fake_batch)
# loss, align, uniform= self.criterion(fake_prediction.reference,
#                                       fake_prediction.positive,
#                                       fake_prediction.negative)
# loss.backward()
# self.optimizer.step()


def clone_batch(batch):
    # 1) shallow-copy the Batch container
    new_batch = copy.copy(batch)

    # 2) for each tensor attribute in the batch, clone & detach
    #    adjust this list to match the actual fields in your Batch
    tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
    for field in tensor_fields:
        tensor = getattr(batch, field, None)
        if isinstance(tensor, torch.Tensor):
            # clone and detach so it shares neither data nor grad
            setattr(new_batch, field, tensor.clone().detach())
        # if the field can be a list/tuple of tensors, you could also do:
        # elif (isinstance(tensor, (list, tuple)) and
        #       all(isinstance(t, torch.Tensor) for t in tensor)):
        #     cloned = [t.clone().detach() for t in tensor]
        #     setattr(new_batch, field, type(tensor)(cloned))

    return new_batch


def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
    """
    Shuffle the second (M) and third (D) dimensions of a 3D tensor independently.

    Parameters:
        data (torch.Tensor): Input tensor of shape [N, M, D].

    Returns:
        torch.Tensor: Tensor with shuffled M and D dimensions.
    """
    N, M, D = data.size()

    # Create random permutations for the second and third dimensions
    perm_M = torch.randperm(M)
    # perm_D = torch.randperm(D)

    # Permute the second dimension (axis=1) first, then the third dimension (axis=2)
    shuffled_data = data[:, perm_M.cuda(), :]

    return shuffled_data


@dataclasses.dataclass
class Solver(abc.ABC, cebra.io.HasDevice):
    """Solver base class.

    A solver contains helper methods for bundling a model, criterion and optimizer.

    Attributes:
        model: The encoder for transforming reference, positive and negative samples.
        criterion: The criterion computed from the similarities between positive pairs
            and negative pairs. The criterion can have trainable parameters on its own.
        optimizer: A PyTorch optimizer for updating model and criterion parameters.
        history: Deprecated since 0.0.2. Use :py:attr:`log`.
        decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
            decoding. See the arguments of :py:meth:`fit`.
        log: The logs recorded during training, typically contains the ``total`` loss as well
            as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
            criterions in CEBRA, also contains the value of the ``temperature``.
        tqdm_on: Use ``tqdm`` for showing a progress bar during training.
        training_mode: The training mode, either "clean" or "adversarial".
        adv_epsilon: The maximum perturbation allowed for adversarial training.
        adv_alpha: The step size for adversarial training.
        adv_steps: The number of steps for adversarial training.
        attack_norm: The norm used for adversarial training, either "l2" or "linf".
        adv_epsilon_mode: How the perturbation budget is chosen (applies to
            both ``"linf"`` and ``"l2"``). ``"constant"`` (default) keeps the
            historical behaviour and uses ``adv_epsilon`` directly. The adaptive
            modes tie the budget to a dispersion statistic of the neural signal
            (see :py:meth:`_resolve_adv_epsilon`), scaled by
            ``adv_epsilon_coef``:

            * ``"per_neuron_std"`` / ``"per_neuron_mad"`` / ``"global_std"`` use
              the statistic of the current *batch*;
            * ``"per_neuron_std_dataset"`` / ``"per_neuron_mad_dataset"`` /
              ``"global_std_dataset"`` use the statistic of the whole recording,
              computed once at the start of :py:meth:`fit` and cached.

            The ``per_neuron_*`` modes give one budget per neuron; ``global_std``
            gives a single scalar budget. ``mad`` is the (robust) median
            absolute deviation; ``std`` the standard deviation.
        adv_epsilon_coef: Coefficient ``c`` used by the adaptive modes, e.g.
            ``eps_j = c * std_j`` for ``"per_neuron_std"``. Ignored when
            ``adv_epsilon_mode == "constant"``.
        adv_alpha_scale_with_epsilon: If ``True`` (only meaningful for the
            adaptive modes), the PGD step size is scaled per neuron so that the
            ratio ``adv_alpha / adv_epsilon`` is preserved for every coordinate.
            Defaults to ``False``, i.e. ``adv_alpha`` stays a single scalar.
    """

    model: torch.nn.Module
    criterion: torch.nn.Module
    optimizer: torch.optim.Optimizer
    history: List = dataclasses.field(default_factory=list)
    decode_history: List = dataclasses.field(default_factory=list)
    log: Dict = dataclasses.field(default_factory=lambda: ({
        "pos": [],
        "neg": [],
        "total": [],
        "temperature": []
    }))
    tqdm_on: bool = True
    training_mode: str = "clean"
    adv_epsilon: float = 0.05
    adv_alpha: float = 0.01
    adv_steps: int = 10
    attack_norm: str = "linf"
    adv_epsilon_mode: str = "constant"
    adv_epsilon_coef: float = 0.2
    adv_alpha_scale_with_epsilon: bool = False

    def __post_init__(self):
        cebra.io.HasDevice.__init__(self)
        self.best_loss = float("inf")
        # Filled lazily by _maybe_cache_dataset_stats for the "*_dataset" modes.
        self._dataset_stats = None

    # Adaptive epsilon modes. Each is (statistic, source):
    #   statistic in {std, mad, global_std}
    #   source    in {batch, dataset}
    _ADAPTIVE_EPSILON_MODES = {
        "per_neuron_std": ("std", "batch"),
        "global_std": ("global_std", "batch"),
        "per_neuron_mad": ("mad", "batch"),
        "per_neuron_std_dataset": ("std", "dataset"),
        "global_std_dataset": ("global_std", "dataset"),
        "per_neuron_mad_dataset": ("mad", "dataset"),
    }

    @staticmethod
    def _dispersion(neurons_by_samples: torch.Tensor, statistic: str):
        """Dispersion per neuron (or a scalar) from a ``(n_neurons, samples)`` tensor.

        ``std``/``mad`` return shape ``(n_neurons,)``; ``global_std`` returns a
        scalar shared by all neurons.
        """
        if statistic == "std":
            return neurons_by_samples.std(dim=1, unbiased=False)
        if statistic == "global_std":
            return neurons_by_samples.std(unbiased=False)
        if statistic == "mad":
            median = neurons_by_samples.median(dim=1, keepdim=True).values
            return (neurons_by_samples - median).abs().median(dim=1).values
        raise ValueError(f"Unknown dispersion statistic: {statistic!r}.")

    def _maybe_cache_dataset_stats(self, loader: "cebra.data.Loader"):
        """Precompute dataset-level dispersion for the ``*_dataset`` modes.

        Computed once over the whole neural recording (``loader.dataset.neural``,
        shape ``(time, n_neurons)``) and cached, so the per-step cost matches the
        batch-based modes. No-op for ``constant`` / batch-based modes.
        """
        self._dataset_stats = None
        spec = self._ADAPTIVE_EPSILON_MODES.get(self.adv_epsilon_mode)
        if spec is None or spec[1] != "dataset":
            return
        statistic = spec[0]
        neural = getattr(getattr(loader, "dataset", None), "neural", None)
        if neural is None:
            raise ValueError(
                f"adv_epsilon_mode={self.adv_epsilon_mode!r} needs "
                "loader.dataset.neural, which is not available on this loader.")
        with torch.no_grad():
            # neural: (time, n_neurons) -> (n_neurons, time) for _dispersion.
            self._dataset_stats = self._dispersion(neural.transpose(0, 1),
                                                   statistic)

    def _resolve_adv_epsilon(self, reference: torch.Tensor):
        """Resolve the perturbation budget for the current batch (both norms).

        In ``"constant"`` mode this returns the scalar ``self.adv_epsilon``
        unchanged, so adversarial training behaves exactly as before. The
        adaptive modes instead derive the budget from a dispersion statistic of
        the neural signal, scaled by ``self.adv_epsilon_coef``:

        * ``per_neuron_std`` / ``per_neuron_mad`` -> ``eps_j = coef * spread_j``
          with a budget per neuron.
        * ``global_std`` -> a single scalar ``coef * spread`` for all neurons.
        * the ``*_dataset`` variants use the same statistic but computed once
          over the whole recording (cached), instead of per batch.

        ``reference`` has shape ``(batch, n_neurons)`` or
        ``(batch, n_neurons, window)`` (neuron axis = dim 1). The return either
        is the scalar ``self.adv_epsilon`` (constant / global_std) or a tensor
        that broadcasts against ``reference`` (shape ``(1, n_neurons)`` or
        ``(1, n_neurons, 1)``).

        Rationale: both attacks bound ``x_adv - x`` in input space, so a single
        scalar budget treats a high-variance and a near-silent neuron
        identically. Scaling the budget by each neuron's own spread makes the
        allowed perturbation proportional to how much that neuron actually
        fluctuates (``eps_j = c * spread_j``) -- the input-space analogue of
        "perturb within the signal's own noise level".
        """
        mode = self.adv_epsilon_mode
        if mode == "constant":
            return self.adv_epsilon

        spec = self._ADAPTIVE_EPSILON_MODES.get(mode)
        if spec is None:
            raise ValueError(
                f"Unknown adv_epsilon_mode: {mode!r}. Expected one of "
                f"{['constant'] + list(self._ADAPTIVE_EPSILON_MODES)}.")
        statistic, source = spec

        with torch.no_grad():
            if source == "dataset":
                if self._dataset_stats is None:
                    raise RuntimeError(
                        f"adv_epsilon_mode={mode!r} requires dataset statistics "
                        "that were not cached; call fit() through the standard "
                        "path so _maybe_cache_dataset_stats runs.")
                spread = self._dataset_stats.to(reference.device)
            else:
                # (batch, n_neurons, [window]) -> (n_neurons, samples).
                flat = reference.transpose(0, 1).reshape(reference.shape[1], -1) \
                    if reference.dim() > 1 else reference.reshape(1, -1)
                spread = self._dispersion(flat, statistic)

            epsilon = self.adv_epsilon_coef * spread

            if statistic == "global_std":
                # Scalar (batch) or (n_neurons,)->scalar already; keep scalar.
                return epsilon if epsilon.dim() == 0 else epsilon.mean()

            # Shape (n_neurons,) -> broadcastable against `reference`.
            view_shape = [1] * reference.dim()
            view_shape[1] = -1
            return epsilon.view(*view_shape)

    def _resolve_adv_alpha(self, adv_epsilon):
        """Resolve the PGD step size to match ``_resolve_adv_epsilon``.

        By default ``adv_alpha`` stays the scalar the user configured. When
        ``adv_alpha_scale_with_epsilon`` is set (adaptive modes only), the step
        size is rescaled per coordinate so that ``adv_alpha / adv_epsilon`` is
        preserved, i.e. every neuron still takes the same number of steps to
        traverse its own ε-ball.
        """
        if (self.adv_epsilon_mode == "constant"
                or not self.adv_alpha_scale_with_epsilon):
            return self.adv_alpha
        # adv_epsilon is a tensor here; ratio to the scalar reference budget.
        ref_eps = self.adv_epsilon if self.adv_epsilon != 0 else 1.0
        return self.adv_alpha * (adv_epsilon / ref_eps)

    def state_dict(self) -> dict:
        """Return a dictionary fully describing the current solver state.

        Returns:
            State dictionary, including the state dictionary of the models and
            optimizer. Also contains the training history and the CEBRA version
            the model was trained with.
        """

        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "loss": torch.tensor(self.history),
            "decode": self.decode_history,
            "criterion": self.criterion.state_dict(),
            "version": cebra.__version__,
            "log": self.log,
        }

    def load_state_dict(self, state_dict: dict, strict: bool = True):
        """Update the solver state with the given state_dict.

        Args:
            state_dict: Dictionary with parameters for the `model`, `optimizer`,
                and the past loss history for the solver.
            strict: Make sure all states can be loaded. Set to `False` to allow
                to partially load the state for all given keys.
        """

        def _contains(key):
            if key in state_dict:
                return True
            elif strict:
                raise KeyError(
                    f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
                )
            return False

        def _get(key):
            return state_dict.get(key)

        if _contains("model"):
            self.model.load_state_dict(_get("model"))
        if _contains("criterion"):
            self.criterion.load_state_dict(_get("criterion"))
        if _contains("optimizer"):
            self.optimizer.load_state_dict(_get("optimizer"))
        # TODO(stes): This will be deprecated at some point; the "log" attribute
        # holds the same information.
        if _contains("loss"):
            self.history = _get("loss").cpu().numpy().tolist()
        if _contains("decode"):
            self.decode_history = _get("decode")
        if _contains("log"):
            self.log = _get("log")

    @property
    def num_parameters(self) -> int:
        """Total number of parameters in the encoder and criterion."""
        return sum(p.numel() for p in self.parameters())

    def parameters(self):
        """Iterate over all parameters."""
        for parameter in self.model.parameters():
            yield parameter

        for parameter in self.criterion.parameters():
            yield parameter

    def _get_loader(self, loader):
        return ProgressBar(
            loader,
            "tqdm" if self.tqdm_on else "off",
        )

    def fit(
            self,
            loader: cebra.data.Loader,
            valid_loader: cebra.data.Loader = None,
            *,
            save_frequency: int = None,
            valid_frequency: int = None,
            decode: bool = False,
            logdir: str = None,
            save_hook: Callable[[int, "Solver"], None] = None,
    ):
        """Train model for the specified number of steps.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            valid_loader: Data loader used for validation of the model.
            save_frequency: If not `None`, the frequency for automatically saving model checkpoints
                to `logdir`.
            valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
            logdir:  The logging directory for writing model checkpoints. The checkpoints
                can be read again using the `solver.load` function, or manually via loading the
                state dict.

        TODO:
            * Refine the API here. Drop the validation entirely, and implement this via a hook?
        """

        self.to(loader.device)

        # Cache dataset-level dispersion statistics for the adaptive epsilon
        # "*_dataset" modes, so they are computed once over the whole neural
        # recording instead of per batch. No-op for the batch-based modes.
        self._maybe_cache_dataset_stats(loader)

        iterator = self._get_loader(loader)
        self.model.train()
        for num_steps, batch in iterator:
            stats = self.step(batch)
            iterator.set_description(stats)

            if save_frequency is None:
                continue
            save_model = num_steps % save_frequency == 0
            run_validation = (valid_loader
                              is not None) and (num_steps % valid_frequency
                                                == 0)
            if run_validation:
                validation_loss = self.validation(valid_loader)
                if self.best_loss is None or validation_loss < self.best_loss:
                    self.best_loss = validation_loss
                    self.save(logdir, "checkpoint_best.pth")
            if save_model:
                if decode:
                    self.decode_history.append(
                        self.decoding(loader, valid_loader))
                if save_hook is not None:
                    save_hook(num_steps, self)
                if logdir is not None:
                    self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

    # ----------------------------------------------------------------------
    # Drop-in replacement for Solver.step
    # ----------------------------------------------------------------------
    def step(self, batch: cebra.data.Batch) -> dict:
        # ------------------------------------------------------------
        # 1) ordinary contrastive update
        # ------------------------------------------------------------
        self.optimizer.zero_grad()
        pred = self._inference(batch)
        loss, align, uniform = self.criterion(
            pred.reference, pred.positive, pred.negative
        )
        loss.backward()
        self.optimizer.step()
        # print(self.training_mode, self.attack_norm)
        if self.training_mode == "adversarial":
            if self.attack_norm == "linf":
                self.optimizer.zero_grad()

                adv_epsilon = self._resolve_adv_epsilon(batch.reference)
                adv_alpha = self._resolve_adv_alpha(adv_epsilon)
                adv_steps = self.adv_steps

                self.optimizer.zero_grad()

                # Create adversarial examples
                # x_adv = batch.reference.clone().detach()

                perturb = torch.empty_like(batch.reference) \
                    .uniform_(-1.0, 1.0) * adv_epsilon
                x_adv = (batch.reference + perturb).clone()

                x_adv.requires_grad = True

                for _ in range(self.adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    with torch.enable_grad():
                        # Forward pass with adversarial examples
                        adv_batch = cebra.data.Batch(
                            reference=x_adv,
                            positive=batch.positive,
                            negative=batch.negative
                        )
                        adv_output = self._inference(adv_batch)
                        loss, _, _ = self.criterion(adv_output.reference,
                                                    adv_output.positive,
                                                    adv_output.negative)

                    grad_x, = torch.autograd.grad(
                        loss, x_adv,
                        retain_graph=False,
                        create_graph=False
                    )

                    with torch.no_grad():
                        grad_sign = grad_x.sign()
                        x_adv = x_adv + adv_alpha * grad_sign
                        x_adv = torch.max(torch.min(x_adv, batch.reference + adv_epsilon),
                                          batch.reference - adv_epsilon)
                        x_adv.requires_grad = True

                # Final forward pass with adversarial examples
                adv_batch = cebra.data.Batch(
                    reference=x_adv,
                    positive=batch.positive,
                    negative=batch.negative
                )
                output = self._inference(adv_batch)
                loss, _, _ = self.criterion(output.reference,
                                            output.positive,
                                            output.negative)
                loss.backward()
                self.optimizer.step()
            elif self.attack_norm == "l2":
                self.optimizer.zero_grad()

                adv_eps = self._resolve_adv_epsilon(batch.reference)
                adv_alpha = self._resolve_adv_alpha(adv_eps)
                adv_steps = self.adv_steps

                x_adv = batch.reference.clone().detach()
                noise = _l2_normalize(torch.randn_like(x_adv))
                noise = noise * (_rand_radius_like(x_adv) * adv_eps)
                x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

                for _ in range(adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    adv_b = cebra.data.Batch(reference=x_adv,
                                             positive=batch.positive,
                                             negative=batch.negative)
                    adv_out = self._inference(adv_b)
                    adv_loss, _, _ = self.criterion(
                        adv_out.reference, adv_out.positive, adv_out.negative
                    )
                    grad_x, = torch.autograd.grad(
                        adv_loss, x_adv,
                        retain_graph=False,
                        create_graph=False
                    )

                    with torch.no_grad():
                        x_adv += adv_alpha * _l2_normalize(grad_x)
                        x_adv = _proj_l2_ball_scaled(x_adv, batch.reference, adv_eps)
                        x_adv.requires_grad = True

                adv_b = cebra.data.Batch(reference=x_adv,
                                         positive=batch.positive,
                                         negative=batch.negative)
                out = self._inference(adv_b)
                loss3, _, _ = self.criterion(out.reference, out.positive, out.negative)
                loss3.backward()
                self.optimizer.step()

        self.history.append(loss.item())
        stats = dict(
            pos=align.item(),
            neg=uniform.item(),
            total=loss.item(),
            temperature=self.criterion.temperature,
        )
        for k, v in stats.items():
            self.log[k].append(v)
        return stats

    # ------------------------------------------------------------
    # 6) logging
    # ------------------------------------------------------------

    def validation(self,
                   loader: cebra.data.Loader,
                   session_id: Optional[int] = None):
        """Compute score of the model on data.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            session_id: The session ID, an integer between 0 and the number of sessions in the
                multisession model, set to None for single session.

        Returns:
            Loss averaged over iterations on data batch.
        """
        assert (session_id is None) or (session_id == 0)
        iterator = self._get_loader(loader)
        total_loss = Meter()
        self.model.eval()
        for _, batch in iterator:
            prediction = self._inference(batch)
            loss, _, _ = self.criterion(prediction.reference,
                                        prediction.positive,
                                        prediction.negative)
            total_loss.add(loss.item())
        return total_loss.average

    @torch.no_grad()
    def decoding(self, train_loader, valid_loader):
        """Deprecated since 0.0.2."""
        train_x = self.transform(train_loader.dataset[torch.arange(
            len(train_loader.dataset.neural))])
        train_y = train_loader.dataset.index
        valid_x = self.transform(valid_loader.dataset[torch.arange(
            len(valid_loader.dataset.neural))])
        valid_y = valid_loader.dataset.index
        decode_metric = train_loader.dataset.decode(
            train_x.cpu().numpy(),
            train_y.cpu().numpy(),
            valid_x.cpu().numpy(),
            valid_y.cpu().numpy(),
        )
        return decode_metric

    @torch.no_grad()
    def transform(self, inputs: torch.Tensor) -> torch.Tensor:
        """Compute the embedding.

        This function by default only applies the ``forward`` function
        of the given model, after switching it into eval mode.

        Args:
            inputs: The input signal

        Returns:
            The output embedding.

        TODO:
            * Remove eval mode
        """

        self.model.eval()
        return self.model(inputs)

    @abc.abstractmethod
    def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
        """Given a batch of input examples, return the model outputs.

        TODO: make this a public function?

        Args:
            batch: The input data, not necessarily aligned across the batch
                dimension. This means that ``batch.index`` specifies the map
                between reference/positive samples, if not equal ``None``.

        Returns:
            Processed batch of data. While the input data might not be aligned
            across the sample dimensions, the output data should be aligned and
            ``batch.index`` should be set to ``None``.
        """
        raise NotImplementedError

    def load(self, logdir, filename="checkpoint.pth"):
        """Load the experiment from its checkpoint file.

        Args:
            filename (str): Checkpoint name for loading the experiment.
        """

        savepath = os.path.join(logdir, filename)
        if not os.path.exists(savepath):
            print("Did not find a previous experiment. Starting from scratch.")
            return
        checkpoint = torch.load(savepath, map_location=self.device)
        self.load_state_dict(checkpoint, strict=True)

    def save(self, logdir, filename="checkpoint_last.pth"):
        """Save the model and optimizer params.

        Args:
            logdir: Logging directory for this model.
            filename: Checkpoint name for saving the experiment.
        """
        if not os.path.exists(os.path.dirname(logdir)):
            os.makedirs(logdir)
        savepath = os.path.join(logdir, filename)
        torch.save(
            self.state_dict(),
            savepath,
        )


@dataclasses.dataclass
class MultiobjectiveSolver(Solver):
    """Train models to satisfy multiple learning objectives.

    This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
    or "hybrid" training.

    Attributes:
        model: A multi-objective CEBRA model
        optimizer: The optimizer used for training.
        num_behavior_features: The feature dimension for the features dedicated
            to satisfy the behavior contrastive objective. The remainder is used
            for time contrastive learning.
        renormalize_features: If ``True``, normalize the behavior and time
            contrastive features individually before computing similarity scores.
    """

    num_behavior_features: int = 3
    renormalize_features: bool = False
    output_mode: Literal["overlapping", "separate"] = "overlapping"

    @property
    def num_time_features(self):
        return self.num_total_features - self.num_behavior_features

    @property
    def num_total_features(self):
        return self.model.num_output

    def __post_init__(self):
        super().__post_init__()
        self._check_dimensions()
        self.model = cebra.models.MultiobjectiveModel(
            self.model,
            dimensions=(self.num_behavior_features, self.model.num_output),
            renormalize=self.renormalize_features,
            output_mode=self.output_mode,
        )

    def _check_dimensions(self):
        """Check the feature dimensions for behavior/time contrastive learning.

        Raises:
            ValueError: If feature dimensions are larger than the model features,
                or not sufficiently large for renormalization.
        """
        if self.output_mode == "separate":
            if self.num_behavior_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
            if self.num_time_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
        if self.renormalize_features:
            if self.num_behavior_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_behavior_features'."
                )
            if self.num_time_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_time_features'."
                )

    def step(self, batch: cebra.data.Batch) -> dict:
        """Perform a single gradient update with multiple objectives.

        Args:
            batch: The input samples

        Returns:
            Dictionary containing training metrics.
        """
        self.optimizer.zero_grad()
        prediction_behavior, prediction_time = self._inference(batch)

        behavior_loss, behavior_align, behavior_uniform = self.criterion(
            prediction_behavior.reference,
            prediction_behavior.positive,
            prediction_behavior.negative,
        )

        time_loss, time_align, time_uniform = self.criterion(
            prediction_time.reference,
            prediction_time.positive,
            prediction_time.negative,
        )

        loss = behavior_loss + time_loss
        loss.backward()
        self.optimizer.step()
        self.history.append(loss.item())

        # 2) ---------------- adversarial branch (optional) ----------------------
        if self.training_mode == "adversarial":
            if self.attack_norm == "linf":
                # We perturb only the reference view
                adv_epsilon = self._resolve_adv_epsilon(batch.reference)
                adv_alpha = self._resolve_adv_alpha(adv_epsilon)

                perturb = torch.empty_like(batch.reference) \
                    .uniform_(-1.0, 1.0) * adv_epsilon
                x_adv = (batch.reference + perturb).clone()

                # x_adv = batch.reference.detach().clone()
                x_adv.requires_grad_(True)

                for _ in range(self.adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    adv_batch = cebra.data.Batch(
                        reference=x_adv,
                        positive=batch.positive,
                        negative=batch.negative,
                    )

                    adv_pred_beh, adv_pred_time = self._inference(adv_batch)
                    adv_beh_loss, _, _ = self.criterion(
                        adv_pred_beh.reference,
                        adv_pred_beh.positive,
                        adv_pred_beh.negative,
                    )
                    adv_time_loss, _, _ = self.criterion(
                        adv_pred_time.reference,
                        adv_pred_time.positive,
                        adv_pred_time.negative,
                    )
                    adv_loss = adv_beh_loss + adv_time_loss
                    adv_loss.backward()

                    with torch.no_grad():
                        # PGD update + projection to ε-ball
                        grad_sign = x_adv.grad.sign()
                        x_adv.add_(adv_alpha * grad_sign)
                        # torch.max/min (not in-place clamp_) so a per-neuron
                        # tensor budget broadcasts on every torch version.
                        x_adv = torch.max(
                            torch.min(x_adv, batch.reference + adv_epsilon),
                            batch.reference - adv_epsilon)
                        x_adv.requires_grad_(True)

                # final update with fixed adversarial examples
                self.optimizer.zero_grad()
                adv_batch = cebra.data.Batch(
                    reference=x_adv.detach(),
                    positive=batch.positive,
                    negative=batch.negative,
                )
                adv_pred_beh, adv_pred_time = self._inference(adv_batch)
                adv_beh_loss, _, _ = self.criterion(
                    adv_pred_beh.reference,
                    adv_pred_beh.positive,
                    adv_pred_beh.negative,
                )
                adv_time_loss, _, _ = self.criterion(
                    adv_pred_time.reference,
                    adv_pred_time.positive,
                    adv_pred_time.negative,
                )
                adv_total_loss = adv_beh_loss + adv_time_loss
                adv_total_loss.backward()
                self.optimizer.step()
            elif self.attack_norm == "l2":
                self.optimizer.zero_grad()

                adv_eps = self._resolve_adv_epsilon(batch.reference)
                adv_alpha = self._resolve_adv_alpha(adv_eps)
                adv_steps = self.adv_steps

                x_adv = batch.reference.clone().detach()
                noise = _l2_normalize(torch.randn_like(x_adv))
                noise = noise * (_rand_radius_like(x_adv) * adv_eps)
                x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

                for _ in range(adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    adv_b = cebra.data.Batch(reference=x_adv,
                                             positive=batch.positive,
                                             negative=batch.negative)
                    adv_out, _ = self._inference(adv_b)
                    adv_loss, _, _ = self.criterion(
                        adv_out.reference, adv_out.positive, adv_out.negative
                    )
                    adv_loss.backward()

                    with torch.no_grad():
                        x_adv += adv_alpha * _l2_normalize(x_adv.grad)
                        x_adv = _proj_l2_ball_scaled(x_adv, batch.reference, adv_eps)
                        x_adv.requires_grad = True

                adv_b = cebra.data.Batch(reference=x_adv,
                                         positive=batch.positive,
                                         negative=batch.negative)
                out, _ = self._inference(adv_b)
                loss3, _, _ = self.criterion(out.reference, out.positive, out.negative)
                loss3.backward()
                self.optimizer.step()

        self.history.append(loss.item())
        return dict(
            behavior_pos=behavior_align.item(),
            behavior_neg=behavior_uniform.item(),
            behavior_total=behavior_loss.item(),
            time_pos=time_align.item(),
            time_neg=time_uniform.item(),
            time_total=time_loss.item(),
        )
