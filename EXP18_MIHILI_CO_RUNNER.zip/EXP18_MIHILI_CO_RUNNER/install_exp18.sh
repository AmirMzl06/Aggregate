#!/usr/bin/env bash
set -euo pipefail
MON="${MON:-/mnt/upmwmathis/scratch/hossein/aj_project/monkey_gru}"
DST="${DST:-/home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source}"
PAYLOAD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -d "$MON/.git" ]] || { echo "Missing professor repository: $MON" >&2; exit 1; }
[[ ! -e "$DST/run_multi.py" ]] || { echo "Destination already contains source, refusing overwrite: $DST" >&2; exit 1; }
mkdir -p "$DST"
git -C "$MON" archive a780890 | tar -x -C "$DST"
if [[ ! -e "$DST/xds" && -d "$MON/xds" ]]; then
  case "$MON" in
    /mnt/upmwmathis/scratch/*)
      ln -s "/data/${MON#/mnt/upmwmathis/scratch/}/xds" "$DST/xds" ;;
    *) ln -s "$MON/xds" "$DST/xds" ;;
  esac
fi
cp "$PAYLOAD"/{exp17_noise.py,exp18_run.py,exp18_cache_entry.py,exp18_4gpu.py,exp18_4gpu.sh,exp18_compare.py} "$DST/"
cp -r "$PAYLOAD/exp17_dprime" "$DST/"
chmod +x "$DST/exp18_4gpu.sh"
echo "FROZEN PROFESSOR REVISION: $(git -C "$MON" rev-parse a780890)"
echo "INSTALLED EXP18 ISOLATED SOURCE: $DST"
echo "PROFESSOR REPOSITORY AND EXP17 ARE UNMODIFIED"
echo "OUTPUT ROOT: /mnt/upmwmathis/scratch/hossein/mm_project/EXP18_MIHILI_CO"
