#!/usr/bin/env python3
"""Exp18 4-GPU run/resume orchestrator. Only standard-library dependencies.

Four independent processes run different (seed, arm) pairs. Each is pinned to one
CUDA-visible device. Data, caches and all new outputs reside on the Scratch PVC.
Professor source and existing Exp18 attack logic are not modified.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time

HOME_SOURCE = Path('/home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source')
SCRATCH_HOST = Path('/mnt/upmwmathis/scratch/hossein/mm_project/EXP18_MIHILI_CO')
SCRATCH_POD = Path('/data/hossein/mm_project/EXP18_MIHILI_CO')
VENV_PYTHON = Path('/data/hossein/aj_project/.venv/bin/python')
SEEDS = (42, 43)
ARMS = (
    'clean', 'pgd_0p5',
    'noise_0p1', 'noise_0p3', 'noise_0p5', 'noise_0p7',
    'noise_1', 'noise_3', 'noise_5', 'noise_7',
    'auto_emp', 'auto_quantile',
)


def task_name(seed: int, arm: str) -> str:
    return f'exp18-co-s{seed}-{arm.replace("_", "-")}'


def all_tasks():
    # Interleave seeds so that all four GPUs have useful, independent work.
    return [(seed, arm) for arm in ARMS for seed in SEEDS]


def check_complete(path: Path, seed: int, arm: str) -> tuple[bool, str]:
    metrics_path = path / 'metrics.json'
    record_path = path / 'exp18_record.json'
    if not metrics_path.is_file() or not record_path.is_file():
        return False, 'missing metrics.json or exp18_record.json'
    try:
        m = json.loads(metrics_path.read_text(encoding='utf-8'))
        r = json.loads(record_path.read_text(encoding='utf-8'))
        if int(m.get('nBatch', -1)) != 30000:
            return False, 'wrong encoder nBatch (expected 30000)'
        if int(m.get('n_decoder_batches', -1)) != 30000:
            return False, 'wrong decoder nBatch (expected 30000)'
        if int(m.get('batchSize', -1)) != 1024:
            return False, 'wrong batchSize (expected 1024)'
        d = m['per_dataset']['mihili_co']
        days = d['r2_other_days']
        if not isinstance(days, dict) or set(map(int, days.keys())) != set(range(1, 11)):
            return False, 'missing one or more of days 1..10'
        float(d['r2_holdout'])
        float(d['r2_mean_other_days'])
        if str(r.get('arm')) != arm or int(r.get('seed')) != seed:
            return False, 'record seed/arm mismatch'
        if m.get('neural_zscore') is not False or r.get('neural_zscore') is not False:
            return False, 'not an Exp18 no-Zscore result'
        if r.get('protocol') != 'professor_day0_80_20_no_neural_zscore_all_days':
            return False, 'wrong experiment protocol'
        return True, 'validated 11-day metrics and Exp18 record'
    except Exception as exc:
        return False, f'invalid metrics/record: {exc}'


def prepare_dirs(root: Path):
    for dirname in ('runs', 'logs', 'tmp', 'cache', 'backups'):
        (root / dirname).mkdir(parents=True, exist_ok=True)
    # A simple write test detects read-only paths and many quota errors.
    with tempfile.NamedTemporaryFile(dir=root / 'tmp', prefix='writecheck-', delete=True) as fh:
        fh.write(b'EXP18 scratch write test\n')
        fh.flush()
        os.fsync(fh.fileno())


def report(scratch: Path) -> list[tuple[int, str]]:
    pending = []
    complete = 0
    for seed, arm in all_tasks():
        name = task_name(seed, arm)
        ok, _ = check_complete(scratch / 'runs' / name, seed, arm)
        if ok:
            d = json.loads((scratch / 'runs' / name / 'metrics.json').read_text())['per_dataset']['mihili_co']
            print(f'[DONE]    {name:<31} cross_day_R2={float(d["r2_mean_other_days"]):.4f}')
            if not (scratch / 'runs' / name / 'checkpoint.pt').exists():
                print(f'[WARNING] {name}: checkpoint.pt not found, but metrics are complete')
            complete += 1
        else:
            print(f'[PENDING] {name}')
            pending.append((seed, arm))
    print(f'\nSTATUS: {complete}/24 COMPLETE, {len(pending)}/24 PENDING', flush=True)
    return pending


def python_command(seed: int, arm: str, output: Path, python: Path, source: Path) -> list[str]:
    eps = arm.removeprefix('noise_').replace('p', '.') if arm.startswith('noise_') else '0.5'
    cmd = [
        str(python), '-u', str(source / 'exp18_cache_entry.py'),
        '--exp18-arm', arm, '--exp18-pairs', '20000',
        '--datasets', 'mihili_co', '--seed', str(seed),
        '--adv-style', 'bin', '--adv_norm', 'l2', '--adv_eps', eps,
        '--enc-optimizer', 'adam', '--enc-lr', '0.02', '--linear-lr',
        '--lr-end', '0.002', '--enc-weight-decay', '1e-5',
        '--adam-eps', '0.1', '--enc-grad-clip', '5.0',
        '--batchSize', '1024', '--nBatch', '30000',
        '--n-decoder-batches', '30000', '--adv-dec', '--adv-dec-eps', '0.1',
        '--output-dir', str(output),
    ]
    if arm == 'clean':
        cmd.append('--no-adv')
    return cmd


def check_gpu_count(python: Path):
    result = subprocess.run(
        [str(python), '-c', 'import torch; print(torch.cuda.device_count())'],
        check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    gpu_count = int(result.stdout.strip().splitlines()[-1])
    if gpu_count < 4:
        raise RuntimeError(f'Four GPUs are required; detected {gpu_count}. Refusing serial fallback.')
    print(f'[GPU] detected {gpu_count} CUDA devices; launching exactly four GPU workers', flush=True)


def run(scratch: Path, source: Path, python: Path) -> int:
    if not str(scratch).startswith('/data/'):
        raise RuntimeError('--run must use the in-pod Scratch path beginning /data/')
    if not python.is_file():
        raise FileNotFoundError(f'Missing Python environment: {python}')
    for file in ('exp18_run.py', 'exp18_cache_entry.py', 'run_multi.py'):
        if not (source / file).is_file():
            raise FileNotFoundError(f'Missing source file: {source / file}')
    prepare_dirs(scratch)
    print("[EXP18] Fresh no-Zscore experiment; never import Exp17 results", flush=True)
    pending = report(scratch)
    if not pending:
        print('EXP18 COMPLETE: no training needed', flush=True)
        return 0
    check_gpu_count(python)
    print('[SCRATCH]', scratch, flush=True)
    free_gb = shutil.disk_usage(scratch).free / (1024 ** 3)
    print(f'[STORAGE] filesystem free approximately {free_gb:.1f} GiB; user quota may differ', flush=True)
    work = queue.Queue()
    for task in pending:
        work.put(task)
    errors = []
    lock = threading.Lock()

    def worker(gpu_index: int):
        local_errors = []
        while True:
            try:
                seed, arm = work.get_nowait()
            except queue.Empty:
                break
            name = task_name(seed, arm)
            out = scratch / 'runs' / name
            log = scratch / 'logs' / f'{name}.log'
            ok, _ = check_complete(out, seed, arm)
            if ok:
                print(f'[GPU {gpu_index}] SKIP already complete {name}', flush=True)
                work.task_done()
                continue
            out.mkdir(parents=True, exist_ok=True)
            env = os.environ.copy()
            env.update({
                'CUDA_VISIBLE_DEVICES': str(gpu_index),
                'USER': 'mirzaei', 'LOGNAME': 'mirzaei', 'USERNAME': 'mirzaei',
                'PYTHONUNBUFFERED': '1', 'SKIP_PLOTS': '1',
                'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4',
                'EXP18_CACHE_DIR': str(scratch / 'cache' / f'gpu{gpu_index}' / 'weights_cache'),
                'TMPDIR': str(scratch / 'tmp' / f'gpu{gpu_index}'),
                'TORCHINDUCTOR_CACHE_DIR': str(scratch / 'cache' / f'gpu{gpu_index}' / 'torchinductor'),
                'XDG_CACHE_HOME': str(scratch / 'cache' / f'gpu{gpu_index}' / 'xdg'),
                'PYTHONPYCACHEPREFIX': str(scratch / 'cache' / f'gpu{gpu_index}' / 'pycache'),
            })
            for key in ('EXP18_CACHE_DIR', 'TMPDIR', 'TORCHINDUCTOR_CACHE_DIR', 'XDG_CACHE_HOME', 'PYTHONPYCACHEPREFIX'):
                Path(env[key]).mkdir(parents=True, exist_ok=True)
            cmd = python_command(seed, arm, out, python, source)
            print(f'[GPU {gpu_index}] START {name} | log={log}', flush=True)
            try:
                # Append rather than truncate, retaining evidence from attempts.
                with log.open('a', encoding='utf-8') as file:
                    file.write(f'\n========== RESUME ATTEMPT GPU {gpu_index}, {time.ctime()} ==========\n')
                    file.flush()
                    result = subprocess.run(cmd, cwd=source, env=env, stdout=file,
                                            stderr=subprocess.STDOUT, check=False)
                ok, reason = check_complete(out, seed, arm)
                if result.returncode == 0 and ok:
                    print(f'[GPU {gpu_index}] DONE  {name}', flush=True)
                else:
                    why = f'exit={result.returncode}, output={reason}'
                    print(f'[GPU {gpu_index}] FAIL  {name} ({why})', flush=True)
                    local_errors.append((name, why))
            except Exception as exc:
                print(f'[GPU {gpu_index}] ERROR {name}: {exc}', flush=True)
                local_errors.append((name, str(exc)))
            finally:
                work.task_done()
        with lock:
            errors.extend(local_errors)

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(worker, i) for i in range(4)]
        for future in futures:
            future.result()

    print('\n========== EXP18 RESUME SUMMARY ==========', flush=True)
    remain = report(scratch)
    if errors:
        print('\nFAILED RUNS (details in Scratch/logs):', flush=True)
        for name, why in errors:
            print(f'  {name}: {why}', flush=True)
    if remain:
        print('Incomplete runs remain. Re-run with same Scratch path; completed models will be skipped.', flush=True)
        return 1
    print('ALL 24 EXP18 RUNS VERIFIED ON SCRATCH', flush=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true', help='Headnode: display complete/pending Exp18 runs on Scratch')
    mode.add_argument('--run', action='store_true', help='Inside RunAI pod: resume pending runs on 4 GPUs')
    parser.add_argument('--scratch', type=Path, help='Override Scratch root; default host for plan and pod for run')
    parser.add_argument('--source', type=Path, default=HOME_SOURCE)
    parser.add_argument('--python', type=Path, default=VENV_PYTHON)
    args = parser.parse_args()
    scratch = args.scratch or (SCRATCH_POD if args.run else SCRATCH_HOST)
    if args.plan:
        report(scratch)
        return 0
    return run(scratch, args.source, args.python)


if __name__ == '__main__':
    sys.exit(main())
