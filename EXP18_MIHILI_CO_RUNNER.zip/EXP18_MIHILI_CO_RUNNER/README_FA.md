# Exp18 — Mihili CO without neural Z-score

**One controlled change relative to Exp17:** The neural input is not Z-score normalized on any day. The original professor `data.load_day_split(..., zscore=False)` and `load_day_trials(..., zscore=False)` are called via an **in-memory patch before imports**; the professor source, Exp17 copy, and existing results are never modified.

- `Mihili_CO_2014_raw`, 11 days, 50-ms unsmoothed binned spikes (`xds_smooth=False`), same internal model smoothing as Exp17.
- Day 0: train encoder/decoder on first 80%; evaluate last 20%. Days 1..10: evaluate last 20% using their raw binned spike counts without per-day fitting of normalization statistics.
- Behavioral labels remain unchanged. CEBRA `time_delta`, model and decoder unchanged.
- Exactly 12 arms per seed: `clean`, `pgd_0p5`, 8 noise arms epsilon `[0.1,0.3,0.5,0.7,1,3,5,7]`, `auto_emp`, `auto_quantile`. Seeds 42, 43 = 24 runs.
- **Very important:** Removing neural-input Z-score does **NOT** remove whitening from the noise-aware metric. Its Ledoit-Wolf spatial covariance is recalculated using only unnormalized Day0 training spikes. AUTO budgets are also recalculated exclusively on Day0 Train. These values can change sharply because the units changed. Standard PGD epsilon 0.5 is now in raw-count input units, not z-score units: numerical cross-experiment epsilons are NOT physically equivalent.
- Same hyperparameters: `--batchSize 1024`, 30000 Encoder and Decoder requested steps, Adam LR 0.02→0.002, `--adv-style bin`, `--adv-dec --adv-dec-eps 0.1`. Decoder early stopping remains enabled.
- Four independent models simultaneously on four H200 GPUs. Each GPU executes one model at a time. Models are resume-safe via metrics.json + exp18_record.json validation; incomplete models restart from scratch.
- **Code** on HOME: `/home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source`
- **New outputs** on Scratch host: `/mnt/upmwmathis/scratch/hossein/mm_project/EXP18_MIHILI_CO/{runs,logs,cache,tmp}`; inside Pod: `/data/hossein/mm_project/EXP18_MIHILI_CO`.

## 1. Install on Headnode

Copy `EXP18_MIHILI_CO_RUNNER.zip` to `/home/mirzaei/sam/result/Aggregate/`, then:

```bash
cd /home/mirzaei/sam/result/Aggregate
unzip -oq EXP18_MIHILI_CO_RUNNER.zip -d EXP18_PKG
MON=/mnt/upmwmathis/scratch/hossein/aj_project/monkey_gru \
  bash EXP18_PKG/EXP18_MIHILI_CO_RUNNER/install_exp18.sh
cd EXP18_MIHILI_CO/source
python3 exp18_4gpu.py --plan
```

Expected plan: `STATUS: 0/24 COMPLETE, 24/24 PENDING` before training. Never copy Exp17 metrics into Exp18: preprocessing differs.

## 2. Preflight inside RunAI Pod (no training)

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source
/data/hossein/aj_project/.venv/bin/python -u exp18_run.py \
  --exp18-arm auto_quantile --exp18-preflight
```

This tests that Day0 train inputs match the original non-Z-scored binned spike data. Additional label-independent geometry/covariance evaluation uses only Day0 Train.

## 3. One-GPU smoke test (RECOMMENDED due to scale change)

Run once inside any GPU pod with the two PVCs mounted. No outputs are written to Exp18 main folder:

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source
mkdir -p /data/hossein/mm_project/EXP18_MIHILI_CO_SMOKE
/data/hossein/aj_project/.venv/bin/python -u exp18_cache_entry.py \
  --exp18-arm noise_0p1 --datasets mihili_co --seed 42 \
  --adv-style bin --adv_norm l2 --adv_eps 0.1 \
  --enc-optimizer adam --enc-lr 0.02 --linear-lr --lr-end 0.002 \
  --enc-weight-decay 1e-5 --adam-eps 0.1 --enc-grad-clip 5.0 \
  --batchSize 1024 --nBatch 100 --n-decoder-batches 100 \
  --adv-dec --adv-dec-eps 0.1 \
  --output-dir /data/hossein/mm_project/EXP18_MIHILI_CO_SMOKE/noise_0p1
```

## 4. Main 4-GPU RunAI job

```bash
runai submit --name sam-exp18 \
  --image registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.9 \
  --gpu 4 --cpu 32 --memory 256Gi --node-pools h200 --large-shm \
  --pvc home:/home/mirzaei --pvc upmwmathis-scratch:/data \
  -e HOME=/home/mirzaei -e USER=mirzaei -e LOGNAME=mirzaei \
  -e PYTHONUNBUFFERED=1 -e SKIP_PLOTS=1 \
  -p upmwmathis-mirzaei --run-as-user --command -- \
  bash /home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source/exp18_4gpu.sh
```

Follow overall job log:

```bash
runai logs sam-exp18 -p upmwmathis-mirzaei -f
```

Follow per-model log from headnode:

```bash
tail -f /mnt/upmwmathis/scratch/hossein/mm_project/EXP18_MIHILI_CO/logs/exp18-co-s42-noise-0p1.log
```

Once models finish:

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source
python3 exp18_4gpu.py --plan
```

**Constraints and interpretation:** Cross-day R² measures performance on clean held-out recordings, not attack robustness of the evaluation inputs. On raw neural counts, epsilon=0.5 does not carry the same physical perturbation as epsilon=0.5 on Z-scored data. Compare within Exp18 first; report normalized-vs-raw as a preprocessing ablation with this caveat. If raw input creates NaNs, optimizer saturation or poor results, that is an experimental finding, not permission to silently change learning rate or budgets.

## 5. Compare Exp17 / Exp18 after completion on Headnode

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP18_MIHILI_CO/source
python3 exp18_compare.py
```

This prints paired differences in mean cross-day R2 and per-day deltas for both seeds, using only the standard library (no numpy needed on Headnode).
