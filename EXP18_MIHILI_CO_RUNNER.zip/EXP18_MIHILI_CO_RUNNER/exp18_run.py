"""Single-run Exp18 adapter. Launch from an *isolated* archive of monkey_gru@a780890.

No professor files are edited: trainer functions are swapped in memory. For
standard PGD and clean training, the professor's original implementation is
used unchanged; for noise-aware arms only the encoder adversarial step changes.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ARMS = [
    "clean", "pgd_0p5",
    "noise_0p1", "noise_0p3", "noise_0p5", "noise_0p7",
    "noise_1", "noise_3", "noise_5", "noise_7",
    "auto_emp", "auto_quantile",
]


def intercept_args():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--exp18-arm", choices=ARMS, required=True)
    p.add_argument("--exp18-pairs", type=int, default=20_000)
    p.add_argument("--exp18-preflight", action="store_true")
    exp, rest = p.parse_known_args()
    sys.argv = [sys.argv[0], *rest]
    return exp


def main():
    args = intercept_args()

    # EXP18 is a single controlled intervention: disable neural Z-score.
    # Must be patched BEFORE multi_trainer/embedding_decoder import
    # `from data import load_day_split`, otherwise their references are stale.
    import data
    _original_split = data.load_day_split
    _original_trials = data.load_day_trials

    def _no_zscore_split(loader, dataset_name, day_idx, xds_smooth=True, zscore=True):
        return _original_split(loader, dataset_name, day_idx,
                               xds_smooth=xds_smooth, zscore=False)

    def _no_zscore_trials(loader, dataset_name, day_idx, xds_smooth=True, zscore=True):
        return _original_trials(loader, dataset_name, day_idx,
                                xds_smooth=xds_smooth, zscore=False)

    data.load_day_split = _no_zscore_split
    data.load_day_trials = _no_zscore_trials

    # Imports rely on professor's frozen checkout, CEBRA fork and XDS runtime.
    import multi_trainer
    import run_multi
    from data import DATASETS
    from exp17_noise import prepare_metric, noise_aware_l2_adv_cebra

    # Fail fast if imports bypassed the Exp18 preprocessing override.
    import embedding_decoder
    assert multi_trainer.load_day_split is data.load_day_split
    assert embedding_decoder.load_day_split is data.load_day_split

    context = {"arm": args.exp18_arm, "session_metrics": {}, "pairs": args.exp18_pairs}
    old_resolve = multi_trainer._resolve_session_adv_eps
    old_attack = multi_trainer._l2_adv_cebra
    old_train_model = run_multi.train_model

    def resolve_session_adv_eps(bundles, adv_eps, adv_eps_mode):
        if args.exp18_arm in ("clean", "pgd_0p5"):
            return old_resolve(bundles, adv_eps, adv_eps_mode)
        results = {}
        for key, bundle in bundles.items():
            arm = args.exp18_arm
            eps = float(arm.split("noise_", 1)[1].replace("p", ".")) if arm.startswith("noise_") else None
            obj = prepare_metric(
                bundle["train_x"].detach().cpu().numpy(),
                bundle["train_y"].detach().cpu().numpy(),
                arm=arm,
                eps_sweep=eps,
                pairs=args.exp18_pairs,
            )
            context["session_metrics"][key] = obj
            results[key] = float(obj.epsilon)
            print(f"[EXP18] {arm} / {key}: selected dprime per-bin eps={obj.epsilon:.6f}", flush=True)
            print("[EXP18] noise+calibration: " + json.dumps(obj.info, sort_keys=True), flush=True)
        return results

    def wrapped_attack(*a, **kw):
        if args.exp18_arm in ("clean", "pgd_0p5"):
            return old_attack(*a, **kw)
        # In professor's function session_name is positional argument 4.
        session_key = kw.get("session_name", a[3] if len(a) >= 4 else None)
        if session_key not in context["session_metrics"]:
            raise RuntimeError(f"No train-only covariance fitted for session {session_key}")
        return noise_aware_l2_adv_cebra(
            *a, **kw, metric=context["session_metrics"][session_key]
        )

    def wrapped_train_model(config):
        if config.get("dataset_keys") != ["mihili_co"]:
            raise ValueError("Exp18 must train only mihili_co, NOT multiple professor datasets")
        if config.get("adv_style") != "bin" or config.get("adv_norm") != "l2":
            raise ValueError("Exp18 requires --adv-style bin --adv_norm l2")
        if not config.get("adv_dec") or float(config.get("adv_dec_eps", 0)) != 0.1:
            raise ValueError("Keep professor decoder settings: --adv-dec --adv-dec-eps 0.1")
        if args.exp18_arm == "clean" and config.get("adv"):
            raise ValueError("clean arm must specify --no-adv")
        if args.exp18_arm != "clean" and not config.get("adv"):
            raise ValueError("Adversarial arms must enable adversarial encoder training")
        if args.exp18_arm == "pgd_0p5" and float(config["adv_eps"]) != 0.5:
            raise ValueError("Normal PGD control requires --adv_eps 0.5")
        if config.get("adv_eps_mode") != "fixed":
            raise ValueError("All arms require fixed eps mode; the Exp18 adapter calibrates AUTO")

        # Supervision: professor's CEBRA time_delta uses labels. Strict train-only calibration.
        print("[EXP18] arm:", args.exp18_arm, "seed:", config.get("seed"), flush=True)
        print("[EXP18] neuron Z-score: DISABLED on all 11 days", flush=True)
        print("[EXP18] train: first 80% of day 0 only", flush=True)
        print("[EXP18] evaluation: last 20% of day 0 and of days 1..10", flush=True)
        print("[EXP18] no decoder/heldout/other-day input to epsilon selection", flush=True)
        metrics = old_train_model(config)
        directory = Path(config["output_dir"])
        # The professor's parser only knows a fixed --adv_eps value. For
        # calibrated AUTO this is a placeholder; mark that field null in the
        # output instead of misleadingly reporting 0.5 as the used budget.
        if args.exp18_arm.startswith("auto_"):
            metrics["adv_eps"] = None
        metrics["exp18_arm"] = args.exp18_arm
        metrics["neural_zscore"] = False
        metrics["cross_day_zscore"] = False
        metrics["exp18_protocol"] = "day0_first80_train_day0_last20_and_days1to10_last20_no_zscore"
        metrics["exp18_budget_units"] = (
            "none_encoder_clean" if args.exp18_arm == "clean" else
            "euclidean_l2_per_bin" if args.exp18_arm == "pgd_0p5" else
            "whitened_noise_dprime_per_bin"
        )
        metrics["exp18_effective_budget"] = metrics.get("session_adv_eps", {}).get("mihili_co") if config.get("adv") else None
        (directory / "metrics.json").write_text(
            json.dumps(metrics, indent=2, allow_nan=False), encoding="utf-8"
        )
        record = {
            "arm": args.exp18_arm,
            "seed": int(config.get("seed", 42)),
            "method": "standard_euclidean_per_bin_L2" if args.exp18_arm == "pgd_0p5" else (
                "clean" if args.exp18_arm == "clean" else "spatial_noise_aware_per_bin_dprime_L2"
            ),
            "normal_pgd_epsilon_l2": 0.5 if args.exp18_arm == "pgd_0p5" else None,
            "session_noise_metric": {k: v.info for k, v in context["session_metrics"].items()},
            "metrics_file": "metrics.json",
            "holdout_r2": metrics["per_dataset"]["mihili_co"]["r2_holdout"],
            "other_day_r2": metrics["per_dataset"]["mihili_co"]["r2_other_days"],
            "mean_other_days_r2": metrics["per_dataset"]["mihili_co"]["r2_mean_other_days"],
            "protocol": "professor_day0_80_20_no_neural_zscore_all_days",
            "neural_zscore": False,
            "cross_day_zscore": False,
            "neural_input": "unsmoothed_50ms_binned_spike_counts_float32",
            "model_internal_smoothing": "unchanged_from_exp17",
            "commit": "a7808902cf721ea8b440684f48fea7514da8c881",
        }
        (directory / "exp18_record.json").write_text(
            json.dumps(record, indent=2, allow_nan=False), encoding="utf-8"
        )
        print("[EXP18] Wrote", directory / "exp18_record.json", flush=True)
        print("[EXP18] Cross-day mean R2 =", record["mean_other_days_r2"], flush=True)
        return metrics

    multi_trainer._resolve_session_adv_eps = resolve_session_adv_eps
    multi_trainer._l2_adv_cebra = wrapped_attack
    run_multi.train_model = wrapped_train_model

    if args.exp18_preflight:
        # CPU validation of data-loading and (for noise-aware arms) budget calibration.
        from utils.constants import DATA_DIR
        from utils.dataset_loader import DatasetLoader
        loader = DatasetLoader(data_root_dir=str(DATA_DIR))
        bundles = multi_trainer.build_session_bundles(loader, ["mihili_co"])
        raw_x, _ = loader.load_dataset_day(0, DATASETS["mihili_co"], xds_smooth=False)
        train_x = bundles["mihili_co"]["train_x"].detach().cpu().numpy()
        np.testing.assert_array_equal(train_x, np.asarray(raw_x[:len(train_x)], dtype=np.float32))
        print("[EXP18] PREFLIGHT: day0 train equals raw binned spikes (no Z-score)", flush=True)
        print("[EXP18] preflight bundle sizes:",
              {k: {name: tuple(b[name].shape) for name in
                   ("train_x", "train_y", "test_x", "test_y")}
               for k, b in bundles.items()}, flush=True)
        if args.exp18_arm.startswith("noise_") or args.exp18_arm.startswith("auto_"):
            resolve_session_adv_eps(bundles, 0.5, "fixed")
        print("[EXP18] PREFLIGHT PASSED (no GPU/model training)", flush=True)
        return

    run_multi.main()


if __name__ == "__main__":
    main()
