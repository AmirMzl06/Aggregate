"""Set ONLY dataset-cache location; execute the existing Exp18 training unchanged.

The professor loader's default './weights_cache' is in /home. Redirect its cache
for each GPU process to the scratch PVC via EXP18_CACHE_DIR. No preprocessing or
training/evaluation algorithm is changed.
"""
from __future__ import annotations

import os
import runpy

import utils.dataset_loader as dataset_loader

_orig_init = dataset_loader.DatasetLoader.__init__


def _init_with_scratch_cache(self, data_root_dir=dataset_loader.DATA_DIR,
                             cache_dir=dataset_loader.CACHE_DIR):
    return _orig_init(
        self,
        data_root_dir=data_root_dir,
        cache_dir=os.environ.get('EXP18_CACHE_DIR', cache_dir),
    )


dataset_loader.DatasetLoader.__init__ = _init_with_scratch_cache
runpy.run_module('exp18_run', run_name='__main__')
