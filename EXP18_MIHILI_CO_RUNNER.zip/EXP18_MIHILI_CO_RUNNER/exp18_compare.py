#!/usr/bin/env python3
"""Compare Exp17 (Z-score) and Exp18 (raw neural counts), using only stdlib."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from statistics import mean, stdev

ARMS = ('clean','pgd_0p5','noise_0p1','noise_0p3','noise_0p5','noise_0p7',
        'noise_1','noise_3','noise_5','noise_7','auto_emp','auto_quantile')


def read_metrics(root: Path, exp: int, seed: int, arm: str):
    name = f'exp{exp}-co-s{seed}-{arm.replace("_", "-")}'
    p = root / 'runs' / name / 'metrics.json'
    if not p.is_file():
        return None
    m = json.loads(p.read_text())
    if exp == 18 and m.get('neural_zscore') is not False:
        raise ValueError(f'Exp18 unexpectedly has normalization: {p}')
    d = m['per_dataset']['mihili_co']
    days = {int(k): float(v) for k, v in d['r2_other_days'].items()}
    if set(days) != set(range(1,11)):
        raise ValueError(f'Incomplete day scores: {p}')
    return {'holdout': float(d['r2_holdout']), 'cross': float(d['r2_mean_other_days']), 'days': days}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exp17', type=Path, default=Path('/mnt/upmwmathis/scratch/hossein/mm_project/EXP17_MIHILI_CO'))
    parser.add_argument('--exp18', type=Path, default=Path('/mnt/upmwmathis/scratch/hossein/mm_project/EXP18_MIHILI_CO'))
    args = parser.parse_args()
    print('EXP17 (Z-score) versus EXP18 (raw binned neural counts)')
    print('Matched seeds 42,43; cross-day metric is unperturbed R2 on days 1..10')
    print('epsilon physical units differ; comparison is an input-preprocessing ablation\n')
    print(f'{"METHOD":21} {"EXP17":>9} {"EXP18":>9} {"DELTA":>10} {"PAIRED Δ / SEED":>22}')
    print('-'*79)
    comparisons=[]
    missing=[]
    for arm in ARMS:
        old=[]; new=[]; diffs=[]
        for seed in (42,43):
            a = read_metrics(args.exp17,17,seed,arm)
            b = read_metrics(args.exp18,18,seed,arm)
            if a is None or b is None:
                missing.append((arm,seed))
                continue
            old.append(a);new.append(b);diffs.append(b['cross']-a['cross'])
        if diffs:
            comparisons.append((arm,mean(diffs),len(diffs)))
            print(f'{arm:21} {mean(x["cross"] for x in old):9.4f} {mean(x["cross"] for x in new):9.4f} '
                  f'{mean(diffs):+10.4f} {", ".join(f"{x:+.4f}" for x in diffs):>22}')
        else:
            print(f'{arm:21} {"-":>9} {"-":>9} {"-":>10} {"pending":>22}')
    if missing:
        print(f'\nPENDING/MISSING: {len(missing)} arm+seed pairs: {missing}')
    if comparisons:
        print('\nLARGEST R2 GAINS FROM REMOVING Z-SCORE:')
        for arm, delta, n in sorted(comparisons,key=lambda r:r[1],reverse=True)[:5]:
            print(f'  {arm}: {delta:+.4f} ({n}/2 matched seeds)')
    print('\nDaywise deltas (Exp18 minus Exp17) for clean, PGD and best Exp17 noise-aware:')
    for arm in ('clean','pgd_0p5','noise_0p1','auto_emp','auto_quantile'):
        pairs=[]
        for seed in (42,43):
            a=read_metrics(args.exp17,17,seed,arm)
            b=read_metrics(args.exp18,18,seed,arm)
            if a is not None and b is not None:
                pairs.append((a,b))
        if not pairs:
            continue
        print(f'  {arm} ({len(pairs)} matched seeds):')
        print('    D0: ' + f'{mean(b["holdout"]-a["holdout"] for a,b in pairs):+.4f}')
        print('    '+' '.join(f'D{d}={mean(b["days"][d]-a["days"][d] for a,b in pairs):+.4f}' for d in range(1,11)))

if __name__=='__main__':
    main()
