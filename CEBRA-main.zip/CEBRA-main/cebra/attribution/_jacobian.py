#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
#

from typing import Union, List

import numpy as np
import torch


def tensors_to_cpu_and_double(vars_: List[torch.Tensor]) -> List[torch.Tensor]:
    """Convert a list of tensors to CPU and double precision."""

    cpu_vars = []
    for v in vars_:
        if v.is_cuda:
            v = v.to("cpu")
        cpu_vars.append(v.double())
    return cpu_vars


def tensors_to_cuda(vars_: List[torch.Tensor],
                    cuda_device: str) -> List[torch.Tensor]:
    """Convert a list of tensors to CUDA device."""

    cpu_vars = []
    for v in vars_:
        if not v.is_cuda:
            v = v.to(cuda_device)
        cpu_vars.append(v)
    return cpu_vars


def compute_jacobian(
    model: torch.nn.Module,
    input_vars: List[torch.Tensor],
    mode: str = "autograd",
    cuda_device: str = "cuda",
    double_precision: bool = False,
    convert_to_numpy: bool = True,
    hybrid_solver: bool = False,
) -> Union[torch.Tensor, np.ndarray]:
    """Compute the Jacobian matrix for a given model and input."""

    if double_precision:
        model = model.to("cpu").double()
        input_vars = tensors_to_cpu_and_double(input_vars)

        if hybrid_solver:
            output = model(*input_vars)
            output_vars = torch.cat(output, dim=1).to("cpu").double()
        else:
            output_vars = model(*input_vars).to("cpu").double()

    else:
        model = model.to(cuda_device).float()
        input_vars = tensors_to_cuda(
            input_vars,
            cuda_device=cuda_device
        )

        if hybrid_solver:
            output = model(*input_vars)
            output_vars = torch.cat(output, dim=1)
        else:
            output_vars = model(*input_vars)


    if mode == "autograd":

        jacob = []

        for i in range(output_vars.shape[1]):

            grads = torch.autograd.grad(
                output_vars[:, i:i + 1],
                input_vars,
                retain_graph=True,
                create_graph=False,
                grad_outputs=torch.ones(
                    output_vars[:, i:i + 1].shape
                ).to(output_vars.device),
            )

            jacob.append(torch.cat(grads, dim=1))

        jacobian = torch.stack(jacob, dim=1)


    jacobian = jacobian.detach().cpu()

    if convert_to_numpy:
        jacobian = jacobian.numpy()

    return jacobian