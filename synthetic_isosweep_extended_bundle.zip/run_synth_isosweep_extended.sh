#!/usr/bin/env bash
set -euo pipefail

cd /home/mirzaei/sam/result/Aggregate
source /home/mirzaei/lm-cebra/.venv/bin/activate
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
OUT=/data/hossein/mm_project/SYNTH_BENCH_ALL

printf '\n=== PREFLIGHT ===\n'
test -f synthetic_benchmark.py
test -f dprime_exp9.py
test -f Acorn-dprime/cebra/dprime/noise.py
test -d "$OUT/records"
python - <<'PY'
from pathlib import Path
import ast, torch
s=Path('synthetic_benchmark.py').read_text()
m=ast.parse(s)
a=next(n for n in m.body if isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ISO_NEW' for t in n.targets))
arms=ast.literal_eval(a.value)
assert len(arms)==14, (len(arms), arms)
assert 'PGD_L2_EPS0.1' in arms and 'MADRY_ISO_D0.7' in arms
assert torch.cuda.is_available() and torch.cuda.device_count()==4
print('EXTENDED ISOSWEEP OK; new arms:',len(arms),'; GPUs:',torch.cuda.device_count())
PY

printf '\n=== BACK UP ORIGINAL SUMMARY FILES ===\n'
mkdir -p "$OUT/pre_extended_isosweep_archive"
for name in SYNTH_RUNS.csv PREDICTIONS.json synth_pilot_report.txt synth_main_report.txt synth_budget_report.txt synth_all_report.txt; do
  if [ -f "$OUT/$name" ]; then
    cp -n "$OUT/$name" "$OUT/pre_extended_isosweep_archive/$name"
  fi
done

printf '\n=== DRY RUN ===\n'
python -u synthetic_benchmark.py --suite isosweep --output-root "$OUT" --dry-run

printf '\n=== EXTENDED ISOSWEEP ===\n'
python -u synthetic_benchmark.py --suite isosweep --gpu-workers 4 --output-root "$OUT"

printf '\n=== FULL REPORT ===\n'
python -u synthetic_benchmark.py --suite main --summarize --output-root "$OUT" | tee "$OUT/synth_all_extended_report.txt"

printf '\n=== FINAL VERIFICATION ===\n'
python - "$OUT" <<'PY'
from pathlib import Path
import json, sys
root=Path(sys.argv[1]); r=[json.loads(p.read_text()) for p in (root/'records').glob('*.json')]
good=[x for x in r if x.get('status')=='success']
errors=[x for x in r if x.get('status')!='success']
extra=['PGD_L2_EPS0.1','PGD_L2_EPS0.3','PGD_L2_EPS0.5','PGD_L2_EPS0.7',
       'PGD_L2_EPS1','PGD_L2_EPS2','PGD_L2_EPS3',
       'MADRY_ISO_D0.1','MADRY_ISO_D0.3','MADRY_ISO_D0.5','MADRY_ISO_D0.7',
       'MADRY_ISO_D1','MADRY_ISO_D2','MADRY_ISO_D4']
sweep=[x for x in good if x.get('arm') in extra]
print('total successful:',len(good),'expected 580')
print('new isosweep arms:',len(sweep),'expected 336')
print('failed:',len(errors),'expected 0')
assert len(good)==580 and len(sweep)==336 and not errors
print('ALL EXPERIMENTS COMPLETED')
PY
