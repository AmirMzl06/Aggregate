#!/usr/bin/env python3
"""Independent 4-GPU, resumable fine-epsilon sweep of existing Exp17 noise-aware code.

Runs only six new budgets x two seeds; 0.1 is already in the completed Exp17.
All new artifacts and caches are on Scratch. Existing Exp17 data are untouched.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import math
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time

SOURCE = Path('/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source')
SCRATCH_HOST = Path('/mnt/upmwmathis/scratch/hossein/mm_project/EXP17_FINE_SWEEP')
SCRATCH_POD = Path('/data/hossein/mm_project/EXP17_FINE_SWEEP')
PYTHON = Path('/data/hossein/aj_project/.venv/bin/python')
ARMS = ('noise_0p01', 'noise_0p025', 'noise_0p05', 'noise_0p075', 'noise_0p15', 'noise_0p2')
SEEDS = (42, 43)
TASKS = tuple((seed, arm) for arm in ARMS for seed in SEEDS)


def task_name(seed, arm):
    return f'exp17-co-s{seed}-{arm.replace("_", "-")}'


def expected_eps(arm):
    return float(arm.removeprefix('noise_').replace('p', '.'))


def check_complete(root, seed, arm):
    out = root / 'runs' / task_name(seed, arm)
    metrics = out / 'metrics.json'
    record = out / 'exp17_record.json'
    if not metrics.is_file() or not record.is_file():
        return False, 'missing metrics.json or exp17_record.json'
    try:
        m = json.loads(metrics.read_text(encoding='utf-8'))
        r = json.loads(record.read_text(encoding='utf-8'))
        assert r['arm'] == arm and int(r['seed']) == seed, 'arm/seed mismatch'
        assert int(m['batchSize']) == 1024
        assert int(m['nBatch']) == 30000
        assert int(m['n_decoder_batches']) == 30000
        d = m['per_dataset']['mihili_co']
        assert set(map(int, d['r2_other_days'])) == set(range(1,11))
        assert math.isfinite(float(d['r2_holdout']))
        assert math.isfinite(float(d['r2_mean_other_days']))
        for value in d['r2_other_days'].values():
            assert math.isfinite(float(value))
        selected = r['session_noise_metric']['mihili_co']['selected_epsilon_dprime_per_bin']
        assert math.isclose(float(selected), expected_eps(arm), rel_tol=1e-9, abs_tol=1e-10)
        return True, 'verified'
    except (KeyError, ValueError, TypeError, AssertionError) as exc:
        return False, f'invalid outputs: {exc}'


def report(root):
    done = 0
    pending = []
    for seed, arm in TASKS:
        name = task_name(seed, arm)
        ok, _ = check_complete(root, seed, arm)
        if ok:
            metrics = json.loads((root/'runs'/name/'metrics.json').read_text())
            r2 = metrics['per_dataset']['mihili_co']['r2_mean_other_days']
            print(f'[DONE] {name:<33} cross-day R2={r2:.4f}', flush=True)
            done += 1
        else:
            print(f'[PENDING] {name}', flush=True)
            pending.append((seed, arm))
    print(f'FINE SWEEP: {done}/12 COMPLETE, {len(pending)}/12 PENDING', flush=True)
    print('Existing noise_0p1: ALREADY IN EXP17; NOT RE-TRAINED', flush=True)
    return pending


def prepare(root):
    for dirname in ('runs','logs','cache','tmp'):
        (root / dirname).mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=root/'tmp') as f:
        f.write(b'scratch-write-test\n')
        f.flush()
        os.fsync(f.fileno())


def command(seed, arm, output):
    return [
        str(PYTHON), '-u', str(SOURCE/'exp17_fine_entry.py'),
        '--exp17-arm', arm, '--exp17-pairs', '20000',
        '--datasets', 'mihili_co', '--seed', str(seed),
        '--adv-style', 'bin', '--adv_norm', 'l2', '--adv_eps', str(expected_eps(arm)),
        '--enc-optimizer', 'adam', '--enc-lr', '0.02', '--linear-lr',
        '--lr-end', '0.002', '--enc-weight-decay', '1e-5',
        '--adam-eps', '0.1', '--enc-grad-clip', '5.0',
        '--batchSize', '1024', '--nBatch', '30000',
        '--n-decoder-batches', '30000', '--adv-dec', '--adv-dec-eps', '0.1',
        '--output-dir', str(output)
    ]


def run(root):
    if not str(root).startswith('/data/'):
        raise RuntimeError('Run mode requires in-pod Scratch root (/data/...)')
    for file in (SOURCE/'exp17_run.py', SOURCE/'exp17_noise.py', SOURCE/'exp17_fine_entry.py', SOURCE/'run_multi.py'):
        if not file.is_file():
            raise RuntimeError(f'Missing required file: {file}')
    if not PYTHON.is_file():
        raise RuntimeError(f'Missing venv: {PYTHON}')
    prepare(root)
    pending = report(root)
    if not pending:
        print('ALL 12 FINE-SWEEP RUNS COMPLETE', flush=True)
        return 0
    found = subprocess.check_output([str(PYTHON),'-c','import torch; print(torch.cuda.device_count())'], text=True)
    gpu_count = int(found.strip().splitlines()[-1])
    if gpu_count < 4:
        raise RuntimeError(f'Need 4 GPUs, found {gpu_count}')
    print(f'[GPU] {gpu_count} devices detected; using four independent workers', flush=True)
    print(f'[SCRATCH] {root}', flush=True)
    print(f'[STORAGE] free {shutil.disk_usage(root).free / 1024**3:.1f} GiB (quota may differ)', flush=True)
    work = queue.Queue()
    for t in pending:
        work.put(t)
    errors = []
    lock = threading.Lock()

    def worker(gpu):
        while True:
            try:
                seed, arm = work.get_nowait()
            except queue.Empty:
                break
            name = task_name(seed, arm)
            output = root/'runs'/name
            log = root/'logs'/f'{name}.log'
            ok, _ = check_complete(root, seed, arm)
            if ok:
                print(f'[GPU {gpu}] SKIP {name}', flush=True)
                work.task_done()
                continue
            output.mkdir(parents=True, exist_ok=True)
            cache_root = root/'cache'/f'gpu{gpu}'
            tmp_root = root/'tmp'/f'gpu{gpu}'
            env = os.environ.copy()
            env.update({
                'CUDA_VISIBLE_DEVICES': str(gpu),
                'USER':'mirzaei','LOGNAME':'mirzaei','USERNAME':'mirzaei',
                'PYTHONUNBUFFERED':'1','SKIP_PLOTS':'1',
                'OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4',
                'EXP17_CACHE_DIR':str(cache_root/'weights_cache'),
                'TMPDIR':str(tmp_root),
                'TORCHINDUCTOR_CACHE_DIR':str(cache_root/'torchinductor'),
                'XDG_CACHE_HOME':str(cache_root/'xdg'),
                'PYTHONPYCACHEPREFIX':str(cache_root/'pycache'),
            })
            for key in ('EXP17_CACHE_DIR','TMPDIR','TORCHINDUCTOR_CACHE_DIR','XDG_CACHE_HOME','PYTHONPYCACHEPREFIX'):
                Path(env[key]).mkdir(parents=True,exist_ok=True)
            print(f'[GPU {gpu}] START {name} | eps={expected_eps(arm)}', flush=True)
            try:
                with log.open('a', encoding='utf-8') as f:
                    f.write(f'\n=== FINE EPS {name} GPU {gpu} {time.ctime()} ===\n')
                    f.flush()
                    status = subprocess.run(command(seed, arm, output), cwd=SOURCE, env=env,
                                            stdout=f, stderr=subprocess.STDOUT, check=False).returncode
                ok, msg = check_complete(root, seed, arm)
                if status == 0 and ok:
                    print(f'[GPU {gpu}] DONE {name}', flush=True)
                else:
                    print(f'[GPU {gpu}] FAIL {name}: exit={status}, {msg}; inspect {log}', flush=True)
                    with lock:
                        errors.append(name)
            except Exception as exc:
                print(f'[GPU {gpu}] ERROR {name}: {exc}', flush=True)
                with lock:
                    errors.append(name)
            finally:
                work.task_done()

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        futures = [ex.submit(worker, gpu) for gpu in range(4)]
        for f in futures:
            f.result()
    print('\n===== FINE SWEEP FINAL =====', flush=True)
    remaining = report(root)
    if remaining or errors:
        print(f'RUN INCOMPLETE: {len(remaining)} pending; re-submit the SAME runner with a new Job name for resume', flush=True)
        return 1
    print('ALL 12 FINE-SWEEP RUNS VERIFIED ON SCRATCH', flush=True)
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--run', action='store_true')
    parser.add_argument('--scratch', type=Path)
    args = parser.parse_args()
    root = args.scratch or (SCRATCH_POD if args.run else SCRATCH_HOST)
    if args.plan:
        report(root)
        return 0
    return run(root)


if __name__ == '__main__':
    sys.exit(main())
