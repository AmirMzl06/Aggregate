# Exp17 Fine Epsilon Sweep, 4 GPUs, Z-score ON

No existing Exp17 code, data, checkpoint or metrics is changed. A separate entrypoint extends the *in-memory* `exp17_run.ARMS` list to accept six new numerical epsilons; the training path `exp17_run.py`, `exp17_noise.py` and professor's code are reused unchanged.

New eps: 0.01, 0.025, 0.05, 0.075, 0.15, 0.2; 2 seeds (42,43) = 12 new training runs. eps=0.1 is already trained as part of Exp17 and is NOT re-trained.

Source (existing): `/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source`

New results in POD: `/data/hossein/mm_project/EXP17_FINE_SWEEP/runs`

New results on Headnode: `/mnt/upmwmathis/scratch/hossein/mm_project/EXP17_FINE_SWEEP/runs`

## Installation

Copy ZIP into `/home/mirzaei/sam/result/Aggregate`, then:

```bash
cd /home/mirzaei/sam/result/Aggregate
unzip -oq EXP17_FINE_SWEEP_4GPU.zip -d EXP17_FINE_PKG
cp EXP17_FINE_PKG/EXP17_FINE_SWEEP_4GPU/exp17_fine_entry.py \
   EXP17_FINE_PKG/EXP17_FINE_SWEEP_4GPU/exp17_fine4.py \
   EXP17_FINE_PKG/EXP17_FINE_SWEEP_4GPU/exp17_fine4.sh \
   EXP17_MIHILI_CO/source/
python3 EXP17_MIHILI_CO/source/exp17_fine4.py --plan
```

Expected `FINE SWEEP: 0/12 COMPLETE, 12/12 PENDING`.

## Submit

```bash
runai submit --name sam-exp17-fine \
  --image registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.9 \
  --gpu 4 --cpu 32 --memory 256Gi --node-pools h200 --large-shm \
  --pvc home:/home/mirzaei --pvc upmwmathis-scratch:/data \
  -e HOME=/home/mirzaei -e USER=mirzaei -e LOGNAME=mirzaei \
  -e PYTHONUNBUFFERED=1 -e SKIP_PLOTS=1 \
  -p upmwmathis-mirzaei --run-as-user --command -- \
  bash /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source/exp17_fine4.sh
```

Logs:

```bash
runai logs sam-exp17-fine -p upmwmathis-mirzaei -f
```

For resume after interruption, submit this same command with a new Job name. Complete results are skipped after verification. Incomplete models restart from the beginning rather than from a partial training step.
