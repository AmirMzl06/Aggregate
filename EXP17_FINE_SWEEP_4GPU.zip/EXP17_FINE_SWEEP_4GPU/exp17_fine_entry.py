"""No edits to Exp17 algorithm: accept additional fine-sweep noise arms at runtime."""
from __future__ import annotations

import os
import exp17_run
import utils.dataset_loader as dataset_loader

_FINE_ARMS = (
    'noise_0p01', 'noise_0p025', 'noise_0p05',
    'noise_0p075', 'noise_0p15', 'noise_0p2',
)

# Exp17's CLI enumerates arms, but the underlying noise-aware method already
# parses arbitrary noise_XpY budgets. Extend the choices in memory, only here.
for arm in _FINE_ARMS:
    if arm not in exp17_run.ARMS:
        exp17_run.ARMS.append(arm)

_original_init = dataset_loader.DatasetLoader.__init__

def _init_with_scratch_cache(self, data_root_dir=dataset_loader.DATA_DIR,
                             cache_dir=dataset_loader.CACHE_DIR):
    return _original_init(
        self,
        data_root_dir=data_root_dir,
        cache_dir=os.environ.get('EXP17_CACHE_DIR', cache_dir),
    )

dataset_loader.DatasetLoader.__init__ = _init_with_scratch_cache

if __name__ == '__main__':
    exp17_run.main()
