#!/usr/bin/env bash
set -euo pipefail
SOURCE=/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
export USER=mirzaei LOGNAME=mirzaei USERNAME=mirzaei
export PYTHONUNBUFFERED=1 SKIP_PLOTS=1
cd "$SOURCE"
exec /data/hossein/aj_project/.venv/bin/python -u "$SOURCE/exp17_fine4.py" --run \
  --scratch /data/hossein/mm_project/EXP17_FINE_SWEEP
