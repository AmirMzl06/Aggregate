"""Tests of cebra.dprime.calibration (ε_JND, ε_NN, ε_det, robustness margin)."""

import math

import numpy as np
import pytest
import torch
from sklearn.metrics import roc_auc_score

from cebra.dprime import calibration as cal


class IdentityNoise:
    device = None

    def whiten(self, delta):
        return delta


def test_make_classes():
    assert cal.make_classes(None) is None
    discrete = np.array([3, 1, 3, 2])
    assert np.array_equal(cal.make_classes(discrete), discrete)
    rng = np.random.default_rng(0)
    continuous = rng.normal(size=(500, 2))
    classes = cal.make_classes(continuous, n_classes=5)
    assert classes.shape == (500,) and len(np.unique(classes)) == 5


def test_valid_indices():
    idx = cal.valid_indices(100, 18, 18)
    assert idx[0] == 18 and idx[-1] == 82


def test_nearest_neighbour_matches_brute_force():
    rng = np.random.default_rng(0)
    neural = rng.normal(size=(300, 3)).astype(np.float32)
    classes = rng.integers(0, 2, size=300)
    left, right, exclusion = 2, 3, 5
    query, dist = cal.nearest_neighbour_dprime(neural, IdentityNoise(), left, right, classes,
                                              bank_size=None, exclusion=exclusion,
                                              batch_size=37)
    windows = np.stack([neural[t - left:t + right].T.reshape(-1) for t in query])
    for i in range(0, len(query), 17):
        candidates = [j for j in range(len(query))
                      if abs(query[i] - query[j]) >= exclusion and classes[query[j]] == classes[query[i]]]
        expected = min(np.linalg.norm(windows[i] - windows[j]) for j in candidates)
        assert dist[i] == pytest.approx(expected, rel=1e-5)


def test_eps_nn_and_per_index():
    distances = np.array([1.0, 2.0, 3.0, 4.0, np.inf])
    assert cal.eps_nn(distances, 0.5) == pytest.approx(2.5)
    table = cal.per_index_eps_nn(10, np.array([2, 5, 5]), np.array([1.0, 3.0, 2.0]))
    assert table[2] == 1.0 and table[5] == 2.0 and np.isinf(table[0])


def test_auc_matches_sklearn_with_ties():
    rng = np.random.default_rng(0)
    neg = rng.integers(0, 5, size=200).astype(float)
    pos = rng.integers(1, 6, size=150).astype(float)
    expected = roc_auc_score(np.r_[np.zeros(200), np.ones(150)], np.r_[neg, pos])
    assert cal.auc(neg, pos) == pytest.approx(expected)


def test_detection_curve_and_eps_det():
    torch.manual_seed(0)
    x_train, x_test = torch.randn(300, 4, 36), torch.randn(300, 4, 36)
    pattern = torch.sin(torch.linspace(0, 6, 36)).expand(4, 36)

    def attack_fn(x, eps, kind):
        return x + eps * pattern

    curve = cal.detection_curve(x_train, x_test, attack_fn, [0.0, 0.05, 3.0], detector_steps=150)
    assert curve[0.0]["auc"] == pytest.approx(0.5, abs=0.1)
    assert curve[3.0]["auc"] > 0.9
    eps_det, status = cal.eps_det_from_curve({0.1: 0.5, 0.2: 0.54, 0.4: 0.7})
    assert (eps_det, status) == (0.2, "ok")
    assert cal.eps_det_from_curve({0.1: 0.9})[1] == "below_grid"
    assert cal.eps_det_from_curve({0.1: 0.5, 1.0: 0.5}) == (1.0, "censored_above")


def test_epsilon_star_and_margin():
    assert cal.epsilon_star(eps_nn=3.0, eps_det=0.4) == (0.4, "det")
    assert cal.epsilon_star(eps_nn=math.inf, eps_det=None) == (1.0, "jnd")
    report = cal.robustness_margin(np.array([0.0, 1.0, 2.0, 3.0, np.inf]), eps_star=1.0)
    assert report["median"] == 2.0 and report["ratio"] == 2.0
    assert report["frac_already_adversarial"] == pytest.approx(0.2)
    assert report["frac_never_broken"] == pytest.approx(0.2)
    assert cal.ideal_observer_accuracy(1.0) == pytest.approx(0.6915, abs=1e-3)


def test_eps_det_crossing_interpolates_in_log_eps():
    curve = {1.0: {"auc": 0.50, "ae_auc": 0.50}, 2.0: {"auc": 0.60, "ae_auc": 0.52},
             4.0: {"auc": 0.70, "ae_auc": 0.60}}
    eps, status = cal.eps_det_crossing(curve, 0.55, key="ae_auc")
    assert status == "ok" and eps == pytest.approx(2.0 * 2.0**0.375)
    assert cal.eps_det_crossing(curve, 0.55)[0] == pytest.approx(2.0**0.5)
    assert cal.eps_det_crossing(curve, 0.45) == (0.5, "below_grid")
    assert cal.eps_det_crossing(curve, 0.9) == (4.0, "censored_above")


def test_eps_energy_detector():
    assert cal.eps_energy_detector(86, 36) == pytest.approx((2 * 86 * 36)**0.25)


def _slow_signal_plus_noise(n=40000, channels=6, rho=0.98, seed=0):
    """x = L z + n: slow AR(1) latents z (unit variance) and white noise of known covariance."""
    rng = np.random.default_rng(seed)
    loading = rng.normal(size=(channels, 2)) * 0.6
    z = np.zeros((n, 2))
    shocks = rng.normal(size=(n, 2)) * math.sqrt(1 - rho**2)
    for t in range(1, n):
        z[t] = rho * z[t - 1] + shocks[t]
    noise_sd = rng.uniform(0.7, 1.4, channels)
    x = z @ loading.T + rng.normal(size=(n, channels)) * noise_sd + 3.0
    return x, loading @ loading.T, np.diag(noise_sd**2)


@pytest.mark.parametrize("temporal_rho", [0.0, 0.4])
def test_eps_signal_recovers_the_signal_separation(temporal_rho):
    # Truth: ε_sig² = 2 Σ_ij (Σ_t⁻¹)_ij ρ^|i−j| tr(Σ_s⁻¹ Σ_signal); the lag-1 proxy underestimates the
    # zero-lag signal by the factor ρ = 0.98.
    rho, window_len = 0.98, 8
    x, signal_cov, noise_cov = _slow_signal_plus_noise(rho=rho)
    lags = np.abs(np.subtract.outer(np.arange(window_len), np.arange(window_len)))
    temporal = temporal_rho**lags
    truth = math.sqrt(2 * np.trace(np.linalg.solve(noise_cov, signal_cov))
                      * np.sum(np.linalg.inv(temporal) * rho**lags))
    assert cal.eps_signal(x, noise_cov, temporal, lag=1) == pytest.approx(truth, rel=0.05)
    assert cal.eps_signal(x, noise_cov, temporal, lag=2) == pytest.approx(truth, rel=0.05)


def test_eps_signal_white_closed_form_and_noise_only():
    x, _, noise_cov = _slow_signal_plus_noise(n=5000)
    traces = cal.signal_lag_traces(x, noise_cov, 3)
    assert cal.eps_signal(x, noise_cov, np.eye(36)) == pytest.approx(math.sqrt(2 * 36 * traces[1]))
    # Temporally white noise alone: the signal estimate is ≈ 0, far below the noise floor √(2D).
    noise_only = np.random.default_rng(1).normal(size=(20000, 6))
    value = cal.eps_signal(noise_only, np.eye(6), np.eye(36))
    assert math.isnan(value) or value < 0.2 * math.sqrt(2 * 6 * 36)
