#!/usr/bin/env python3
"""Exp12 summary: refined eps1/2 and kappa of the Exp11 models, and the random-direction control.

Keep next to dprime_exp9.py. Reads <root>/summary_<tag>.csv (eval-only re-evaluation of the Exp11
models with --eval-refine / --eval-kappa) and the control suites, and prints:
  1  per arm: runs, refined eps1/2 (reference metric; runs still halved at the floor of the
     search are counted, their value is the bound), the paired ratio with PGD6 before (grid
     interpolation, v1 eps1/2 of the same records) and after refinement, wins, isotropic ratio,
     clean R2 difference, and kappa = eps1/2 / eps_beh(reference) with its CV over sessions;
  2  the control MADRY_SPDIFF_D8_RAND (random direction, same metric and budget) against DIFF8
     and PGD6, paired by (session, seed);
  3  kappa per session and arm (and eps_beh of the session);
  4  the pre-registered failure prediction re-scored with the refined values (failure: refined
     eps1/2 below 0.5, the old floor) and the AUCs of x_beh, x_sig and the nominal budget.
The merged table is written to <sup root>/EXP12_RUNS.csv.

    python exp12_summary.py > exp12_report.txt
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
BASELINE = "PGD_L2_EPS6"
CONTROL = "MADRY_SPDIFF_D8_RAND"
FLOOR = 0.5  # the smallest budget of the Exp11 grid
SHORT = {"PGD_L2_EPS6": "PGD6", "MADRY_SPDIFF_D8": "DIFF8", "MADRY_SP_D8": "SP8",
         "MADRY_SP_AUTOSIG": "SP/SIG", "MADRY_SPDIFF_AUTOSIG": "DIFF/SIG",
         "MADRY_SP_AUTOSIG_POOL": "POOL/SIG", "MADRY_SPDIFF_AUTOBEH": "DIFF/BEH",
         "MADRY_SP_AUTOBEH": "SP/BEH", "MADRY_SP_AUTOBEH_POOL": "POOL/BEH",
         CONTROL: "DIFF8_RAND"}


def auc(negative, positive) -> float:
    """P(positive > negative) + 0.5 P(tie) (Mann-Whitney)."""
    negative, positive = np.asarray(negative, float), np.asarray(positive, float)
    if len(negative) == 0 or len(positive) == 0:
        return float("nan")
    ranks = pd.Series(np.concatenate([negative, positive])).rank().to_numpy()
    return float((ranks[len(negative):].sum() - len(positive) * (len(positive) + 1) / 2)
                 / (len(negative) * len(positive)))


def refined(runs: pd.DataFrame, key: str, floor: float, top: float) -> pd.Series:
    """Refined eps1/2; censored runs at their bound (below the floor: floor; above: top)."""
    value = runs[f"{key}_half_refined"].astype(float)
    status = runs[f"{key}_status"].fillna("")
    value = value.where(status != "below_floor", floor)
    return value.where(status != "above_grid", top)


def load(root: Path, tag: str, mode: str, floor: float, top: float) -> pd.DataFrame:
    name = "summary.csv" if tag == "v1" else f"summary_{tag}.csv"
    runs = pd.read_csv(root / name)
    runs = runs[runs.status == "success"].copy()
    runs["mode"] = mode
    runs["ref"] = refined(runs, "ref", floor, top)
    runs["iso"] = refined(runs, "iso", floor, top)
    predictions = root / "PREDICTIONS.csv"
    if predictions.is_file():
        p = pd.read_csv(predictions).rename(columns={"arm": "experiment"})
        keep = ["session", "experiment", "x_sig", "x_beh", "budget", "predicted_broken"]
        runs = runs.merge(p[keep], on=["session", "experiment"], how="left")
    runs["short"] = runs.experiment.map(SHORT).fillna(runs.experiment)
    return runs


def paired(runs: pd.DataFrame, arm: str, base: str, column: str) -> pd.Series:
    """Log ratios arm / base for the same (session, seed)."""
    a = runs[runs.experiment == arm].set_index(["session", "seed"])[column].astype(float)
    b = runs[runs.experiment == base].set_index(["session", "seed"])[column].astype(float)
    joined = pd.concat([a.rename("a"), b.rename("b")], axis=1, join="inner").dropna()
    return np.log(joined.a / joined.b)


def arm_table(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for arm, d in runs.groupby("experiment", sort=False):
        kappa = d.groupby("session").ref_kappa.median().astype(float)
        row = {"arm": SHORT.get(arm, arm), "runs": len(d),
               "below_floor": int((d.ref_status == "below_floor").sum()),
               "under_0.5": int((d.ref < FLOOR).sum()),
               "ref_med": d.ref.median(), "iso_med": d.iso.median(), "r2_mean": d.r2.mean(),
               "kappa_mean": kappa.mean(), "kappa_cv": kappa.std() / kappa.mean()}
        if arm != BASELINE:
            lin = paired(runs, arm, BASELINE, "ref_half")
            ref = paired(runs, arm, BASELINE, "ref")
            iso = paired(runs, arm, BASELINE, "iso")
            r2 = runs[runs.experiment.isin([arm, BASELINE])].pivot_table(
                index=["session", "seed"], columns="experiment", values="r2")
            row.update(pairs=len(ref), ratio_grid=np.exp(lin.mean()), ratio_refined=np.exp(ref.mean()),
                       wins=int((ref > 0).sum()), iso_ratio=np.exp(iso.mean()),
                       r2_minus_pgd=(r2[arm] - r2[BASELINE]).mean() if arm in r2 else np.nan)
        rows.append(row)
    return pd.DataFrame(rows)


def control_table(runs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for base in ("MADRY_SPDIFF_D8", BASELINE):
        if not ((runs.experiment == CONTROL).any() and (runs.experiment == base).any()):
            continue
        ref, iso = paired(runs, CONTROL, base, "ref"), paired(runs, CONTROL, base, "iso")
        r2 = runs[runs.experiment.isin([CONTROL, base])].pivot_table(
            index=["session", "seed"], columns="experiment", values="r2").dropna()
        per_session = np.exp(ref.groupby(level=0).mean())
        rows.append({"comparison": f"DIFF8_RAND / {SHORT[base]}", "pairs": len(ref),
                     "ref_ratio": np.exp(ref.mean()), "ref_wins": int((ref > 0).sum()),
                     "sessions_above_1": f"{int((per_session > 1).sum())}/{len(per_session)}",
                     "iso_ratio": np.exp(iso.mean()),
                     "r2_diff": (r2[CONTROL] - r2[base]).mean()})
    gains = runs[runs.experiment.isin([CONTROL, "MADRY_SPDIFF_D8"])].groupby(
        "experiment").loss_gain_median.median()
    for arm, value in gains.items():
        rows.append({"comparison": f"training loss gain median {SHORT.get(arm, arm)}",
                     "ref_ratio": value})
    return pd.DataFrame(rows)


def prediction_test(runs: pd.DataFrame) -> str:
    d = runs[runs.x_beh.notna() & (runs.experiment != CONTROL)].copy()
    if d.empty:
        return "  (no pre-registered x_beh)"
    failed = (d.ref < FLOOR).to_numpy()
    predicted = (d.predicted_broken.astype(str).str.lower() == "true").to_numpy()
    lines = [f"  runs {len(d)}; refined eps1/2 < {FLOOR}: {int(failed.sum())} "
             f"(v1 floor failures: {int((d.ref_half.astype(float) <= FLOOR + 1e-6).sum())})",
             f"  pre-registered rule: TP {int((predicted & failed).sum())}  FP "
             f"{int((predicted & ~failed).sum())}  FN {int((~predicted & failed).sum())}  TN "
             f"{int((~predicted & ~failed).sum())}"]
    for name in ("x_beh", "x_sig", "budget"):
        v = d[name].astype(float).to_numpy()
        lines.append(f"  AUC {name:7s} {auc(v[~failed], v[failed]):.3f}")
    rho = d.groupby("session").apply(
        lambda g: g[["x_beh", "ref_kappa"]].astype(float).corr(method="spearman").iloc[0, 1])
    lines.append(f"  within-session Spearman(x_beh, kappa), median over sessions: {rho.median():.2f}")
    return "\n".join(lines)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--sup", type=Path, default=ROOT / "DPRIME_EXP11_NEWSESS_SUPERVISED")
    p.add_argument("--time", type=Path, default=ROOT / "DPRIME_EXP11_NEWSESS_TIMEONLY")
    p.add_argument("--control-sup", type=Path, default=ROOT / "DPRIME_EXP12_CONTROL_SUPERVISED")
    p.add_argument("--control-time", type=Path, default=ROOT / "DPRIME_EXP12_CONTROL_TIMEONLY")
    p.add_argument("--tag", default="v2")
    p.add_argument("--floor", type=float, default=FLOOR / 16,
                   help="Value of runs still halved at the floor of the search")
    p.add_argument("--top", type=float, default=16.0,
                   help="Value of runs never halved on the grid")
    args = p.parse_args()
    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", 30)
    merged = []
    for mode, root, control in (("supervised", args.sup, args.control_sup),
                                ("time_only", args.time, args.control_time)):
        print(f"\n===== {mode}: {root} (+ {control})")
        parts = [load(r, args.tag, mode, args.floor, args.top) for r in (root, control)
                 if (r / f"summary_{args.tag}.csv").is_file()]
        if not parts:
            print("  missing")
            continue
        runs = pd.concat(parts, ignore_index=True)
        merged.append(runs)
        print(f"sessions {runs.session.nunique()}, runs {len(runs)}")
        print("\n1  arms (ref = refined eps1/2, reference metric; ratios paired with PGD6)")
        print(arm_table(runs).round(3).to_string(index=False))
        print("\n2  control: random direction on the d' sphere vs the attack")
        print(control_table(runs).round(3).to_string(index=False))
        print("\n3  kappa (reference) per session: median over seeds; eps_beh of the session")
        table = runs.pivot_table(index="session", columns="short", values="ref_kappa")
        table.insert(0, "eps_beh_ref", runs.groupby("session").ref_eps_beh.median())
        print(table.round(3).to_string())
        print("\n4  failure prediction with the refined eps1/2")
        print(prediction_test(runs))
    if merged:
        pd.concat(merged).to_csv(args.sup / "EXP12_RUNS.csv", index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
