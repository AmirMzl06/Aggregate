#!/usr/bin/env bash
# Immutable-copy installation: never checkout/change the professor's shared repo.
set -euo pipefail

MON="${MON:-/data/hossein/aj_project/monkey_gru}"
DST="${DST:-/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source}"
PAYLOAD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$MON/.git" ]]; then
  echo "Missing source Git repository: $MON" >&2
  exit 1
fi
if [[ -e "$DST/run_multi.py" ]]; then
  echo "Destination contains project files; refusing overwrite: $DST" >&2
  exit 1
fi
mkdir -p "$DST"
git -C "$MON" archive a780890 | tar -x -C "$DST"
# XDS may be untracked; link it using the path visible INSIDE RunAI pods.
# Headnode scratch is /mnt/upmwmathis/scratch, but pod mounts it as /data.
if [[ ! -e "$DST/xds" && -d "$MON/xds" ]]; then
  case "$MON" in
    /mnt/upmwmathis/scratch/*)
      ln -s "/data/${MON#/mnt/upmwmathis/scratch/}/xds" "$DST/xds" ;;
    *) ln -s "$MON/xds" "$DST/xds" ;;
  esac
fi
cp "$PAYLOAD/exp17_noise.py" "$PAYLOAD/exp17_run.py" "$PAYLOAD/exp17_plan.py" "$DST/"
cp -r "$PAYLOAD/exp17_dprime" "$DST/"
mkdir -p "$DST/runs" "$DST/logs"
echo "SOURCE CHECKOUT: $(git -C "$MON" rev-parse a780890)"
echo "INSTALLED TO: $DST"
echo "PROFESSOR'S REPOSITORY WAS NOT MODIFIED"
echo "Verify dependency Python in /data/hossein/aj_project/.venv/bin/python"
