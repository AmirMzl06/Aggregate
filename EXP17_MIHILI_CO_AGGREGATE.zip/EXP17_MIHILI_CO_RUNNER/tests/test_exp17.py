import math

import numpy as np
import torch

from exp17_noise import (
    behaviour_pair_quantile, color_per_bin, prepare_metric, project_per_bin,
)


def test_per_bin_projection_and_spatial_whitening():
    torch.manual_seed(2)
    cov = torch.tensor([[2.0, 0.4], [0.4, 1.0]], dtype=torch.float64)
    eig, u = torch.linalg.eigh(cov)
    root = (u * eig.sqrt()) @ u.T
    invroot = (u * eig.rsqrt()) @ u.T
    z = torch.randn(3, 2, 36, dtype=torch.float64)
    z = project_per_bin(z, 0.3)
    delta = color_per_bin(z, root)
    z_back = color_per_bin(delta, invroot)
    assert torch.allclose(z, z_back, atol=1e-10)
    assert torch.all(z_back.norm(dim=1) <= 0.30000001)


def test_quantile_responds_to_scale_without_decoder():
    rng = np.random.default_rng(4)
    prediction = rng.normal(size=(300, 4))
    budget, x05, samples = behaviour_pair_quantile(
        prediction, alpha=0.05, pairs=300, seed=1,
    )
    budget2, x052, _ = behaviour_pair_quantile(
        prediction * 3.0, alpha=0.05, pairs=300, seed=1,
    )
    assert math.isclose(budget2, 3 * budget, rel_tol=1e-10)
    assert math.isclose(x05, x052, rel_tol=1e-10)
    assert samples == 300 and budget > 0


def test_manual_noise_metric_is_positive():
    rng = np.random.default_rng(9)
    x = rng.normal(size=(220, 7))
    y = rng.normal(size=(220, 2))
    metric = prepare_metric(x, y, arm="noise_0p3", eps_sweep=0.3)
    assert math.isclose(metric.epsilon, 0.3)
    assert metric.sqrt_spatial.shape == (7, 7)
    assert metric.info["source"] == "first_80pct_day0_only"


def test_noise_aware_step_runs_and_updates_weights(monkeypatch):
    import contextlib
    import sys
    import types
    from exp17_noise import SessionMetric, noise_aware_l2_adv_cebra

    # CPU stand-in for the professor's BF16 CUDA autocast module.
    utils = types.ModuleType("utils")
    ev = types.ModuleType("utils.eval_stream")
    ev.amp_ctx = lambda device: contextlib.nullcontext()
    monkeypatch.setitem(sys.modules, "utils", utils)
    monkeypatch.setitem(sys.modules, "utils.eval_stream", ev)

    torch.manual_seed(10)

    class ToyModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.proj = torch.nn.Linear(4, 3)

        def encode_cebra_windows(self, inp, key):
            return self.proj(inp.mean(dim=2))

        def encoder_parameters(self):
            return self.parameters()

    class Batch:
        reference = torch.randn(3, 4, 5)
        positive = torch.randn(3, 4, 5)
        negative = torch.randn(3, 4, 5)

    class Objective:
        def __call__(self, a, p, n):
            loss = (a - p).square().mean() - (a - n).square().mean()
            return loss, None, None

    model = ToyModel()
    before = [p.detach().clone() for p in model.parameters()]
    opt = torch.optim.SGD(model.parameters(), lr=0.01)
    metric = SessionMetric(torch.eye(4), 0.3, {})
    out = noise_aware_l2_adv_cebra(
        model, opt, Batch, "mihili_co", Objective(), 0.3, 3,
        adv_style="bin", metric=metric,
    )
    assert torch.isfinite(out)
    assert any(not torch.equal(p, old) for p, old in zip(model.parameters(), before))
