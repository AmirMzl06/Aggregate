"""Exp17 L2-per-bin noise-aware PGD and two train-data-only budget selectors.

This is an explicit per-bin adaptation of the supplied Acorn-dprime spatial
DIFF metric and calibration logic, not a claim of identical whole-window PGD.
The professor's model/decoder/evaluation are not modified.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch

from exp17_dprime import calibration, noise

BEHAVIOUR_FRACTION = 0.363
GEOMETRY_ALPHA = 0.05
RECEPTIVE_WINDOW = 36  # Original model Offset36_multi
BEHAVIOUR_LAGS = (-8, -4, 0, 4, 8)
BEHAVIOUR_FEATURES = 400


@dataclass
class SessionMetric:
    sqrt_spatial: torch.Tensor  # CPU (C,C); migrated to batch.device on first use
    epsilon: float              # per-time-bin d-prime radius
    info: dict[str, Any]


def positive_finite(value: float, name: str) -> float:
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive; got {value!r}")
    return value


def behaviour_pair_quantile(
    whitened_prediction: np.ndarray,
    *,
    alpha: float = GEOMETRY_ALPHA,
    pairs: int = 20_000,
    window: int = RECEPTIVE_WINDOW,
    seed: int = 0,
) -> tuple[float, float, int]:
    """Half the alpha-quantile of nonoverlapping window distances, divided by sqrt(T).

    Distances are estimated on cross-fitted behaviour predictions of *train*
    only, in the whitened noise metric. A fixed alpha is preregistered; no
    validation labels, decoder, or cross-day data are used. Window distances
    are converted to per-bin L2 budgets using sqrt(T) for the professor's
    `adv-style bin` setting.
    """
    z = np.asarray(whitened_prediction, dtype=np.float64)
    if z.ndim != 2 or len(z) < 2 * window + 2:
        raise ValueError(f"Need >= {2 * window + 2} bins, got {z.shape}")
    if not 0 < alpha < 0.5 or pairs < 200:
        raise ValueError("alpha must be in (0,.5) and pairs >= 200")
    n_starts = len(z) - window + 1
    rng = np.random.default_rng(seed)
    distances2 = np.empty(pairs, dtype=np.float64)
    complete = 0
    trials = 0
    # Exactly the Exp16 36-bin negative-pair construction, with no overlapping windows.
    while complete < pairs and trials < 100:
        m = max(1024, 2 * (pairs - complete))
        a = rng.integers(0, n_starts, size=m)
        b = rng.integers(0, n_starts, size=m)
        keep = np.flatnonzero(np.abs(a - b) >= window)
        a, b = a[keep], b[keep]
        count = min(pairs - complete, len(a))
        if count:
            a, b = a[:count], b[:count]
            idx = np.arange(window)
            for start in range(0, count, 256):
                stop = min(start + 256, count)
                delta = z[a[start:stop, None] + idx] - z[b[start:stop, None] + idx]
                distances2[complete + start:complete + stop] = np.einsum(
                    "ntc,ntc->n", delta, delta)
            complete += count
        trials += 1
    if complete != pairs:
        raise RuntimeError(f"Sampled only {complete}/{pairs} nonoverlapping negative pairs")
    quantile2 = float(np.quantile(distances2, alpha))
    typical2 = float(np.mean(distances2))
    if quantile2 <= 0 or typical2 <= 0:
        raise ValueError("Degenerate behaviour geometry; cannot calibrate quantile budget")
    eps_per_bin = 0.5 * math.sqrt(quantile2 / window)
    dimensionless_x = 0.5 * math.sqrt(quantile2 / typical2)
    return eps_per_bin, dimensionless_x, pairs


def prepare_metric(
    train_x: np.ndarray,
    train_y: np.ndarray,
    *,
    arm: str,
    eps_sweep: float | None = None,
    pairs: int = 20_000,
) -> SessionMetric:
    """Fit spatial covariance on day0/train using fork's DIFF + Ledoit-Wolf.

    `train_x` MUST be the professor's already z-scored day0 80% split.
    No refit or prediction on any day beyond day0/train is allowed.
    """
    x = np.asarray(train_x, dtype=np.float64)
    y = np.asarray(train_y, dtype=np.float64)
    if x.ndim != 2 or y.ndim != 2 or len(x) != len(y):
        raise ValueError(f"Bad day0 train shapes: x={x.shape}, y={y.shape}")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Nonfinite train-only data")
    channels = x.shape[1]
    residual = noise.compute_residuals(x, None, mode="difference")
    spatial = noise.spatial_covariance(residual, estimator="ledoit_wolf")
    nm = noise.NoiseModel(spatial, np.eye(1))
    spatial_sqrt = nm.spatial_sqrt.detach().clone()
    info: dict[str, Any] = {
        "source": "first_80pct_day0_only",
        "metric": "per_bin_whitened_L2",
        "covariance": "difference_residuals_LedoitWolf_spatial_white_temporal",
        "n_train": int(len(x)),
        "channels": int(channels),
        "attack_style": "bin",
        "attack_semantics": "per-bin ||Sigma_spatial^-1/2 delta_t||_2 <= eps",
        "window_for_geometry": RECEPTIVE_WINDOW,
        "window_to_bin_rule": "divide_window_L2_radius_by_sqrt(36)",
        "cov_eig_min": float(np.linalg.eigvalsh(spatial).min()),
        "cov_eig_max": float(np.linalg.eigvalsh(spatial).max()),
    }
    cap = (2.0 * channels) ** 0.25  # per-bin D=C version of the fork's blind detector cap
    info["per_bin_cap"] = float(cap)

    if arm.startswith("noise_"):
        eps = positive_finite(eps_sweep, "manual noise-aware epsilon")
        info["rule"] = "manual_dprime_per_bin"
    elif arm in ("auto_emp", "auto_quantile"):
        pred, pred_info = calibration.behaviour_prediction(
            x, y,
            lags=BEHAVIOUR_LAGS,
            features=BEHAVIOUR_FEATURES,
            folds=5,
            seed=0,
        )
        info["behaviour_model"] = {
            "cross_fitted_r2": float(pred_info["r2"]),
            "lags": list(BEHAVIOUR_LAGS),
            "random_fourier_features": BEHAVIOUR_FEATURES,
            "folds": 5,
            "seed": 0,
        }
        eps_beh_window = positive_finite(
            calibration.eps_behaviour(x, pred, spatial, np.eye(RECEPTIVE_WINDOW)),
            "eps_beh_36bin",
        )
        eps_beh_perbin = eps_beh_window / math.sqrt(RECEPTIVE_WINDOW)
        info["eps_beh_36bin"] = eps_beh_window
        info["eps_beh_perbin"] = eps_beh_perbin
        if arm == "auto_emp":
            # Original *supervised* AUTO coefficient (0.363) and floor (1).
            # The attack threat model is per-bin here, so cap uses C not C*T.
            eps = max(1.0, min(cap, BEHAVIOUR_FRACTION * eps_beh_perbin))
            info["rule"] = "max(1,min((2*C)^.25,0.363*eps_beh_36bin/sqrt(36)))"
            info["historical_fraction"] = BEHAVIOUR_FRACTION
        else:
            spatial_inv_sqrt = calibration._symmetric_power(spatial, -0.5)
            pred_whitened = (pred - pred.mean(axis=0)) @ spatial_inv_sqrt
            quantile_eps, x05, n_pairs = behaviour_pair_quantile(
                pred_whitened, alpha=GEOMETRY_ALPHA,
                pairs=pairs,
                window=RECEPTIVE_WINDOW,
                seed=0,
            )
            eps = min(cap, quantile_eps)
            info["rule"] = "min((2*C)^.25, Q_0.05(dprime_pair_36bin)/(2*sqrt(36)))"
            info["quantile_alpha"] = GEOMETRY_ALPHA
            info["quantile_pairs"] = n_pairs
            info["empirical_x05_window"] = x05
            info["quantile_eps_before_cap"] = quantile_eps
    else:
        raise ValueError(f"Unknown noise-aware arm: {arm}")

    info["selected_epsilon_dprime_per_bin"] = positive_finite(eps, "selected epsilon")
    info["approx_raw_l2_per_bin_for_random_whitened_direction"] = float(
        eps * math.sqrt(float(np.trace(spatial)) / channels)
    )
    return SessionMetric(spatial_sqrt, float(eps), info)


def project_per_bin(z: torch.Tensor, eps: float) -> torch.Tensor:
    """Projection onto independent L2 balls for each bin along neural channels."""
    norms = z.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12)
    return z * (eps / norms).clamp(max=1.0)


def color_per_bin(z: torch.Tensor, sqrt_spatial: torch.Tensor) -> torch.Tensor:
    """Spatial coloring, with Σ_t = I. Input shapes (B,C,T), (C,C)."""
    return torch.einsum("ij,bjt->bit", sqrt_spatial.to(device=z.device, dtype=z.dtype), z)


def _default_alpha(eps: float, steps: int) -> float:
    return 2.0 * eps / steps


def noise_aware_l2_adv_cebra(
    model,
    optimizer,
    batch,
    session_name,
    criterion,
    adv_eps,
    adv_steps,
    adv_style="bin",
    adv_alpha=None,
    enc_grad_clip=0.0,
    enc_params=None,
    *,
    metric: SessionMetric,
):
    """Mirror monkey_gru._l2_adv_cebra, but optimize whitened per-bin z.

    References/positives/negatives, 10 steps, second optimizer update, BF16
    autocast and gradient clipping are copied from the professor's method.
    """
    from utils.eval_stream import amp_ctx
    import torch.nn.utils as nn_utils

    if adv_style != "bin":
        raise ValueError("Exp17 only supports --adv-style bin")
    eps = positive_finite(adv_eps, "PGD budget")
    if abs(eps - metric.epsilon) > 1e-6:
        raise ValueError(f"Metric budget mismatch: {eps} vs {metric.epsilon}")
    alpha = adv_alpha if adv_alpha is not None else _default_alpha(eps, adv_steps)
    reference = batch.reference.detach()
    sqrt_spatial = metric.sqrt_spatial.to(reference.device, dtype=reference.dtype)
    z = torch.randn_like(reference)
    z = z / z.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12)
    z = z * (torch.rand((z.shape[0], 1, z.shape[2]), device=z.device, dtype=z.dtype) * eps)

    for _ in range(adv_steps):
        z = z.detach().requires_grad_(True)
        x_adv = reference + color_per_bin(z, sqrt_spatial)
        with amp_ctx(reference.device):
            r_adv = model.encode_cebra_windows(x_adv, session_name)
            p = model.encode_cebra_windows(batch.positive, session_name)
            n = model.encode_cebra_windows(batch.negative, session_name)
            adv_loss, _, _ = criterion(r_adv, p, n)
        grad_z, = torch.autograd.grad(adv_loss, z, retain_graph=False, create_graph=False)
        with torch.no_grad():
            norms = grad_z.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12)
            z = project_per_bin(z + alpha * (grad_z / norms), eps).detach()

    x_adv = reference + color_per_bin(z, sqrt_spatial)
    optimizer.zero_grad(set_to_none=True)
    with amp_ctx(reference.device):
        r_adv = model.encode_cebra_windows(x_adv, session_name)
        p = model.encode_cebra_windows(batch.positive, session_name)
        n = model.encode_cebra_windows(batch.negative, session_name)
        adv_loss, _, _ = criterion(r_adv, p, n)
    if torch.isfinite(adv_loss):
        adv_loss.backward()
        if enc_grad_clip is not None and enc_grad_clip > 0:
            nn_utils.clip_grad_norm_(enc_params if enc_params is not None else model.encoder_parameters(), enc_grad_clip)
        optimizer.step()
    return adv_loss
