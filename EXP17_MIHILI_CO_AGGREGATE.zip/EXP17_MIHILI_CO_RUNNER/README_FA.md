# Exp17 — Mihili CO / 11-day generalization

این بسته یک لایهٔ مستقل روی نسخهٔ **a780890** پروژهٔ `monkey_gru` استاد اضافه می‌کند و **Repository مشترک استاد یا فورک Acorn-dprime را تغییر نمی‌دهد**. نصب با `git archive` از Commit مشخص‌شده یک کپی جداگانه می‌سازد و فایل‌های Exp17 را فقط به همان کپی اضافه می‌کند.

## مسیر نصب و نرمال‌سازی

- محل کد نصب‌شده: `/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source`؛ فورک `Acorn-dprime` و Repository استاد تغییر نمی‌کنند.
- `batchSize=1024` در `exp17_plan.py` پیش‌فرض است و به همان صورت به `run_multi.py` پاس داده می‌شود.
- بر اساس تابع اصلی استاد `load_day_split`، **فقط Neural Activity (X)** با آمار ۸۰٪ اول همان روز Z-score می‌شود؛ کانال با `std<1e-3` صفر می‌شود. Behavioral Labels (Y) Z-score نمی‌شود.
- Training و برآورد کوواریانس/ε فقط از ۸۰٪ اول Day 0 هستند. هنگام Cross-Day، برای هر روز از ۸۰٪ ابتدایی همان روز برای آمار Z-score و ۲۰٪ انتهایی برای R² استفاده می‌شود؛ بنابراین ارزیابی کاملاً بدون سازگارسازی پیش‌پردازش نیست.

## تعریف آزمایش

- فقط دیتاست `mihili_co`، معادل `Mihili_CO_2014_raw`، ۱۱ روز.
- Encoder و Decoder هر دو فقط بر اساس **۸۰٪ اول روز صفر** آموزش می‌بینند.
- R² روی **۲۰٪ انتهایی روز صفر** و **۲۰٪ انتهایی روزهای ۱ تا ۱۰** محاسبه می‌شود.
- طبق کد استاد، برای هر روز دیگر Z-score با ۸۰٪ همان روز محاسبه می‌شود؛ یعنی ارزیابی Cross-Day با *day-specific normalization* است، نه کاملاً zero-shot در مرحلهٔ پیش‌پردازش.
- معماری اصلی استاد و روش آموزش Decoder، محاسبهٔ R²، CEBRA `time_delta` با Continuous Labels، `xds_smooth=False` و `use_smooth=True` حفظ شده‌اند.
- `--adv-dec --adv-dec-eps 0.1` برای **تمام بازوها، حتی Clean Encoder** روشن است؛ بنابراین `clean` یعنی **Encoder بدون PGD**، نه Decoder بدون Adversarial Training.
- `--adv-style bin`, L2, 10 PGD steps، Adam، LR خطی 0.02→0.002، weight decay 1e-5، Adam eps 0.1، clip 5.0، Batch Size 1024، encoder 30000 steps، decoder 30000 steps. دستور استاد `runai_ctl_merged.py` شامل Batch=1024 و `adv_eps=0.8` است. **به درخواست شما Baseline PGD را عمداً با ε=0.5 اجرا می‌کنیم.** اگر واقعاً Batch=102 (نه 1024) می‌خواهید در `exp17_plan.py --batchSize 102` تعیین کنید؛ ولی آن دیگر برابر تنظیم واقعی استاد نخواهد بود.

## بازوها (۱۲ مدل برای هر Seed)

| Arm | تعریف |
|---|---|
| `clean` | Encoder بدون حمله؛ Decoder همچنان PGD=0.1 |
| `pgd_0p5` | PGD اصلی استاد، ε=0.5 **L2 اقلیدسی در هر Bin** |
| `noise_0p1` | Noise-Aware per-bin d′ ε=0.1 |
| `noise_0p3` | ε=0.3 |
| `noise_0p5` | ε=0.5 |
| `noise_0p7` | ε=0.7 |
| `noise_1` | ε=1 |
| `noise_3` | ε=3 |
| `noise_5` | ε=5 |
| `noise_7` | ε=7 |
| `auto_emp` | ضریب تجربی 0.363 از Perich، اعمال‌شده روی مقیاس سیگنال رفتاری Day0 Train |
| `auto_quantile` | ضریب تطبیقی از Quantile 5% توزیع فاصلهٔ پیش‌بینی رفتار Day0 Train |

با Seedهای پیش‌فرض `[42, 43]` مجموعاً **۲۴ Run** برنامه‌ریزی می‌شود؛ قابل تغییر با `--seeds`.

## یک تفاوت علمی که باید در مقاله شفاف گزارش شود

کد اصلی DPrime ما PGD برحسب `d′` روی **کل پنجره** انجام می‌داد؛ اما استاد `--adv-style bin` دارد، یعنی برای هر Bin جداگانه L2 پروجکت می‌کند. برای یکسان‌ماندن معماری/پروتکل استاد، این بسته **Spatial DIFF + Ledoit–Wolf + temporal white** از کد خودمان را به **حملهٔ per-bin** منتقل می‌کند. در نتیجه این یک **انتقال صریح الگوریتم به Threat Model استاد** است، نه اجرای بیت‌به‌بیت همان حملهٔ پنجره‌ای Exp14/15.

برای Noise-Aware روی ورودی Z-score شدهٔ ۸۰٪ Train روز صفر، اختلاف‌های زمانی بر √۲ تقسیم و Covariance اسپیشال با Ledoit–Wolf تخمین زده می‌شود. سپس برای هر Bin، در فضای `z` با `||z_t||₂ ≤ ε` حمله می‌کنیم و اختلاف ورودی `δ_t = Σ_spatial^{1/2} z_t` می‌شود. این تعریف با Normal PGD که در فضای خام *پس از Z-score* پروجکت می‌کند، یکی نیست. بنابراین εهای برابر **الزاماً قدرت فیزیکی برابر ندارند**. علاوه بر ε، فایل `exp17_record.json` و `metrics.json` واحد بودجه و تخمین تقریبی Raw-L2 را ثبت می‌کنند.

**AUTO تجربی (برای supervised):**

`eps_auto_emp = max(1, min((2*C)^0.25, 0.363 * eps_beh_36 / sqrt(36)))`

**AUTO هندسی:**

`eps_auto_quantile = min((2*C)^0.25, Q_0.05(D_36) / (2*sqrt(36)))`

در هر دو فرمول C=96 (کانال‌ها؛ هندسهٔ per-bin)، `eps_beh_36` از `calibration.eps_behaviour` اصلی Acorn-dprime، و `D_36` فاصلهٔ whiten‌شدهٔ دو پنجرهٔ ۳۶بینی از **پیش‌بینی Cross-Fitted رفتار در Train** است. زوج‌های منفی دارای فاصلهٔ شروع حداقل ۳۶ Bin هستند. این تعریف Quantile برای انتقال به سبک per-bin از √۳۶ تقسیم شده؛ مقدار 0.355 عمومی Perich مستقیماً به این دیتاست تحمیل نمی‌شود. هیچ Decoder یا برچسب روزهای آزمون در انتخاب بودجه دخالت ندارد. این روش **supervised** است، زیرا از برچسب‌های رفتاری Train استفاده می‌کند. نسخهٔ Time-only با ضریب 0.24 در این بسته نیست.

محدودیت: پیش‌بینی رفتار و زوج‌های پنجره‌ای بر جریان Concatenated اجرا می‌شوند، چون کد استاد CEBRA را روی جریان بدون Trial-ID آموزش می‌دهد؛ بنابراین پنجره‌های نزدیک مرز Trial نیازمند تحلیل حساسیت جداگانه‌اند. برای Quantile ادعای بهینه‌بودن ریاضی وجود ندارد.

## نصب روی Headnode

پس از انتقال فایل `EXP17_MIHILI_CO_AGGREGATE.zip` به `/home/mirzaei/sam/result/Aggregate/`:

```bash
cd /home/mirzaei/sam/result/Aggregate
unzip -q EXP17_MIHILI_CO_AGGREGATE.zip -d /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO_PACKAGE

MON=/mnt/upmwmathis/scratch/hossein/aj_project/monkey_gru \
DST=/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source \
bash /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO_PACKAGE/EXP17_MIHILI_CO_RUNNER/install_exp17.sh
```

در نصب، **هیچ `git checkout` انجام نمی‌شود**. اگر مسیر مقصد از قبل کد داشته باشد، نصب از Overwrite خودداری می‌کند. در صورت نیاز، بر اساس Git `a780890` کل Source به مقصد کپی می‌شود. اگر پوشهٔ XDS در آرشیو Git نباشد و در Repository اصلی موجود باشد، لینک آن با مسیر قابل‌دسترسی داخل Pod (`/data/.../xds`) ساخته می‌شود؛ روی Headnode ممکن است این لینک باز نشود، اما داخل Pod قابل‌استفاده است.

## Preflight بدون Training (داخل GPU/CPU Pod که Scratch را روی `/data` مونت کرده)

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
/data/hossein/aj_project/.venv/bin/python -u exp17_run.py \
  --exp17-arm auto_quantile --exp17-preflight
```

این مرحله باید Shapeها و بودجهٔ محاسبه‌شدهٔ Train را نشان دهد. اگر Python یا `xds` در محیط در دسترس نبود، ابتدا همان وابستگی‌های پروژهٔ استاد را در Pod بررسی کنید. هرگز روی Headnode GPU Training اجرا نکنید.

## برنامه‌ریزی و Smoke Test در Headnode

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
python exp17_plan.py --seeds 42 --arms pgd_0p5 noise_0p3 auto_emp auto_quantile --tag smoke --nBatch 100 --nDecoderBatches 100
```

خط بالا فقط Commandها را **نمایش** می‌دهد و Job نمی‌سازد. بعد از بررسی دستورها، در صورت تمایل برای اجرای واقعی Smoke Test همان را با `--submit` بزنید:

```bash
python exp17_plan.py --seeds 42 --arms pgd_0p5 noise_0p3 auto_emp auto_quantile --tag smoke \
  --nBatch 100 --nDecoderBatches 100 --submit
```

Smoke Test با پسوند `-smoke` در نام Job و خروجی مستقل ذخیره می‌شود؛ هیچ‌گاه با نتیجهٔ ۳۰هزار Step مقایسه نشود.

## اجرای اصلی

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source

# ابتدا Plan کامل 24 مدل را ببین:
python exp17_plan.py --seeds 42 43

# در صورت تأیید و ظرفیت کلاستر، فقط گروه اول را Submit کن:
python exp17_plan.py --seeds 42 --arms clean pgd_0p5 noise_0p1 noise_0p3 --submit

# برای تمام مدل‌های باقی‌ماندهٔ هر دو Seed (دوباره‌ارسال موارد تکمیل‌شده نمی‌شود):
python exp17_plan.py --seeds 42 43 --resume --submit
```

**توجه:** گزینهٔ `--resume` فقط `exp17_record.json` تکمیل‌شده را بررسی می‌کند، نه وضعیت Jobهای هنوز در حال اجرا را. برای جلوگیری از ارسال تکراری Jobهای Running، قبل از آخرین Command وضعیت RunAI را بررسی کنید. اگر محدودیت صف دارید، از `--seeds`, `--arms`, یا `--limit` برای اجرای تدریجی استفاده کنید. Image پیش‌فرض RunAI نسخهٔ `robust-cebra:v0.9` است که در کنترلر همین Commit ثبت شده؛ Pool پیش‌فرض `h200`، GPU=1، CPU=8، Memory=64Gi. این مقادیر از CLI قابل تغییرند (`--image`, `--pool`, `--cpu`, `--memory`, `--python`).

## نتایج و خلاصه

```bash
cd /home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source
python exp17_plan.py --summary --seeds 42 43
cat exp17_summary.csv
```

برای هر اجرا:

- `runs/exp17-co-s42-.../metrics.json`: فایل استاد با مقادیر R² Train/Holdout و ۱۰ روز دیگر، و فیلدهای جدید `exp17_arm` و `exp17_budget_units` و `exp17_effective_budget`.
- `runs/exp17-co-s42-.../exp17_record.json`: اطلاعات بودجهٔ منتخب و منبع آن؛ R² هر روز و میانگین بین روزها.
- `logs/exp17-co-s42-....log`: Log کامل آموزش و R².
- `exp17_summary.csv`: سطر جدا برای هر Seed/Arm و ستون‌های R² روز ۰ تا ۱۰.

## وضعیت اعتبارسنجی بسته

کدهای Python از نظر Syntax بررسی شده‌اند. تست‌های CPU برای Projection، سازگاری فضای whiten‌شده، تغییر مقیاس Quantile، محاسبهٔ Covariance و یک Step آموزش Noise-Aware اجرا شده و پاس شده‌اند. **Training واقعی روی GPU، دسترسی XDS و بارگذاری MAT اصلی روی کلاستر در این محیط انجام نشده است**؛ به همین دلیل Preflight و Smoke Test اجباری‌اند و نباید پیش از آن ادعای اجرای End-to-End داشت.
