"""List, submit, or summarize Exp17 jobs. Never submits without --submit."""
from __future__ import annotations

import argparse
import json
import shlex
import subprocess
from pathlib import Path

ARMS = [
    "clean", "pgd_0p5",
    "noise_0p1", "noise_0p3", "noise_0p5", "noise_0p7",
    "noise_1", "noise_3", "noise_5", "noise_7", "auto_emp", "auto_quantile",
]

PROJECT = "upmwmathis-mirzaei"
IMAGE = "registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.9"
WORKDIR = "/home/mirzaei/sam/result/Aggregate/EXP17_MIHILI_CO/source"
PYTHON = "/data/hossein/aj_project/.venv/bin/python"


def configs(seeds, tag=""):
    suffix = f"-{tag}" if tag else ""
    return [(seed, arm, f"exp17-co-s{seed}-{arm.replace('_', '-')}{suffix}")
            for seed in seeds for arm in ARMS]


def train_command(seed, arm, job, *, n_batch, n_dec_batch, batch_size, pairs, workdir, python):
    true_eps = (arm.split("noise_", 1)[1].replace("p", ".")
                if arm.startswith("noise_") else "0.5")
    params = [
        python, "-u", "exp17_run.py",
        "--exp17-arm", arm,
        "--exp17-pairs", str(pairs),
        "--datasets", "mihili_co",
        "--seed", str(seed),
        "--adv-style", "bin",
        "--adv_norm", "l2",
        "--adv_eps", true_eps,  # Actual manual eps; AUTO overrides from train data.
        "--enc-optimizer", "adam",
        "--enc-lr", "0.02",
        "--linear-lr",
        "--lr-end", "0.002",
        "--enc-weight-decay", "1e-5",
        "--adam-eps", "0.1",
        "--enc-grad-clip", "5.0",
        "--batchSize", str(batch_size),
        "--nBatch", str(n_batch),
        "--n-decoder-batches", str(n_dec_batch),
        "--adv-dec",
        "--adv-dec-eps", "0.1",
        "--output-dir", job,
    ]
    if arm == "clean":
        params.append("--no-adv")
    command = " ".join(shlex.quote(x) for x in params)
    # tee with pipefail to avoid false success on Python errors.
    return f"set -o pipefail; cd {shlex.quote(workdir)} && mkdir -p logs && {command} 2>&1 | tee logs/{job}.log"


def runai_command(job, inner, *, image, gpu_pool, cpu, memory):
    return [
        "runai", "submit", "--name", job,
        "--image", image,
        "--gpu", "1", "--cpu", str(cpu), "--memory", memory,
        "--node-pools", gpu_pool, "--large-shm",
        "--pvc", "home:/home/mirzaei",
        "--pvc", "upmwmathis-scratch:/data",
        "-e", "HOME=/home/mirzaei",
        "-e", "PYTHONUNBUFFERED=1",
        "-e", "SKIP_PLOTS=1",
        "-p", PROJECT, "--run-as-user",
        "--command", "--", "bash", "-lc", inner,
    ]


def summarize(workdir, seeds, tag=""):
    entries = []
    for seed, arm, job in configs(seeds, tag=tag):
        metrics = Path(workdir) / "runs" / job / "metrics.json"
        record = Path(workdir) / "runs" / job / "exp17_record.json"
        if not (metrics.exists() and record.exists()):
            print(f"PENDING {job}")
            continue
        try:
            m = json.loads(metrics.read_text())["per_dataset"]["mihili_co"]
            r = json.loads(record.read_text())
            days = m["r2_other_days"]
            assert len(days) == 10, f"Expected 10 other days, got {len(days)}"
            values = [f"day0={m['r2_holdout']:.5f}"] + [
                f"day{d}={float(days[str(d)]):.5f}" for d in range(1, 11)
            ]
            print(f"DONE {job}  mean_other={m['r2_mean_other_days']:.5f}  "
                  + " ".join(values))
            entries.append((seed, arm, float(m["r2_holdout"]),
                            float(m["r2_mean_other_days"]), *(float(days[str(d)]) for d in range(1, 11))))
        except Exception as exc:
            print(f"INVALID {job}: {exc}")
    import csv
    outfile = Path(workdir) / "exp17_summary.csv"
    if entries:
        with outfile.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["seed", "arm", "r2_day0_holdout", "r2_mean_day1to10", *[f"r2_day{i}" for i in range(1, 11)]])
            writer.writerows(entries)
        print(f"Summary CSV: {outfile} | successful: {len(entries)}")
    else:
        print("No complete runs found yet")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 43])
    parser.add_argument("--tag", default="", choices=("", "smoke"), help="Separate smoke-test runs from real experiments")
    parser.add_argument("--limit", type=int, default=0, help="Max jobs to list/submit (0 = all chosen)")
    parser.add_argument("--arms", nargs="+", choices=ARMS, default=ARMS)
    parser.add_argument("--submit", action="store_true", help="Actually submit selected jobs")
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--resume", action="store_true", help="Skip completed records before submission")
    parser.add_argument("--workdir", default=WORKDIR)
    parser.add_argument("--python", default=PYTHON)
    parser.add_argument("--image", default=IMAGE)
    parser.add_argument("--pool", default="h200")
    parser.add_argument("--cpu", type=int, default=8)
    parser.add_argument("--memory", default="64Gi")
    parser.add_argument("--nBatch", type=int, default=30_000)
    parser.add_argument("--nDecoderBatches", type=int, default=30_000)
    parser.add_argument("--batchSize", type=int, default=1024)
    parser.add_argument("--pairs", type=int, default=20_000)
    args = parser.parse_args()
    if args.summary:
        summarize(args.workdir, args.seeds, tag=args.tag)
        return
    selections = [(seed, arm, name) for seed, arm, name in configs(args.seeds, tag=args.tag) if arm in args.arms]
    if args.limit > 0:
        selections = selections[:args.limit]
    print(f"Experiment plans: {len(selections)} (seeds={args.seeds}, arms={args.arms})")
    print("NOTE: --submit is required to create RunAI jobs; otherwise commands only printed")
    for seed, arm, name in selections:
        finished = Path(args.workdir) / "runs" / name / "exp17_record.json"
        if args.resume and finished.is_file():
            print("SKIP completed:", name)
            continue
        cmd = runai_command(
            name,
            train_command(seed, arm, name, n_batch=args.nBatch,
                          n_dec_batch=args.nDecoderBatches, batch_size=args.batchSize,
                          pairs=args.pairs, workdir=args.workdir, python=args.python),
            image=args.image, gpu_pool=args.pool, cpu=args.cpu, memory=args.memory,
        )
        print("\n" + " ".join(shlex.quote(part) for part in cmd))
        if args.submit:
            proc = subprocess.run(cmd, check=False)
            if proc.returncode != 0:
                print("ERROR submitting", name, "exit", proc.returncode)
                break


if __name__ == "__main__":
    main()
