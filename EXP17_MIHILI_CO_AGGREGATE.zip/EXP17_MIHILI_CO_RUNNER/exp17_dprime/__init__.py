"""Unmodified DPrime noise and calibration modules from the supplied Acorn-dprime fork."""
