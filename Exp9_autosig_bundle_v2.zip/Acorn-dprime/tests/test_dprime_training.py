"""End-to-end tests of the d′ training through ``cebra.CEBRA`` (tiny, CPU)."""

import json

import numpy as np
import pytest
import torch

import cebra
import cebra.distributions
from cebra.dprime import calibration
from cebra.dprime import noise

_RECORDING = np.random.default_rng(0).poisson(2.0, size=(400, 6)).astype("float32")
# Spike counts whose rates follow a slow shared signal (the auto_sig budget needs a signal).
_SLOW_RATES = 2.0 * np.exp(0.6 * np.sin(2 * np.pi * np.arange(400) / 80.0)[:, None]
                           * np.linspace(-1.0, 1.0, 6)[None, :])
_SLOW = np.random.default_rng(2).poisson(_SLOW_RATES).astype("float32")


def _fit(seed=0, recording=None, **kwargs):
    torch.manual_seed(seed)
    np.random.seed(seed)
    config = dict(model_architecture="offset10-model", batch_size=32, max_iterations=6,
                  output_dimension=3, num_hidden_units=8, device="cpu", verbose=False,
                  training_mode="adversarial", adv_steps=2, adv_epsilon_mode="dprime",
                  adv_dprime_epsilon=1.0, adv_dprime_guard_mode="off",
                  adv_dprime_instance_adaptive=False, adv_dprime_nn_bank=50,
                  adv_dprime_margin_steps=3, adv_dprime_det_steps=5,
                  adv_dprime_det_grid=(1.0,), adv_dprime_warmup=0.0,
                  adv_dprime_curriculum=0.0)
    config.update(kwargs)
    model = cebra.CEBRA(**config)
    model.fit(_RECORDING if recording is None else recording)
    return model


def test_sampler_follows_torch_seed():
    torch.manual_seed(3)
    first = cebra.distributions.TimeContrastive(num_samples=1000).sample_prior(50)
    torch.manual_seed(3)
    second = cebra.distributions.TimeContrastive(num_samples=1000).sample_prior(50)
    torch.manual_seed(4)
    third = cebra.distributions.TimeContrastive(num_samples=1000).sample_prior(50)
    assert torch.equal(first, second)
    assert not torch.equal(first, third)


def test_fit_is_reproducible_and_seed_dependent():
    a, b, c = _fit(0), _fit(0), _fit(1)
    assert np.array_equal(a.transform(_RECORDING), b.transform(_RECORDING))
    assert not np.array_equal(a.transform(_RECORDING), c.transform(_RECORDING))


def test_auto_calibration_does_not_change_training_stream():
    # With ε* = 1 (the AUC threshold 1 passes every grid point, so ε_det = 1 = ε_JND), "auto"
    # must train exactly like the fixed ε = 1 run: the calibration has its own generator and
    # leaves the global RNG alone.
    fixed = _fit(0)
    auto = _fit(0, adv_dprime_epsilon="auto", adv_dprime_det_auc=1.0)
    assert auto.dprime_report_["epsilon"]["eps_star"] == pytest.approx(1.0)
    assert np.array_equal(fixed.transform(_RECORDING), auto.transform(_RECORDING))


def test_report_without_curriculum_and_budget_quantiles():
    model = _fit(0)
    report = model.dprime_report_
    json.dumps(report)
    training = report["training"]
    assert training["curriculum_steps"] == 0
    budgets = training["epsilon_per_reference"]
    assert budgets["min"] == pytest.approx(1.0) and budgets["max"] == pytest.approx(1.0)
    assert report["eps_nn"]["noise_floor_sqrt_2D"] == pytest.approx(np.sqrt(2 * 6 * 10))
    assert report["robustness_margin"]["decision"] == "chance"


def test_trades_with_vanishing_budget_runs():
    model = _fit(0, adv_dprime_objective="trades", adv_dprime_epsilon=1e-6)
    assert model.dprime_report_["training"]["mean_dprime"] <= 1e-6 + 1e-9


def test_isotropic_geometry_is_scaled_l2():
    rng = np.random.default_rng(1)
    recording = rng.normal(size=(3000, 4)) * np.array([1.0, 2.0, 0.5, 1.5])
    model, info = noise.fit_noise_model(recording, window_len=8, spatial_estimator="isotropic",
                                        temporal_method="white")
    sigma2 = recording.var(axis=0).mean()
    delta = torch.randn(5, 4, 8, dtype=torch.float64)
    expected = delta.flatten(1).norm(dim=1) / np.sqrt(sigma2)
    assert torch.allclose(model.dprime(delta).double(), expected, rtol=1e-4)


def test_auto_blind_uses_the_anomaly_detector():
    model = _fit(0, adv_dprime_epsilon="auto_blind", adv_dprime_det_auc=1.0,
                 adv_dprime_det_grid=(0.5, 2.0))
    epsilon = model.dprime_report_["epsilon"]
    assert epsilon["source"] == "auto_blind"
    # Every grid point passes AUC <= 1: the blind ε_det is censored at the largest grid value,
    # above the note's ε* = min(ε_JND = 1, ...).
    assert epsilon["eps_det_blind"] == pytest.approx(2.0)
    assert epsilon["eps_det_blind_status"] == "censored_above"
    assert epsilon["eps_star_note"] == pytest.approx(1.0)
    assert epsilon["eps_star"] == pytest.approx(min(2.0, epsilon["eps_nn"]))
    assert model.dprime_report_["training"]["epsilon_per_reference"]["max"] == pytest.approx(
        epsilon["eps_star"])


def _signal_budget(recording, **metric):
    model, _ = noise.fit_noise_model(recording, window_len=10, kronecker_channels=0, **metric)
    return calibration.eps_signal(recording, model.spatial_cov, model.temporal_cov, 1), model


@pytest.mark.parametrize("cap", ["none", "blind"])
def test_auto_sig_budget_from_the_signal_separation(cap):
    model = _fit(0, recording=_SLOW, adv_dprime_epsilon="auto_sig", adv_dprime_residuals="whole",
                 adv_dprime_temporal="white", adv_dprime_sig_cap=cap)
    epsilon = model.dprime_report_["epsilon"]
    eps_sig, _ = _signal_budget(_SLOW, residual_mode="whole", temporal_method="white")
    blind = calibration.eps_energy_detector(6, 10) if cap == "blind" else np.inf
    assert epsilon["source"] == "auto_sig"
    assert epsilon["eps_sig"] == pytest.approx(eps_sig, rel=1e-6)
    assert epsilon["eps_star"] == pytest.approx(min(0.24 * eps_sig, blind), rel=1e-6)
    assert epsilon["binding"] == ("signal" if 0.24 * eps_sig <= blind else "blind_cap")
    budgets = model.dprime_report_["training"]["epsilon_per_reference"]
    assert budgets["min"] == pytest.approx(epsilon["eps_star"], rel=1e-5)
    assert budgets["max"] == pytest.approx(epsilon["eps_star"], rel=1e-5)
    json.dumps(model.dprime_report_)


def test_auto_sig_gives_every_pool_member_its_own_budget():
    model = _fit(0, recording=_SLOW, max_iterations=12, adv_dprime_epsilon="auto_sig",
                 adv_dprime_residuals="whole", adv_dprime_temporal="white",
                 adv_dprime_cov_pool=("isotropic",), adv_dprime_sig_cap="none")
    epsilon = model.dprime_report_["epsilon"]
    pool = epsilon["pool"]
    assert [member["pool_index"] for member in pool] == [0, 1]
    for member in pool:
        assert member["budget"] == pytest.approx(0.24 * member["eps_sig"], rel=1e-6)
    assert epsilon["eps_star"] == pytest.approx(pool[0]["budget"])
    # Both members are drawn in 12 steps, each with its own budget.
    budgets = model.dprime_report_["training"]["epsilon_per_reference"]
    used = sorted(member["budget"] for member in pool)
    assert budgets["min"] == pytest.approx(used[0], rel=1e-5)
    assert budgets["max"] == pytest.approx(used[1], rel=1e-5)


def test_auto_sig_rejects_the_trial_mask_layer():
    with pytest.raises(ValueError, match="stationary"):
        _fit(0, recording=_SLOW, adv_dprime_epsilon="auto_sig", adv_dprime_layer="trial_mask")


def test_signal_projection_restricts_the_attack():
    model = _fit(0, recording=_SLOW, adv_dprime_residuals="whole", adv_dprime_temporal="white",
                 adv_dprime_signal_projection="jnd")
    report = model.dprime_report_
    member = report["signal_projection"]["members"][0]
    assert report["signal_projection"]["remove"] == "jnd"
    assert 1 <= member["removed"] < 6
    assert report["training"]["realized"]["dprime_training"]["median"] == pytest.approx(1.0, rel=1e-3)
    json.dumps(report)
