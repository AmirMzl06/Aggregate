"""d′ adversarial training inside the CEBRA solvers (Section 6 of ``DPRIME_DESIGN.md``).

"Drop d′-PGD into Madry-style AT or TRADES with a per-trial budget ε_i = min(ε*, ε_NN,i), i.e.,
instance-adaptive AT in the spirit of IAAT/MMA, with a curriculum from 0.25 up to ε*."

:py:class:`DprimeTrainer` holds the state of one ``Solver.fit`` call in
``adv_epsilon_mode="dprime"``:

1. ``__init__`` (start of ``fit``): fit the noise model on the training recording (Layer 1),
   the class ids of ε_NN (k-means on continuous labels), the per-trial ε_NN,i (whitened
   nearest-neighbour distance, temporal neighbours excluded), the Layer-3 guards, and the
   Kronecker check.
2. ``step``: with ``adv_dprime_epsilon="auto"``, the first ``adv_dprime_warmup`` of the
   iterations are clean; then ε_det is calibrated once on the current batch with the current
   encoder as the attacked model (detectors trained on the earlier half of the batch in time,
   evaluated on the later half) and ``ε* = min(ε_JND, ε_NN, ε_det)``. With
   ``adv_dprime_epsilon="auto_sig"`` the training budget is set in ``__init__`` from the data
   alone, ``ε* = min((2D)^{1/4}, x*·ε_sig)`` of the training metric (every member of a covariance
   pool gets its own budget at the same x*); see :py:func:`calibration.eps_signal`. With
   ``adv_dprime_signal_projection`` the attack is restricted to nuisance directions (the
   signal readouts of the training recording stay fixed; Part 2 of the note). Every later
   step builds
   the coloring (Layer 1, Layer 2 or leadfield; Σ_spatial sampled from the pool), the budget
   ``ε_i = min(ε_t, ε_NN,i)`` with the curriculum ``ε_t`` from ``min(0.25, ε*)`` to ε*, runs
   :py:func:`cebra.dprime.attacks.dprime_pgd` on the reference view and updates the model
   ("madry": the original ACORN structure, a clean update then an update on the adversarial
   reference; "trades": one update on ``InfoNCE(clean) + β · KL(p(x) ‖ p(x_adv))``).
3. ``finalize`` (end of ``fit``): the robustness margin ``median(d′_boundary) / ε*`` with the
   minimum-norm attack on the last batch, in the run's own metric and in the two common metrics
   (Ledoit–Wolf ⊗ Welch and isotropic ``‖δ‖₂ / σ̄``), the realised training perturbations in
   all of these units, and the report.

The solver supplies a few hooks (``_dprime_forward``, ``_dprime_subset``,
``_dprime_clean_stats``) so that single-objective and hybrid (behaviour + time) solvers are
handled alike: every per-sample loss, probability or decision sums or uses all objectives.
"""

import math
import warnings
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

import cebra.data
from cebra.dprime import attacks
from cebra.dprime import calibration
from cebra.dprime import guards as guards_module
from cebra.dprime import noise
from cebra.dprime import trial_mask

__all__ = ["DprimeTrainer", "LAYERS", "OBJECTIVES", "MARGIN_DECISIONS", "AUTO_MODES", "SIG_CAPS"]

LAYERS = ("stationary", "trial_mask")
# "auto": ε* = min(ε_JND, ε_NN, ε_det) (the note). "auto_blind": the training budget is the
# ε_det of the clean-only anomaly detector alone (log-interpolated), bounded by ε_NN.
# "auto_sig": the training budget is the fraction adv_dprime_sig_fraction of the signal
# separation ε_sig of the training metric, capped by the blind threshold (2D)^{1/4}.
AUTO_MODES = ("auto", "auto_blind", "auto_sig")
# Values of adv_dprime_sig_cap: the blind-detector threshold (2D)^{1/4}, or no cap.
SIG_CAPS = ("blind", "none")
OBJECTIVES = ("madry", "trades")
MARGIN_DECISIONS = ("top1", "chance")
# Windows (queries) used for the global ε_NN quantile when the per-trial table is not needed.
_NN_QUERIES = 4000
# Batch samples used for the robustness margin.
_MARGIN_SAMPLES = 512
# Growth of the DDN norm per step before the first adversarial iterate (margin search).
_MARGIN_GROWTH = 0.3
# Shortest receptive field of the trial-level time–frequency mask (Layer 2).
_MIN_TRIAL_MASK_LEN = 4


def _json_float(value: float) -> Optional[float]:
    value = float(value)
    return value if math.isfinite(value) else None


def _infonce_per_sample(pos_dist: torch.Tensor, neg_dist: torch.Tensor) -> torch.Tensor:
    """Per-sample InfoNCE loss ``−φ(ref, pos) + log Σ_j exp φ(ref, neg_j)`` (CEBRA's definition)."""
    return -pos_dist + torch.logsumexp(neg_dist, dim=1)


def _log_probabilities(pos_dist: torch.Tensor, neg_dist: torch.Tensor) -> torch.Tensor:
    """Log-softmax over the candidates [positive, negatives]: ``(B, 1 + M)``."""
    return torch.log_softmax(torch.cat([pos_dist[:, None], neg_dist], dim=1), dim=1)


class DprimeTrainer:
    """State of the d′ adversarial training of one ``fit`` call (see the module docstring).

    Args:
        solver: The CEBRA solver (provides the model, criterion, optimizer, hooks and the
            ``adv_dprime_*`` settings).
        loader: The training loader (single-session).
    """

    def __init__(self, solver, loader):
        self.solver = solver
        self.settings = {
            name: getattr(solver, name) for name in dir(solver) if name.startswith("adv_dprime_")
        }
        self._validate()
        self.device = torch.device(loader.device) if loader.device is not None else torch.device("cpu")
        # Training attacks and the ε_det calibration use separate generators, so the random
        # stream of training does not depend on whether (or when) the calibration ran.
        self.generator = torch.Generator().manual_seed(int(solver.adv_dprime_seed))
        self.calibration_generator = torch.Generator().manual_seed(int(solver.adv_dprime_seed) + 1)
        dataset = loader.dataset
        neural = getattr(dataset, "neural", None)
        offset = getattr(dataset, "offset", None)
        if not isinstance(neural, torch.Tensor) or offset is None:
            raise ValueError("adv_epsilon_mode='dprime' needs a single-session dataset with "
                             "`neural` (n_time, C) and a configured `offset`.")
        self.left, self.right = int(offset.left), int(offset.right)
        self.window_len = self.left + self.right
        self.n_time = int(neural.shape[0])
        recording = neural.detach().float().cpu().numpy()
        labels, kind = self._labels(dataset)
        total = getattr(loader, "num_steps", None)
        self.num_steps = int(total) if total else 1
        self.step_index = 0
        self.report: Dict[str, Any] = {"settings": self._jsonable(self.settings)}
        self.layer = solver.adv_dprime_layer
        if self.layer == "trial_mask" and self.window_len < _MIN_TRIAL_MASK_LEN:
            warnings.warn(f"The model's receptive field ({self.window_len} samples) is too short "
                          "for the trial-level time–frequency mask; using the stationary layer.")
            self.layer = "stationary"
        self.report["layer"] = ("leadfield" if solver.adv_dprime_leadfield is not None else
                                self.layer)

        # Layer 1: the noise model of the training recording.
        self.noise_model, noise_info = noise.fit_noise_model(
            recording,
            labels,
            label_kind=kind,
            window_len=self.window_len,
            residual_mode=solver.adv_dprime_residuals,
            spatial_estimator=solver.adv_dprime_spatial,
            temporal_method=solver.adv_dprime_temporal,
            ar_order=solver.adv_dprime_ar_order,
            vanrossum_tau=solver.adv_dprime_vanrossum_tau,
            cov_pool=solver.adv_dprime_cov_pool,
            leadfield=solver.adv_dprime_leadfield,
            leadfield_noise=solver.adv_dprime_leadfield_noise,
            kronecker_channels=solver.adv_dprime_kronecker_channels,
            device=self.device)
        self.report["noise_model"] = noise_info
        self._fit_common_metrics(recording, noise_info["residual_mode"])

        # Optional nuisance-only attack: one projector per pool member (None: off).
        self.signal_projectors: Optional[List[np.ndarray]] = None
        if solver.adv_dprime_signal_projection is not None:
            self._fit_signal_projectors(recording)

        # Classes ("same-class") and ε_NN ("natural repeat").
        self.classes = calibration.make_classes(labels, kind, solver.adv_dprime_num_classes,
                                                seed=solver.adv_dprime_seed)
        valid = calibration.valid_indices(self.n_time, self.left, self.right)
        if len(valid) < 2:
            raise ValueError("The recording is too short for the model's receptive field.")
        rng = np.random.default_rng(solver.adv_dprime_seed)
        if solver.adv_dprime_instance_adaptive or len(valid) <= _NN_QUERIES:
            queries = valid
        else:
            queries = np.sort(rng.choice(valid, _NN_QUERIES, replace=False))
        query_index, distances = calibration.nearest_neighbour_dprime(
            neural.detach().float(),
            self.noise_model,
            self.left,
            self.right,
            classes=self.classes,
            query_indices=queries,
            bank_size=solver.adv_dprime_nn_bank,
            exclusion=self.window_len,
            seed=solver.adv_dprime_seed,
            device=self.device)
        self.eps_nn = calibration.eps_nn(distances, solver.adv_dprime_nn_quantile)
        self.eps_nn_table = None
        if solver.adv_dprime_instance_adaptive:
            self.eps_nn_table = torch.from_numpy(
                calibration.per_index_eps_nn(self.n_time, query_index, distances)).to(self.device)
        finite = distances[np.isfinite(distances)]
        # Two independent noise draws differ by ≈ √(2D) in the whitened metric (D = C·T), so a
        # nearest-neighbour distance near this floor is mostly noise, and ε_NN ≫ ε_JND in
        # high-dimensional windows (the per-trial bound can then never bind).
        noise_floor = math.sqrt(2.0 * self.noise_model.num_channels * self.window_len)
        self.report["eps_nn"] = {
            "value": _json_float(self.eps_nn),
            "quantile": float(solver.adv_dprime_nn_quantile),
            "noise_floor_sqrt_2D": noise_floor,
            "value_over_noise_floor": _json_float(self.eps_nn / noise_floor),
            "distance_median": _json_float(np.median(finite)) if len(finite) else None,
            "distance_q10": _json_float(np.quantile(finite, 0.1)) if len(finite) else None,
            "n_queries": int(len(query_index)),
            "bank_size": solver.adv_dprime_nn_bank,
            "classes": None if self.classes is None else int(len(np.unique(self.classes))),
        }

        # Layer 3: guards fitted on training windows.
        self.guards = None
        if solver.adv_dprime_guard_mode != "off" and len(solver.adv_dprime_guards) > 0:
            count = min(int(solver.adv_dprime_guard_fit_windows), len(valid))
            times = np.sort(rng.choice(valid, count, replace=False))
            windows = self._windows(neural, times)
            self.guards = guards_module.GuardSet(
                guards=solver.adv_dprime_guards,
                tau=solver.adv_dprime_guard_tau,
                bands=solver.adv_dprime_guard_bands,
                sampling_rate=solver.adv_dprime_sampling_rate,
                erp_window=solver.adv_dprime_erp_window,
                riemann_channels=solver.adv_dprime_riemann_channels,
                artifact_rate=solver.adv_dprime_artifact_rate,
                seed=solver.adv_dprime_seed,
                multitaper_nw=solver.adv_dprime_multitaper_nw,
                multitaper_k=solver.adv_dprime_multitaper_k).fit(
                    windows, None if self.classes is None else self.classes[times], times,
                    exclusion=self.window_len)
            self.report["guards"] = self.guards.report()
            if not self.guards.guards:  # every guard disabled (receptive field too short)
                self.guards = None

        # ε*: user-given, set from the signal separation (auto_sig), or calibrated after the
        # warm-up. eps_pool: the budget of every pool member (auto_sig only).
        epsilon = solver.adv_dprime_epsilon
        self.eps_star: Optional[float] = None
        self.eps_pool: Optional[List[float]] = None
        if isinstance(epsilon, str) and epsilon == "auto_sig":
            self.warmup_steps = 0
            self._calibrate_signal(recording)
        elif isinstance(epsilon, str):
            self.warmup_steps = int(round(float(solver.adv_dprime_warmup) * self.num_steps))
            self.report["epsilon"] = {"source": epsilon, "eps_jnd": float(solver.adv_dprime_jnd),
                                      "eps_nn": _json_float(self.eps_nn)}
        else:
            self.warmup_steps = 0
            self.eps_star = float(epsilon)
            self.report["epsilon"] = {"source": "user", "eps_star": self.eps_star}
        self.curriculum_steps = int(
            round(float(solver.adv_dprime_curriculum) * (self.num_steps - self.warmup_steps)))
        self._last_batch = None
        self._totals = {"steps": 0, "dprime_sum": 0.0, "accepted": 0, "samples": 0,
                        "nn_bound": 0, "backtracks": 0}
        # Per-reference budgets ε_i actually used (≤ 64 evenly spaced samples per step).
        self._eps_samples: List[torch.Tensor] = []
        # The realised perturbations of the same samples (accepted ones) in common units.
        self._size_samples: Dict[str, List[torch.Tensor]] = {
            key: [] for key in ("dprime_training", "dprime_reference", "raw_l2", "loss_gain")
        }

    # -- helpers ------------------------------------------------------------------------
    def _fit_common_metrics(self, recording: np.ndarray, residual_mode: str) -> None:
        """Fixed metrics in which perturbations and margins are also reported.

        Runs with different geometries (Σ estimators, residual modes, layers, isotropic
        controls) measure ε in different units, so the realised perturbations and the
        robustness margins are also given in two metrics that do not depend on the run (the
        same as in :py:mod:`cebra.dprime.evaluation`): ``"reference"``, the note's default
        Ledoit–Wolf ⊗ Welch metric on the label-free ``"whole"`` residuals, and
        ``"isotropic"``, ``‖δ‖₂ / σ̄`` with σ̄² the mean variance of these residuals (raw L2 in
        noise-SD units).
        """
        s = self.solver
        if (s.adv_dprime_spatial, s.adv_dprime_temporal, residual_mode) == ("ledoit_wolf", "welch",
                                                                            "whole"):
            self.reference_model = self.noise_model
        else:
            self.reference_model, _ = noise.fit_noise_model(recording,
                                                            None,
                                                            window_len=self.window_len,
                                                            residual_mode="whole",
                                                            spatial_estimator="ledoit_wolf",
                                                            temporal_method="welch",
                                                            kronecker_channels=0,
                                                            device=self.device)
        residuals = noise.compute_residuals(recording, None, "whole")
        variance = max(float(residuals.var(axis=0).mean()), 1e-12)
        num_channels = self.noise_model.num_channels
        self.isotropic_model = noise.NoiseModel(np.eye(num_channels) * variance,
                                                np.eye(self.window_len),
                                                device=self.device)
        self.isotropic_sigma = math.sqrt(variance)
        self.report["common_metrics"] = {
            "reference": "ledoit_wolf x welch (whole residuals)",
            "isotropic_sigma": self.isotropic_sigma,
            "sqrt_D": math.sqrt(num_channels * self.window_len),
        }

    def _record_sizes(self, x0: torch.Tensor, x_adv: torch.Tensor, info, stride: int) -> None:
        """Store the realised size of every ``stride``-th accepted perturbation."""
        with torch.no_grad():
            index = torch.arange(0, x0.shape[0], stride, device=x0.device)
            index = index[info["accepted"][index]]
            if len(index) == 0:
                return
            delta = (x_adv - x0)[index]
            values = {
                "dprime_training": info["dprime"][index],
                "dprime_reference": self.reference_model.dprime(delta),
                "raw_l2": torch.linalg.vector_norm(delta.flatten(1), dim=1),
                "loss_gain": info["loss"][index] - info["loss_start"][index],
            }
            for key, value in values.items():
                self._size_samples[key].append(value.detach().double().cpu())

    def _validate(self) -> None:
        s = self.solver
        checks = [
            (s.adv_dprime_layer in LAYERS, f"adv_dprime_layer must be one of {LAYERS}"),
            (s.adv_dprime_objective in OBJECTIVES,
             f"adv_dprime_objective must be one of {OBJECTIVES}"),
            (s.adv_dprime_margin_decision in MARGIN_DECISIONS,
             f"adv_dprime_margin_decision must be one of {MARGIN_DECISIONS}"),
            (s.adv_dprime_guard_mode in ("backtrack", "final", "off"),
             "adv_dprime_guard_mode must be 'backtrack', 'final' or 'off'"),
            (s.adv_dprime_optimizer in ("apgd", "pgd"), "adv_dprime_optimizer must be 'apgd' or 'pgd'"),
            (isinstance(s.adv_dprime_epsilon, str) and s.adv_dprime_epsilon in AUTO_MODES
             or (not isinstance(s.adv_dprime_epsilon, str) and float(s.adv_dprime_epsilon) >= 0),
             f"adv_dprime_epsilon must be one of {AUTO_MODES} or a number >= 0"),
            (0.0 <= float(s.adv_dprime_warmup) < 1.0, "adv_dprime_warmup must be in [0, 1)"),
            (float(s.adv_dprime_curriculum) >= 0.0, "adv_dprime_curriculum must be >= 0"),
            (s.adv_steps >= 1, "adv_steps must be >= 1"),
            (float(s.adv_dprime_sig_fraction) > 0.0, "adv_dprime_sig_fraction must be > 0"),
            (int(s.adv_dprime_sig_lag) >= 1, "adv_dprime_sig_lag must be >= 1"),
            ((s.adv_dprime_sig_cap or "none") in SIG_CAPS,
             f"adv_dprime_sig_cap must be one of {SIG_CAPS} (or None)"),
            (s.adv_dprime_signal_projection in (None, "jnd")
             or (isinstance(s.adv_dprime_signal_projection, (int, np.integer))
                 and not isinstance(s.adv_dprime_signal_projection, bool)
                 and s.adv_dprime_signal_projection >= 1),
             "adv_dprime_signal_projection must be None, 'jnd' or an int >= 1"),
        ]
        for ok, message in checks:
            if not ok:
                raise ValueError(message)

    @staticmethod
    def _jsonable(value):
        """Plain Python (JSON / ``torch.load(weights_only=True)`` safe) version of ``value``."""
        if isinstance(value, dict):
            return {str(k): DprimeTrainer._jsonable(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [DprimeTrainer._jsonable(v) for v in value]
        if isinstance(value, (np.ndarray, torch.Tensor)):
            if value.ndim == 0:
                return DprimeTrainer._jsonable(value.item())
            return f"array{tuple(value.shape)}"
        if isinstance(value, np.generic):
            return DprimeTrainer._jsonable(value.item())
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if value is None or isinstance(value, (bool, int, float, str)):
            return value
        return repr(value)

    @staticmethod
    def _labels(dataset) -> Tuple[Optional[np.ndarray], Optional[str]]:
        continuous = getattr(dataset, "continuous_index", None)
        if continuous is not None:
            return continuous.detach().float().cpu().numpy(), "continuous"
        discrete = getattr(dataset, "discrete_index", None)
        if discrete is not None:
            return discrete.detach().long().cpu().numpy(), "discrete"
        return None, None

    def _windows(self, neural: torch.Tensor, times) -> torch.Tensor:
        times = torch.as_tensor(np.asarray(times), device=neural.device)
        offsets = torch.arange(-self.left, self.right, device=neural.device)
        return neural[times[:, None] + offsets[None, :]].transpose(1, 2).float().to(self.device)

    def _pool_index(self) -> int:
        size = self.noise_model.pool_size
        if size == 1:
            return 0
        return int(torch.randint(size, (1,), generator=self.generator))

    def _coloring(self, x0: torch.Tensor, pool_index: int):
        s = self.solver
        if self.noise_model.leadfield is not None:
            return self.noise_model.leadfield_coloring(x0, generator=self.generator)
        if self.layer == "trial_mask":
            return trial_mask.TrialMaskColoring(x0,
                                                self.noise_model.spatial_sqrt_of(pool_index),
                                                n_fft=s.adv_dprime_stft_nfft,
                                                hop=s.adv_dprime_stft_hop,
                                                nw=s.adv_dprime_multitaper_nw,
                                                k=s.adv_dprime_multitaper_k)
        if self.signal_projectors is not None:
            return noise.ProjectedColoring(self.noise_model, self.signal_projectors[pool_index],
                                           pool_index)
        return self.noise_model.stationary_coloring(pool_index)

    def _fit_signal_projectors(self, recording: np.ndarray) -> None:
        """``adv_dprime_signal_projection``: restrict the attack to nuisance directions.

        "Run the d′-PGD attack restricted to the nuisance latent" (Part 2 of the note): the
        signal modes are estimated from the training recording (slow lag-1 covariance against
        the difference-residual noise, :py:func:`calibration.signal_projector`); ``"jnd"`` removes
        every mode detectable within a window (T·ψ > 1), an int the leading modes. The budget is
        unchanged; it can only be spent where the perturbation leaves the signal readouts fixed.
        """
        s = self.solver
        if self.layer != "stationary" or s.adv_dprime_leadfield is not None:
            raise ValueError("adv_dprime_signal_projection needs the stationary layer without a "
                             "leadfield.")
        noise_cov = noise.spatial_covariance(
            noise.compute_residuals(recording, None, "difference"), "ledoit_wolf")
        self.signal_projectors, members = [], []
        for index in range(self.noise_model.pool_size):
            projector, info = calibration.signal_projector(recording,
                                                           self.noise_model.spatial_cov_of(index),
                                                           noise_cov, self.window_len,
                                                           s.adv_dprime_signal_projection)
            self.signal_projectors.append(projector)
            members.append({"pool_index": index, **info})
        self.report["signal_projection"] = {"remove": str(s.adv_dprime_signal_projection),
                                            "noise": "ledoit_wolf (difference residuals)",
                                            "members": members}

    def _distances(self, x: torch.Tensor, batch) -> List[Tuple[torch.Tensor, torch.Tensor]]:
        """(pos_dist, neg_dist) of every objective with ``x`` as the reference view."""
        return [self.solver.criterion._distance(r, p, n)
                for r, p, n in self.solver._dprime_forward(x, batch)]

    def _attack_loss(self, batch, clean_log_probs=None):
        """Per-sample loss to maximise: InfoNCE (madry) or KL to the clean softmax (trades)."""

        def loss_fn(x):
            terms = self._distances(x, batch)
            if clean_log_probs is None:
                return sum(_infonce_per_sample(p, n) for p, n in terms)
            return sum((clean.exp() * (clean - _log_probabilities(p, n))).sum(dim=1)
                       for clean, (p, n) in zip(clean_log_probs, terms))

        return loss_fn

    def current_epsilon(self) -> float:
        """Curriculum ``ε_t`` from ``min(0.25, ε*)`` to ε* (0 before ε* is known).

        ``adv_dprime_curriculum = 0`` means no curriculum: ε* from the first adversarial step.
        """
        if self.eps_star is None:
            return 0.0
        if self.curriculum_steps <= 0:
            return self.eps_star
        start = min(0.25, self.eps_star)
        progress = (self.step_index - self.warmup_steps) / self.curriculum_steps
        return start + (self.eps_star - start) * min(1.0, max(0.0, progress))

    def _member_epsilon(self, epsilon: float, pool_index: int) -> float:
        """Budget of pool member ``pool_index``: with auto_sig, ε_t scaled to its own ε_sig."""
        if self.eps_pool is None or pool_index == 0 or not self.eps_star:
            return epsilon
        return epsilon * self.eps_pool[pool_index] / self.eps_star

    def _budget(self, batch, epsilon: float) -> torch.Tensor:
        size = batch.reference.shape[0]
        eps = torch.full((size,), float(epsilon), device=batch.reference.device)
        index = getattr(batch, "reference_index", None)
        if self.eps_nn_table is not None and index is not None:
            index = torch.as_tensor(index, device=self.eps_nn_table.device).long()
            index = index.clamp(self.left, self.n_time - self.right)
            per_trial = self.eps_nn_table[index].to(eps.device)
            self._totals["nn_bound"] += int((per_trial < eps).sum())
            eps = torch.minimum(eps, per_trial)
        return eps

    # -- signal-referenced budget (auto_sig) ---------------------------------------------
    def _calibrate_signal(self, recording: np.ndarray) -> None:
        """``adv_dprime_epsilon="auto_sig"``: ``ε* = min(cap, x*·ε_sig)`` of the training metric.

        The note's ε* = min(ε_JND, ε_NN, ε_det) is the threat budget (one JND on spike data);
        the training budget must also stay below the size of natural changes of the signal, or
        adversarial training asks the encoder to ignore the signal itself. ε_sig
        (:py:func:`calibration.eps_signal`) is the typical d′ distance between the signal parts
        of two windows in the training metric (the ε_NN idea without its noise floor); the budget
        is the fraction x* = ``adv_dprime_sig_fraction`` of it, capped by the blind-detector
        threshold (2D)^{1/4} (``adv_dprime_sig_cap="blind"``, the ε_det idea for an observer who
        does not know the attack). Every member of a covariance pool gets its own budget at the
        same x*, so a change of geometry keeps the same distance to the signal. Needs only the
        training data: no warm-up, no detectors.
        """
        s = self.solver
        if self.layer != "stationary" or s.adv_dprime_leadfield is not None:
            raise ValueError("adv_dprime_epsilon='auto_sig' needs the stationary layer without a "
                             "leadfield (the signal separation is defined for a stationary metric).")
        fraction = float(s.adv_dprime_sig_fraction)
        lag = int(s.adv_dprime_sig_lag)
        cap = (calibration.eps_energy_detector(self.noise_model.num_channels, self.window_len)
               if (s.adv_dprime_sig_cap or "none") == "blind" else math.inf)
        members = []
        for index in range(self.noise_model.pool_size):
            eps_sig = calibration.eps_signal(recording, self.noise_model.spatial_cov_of(index),
                                             self.noise_model.temporal_cov, lag)
            if not math.isfinite(eps_sig):
                raise ValueError("The estimated signal of the recording is not positive in the "
                                 "training metric; auto_sig cannot set a budget.")
            budget = min(fraction * eps_sig, cap)
            members.append({"pool_index": index, "eps_sig": eps_sig, "budget": budget,
                            "binding": "signal" if fraction * eps_sig <= cap else "blind_cap"})
        self.eps_pool = [member["budget"] for member in members]
        self.eps_star = self.eps_pool[0]
        self.report["epsilon"] = {
            "source": "auto_sig",
            "eps_star": self.eps_star,
            "eps_sig": members[0]["eps_sig"],
            "sig_fraction": fraction,
            "sig_lag": lag,
            "sig_cap": s.adv_dprime_sig_cap or "none",
            "eps_cap": _json_float(cap),
            "binding": members[0]["binding"],
            "x_train": self.eps_star / members[0]["eps_sig"],
            "eps_jnd": float(s.adv_dprime_jnd),
            "eps_nn": _json_float(self.eps_nn),
            "pool": members if len(members) > 1 else None,
        }

    # -- calibration of ε_det ---------------------------------------------------------
    def _calibrate(self, batch) -> None:
        s = self.solver
        model_training = s.model.training
        s.model.eval()
        try:
            size = batch.reference.shape[0]
            index = getattr(batch, "reference_index", None)
            order = (torch.argsort(torch.as_tensor(index).to(batch.reference.device))
                     if index is not None else torch.arange(size, device=batch.reference.device))
            half = size // 2
            if half < 2:
                raise ValueError("The batch is too small to calibrate the detectors.")
            parts = {"train": order[:half], "test": order[half:2 * half]}
            subsets = {name: s._dprime_subset(batch, idx) for name, idx in parts.items()}
            by_pointer = {}
            for name, subset in subsets.items():
                by_pointer[subset.reference.data_ptr()] = subset
            sigma = float(self.report["noise_model"]["noise_std_median"])
            dim = float(self.noise_model.num_channels * self.window_len)
            realized = {}

            def attack_fn(x, eps, kind):
                subset = by_pointer[x.data_ptr()]
                x0 = subset.reference
                if eps <= 0:
                    return x0.clone()
                if kind == "dprime":
                    # ε_det calibrates the d′ ball itself, so the attack uses its whole budget
                    # (no guards: a guard-capped attack would make the curve flat above the cap).
                    adv, info = attacks.dprime_pgd(self._attack_loss(subset), x0,
                                                   self.noise_model.stationary_coloring(0), eps,
                                                   steps=s.adv_steps,
                                                   optimizer=s.adv_dprime_optimizer, restarts=1,
                                                   guards=None,
                                                   generator=self.calibration_generator)
                    realized.setdefault(float(eps), []).append(float(info["dprime"].mean()))
                    return adv
                if kind == "colored_noise":
                    coloring = self.noise_model.stationary_coloring(0)
                    return x0 + coloring.color(
                        coloring.random_z(x0, eps, self.calibration_generator))
                # "linf": a box corner of d′ ≈ eps for noise of the median std.
                return attacks.linf_pgd(self._attack_loss(subset), x0, eps * sigma / math.sqrt(dim),
                                        steps=s.adv_steps, generator=self.calibration_generator)

            curve = calibration.detection_curve(subsets["train"].reference,
                                                subsets["test"].reference, attack_fn,
                                                s.adv_dprime_det_grid,
                                                detector_steps=s.adv_dprime_det_steps,
                                                device=self.device, seed=s.adv_dprime_seed)
            for eps, values in curve.items():
                if float(eps) in realized:
                    values["mean_dprime"] = float(np.mean(realized[float(eps)]))
            eps_det, status = calibration.eps_det_from_curve(curve, s.adv_dprime_det_auc)
            eps_star, source = calibration.epsilon_star(self.eps_nn, eps_det, s.adv_dprime_jnd)
            eps_blind, blind_status = calibration.eps_det_crossing(curve, s.adv_dprime_det_auc,
                                                                   key="ae_auc")
            energy = calibration.eps_energy_detector(self.noise_model.num_channels,
                                                     self.window_len)
            if s.adv_dprime_epsilon == "auto_blind":
                self.eps_star = min(eps_blind, self.eps_nn)
                source = "blind_det" if eps_blind <= self.eps_nn else "nn"
            else:
                self.eps_star = eps_star
            self.report["epsilon"].update({
                "eps_det": _json_float(eps_det),
                "eps_det_status": status,
                "eps_det_blind": _json_float(eps_blind),
                "eps_det_blind_status": blind_status,
                "eps_energy_detector": energy,
                "eps_star_note": _json_float(eps_star),
                "detection_curve": {str(k): v for k, v in curve.items()},
                "detection_attack": "d′-PGD without guards + colored noise + L∞-PGD (CNN), "
                                    "d′-PGD (held-out)",
                "eps_star": _json_float(self.eps_star),
                "binding": source,
                "calibration_step": self.step_index,
            })
        finally:
            s.model.train(model_training)

    # -- training step ------------------------------------------------------------------
    def step(self, batch) -> Dict[str, float]:
        """One training step in d′ mode; returns the statistics of the solver's ``step``."""
        s = self.solver
        self._last_batch = batch
        warm = self.eps_star is None and self.step_index < self.warmup_steps
        if self.eps_star is None and not warm:
            self._calibrate(batch)

        epsilon = 0.0 if warm else self.current_epsilon()
        objective = s.adv_dprime_objective
        stats_extra = {"dprime_eps": float(epsilon), "dprime_mean": 0.0, "dprime_accept": 0.0}

        x_adv = None
        clean_log_probs = None
        if not warm and epsilon > 0:
            if objective == "trades":
                with torch.no_grad():
                    clean_log_probs = [_log_probabilities(p, n).detach()
                                       for p, n in self._distances(batch.reference, batch)]
            # The pool member is drawn first (same generator stream as before: nothing in
            # between uses it) because auto_sig gives every member its own budget.
            pool_index = self._pool_index()
            eps = self._budget(batch, self._member_epsilon(epsilon, pool_index))
            stride = max(1, len(eps) // 64)
            self._eps_samples.append(eps[::stride].detach().float())
            x0 = batch.reference.detach()
            x_adv, info = attacks.dprime_pgd(self._attack_loss(batch, clean_log_probs),
                                             x0,
                                             self._coloring(x0, pool_index),
                                             eps,
                                             steps=s.adv_steps,
                                             optimizer=s.adv_dprime_optimizer,
                                             restarts=s.adv_dprime_restarts,
                                             guards=self.guards,
                                             guard_mode=s.adv_dprime_guard_mode,
                                             max_backtrack=s.adv_dprime_max_backtrack,
                                             soft_penalty_weight=s.adv_dprime_soft_riemann,
                                             generator=self.generator)
            accepted = info["accepted"]
            stats_extra["dprime_mean"] = float(info["dprime"].mean())
            stats_extra["dprime_accept"] = float(accepted.float().mean())
            self._totals["dprime_sum"] += float(info["dprime"].sum())
            self._totals["accepted"] += int(accepted.sum())
            self._totals["samples"] += int(accepted.numel())
            self._totals["backtracks"] += int(info["backtracks"])
            self._record_sizes(x0, x_adv, info, stride)

        # Updates.
        if x_adv is not None and objective == "trades":
            s.optimizer.zero_grad()
            clean = s._dprime_forward(batch.reference, batch)
            losses = [s.criterion(r, p, n) for r, p, n in clean]
            kl = 0.0
            for (r, p, n), (pa, na) in zip(clean, self._distances(x_adv, batch)):
                clean_lp = _log_probabilities(*s.criterion._distance(r, p, n))
                kl = kl + (clean_lp.exp() * (clean_lp - _log_probabilities(pa, na))).sum(dim=1).mean()
            total = sum(loss for loss, _, _ in losses) + float(s.adv_dprime_trades_beta) * kl
            total.backward()
            s.optimizer.step()
            stats_extra["dprime_trades_kl"] = float(kl)
        else:
            s.optimizer.zero_grad()
            losses = [s.criterion(r, p, n) for r, p, n in s._dprime_forward(batch.reference, batch)]
            sum(loss for loss, _, _ in losses).backward()
            s.optimizer.step()
            if x_adv is not None:
                s.optimizer.zero_grad()
                adv_losses = [s.criterion(r, p, n) for r, p, n in s._dprime_forward(x_adv, batch)]
                sum(loss for loss, _, _ in adv_losses).backward()
                s.optimizer.step()

        clean_total = sum(float(loss) for loss, _, _ in losses)
        s.history.append(clean_total)
        stats = s._dprime_clean_stats(losses)
        stats.update(stats_extra)
        for key, value in stats.items():
            s.log.setdefault(key, []).append(value)
        self.step_index += 1
        self._totals["steps"] += 1
        return stats

    # -- end of training ----------------------------------------------------------------
    def _epsilon_distribution(self) -> Optional[Dict[str, Any]]:
        """Quantiles of the per-reference budgets ε_i used in training (None without attacks)."""
        if not self._eps_samples:
            return None
        values = torch.cat(self._eps_samples).cpu().double().numpy()
        quantiles = np.quantile(values, [0.0, 0.1, 0.5, 0.9, 1.0])
        return {
            "min": _json_float(quantiles[0]),
            "q10": _json_float(quantiles[1]),
            "median": _json_float(quantiles[2]),
            "q90": _json_float(quantiles[3]),
            "max": _json_float(quantiles[4]),
            "n": int(values.size),
            "frac_bound_by_eps_nn": self._totals["nn_bound"] / max(self._totals["samples"], 1),
        }

    @staticmethod
    def _summary(values: np.ndarray) -> Dict[str, Any]:
        quantiles = np.quantile(values, [0.1, 0.5, 0.9])
        return {"mean": _json_float(values.mean()), "q10": _json_float(quantiles[0]),
                "median": _json_float(quantiles[1]), "q90": _json_float(quantiles[2])}

    def _realized_sizes(self) -> Optional[Dict[str, Any]]:
        """Realised training perturbations in common units (None without accepted attacks).

        ``dprime_training`` (the run's own metric), ``dprime_reference`` (Ledoit–Wolf ⊗
        Welch), ``dprime_isotropic`` (``‖δ‖₂ / σ̄``), ``raw_l2`` (input units, whole window),
        ``rms_per_entry`` (``‖δ‖₂ / √(C·T)``) and ``loss_gain`` (increase of the attack
        objective over the unperturbed loss): mean / q10 / median / q90 each.
        """
        if not self._size_samples["raw_l2"]:
            return None
        values = {key: torch.cat(parts).numpy() for key, parts in self._size_samples.items()}
        values["dprime_isotropic"] = values["raw_l2"] / self.isotropic_sigma
        values["rms_per_entry"] = values["raw_l2"] / math.sqrt(
            self.noise_model.num_channels * self.window_len)
        report = {key: self._summary(value) for key, value in values.items()}
        report["n"] = int(values["raw_l2"].size)
        return report

    def finalize(self) -> Dict[str, Any]:
        """Robustness margin on the last batch and the final report."""
        s = self.solver
        totals = self._totals
        self.report["training"] = {
            "steps": int(totals["steps"]),
            "warmup_steps": int(self.warmup_steps),
            "curriculum_steps": int(self.curriculum_steps),
            "mean_dprime": totals["dprime_sum"] / max(totals["samples"], 1),
            "accept_rate": totals["accepted"] / max(totals["samples"], 1),
            "eps_nn_binding_rate": totals["nn_bound"] / max(totals["samples"], 1),
            "backtracks": int(totals["backtracks"]),
            "final_epsilon": _json_float(self.current_epsilon()),
            "epsilon_per_reference": self._epsilon_distribution(),
            "realized": self._realized_sizes(),
        }
        batch = self._last_batch
        if batch is not None and self.eps_star is not None and self.eps_star > 0:
            model_training = s.model.training
            s.model.eval()
            try:
                size = min(batch.reference.shape[0], _MARGIN_SAMPLES)
                subset = s._dprime_subset(batch, torch.arange(size, device=batch.reference.device))
                decision = s.adv_dprime_margin_decision

                def is_adv(x):
                    with torch.no_grad():
                        terms = self._distances(x, subset)
                        if decision == "top1":
                            flags = [p <= n.max(dim=1).values for p, n in terms]
                        else:
                            flags = [p - (torch.logsumexp(n, dim=1) - math.log(n.shape[1])) <= 0
                                     for p, n in terms]
                        out = flags[0]
                        for flag in flags[1:]:
                            out = out | flag
                        return out

                # The run's own metric (ratio to ε*), then the two common metrics (ratio to
                # ε_JND), which compare runs of different geometries. The search starts at
                # max(ε*, ε_JND) and is scale-free (relative steps, fast growth until the
                # first adversarial iterate): margins range from about 1 to well above 10.
                jnd = float(s.adv_dprime_jnd)
                metrics = (("robustness_margin", self.noise_model, self.eps_star),
                           ("robustness_margin_reference", self.reference_model, jnd),
                           ("robustness_margin_isotropic", self.isotropic_model, jnd))
                for key, model, denominator in metrics:
                    distance, _ = attacks.min_norm_ddn(is_adv, self._attack_loss(subset),
                                                       subset.reference,
                                                       model.stationary_coloring(0),
                                                       steps=s.adv_dprime_margin_steps,
                                                       init_epsilon=max(self.eps_star, jnd),
                                                       relative_step=True,
                                                       growth=_MARGIN_GROWTH)
                    margin = calibration.robustness_margin(distance, denominator)
                    self.report[key] = self._jsonable(
                        {k: (v if not isinstance(v, float) or math.isfinite(v) else None)
                         for k, v in margin.items()})
                    self.report[key]["decision"] = decision
            finally:
                s.model.train(model_training)
        self.report = self._jsonable(self.report)
        return self.report
