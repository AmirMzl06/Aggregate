#!/usr/bin/env bash
set -euo pipefail
source /home/mirzaei/lm-cebra/.venv/bin/activate
cd /home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main
export PYTHONDONTWRITEBYTECODE=1

echo '========== C-CO0 EPS SWEEP / 4x H200 =========='
nvidia-smi --list-gpus
python -B - <<'PY'
import torch
assert torch.cuda.is_available() and torch.cuda.device_count() == 4, (
    f'Expected 4 GPUs, got {torch.cuda.device_count()}')
print('CUDA:',torch.cuda.is_available(),'GPU count:',torch.cuda.device_count(),flush=True)
PY
python -u launch_cco0_eps_4gpu.py
