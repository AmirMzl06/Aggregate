#!/usr/bin/env python3
"""20 source-only C-CO0 jobs (5 eps x 2 attacks x 2 seeds), 4 GPUs."""
import csv
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np

PROJECT = Path('/home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main')
DATA = Path('/data/hossein/mm_project/perich_data_valid_final_raw')
FORK = Path('/home/mirzaei/sam/result/Aggregate/Acorn-dprime')
OUT = Path('/data/hossein/mm_project/exp16_CCO0_80_20_eps_sweep_raw')
EPS = ('0.1','0.3','0.5','0.7','0.9')
ARMS = tuple(f'ACORN_EPS{x}' for x in EPS) + tuple(f'SPDIFF_D{x}' for x in EPS)
SEEDS = (42,43)

assert (PROJECT/'run_multi_transfer.py').is_file()
assert (PROJECT/'run_cco0_eps_extension.py').is_file()
assert (PROJECT/'multi_dprime_bridge.py').is_file()
assert (FORK/'cebra/dprime/noise.py').is_file()
assert (FORK/'cebra/dprime/calibration.py').is_file()
with np.load(DATA/'C-CO0.npz',allow_pickle=False) as d:
    train_n, test_n = len(d['train_data']),len(d['valid_data'])
    print(f'C-CO0 PREDEFINED SPLIT: train={train_n}, holdout={test_n}, '
          f'train_fraction={train_n/(train_n+test_n):.3%}',flush=True)
OUT.mkdir(parents=True,exist_ok=True)
print('RAW source-only, supervised; PGD_L2 + SPDIFF fixed budgets; seeds 42 and 43',flush=True)


def succeeded(arm,seed):
    dest=OUT/arm/f'seed{seed}'
    ckpt=dest/arm/f'seed{seed}'/'source_encoder.pt'
    log=dest/'records.jsonl'
    if not ckpt.is_file() or not log.is_file(): return False
    for line in log.read_text().splitlines():
        try:r=json.loads(line)
        except ValueError:continue
        if (r.get('arm')==arm and r.get('seed')==seed and
            r.get('session')=='C-CO0' and r.get('status')=='success'):
            return True
    return False


def worker(gpu, arm, seed):
    dest=OUT/arm/f'seed{seed}'
    dest.mkdir(parents=True,exist_ok=True)
    if succeeded(arm,seed):
        print(f'[GPU {gpu}] SKIP complete {arm} seed={seed}',flush=True)
        return True
    cmd=[sys.executable,'-B','-u',str(PROJECT/'run_cco0_eps_extension.py'),
         '--data-dir',str(DATA),'--fork-dir',str(FORK),'--out',str(dest),
         '--source','C-CO0','--mode','supervised',
         '--arms',arm,'--seeds',str(seed),
         '--source-steps','3000','--adapter-steps','1000',
         '--decoder-steps','2500','--batch-size','512',
         '--attack-steps','10','--device','auto','--resume']
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONDONTWRITEBYTECODE='1')
    print(f'[GPU {gpu}] START {arm} seed={seed}',flush=True)
    log=dest/'worker.log'
    with log.open('a',encoding='utf-8') as f:
        f.write('\n==== NEW ATTEMPT ====\n')
        ret=subprocess.run(cmd,cwd=str(PROJECT),env=env,stdout=f,
                           stderr=subprocess.STDOUT,check=False).returncode
    if ret:
        print(f'[GPU {gpu}] FAILED {arm} seed={seed}: exit {ret}; log {log}',flush=True)
        print('\n'.join(log.read_text(errors='replace').splitlines()[-30:]),flush=True)
        return False
    print(f'[GPU {gpu}] DONE {arm} seed={seed}',flush=True)
    return True


def export_summary():
    rows=[]
    for arm in ARMS:
        for seed in SEEDS:
            path=OUT/arm/f'seed{seed}'/'records.jsonl'
            if not path.is_file(): continue
            matches=[]
            for line in path.read_text().splitlines():
                try: row=json.loads(line)
                except ValueError:continue
                if row.get('arm')==arm and row.get('seed')==seed and row.get('session')=='C-CO0' and row.get('status')=='success':
                    matches.append(row)
            if matches:rows.append(matches[-1])
    columns=['arm','seed','session','phase','status','r2_train','r2_holdout',
             'n_neurons','n_train','n_test','train_dprime_epsilon']
    with (OUT/'summary_ALL.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)
    print(f'COMPLETED {len(rows)}/20 | SUMMARY {OUT}/summary_ALL.csv',flush=True)
    for r in rows:
        print(f"{r['arm']:20s} seed={r['seed']} R2_holdout={r['r2_holdout']:.5f}",flush=True)
    return len(rows)


def main():
    # Each worker loops over tasks and sees one dedicated GPU.
    from queue import Queue,Empty
    q=Queue()
    for arm in ARMS:
        for seed in SEEDS:q.put((arm,seed))
    def loop(gpu):
        all_ok=True
        while True:
            try:arm,seed=q.get_nowait()
            except Empty:return all_ok
            try:
                all_ok=worker(gpu,arm,seed) and all_ok
            finally:q.task_done()
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(loop,gpu) for gpu in range(4)]
        ok=[f.result() for f in as_completed(futures)]
    n=export_summary()
    if not all(ok) or n!=20:sys.exit(1)
    print('ALL C-CO0 EPSILON SWEEP RUNS COMPLETED',flush=True)

if __name__=='__main__':main()
