#!/usr/bin/env python3
"""Source-only C-CO0 80/20 fixed-epsilon extension of Exp15; no original edits."""
from pathlib import Path
import run_multi_transfer as base

EPS = ("0.1", "0.3", "0.5", "0.7", "0.9")
ARMS = tuple(f"ACORN_EPS{e}" for e in EPS) + tuple(f"SPDIFF_D{e}" for e in EPS)
base.ARMS = ARMS
base.DPRIME_ARMS = frozenset(a for a in ARMS if a.startswith("SPDIFF_D"))

_original_kwargs = base.train_kwargs

def train_kwargs(args, n_steps, arm):
    result = _original_kwargs(args, n_steps, arm)
    if arm.startswith("ACORN_EPS"):
        result["adv_eps"] = float(arm[len("ACORN_EPS"):])
    return result

base.train_kwargs = train_kwargs

class FixedDprimeBridge(base.DprimeBridge):
    def fit(self, key, x, y, arm, mode, standardized=False):
        # Reuse exactly the pre-existing SPDIFF_D8 noise estimation code.
        note = super().fit(key, x, y, "SPDIFF_D8", mode, standardized)
        epsilon = float(arm[len("SPDIFF_D"):])
        note["arm"] = arm
        note["budget_dprime"] = epsilon
        note["calibration"] = {"method": "fixed", "epsilon": epsilon}
        self.contexts[key] = note
        return note

base.DprimeBridge = FixedDprimeBridge

def source_only(args):
    source = base.norm_key(args.source)
    if source != "C-CO0":
        raise ValueError("This sweep is restricted to C-CO0")
    if not (args.data_dir / "C-CO0.npz").is_file():
        raise FileNotFoundError(args.data_dir / "C-CO0.npz")
    # Original runner also evaluates `source` on its valid_data.
    # Return no targets to prevent fitting any target-session adapters.
    return source, []

base.discover = source_only

if __name__ == "__main__":
    base.main()
