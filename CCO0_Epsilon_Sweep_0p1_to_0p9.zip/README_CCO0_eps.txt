C-CO0 source-only 80/20 epsilon sweep for existing EXP15 project's raw NPZ.

Do not overwrite original run_multi_transfer.py or multi_dprime_bridge.py.
These three NEW files go alongside them in:
/home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main

Arms (10):
 ACORN_EPS0.1, ACORN_EPS0.3, ACORN_EPS0.5, ACORN_EPS0.7, ACORN_EPS0.9
 SPDIFF_D0.1, SPDIFF_D0.3, SPDIFF_D0.5, SPDIFF_D0.7, SPDIFF_D0.9
Seeds 42,43 -> 20 runs. 4 GPUs one run per GPU.

Source data from the EXISTING C-CO0.npz:
 Train = train_data/train_label; 20% holdout = valid_data/valid_label
 Train-only decoder, evaluates on held-out valid_data, outputs holdout R2.
 Does not evaluate target C-CO sessions. Raw/no --standardize.

Inherited EXP15 settings: supervised, source_steps 3000,
 decoder_steps 2500, batch_size 512, attack_steps 10,
 time offset 4, Offset36 Multi architecture.

Output:
 /data/hossein/mm_project/exp16_CCO0_80_20_eps_sweep_raw
 summary_ALL.csv and per-arm/seed worker.log

Dprime fixed epsilon uses existing DprimeBridge SPDIFF noise estimator;
 its SPDIFF_D8 calibration is used to fit the same covariance, then
 the attack budget is explicitly overridden with the requested fixed epsilon.
 Original model/frozen dprime source files remain unchanged.

All jobs may be retried with same launch script: successfully completed
 arms/seeds are skipped, and partial jobs are rerun from original runner's
 source checkpoint if it exists. Not a guaranteed mid-step recovery.

IMPORTANT: same numerical epsilon for PGD L2 and Mahalanobis dprime is NOT
 identical physical perturbation magnitude. They are different geometries.
