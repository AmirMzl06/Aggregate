#!/usr/bin/env python3
"""Safe 4-GPU continuation of Exp15: per-(arm,seed) isolated outputs.

Original Exp15 runner is used unchanged. Checkpoints and successful records are
copied from the original output; no writes to the original output. Four separate
Python processes each see precisely one GPU via CUDA_VISIBLE_DEVICES.
"""
from __future__ import annotations
import argparse
import csv
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import sys
import threading
from collections import Counter

ARMS = (
    'CEBRA','ACORN_EPS1','ACORN_EPS3','ACORN_EPS6',
    'SPDIFF_D8','SPDIFF_AUTOBEH','SPDIFF_AUTOSIG',
    'SP_AUTOBEH_POOL','SPDIFF_GAUSS',
)
# Try the costliest arms first so all GPUs stay useful at the end.
ORDER = ('SPDIFF_AUTOBEH','SPDIFF_AUTOSIG','SP_AUTOBEH_POOL',
         'SPDIFF_D8','SPDIFF_GAUSS','ACORN_EPS6','ACORN_EPS3',
         'ACORN_EPS1','CEBRA')
SEEDS = (42,43)
SOURCE = 'C-CO0'
ORIGINAL = Path('/data/hossein/mm_project/exp15_multi_transfer')
DEST = Path('/data/hossein/mm_project/exp15_multi_transfer_4gpu')
PROJECT = Path('/home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main')
FORK = Path('/home/mirzaei/sam/result/Aggregate/Acorn-dprime')
DATA = Path('/data/hossein/mm_project/perich_data_valid_final_raw')
EXPECTED = 52
STEP_ARGS = [
    '--data-dir',str(DATA),'--fork-dir',str(FORK),
    '--source',SOURCE,'--mode','supervised',
    '--source-steps','3000','--adapter-steps','1000',
    '--decoder-steps','2500','--batch-size','512',
    '--attack-steps','10',
]


def read_jsonl(path):
    """Success-only mapping. Last success wins; malformed partial tails ignored."""
    success = {}
    if not path.exists():
        return success
    with path.open(encoding='utf8') as f:
        for line in f:
            try:
                r = json.loads(line)
                key = (r['arm'],int(r['seed']),r['session'])
            except (ValueError,TypeError,KeyError):
                continue
            if r.get('status') == 'success':
                success[key] = r
    return success


def read_targets():
    path = ORIGINAL/'manifest.json'
    if not path.is_file():
        raise RuntimeError('Original manifest missing: '+str(path))
    manifest = json.loads(path.read_text())
    required = {
        'selected_source':SOURCE,'mode':'supervised',
        'source_steps':3000,'adapter_steps':1000,
        'decoder_steps':2500,'batch_size':512,'attack_steps':10,
        'standardize':False,
    }
    for key, val in required.items():
        if manifest.get(key)!=val:
            raise RuntimeError(f'Original manifest mismatch for {key}: {manifest.get(key)!r} != {val!r}')
    if set(manifest.get('arms',[])) != set(ARMS):
        raise RuntimeError('Original manifest arms do not match the nine requested arms')
    if set(manifest.get('seeds',[])) != set(SEEDS):
        raise RuntimeError('Original manifest seeds differ from [42,43]')
    if str(manifest.get('data_dir'))!=str(DATA):
        raise RuntimeError('Original manifest data_dir mismatch')
    targets = manifest.get('selected_targets',[])
    if len(targets)!=EXPECTED or len(set(targets))!=EXPECTED:
        raise RuntimeError(f'Expected {EXPECTED} distinct targets, got {len(targets)}')
    if any(t==SOURCE for t in targets):
        raise RuntimeError('Source included in targets')
    return targets


def target_dir(arm, seed):
    return DEST/arm/f'seed{seed}'


def combine_success():
    # Original is never modified. Child outputs override it only for their own key.
    results=read_jsonl(ORIGINAL/'records.jsonl')
    for arm in ARMS:
        for seed in SEEDS:
            results.update(read_jsonl(target_dir(arm,seed)/'records.jsonl'))
    return results


def status(targets, export=False):
    data = combine_success()
    good = {(a,s,t):r for (a,s,t),r in data.items()
            if a in ARMS and s in SEEDS and (t==SOURCE or t in targets)}
    n_targets = sum(t!=SOURCE for a,s,t in good)
    n_sources = sum(t==SOURCE for a,s,t in good)
    print(f'TARGET SUCCESS: {n_targets}/{EXPECTED*len(ARMS)*len(SEEDS)} '
          f'({100*n_targets/(EXPECTED*len(ARMS)*len(SEEDS)):.2f}%)',flush=True)
    print(f'SOURCE SUCCESS: {n_sources}/{len(ARMS)*len(SEEDS)}',flush=True)
    for arm in ARMS:
        print(f'  {arm:22s} {sum(a==arm and t!=SOURCE for a,s,t in good):3d}/{EXPECTED*len(SEEDS)}',flush=True)
    if export:
        DEST.mkdir(parents=True,exist_ok=True)
        columns=['arm','seed','session','phase','status','r2_train','r2_holdout',
                 'n_neurons','n_train','n_test','train_dprime_epsilon','error']
        output=DEST/'summary_ALL.csv'
        tmp=output.with_suffix('.csv.tmp')
        with tmp.open('w',newline='',encoding='utf8') as f:
            writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore')
            writer.writeheader()
            for key in sorted(good, key=lambda k:(ARMS.index(k[0]),k[1],
                     -1 if k[2]==SOURCE else int(k[2].split('CO')[-1]))):
                writer.writerow(good[key])
        tmp.replace(output)
        print('CONSOLIDATED CSV:',output,flush=True)
    return n_targets


def prepare(targets):
    if not PROJECT.joinpath('run_multi_transfer.py').is_file():
        raise RuntimeError('Missing original runner: '+str(PROJECT))
    if not FORK.joinpath('cebra/dprime/noise.py').is_file():
        raise RuntimeError('Missing frozen dprime fork')
    if not DEST.is_absolute() or DEST.resolve()==ORIGINAL.resolve():
        raise RuntimeError('DEST must differ from ORIGINAL')
    DEST.mkdir(parents=True,exist_ok=True)
    old = read_jsonl(ORIGINAL/'records.jsonl')
    needed=set(targets)|{SOURCE}
    imported=0
    for arm in ARMS:
        for seed in SEEDS:
            dst=target_dir(arm,seed)
            dst.mkdir(parents=True,exist_ok=True)
            recpath=dst/'records.jsonl'
            current=read_jsonl(recpath)
            old_candidates=[r for (a,s,t),r in old.items()
                            if a==arm and s==seed and t in needed and (a,s,t) not in current]
            if old_candidates:
                # append old success-only records, preserving any sharded progress.
                with recpath.open('a',encoding='utf8') as f:
                    for r in old_candidates:
                        f.write(json.dumps(r,allow_nan=False,sort_keys=True)+'\n')
                        imported+=1
                    f.flush()
                    os.fsync(f.fileno())
            srcdir=ORIGINAL/arm/f'seed{seed}'
            ckpt_src=srcdir/'source_encoder.pt'
            ckpt_dst=dst/arm/f'seed{seed}'/'source_encoder.pt'
            if ckpt_src.exists() and not ckpt_dst.exists():
                ckpt_dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(ckpt_src,ckpt_dst)
            note_src=srcdir/'source_calibration.json'
            note_dst=ckpt_dst.parent/'source_calibration.json'
            if note_src.exists() and not note_dst.exists():
                shutil.copy2(note_src,note_dst)
    print(f'PREPARED: {DEST} | copied {imported} new completed records from original',flush=True)


def run(targets, nworkers):
    if nworkers!=4:
        raise ValueError('This launch is configured for exactly four GPUs')
    gpu_list=subprocess.run(['nvidia-smi','--list-gpus'],capture_output=True,text=True)
    if gpu_list.returncode or len([l for l in gpu_list.stdout.splitlines() if l.strip()]) < nworkers:
        raise RuntimeError('This pod must have 4 visible GPUs; use RunAI --gpu 4')
    prepare(targets)
    print('========== EXP15 RESUME BEFORE START ==========',flush=True)
    status(targets,export=True)
    pending=[]
    old_plus_new=combine_success()
    for arm in ORDER:
        for seed in SEEDS:
            done=sum((arm,seed,t) in old_plus_new for t in targets)
            srcdone=(arm,seed,SOURCE) in old_plus_new
            if done==len(targets) and srcdone:
                print('SKIP complete:',arm,seed,flush=True)
                continue
            pending.append((arm,seed))
    jobs=queue.Queue()
    for task in pending: jobs.put(task)
    stop=threading.Event()
    failures=[]
    def worker(gpu):
        while not stop.is_set():
            try: arm,seed=jobs.get_nowait()
            except queue.Empty: return
            dest=target_dir(arm,seed)
            env=dict(os.environ)
            env['CUDA_VISIBLE_DEVICES']=str(gpu)
            env['PYTHONDONTWRITEBYTECODE']='1'
            cmd=[sys.executable,'-B','-u',str(PROJECT/'run_multi_transfer.py'),
                 *STEP_ARGS,'--out',str(dest),'--arms',arm,'--seeds',str(seed),'--resume',
                 '--device','auto']
            log=dest/'worker.log'
            print(f'[GPU {gpu}] START {arm} seed={seed} | log={log}',flush=True)
            try:
                with log.open('a',encoding='utf8',buffering=1) as logf:
                    logf.write('\n=== NEW ATTEMPT ===\n')
                    proc=subprocess.Popen(cmd,cwd=str(PROJECT),env=env,
                                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                          text=True,bufsize=1)
                    for line in proc.stdout:
                        logf.write(line)
                        # Useful progress and errors go to the main RunAI log.
                        if ('SUCCESS:' in line or 'TRAINED source:' in line or
                            'RESUMED source:' in line or 'Traceback' in line or
                            'Error:' in line or line.startswith('COMPLETE:')):
                            print(f'[GPU {gpu} {arm} seed={seed}] {line.rstrip()}',flush=True)
                    rc=proc.wait()
                if rc:
                    failures.append((gpu,arm,seed,rc,str(log)))
                    stop.set()
                    print(f'[GPU {gpu}] FAILED {arm} seed={seed} exit={rc}, see {log}',flush=True)
                else:
                    print(f'[GPU {gpu}] FINISHED {arm} seed={seed}',flush=True)
            except Exception as exc:
                failures.append((gpu,arm,seed,'exception',repr(exc)))
                stop.set()
                print(f'[GPU {gpu}] ERROR {arm} seed={seed}: {exc}',flush=True)
            finally:
                jobs.task_done()
    threads=[threading.Thread(target=worker,args=(g,),daemon=False) for g in range(nworkers)]
    for t in threads:t.start()
    for t in threads:t.join()
    print('========== EXP15 RESUME FINAL STATUS ==========',flush=True)
    status(targets,export=True)
    if failures:
        for item in failures:print('FAILED TASK:',item,flush=True)
        return 1
    return 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['run','status','prepare'])
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    targets=read_targets()
    if args.action=='status':status(targets,export=True)
    elif args.action=='prepare':
        prepare(targets)
        status(targets,export=True)
    else:sys.exit(run(targets,args.workers))

if __name__=='__main__':main()
