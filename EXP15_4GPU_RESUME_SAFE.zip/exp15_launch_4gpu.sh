#!/usr/bin/env bash
set -euo pipefail
cd /home/mirzaei/sam/result/Aggregate
source /home/mirzaei/lm-cebra/.venv/bin/activate
export PYTHONDONTWRITEBYTECODE=1
python -B -u /home/mirzaei/sam/result/Aggregate/exp15_resume_4gpu.py run --workers 4
