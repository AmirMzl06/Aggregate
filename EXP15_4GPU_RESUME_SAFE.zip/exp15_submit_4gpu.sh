#!/usr/bin/env bash
set -euo pipefail
# Run this on haas034 AFTER the single-GPU sam-exp15 job has been deleted.
runai submit --name sam-exp15-4gpu \
  --image registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.4 \
  --gpu 4 --cpu 64 --memory 256Gi --node-pools h200 --large-shm \
  --pvc home:/home/mirzaei \
  --pvc upmwmathis-scratch:/data \
  -e HOME=/home/mirzaei \
  -e USER=mirzaei \
  -e LOGNAME=mirzaei \
  -e PYTHONDONTWRITEBYTECODE=1 \
  -e LD_LIBRARY_PATH=/home/mirzaei/lm-cebra/.venv/lib/python3.10/site-packages/nvidia/cu13/lib:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 \
  -p upmwmathis-mirzaei --run-as-user \
  --command -- bash /home/mirzaei/sam/result/Aggregate/exp15_launch_4gpu.sh
