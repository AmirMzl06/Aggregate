#!/usr/bin/env bash
set -euo pipefail
runai submit --name sam-dprime-exp15 \
  --image registry.rcp.epfl.ch/upmwmathis-mirzaei/robust-cebra:v0.4 \
  --gpu 1 --cpu 32 --memory 128Gi --node-pools h200 --large-shm \
  --pvc home:/home/mirzaei --pvc upmwmathis-scratch:/data \
  -e HOME=/home/mirzaei -e USER=mirzaei -e LOGNAME=mirzaei \
  -e PYTHONDONTWRITEBYTECODE=1 \
  -e LD_LIBRARY_PATH=/home/mirzaei/lm-cebra/.venv/lib/python3.10/site-packages/nvidia/cu13/lib:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 \
  -p upmwmathis-mirzaei --run-as-user \
  --command -- bash /home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main/runai_launch_exp15.sh
