#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
PROJECT=/home/mirzaei/sam/result/Aggregate/Acorn-multi/acorn-main
VENV=/home/mirzaei/lm-cebra/.venv
cd "$PROJECT"
# The acorn-main pyproject requires Python >=3.11; make sure VENV is compatible.
"$VENV/bin/python" -V
"$VENV/bin/python" -B -u run_multi_transfer.py \
  --data-dir /data/hossein/mm_project/perich_data_valid_final_raw \
  --fork-dir /home/mirzaei/sam/result/Aggregate/Acorn-dprime \
  --out /data/hossein/mm_project/exp15_multi_transfer \
  --mode supervised \
  --seeds 42 43 \
  --source-steps 3000 --adapter-steps 1000 --decoder-steps 2500 \
  --batch-size 512 --resume
