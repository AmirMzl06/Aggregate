#!/usr/bin/env python3
"""Exp15: C-CO0 source -> C-CO target sessions with ACORN's original
Offset36_multi and learned per-session input/output Conv1D adapters.

Source: train only on source train_data. Transfer: freeze the shared backbone
and source adapters, fit *each target adapter* on its own train_data. Train a
per-target GRU decoder only on that target's train_data, test only valid_data.
This is CALIBRATED TRANSFER, NOT ZERO SHOT.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import traceback

import numpy as np
import torch

# This script is copied into the ACORN project; its existing multi-session
# model/trainer files are used unchanged.
from acorn.models.multi_session import MultiSessionModel
from acorn.models.registry import get_recipe
from acorn.train.encoder_trainer import EncoderTrainer
from acorn.train.config import set_seed
from acorn.eval.decoder_probe import encode_full_trajectory, train_session_decoder
from acorn.utils.device import activate_torch_device, resolve_device

from multi_dprime_bridge import DprimeBridge

ARMS = ('CEBRA','ACORN_EPS1','ACORN_EPS3','ACORN_EPS6',
        'SPDIFF_D8','SPDIFF_AUTOBEH','SPDIFF_AUTOSIG',
        'SP_AUTOBEH_POOL','SPDIFF_GAUSS')
DPRIME_ARMS = frozenset(a for a in ARMS if a.startswith('SP'))


def args_parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir', type=Path,
                   default=Path('/data/hossein/mm_project/perich_data_valid_final_raw'))
    p.add_argument('--fork-dir', type=Path, default=Path('../Acorn-dprime'))
    p.add_argument('--out', type=Path,
                   default=Path('/data/hossein/mm_project/exp15_multi_transfer'))
    p.add_argument('--source', default='C-CO0')
    p.add_argument('--targets', nargs='*', default=None,
                   help='Session names C-CO1 C-CO2 ...; default all available C-CO excluding source')
    p.add_argument('--max-targets', type=int, default=0,
                   help='For quick tests only; 0 means all targets')
    p.add_argument('--mode', choices=['supervised','time_only'], default='supervised')
    p.add_argument('--arms', nargs='+', choices=ARMS,
                   default=['CEBRA','ACORN_EPS1','ACORN_EPS3','ACORN_EPS6',
                            'SPDIFF_D8','SPDIFF_AUTOBEH','SPDIFF_GAUSS'])
    p.add_argument('--seeds', nargs='+', type=int, default=[42,43])
    p.add_argument('--source-steps', type=int, default=3000)
    p.add_argument('--adapter-steps', type=int, default=1000)
    p.add_argument('--decoder-steps', type=int, default=2500)
    p.add_argument('--batch-size', type=int, default=512)
    p.add_argument('--hidden', type=int, default=256)
    p.add_argument('--embedding-dim', type=int, default=64)
    p.add_argument('--decoder-window', type=int, default=256)
    p.add_argument('--attack-steps', type=int, default=10)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--device', choices=['auto','cuda','cpu'], default='auto')
    p.add_argument('--standardize', action='store_true',
                   help='Scale each session with train-only mean/std (off: original spike counts)')
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--resume', action='store_true')
    return p.parse_args()


def norm_key(name):
    name = name.strip().upper()
    if not name.startswith('C-CO') or not name[4:].isdigit():
        raise ValueError(f'Only C-CO sessions supported in this experiment: {name}')
    return name


def discover(args):
    if not args.data_dir.is_dir():
        raise FileNotFoundError(f'Dataset directory does not exist: {args.data_dir}')
    source = norm_key(args.source)
    if not (args.data_dir / f'{source}.npz').is_file():
        raise FileNotFoundError(f'Source missing: {source}.npz')
    if args.targets is None or not args.targets:
        targets = sorted((x.stem for x in args.data_dir.glob('C-CO*.npz')
                          if x.stem != source), key=lambda s: int(s.split('CO')[-1]))
    else:
        targets = list(dict.fromkeys(norm_key(s) for s in args.targets))
        targets = [s for s in targets if s != source]
    if args.max_targets > 0:
        targets = targets[:args.max_targets]
    if not targets:
        raise ValueError('No target sessions found')
    for session in targets:
        if not (args.data_dir/f'{session}.npz').is_file():
            raise FileNotFoundError(f'Missing target: {session}.npz')
    return source, targets


def load_session(path: Path, standardize: bool):
    with np.load(path, allow_pickle=False) as f:
        for k in ('train_data','valid_data','train_label','valid_label'):
            if k not in f:
                raise ValueError(f'{path}: missing {k}; wrong NPZ schema')
        x = np.asarray(f['train_data'], dtype=np.float32)
        xt = np.asarray(f['valid_data'], dtype=np.float32)
        y = np.asarray(f['train_label'], dtype=np.float32)
        yt = np.asarray(f['valid_label'], dtype=np.float32)
        if 'train_idx' in f and 'valid_idx' in f:
            ti = np.asarray(f['train_idx']).reshape(-1)
            vi = np.asarray(f['valid_idx']).reshape(-1)
            if len(ti) and len(vi) and ti.max() >= vi.min():
                raise ValueError(f'{path}: train/valid bin indices overlap or unordered')
    if y.ndim == 1: y = y[:,None]
    if yt.ndim == 1: yt = yt[:,None]
    if any(a.ndim != 2 or not np.isfinite(a).all() for a in (x,xt,y,yt)):
        raise ValueError(f'{path}: invalid data shape or nonfinite values')
    if not (len(x)==len(y) and len(xt)==len(yt)):
        raise ValueError(f'{path}: unequal neural/label samples')
    if not (x.shape[1] == xt.shape[1] and y.shape[1] == yt.shape[1]):
        raise ValueError(f'{path}: incompatible dims between train and valid')
    if min(len(x),len(xt)) < 64:
        raise ValueError(f'{path}: too few bins for Offset36')
    if standardize:
        mean=x.mean(axis=0,keepdims=True)
        std=x.std(axis=0,keepdims=True)+1e-3
        x=(x-mean)/std
        xt=(xt-mean)/std  # NEVER fit normalization on test!
    return {'train_x': torch.from_numpy(np.ascontiguousarray(x)),
            'test_x': torch.from_numpy(np.ascontiguousarray(xt)),
            'train_y': torch.from_numpy(np.ascontiguousarray(y)),
            'test_y': torch.from_numpy(np.ascontiguousarray(yt)),
            'n_neurons': int(x.shape[1]), 'n_labels': int(y.shape[1]),
            'use_smooth': False, 'dataset_group': 'perich', 'zscore': standardize}


def seed_for_target(seed: int, target: str) -> int:
    h = int.from_bytes(hashlib.sha256(target.encode()).digest()[:4], 'little')
    return (seed + h) % (2**31)


def train_kwargs(args, n_steps, arm):
    dprime=arm in DPRIME_ARMS
    eps={'ACORN_EPS1':1.,'ACORN_EPS3':3.,'ACORN_EPS6':6.}.get(arm, 1.)
    return dict(nBatch=n_steps, batchSize=args.batch_size,
        time_offset=(4 if args.mode == 'supervised' else 1),
        conditional=('time_delta' if args.mode == 'supervised' else 'time'),
        temperature=0.4, enc_lr=args.lr,
        adv=arm!='CEBRA', adv_norm='l2',
        adv_eps=float(eps), adv_eps_mode='fixed',
        adv_steps=args.attack_steps,
        adv_style='global' if dprime else 'cluster_pgd',
        adv_alpha=None,
        encoder_val_checkpoint=False,
    )


@contextlib.contextmanager
def dprime_patch(bridge, arm):
    if arm not in DPRIME_ARMS:
        yield
        return
    # Exactly the existing EncoderTrainer calls its module-local l2_adv_cebra.
    import acorn.train.encoder_trainer as m
    original=m.l2_adv_cebra
    m.l2_adv_cebra=bridge.make_train_attack()
    try:
        yield
    finally:
        m.l2_adv_cebra=original


class AdapterTrainer(EncoderTrainer):
    """Freeze shared backbone/source heads; permit only current target heads.

    The standard trainer calls model.unfreeze_encoder() at its start, so
    temporarily override that method to restore the required freeze mask.
    """
    def __init__(self, model, bundles, device, args, target_key):
        super().__init__(model, bundles, device, args)
        self.target_key=target_key

    def run(self):
        model=self.model
        original=model.unfreeze_encoder
        key=model.monkey_encoder._safe_key(self.target_key)
        def only_target():
            for p in model.encoder_parameters():
                p.requires_grad_(False)
            layers=model.monkey_encoder.cebra
            for mod in (layers.session_layer.session_dict[key],
                        layers.last_layer_multi.session_dict[key]):
                for p in mod.parameters():
                    p.requires_grad_(True)
        model.unfreeze_encoder=only_target
        try:
            result=super().run()
            # Verify source and common backbone truly stayed frozen.
            return result
        finally:
            model.unfreeze_encoder=original


def atomic_json(path:Path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    t=path.with_suffix(path.suffix+'.tmp')
    t.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False),encoding='utf-8')
    t.replace(path)


def serializable_context(ctx):
    return {k:v for k,v in ctx.items() if k != 'noise_model'}


def eval_session(model, key, bundle, device, decoder_steps, args, seed):
    recipe=get_recipe('offset36_gru')
    model.eval()
    decoder=train_session_decoder(
        model,key,bundle['train_x'],bundle['train_y'],bundle['n_labels'],
        device,decoder_steps,seed=seed,use_val_checkpoint=False,
        decoder_cls=recipe.decoder_cls,
        decoder_kwargs=recipe.decoder_kwargs,
        ceb_out=args.embedding_dim,window_size=args.decoder_window,
        decoder_adv='off',mlp_decoder=False)
    train_emb=encode_full_trajectory(model,key,bundle['train_x'],device)
    test_emb=encode_full_trajectory(model,key,bundle['test_x'],device)
    r2_train=float(decoder.score(train_emb,bundle['train_y'],device))
    r2_test=float(decoder.score(test_emb,bundle['test_y'],device))
    return dict(r2_train=r2_train,r2_holdout=r2_test,
                n_neurons=bundle['n_neurons'],
                n_train=len(bundle['train_x']),n_test=len(bundle['test_x']))


def append_record(out, record):
    out.mkdir(parents=True,exist_ok=True)
    with (out/'records.jsonl').open('a',encoding='utf8') as f:
        f.write(json.dumps(record,allow_nan=False,sort_keys=True)+'\n')
        f.flush()
        os.fsync(f.fileno())
    records={}
    for line in (out/'records.jsonl').read_text().splitlines():
        try: r=json.loads(line)
        except (ValueError,TypeError): continue
        records[(r['arm'],r['seed'],r['session'])]=r
    columns=['arm','seed','session','phase','status','r2_train','r2_holdout',
             'n_neurons','n_train','n_test','train_dprime_epsilon','error']
    temp=out/'summary.csv.tmp'
    with temp.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore')
        w.writeheader()
        w.writerows(records.values())
    temp.replace(out/'summary.csv')


def read_done(out):
    path=out/'records.jsonl'
    if not path.is_file():return set()
    done=set()
    for line in path.read_text().splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('status')=='success':
            done.add((r['arm'],r['seed'],r['session']))
    return done


def main():
    args=args_parser()
    source,targets=discover(args)
    if not args.source_steps>0 or not args.adapter_steps>0 or not args.decoder_steps>0:
        raise ValueError('All training-step counts must be positive')
    if args.mode=='time_only':
        illegal=[a for a in args.arms if 'AUTOBEH' in a]
        if illegal:raise ValueError(f'AUTO_BEH is supervised-only: {illegal}')
    if args.mode=='supervised' and 'SPDIFF_AUTOSIG' in args.arms:
        print('NOTE: AUTO_SIG is label-free even though its encoder mode is supervised.')
    if len(set(args.arms))!=len(args.arms):
        raise ValueError('Duplicate arms')
    print('ACORN multi-session (original learned Conv1D per session)',flush=True)
    print('SOURCE:',source,'TARGETS:',len(targets),targets,flush=True)
    print('ARMS:',args.arms,'SEEDS:',args.seeds,'MODE:',args.mode,flush=True)
    print('PROTOCOL: shared backbone trained on source; target-specific adapters +',
          'decoder fit on target TRAIN; target VALID is never used for fitting',flush=True)
    print('WARNING: not zero-shot. Dataset valid_data is assumed to be last 20%;',
          'source NPZ split construction must be independently checked.',flush=True)
    print('OUTPUT:',args.out,flush=True)
    if args.dry_run:return
    if args.out.resolve().is_relative_to(Path.home().resolve()):
        print('WARNING: output is under HOME; previous Exp14 hit quota. Prefer /data!',flush=True)
    if any(a in DPRIME_ARMS for a in args.arms):
        if not (args.fork_dir/'cebra/dprime/noise.py').is_file():
            raise FileNotFoundError(f'Bad frozen fork path: {args.fork_dir}')
    args.out.mkdir(parents=True,exist_ok=True)
    manifest={k:v for k,v in vars(args).items() if k not in ('resume','dry_run')}
    manifest={k:str(v) if isinstance(v,Path) else v for k,v in manifest.items()}
    manifest['selected_source']=source
    manifest['selected_targets']=targets
    mp=args.out/'manifest.json'
    if mp.is_file():
        prev=json.loads(mp.read_text())
        if manifest!=prev:
            raise RuntimeError('Manifest mismatch: use a new --out directory, do not mix protocols')
    else: atomic_json(mp,manifest)
    done=read_done(args.out) if args.resume else set()
    if (args.out/'records.jsonl').exists() and not args.resume:
        raise RuntimeError('Existing records: pass --resume, or use a new --out')

    device=resolve_device(args.device)
    activate_torch_device(device)
    bundles={name:load_session(args.data_dir/f'{name}.npz', args.standardize)
             for name in [source]+targets}
    print('Data shapes:',{s:(b['n_neurons'],len(b['train_x']),len(b['test_x']))
                          for s,b in bundles.items()},flush=True)

    for arm in args.arms:
        for seed in args.seeds:
            set_seed(seed)
            model=MultiSessionModel(ceb_hidden=args.hidden,ceb_out=args.embedding_dim)
            sb=bundles[source]
            model.add_session(source,sb['n_neurons'],sb['n_labels'],use_smooth=False)
            model.to(device)
            bridge=None
            needs_dprime=arm in DPRIME_ARMS
            if needs_dprime:
                bridge=DprimeBridge(args.fork_dir,device,seed)
            ckpt_dir=args.out/arm/f'seed{seed}'
            ckpt_dir.mkdir(parents=True,exist_ok=True)
            ckpt=ckpt_dir/'source_encoder.pt'
            source_note=None
            if ckpt.exists() and args.resume:
                payload=torch.load(ckpt,map_location='cpu',weights_only=True)
                if payload.get('session')!=source or payload.get('arm')!=arm:
                    raise RuntimeError(f'Checkpoint conflict {ckpt}')
                load_result=model.load_state_dict(payload['state_dict'])
                if load_result.missing_keys or load_result.unexpected_keys:
                    raise RuntimeError(f'Source checkpoint keys mismatch: {load_result}')
                print('RESUMED source:',arm,seed,flush=True)
            else:
                if needs_dprime:
                    source_note=bridge.fit(source,sb['train_x'].numpy(),sb['train_y'].numpy(),
                                           arm,args.mode,args.standardize)
                    atomic_json(ckpt_dir/'source_calibration.json',serializable_context(source_note))
                trainer=EncoderTrainer(model,{source:sb},device,
                    train_kwargs(args,args.source_steps,arm))
                with dprime_patch(bridge,arm):
                    trainer.run()
                torch.save(dict(session=source,arm=arm,seed=seed,
                     state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()}),
                           ckpt)
                print('TRAINED source:',arm,seed,flush=True)
            if (arm,seed,source) not in done:
                try:
                    metrics=eval_session(model,source,sb,device,args.decoder_steps,args,seed)
                    append_record(args.out, dict(arm=arm,seed=seed,session=source,
                        phase='source',status='success',
                        train_dprime_epsilon=(source_note or {}).get('budget_dprime'),**metrics))
                except Exception as e:
                    append_record(args.out,dict(arm=arm,seed=seed,session=source,
                        phase='source',status='error',error=repr(e)))
                    traceback.print_exc()
                    raise
            for target in targets:
                if (arm,seed,target) in done:
                    continue
                try:
                    # deterministic target initialization independent of prior targets
                    set_seed(seed_for_target(seed,target))
                    tb=bundles[target]
                    model.add_session(target,tb['n_neurons'],tb['n_labels'],use_smooth=False)
                    model.to(device)
                    # Target adaptations cannot modify backbone or source heads.
                    # New Covariance is learned only from each target's train split.
                    if needs_dprime:
                        target_note=bridge.fit(target,tb['train_x'].numpy(),
                            tb['train_y'].numpy(),arm,args.mode,args.standardize)
                        atomic_json(ckpt_dir/f'{target}_calibration.json',
                                    serializable_context(target_note))
                    else:target_note=None
                    shared_before={k:v.detach().cpu().clone() for k,v in
                        model.monkey_encoder.cebra.first_net.state_dict().items()}
                    with dprime_patch(bridge,arm):
                        AdapterTrainer(model,{target:tb},device,
                            train_kwargs(args,args.adapter_steps,arm),target).run()
                    for k,v in model.monkey_encoder.cebra.first_net.state_dict().items():
                        if not torch.equal(v.detach().cpu(),shared_before[k]):
                            raise RuntimeError('SHARED BACKBONE CHANGED in target adaptation!')
                    metrics=eval_session(model,target,tb,device,args.decoder_steps,
                                         args,seed_for_target(seed,target))
                    record=dict(arm=arm,seed=seed,session=target,phase='target_adapter',
                        status='success',
                        train_dprime_epsilon=(target_note or {}).get('budget_dprime'),**metrics)
                    append_record(args.out,record)
                    print('SUCCESS:',arm,seed,target,'R2=',round(metrics['r2_holdout'],4),
                          flush=True)
                except Exception as e:
                    append_record(args.out,dict(arm=arm,seed=seed,session=target,
                      phase='target_adapter',status='error',error=repr(e)))
                    traceback.print_exc()
                    raise
                finally:
                    # next target starts with same shared trained backbone,
                    # but previous target head is frozen automatically.
                    pass
    print('COMPLETE:',args.out/'summary.csv',flush=True)


if __name__ == '__main__':
    main()
