"""Small integration bridge: existing frozen Acorn-dprime noise/calibration +
Acorn Offset36_multi training. Never edits either original fork.

Dprime attack uses exactly the fork's NoiseModel + calibration routines, but
has a new training-loop bridge. It is NOT a byte-identical re-run of Exp14.
"""
from __future__ import annotations

import importlib.util
import math
from pathlib import Path

import numpy as np
import torch


def _load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f'Cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DprimeBridge:
    def __init__(self, fork_dir: Path, device: torch.device, seed: int = 42):
        d = fork_dir / 'cebra' / 'dprime'
        for name in ('noise.py', 'calibration.py'):
            if not (d / name).is_file():
                raise FileNotFoundError(f'Missing frozen fork component: {d/name}')
        self.noise = _load_module(d/'noise.py', 'exp15_frozen_noise')
        self.calibration = _load_module(d/'calibration.py', 'exp15_frozen_calibration')
        self.device = device
        self.seed = seed
        self.contexts: dict[str, dict] = {}

    def fit(self, key: str, x: np.ndarray, y: np.ndarray, arm: str,
            mode: str, standardized: bool = False) -> dict:
        if standardized:
            # With train-only standardized spikes, dprime measures distances
            # in standardized units, not in the original spike-count units.
            pass
        residual = 'difference' if 'SPDIFF' in arm else 'whole'
        model, details = self.noise.fit_noise_model(
            x, window_len=36, residual_mode=residual,
            spatial_estimator='ledoit_wolf', temporal_method='white',
            kronecker_channels=0, device=self.device,
            cov_pool=('isotropic',) if arm.endswith('_POOL') else None)
        C, T = model.num_channels, model.window_len
        cap = float(self.calibration.eps_energy_detector(C, T))
        note = {'session': key, 'arm': arm, 'noise_model': model,
                'noise_summary': model.summary(), 'budget_cap': cap,
                'budget_dprime': None, 'calibration': {}}
        if arm == 'SPDIFF_D8':
            epsilon = 8.0
        elif arm == 'SPDIFF_GAUSS':
            epsilon = math.sqrt(C * T)
        elif arm in ('SPDIFF_AUTOBEH','SP_AUTOBEH_POOL'):
            if mode != 'supervised':
                raise ValueError('AUTO_BEH requires supervised mode')
            prediction, fitinfo = self.calibration.behaviour_prediction(
                x, y, lags=(-8,-4,0,4,8), features=400,
                folds=5, seed=self.seed)
            eps_beh = [float(self.calibration.eps_behaviour(
                x, prediction, model.spatial_cov_of(i), model.temporal_cov))
                for i in range(model.pool_size)]
            if not all(np.isfinite(v) for v in eps_beh):
                raise ValueError(f'{key}: nonfinite eps_beh; cannot auto-calibrate')
            budgets = [max(1., min(cap, 0.363 * v)) for v in eps_beh]
            epsilon = budgets[0]
            note['pool_budgets_dprime'] = budgets
            note['calibration'] = {'eps_beh_by_covariance': eps_beh,
                  'behaviour_crossfit_r2': float(fitinfo['r2']),
                  'fraction': 0.363, 'formula': 'max(1,min(cap,0.363*eps_beh))'}
        elif arm == 'SPDIFF_AUTOSIG':
            eps_sig = float(self.calibration.eps_signal(
                x, model.spatial_cov, model.temporal_cov, lag=1))
            if not np.isfinite(eps_sig):
                raise ValueError(f'{key}: nonfinite eps_sig; cannot auto-calibrate')
            epsilon = min(cap, 0.24 * eps_sig)
            note['calibration'] = {'eps_sig': eps_sig, 'fraction': 0.24,
                                    'formula': 'min(cap,0.24*eps_sig)'}
        else:
            raise ValueError(f'Unknown dprime arm {arm}')
        if not np.isfinite(epsilon) or epsilon <= 0:
            raise ValueError(f'{key}: invalid calibrated epsilon {epsilon}')
        note['budget_dprime'] = float(epsilon)
        self.contexts[key] = note
        return note

    def make_train_attack(self):
        from acorn.utils.amp import amp_ctx

        def attack(model, optimizer, batch, session_name, criterion,
                   adv_eps, adv_steps, adv_style='global', adv_alpha=None,
                   clip_grad_fn=None):
            ctx = self.contexts[session_name]
            noise = ctx['noise_model']
            # Pool variants sample either the empirical covariance or the
            # isotropic control, using their own preregistered eps_beh budget.
            pool_index = (int(torch.randint(noise.pool_size, (1,)).item())
                          if ctx['arm'].endswith('_POOL') else 0)
            eps = ctx.get('pool_budgets_dprime', [ctx['budget_dprime']])[pool_index]
            reference = batch.reference.detach()
            b = reference.shape[0]
            shape = tuple(reference.shape)
            if shape[1:] != (noise.num_channels, noise.window_len):
                raise ValueError(f'{session_name}: window shape {shape} != noise model')
            # All dprime steps happen in whitened coordinates z, ||z||<=eps.
            z = torch.randn_like(reference)
            z = z / z.flatten(1).norm(dim=1).clamp_min(1e-12).view(-1,1,1)
            radii = torch.rand(b, 1, 1, device=z.device)
            z = (eps * radii * z).detach()
            if ctx['arm'] == 'SPDIFF_GAUSS':
                # Exp13 control: random direction, fixed natural noise-scale
                # radius sqrt(C*T), without any gradient-based attack steps.
                z = z / z.flatten(1).norm(dim=1).clamp_min(1e-12).view(-1,1,1) * eps
            else:
                alpha = float(adv_alpha) if adv_alpha is not None else eps / 5.0
                for _ in range(adv_steps):
                    z.requires_grad_(True)
                    x_adv = reference + noise.color(z, pool_index=pool_index)
                    with amp_ctx(reference.device):
                        r = model.encode_cebra_windows(x_adv, session_name)
                        p = model.encode_cebra_windows(batch.positive, session_name)
                        n = model.encode_cebra_windows(batch.negative, session_name)
                        loss, _, _ = criterion(r, p, n)
                    (grad,) = torch.autograd.grad(loss, z, retain_graph=False)
                    with torch.no_grad():
                        grad = grad / grad.flatten(1).norm(dim=1).clamp_min(1e-12).view(-1,1,1)
                        z = (z + alpha * grad).detach()
                        length = z.flatten(1).norm(dim=1).clamp_min(1e-12).view(-1,1,1)
                        z = z * (eps / length).clamp(max=1.0)
            x_adv = (reference + noise.color(z.detach(), pool_index=pool_index)).detach()
            optimizer.zero_grad(set_to_none=True)
            with amp_ctx(reference.device):
                r = model.encode_cebra_windows(x_adv, session_name)
                p = model.encode_cebra_windows(batch.positive, session_name)
                n = model.encode_cebra_windows(batch.negative, session_name)
                adv_loss, _, _ = criterion(r, p, n)
            if torch.isfinite(adv_loss):
                adv_loss.backward()
                if clip_grad_fn is not None:
                    clip_grad_fn()
                optimizer.step()
            return adv_loss.detach()
        return attack
