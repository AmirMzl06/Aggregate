# Exp15 — Multi-session C-CO0 transfer (روی پروژهٔ `acorn-main (3) (1).zip`)

این بسته یک **پیاده‌سازی جدیدِ پروتکل Transfer** روی کلاس‌های Multi-session **دقیقاً موجود در پروژهٔ استاد** است و فایل‌های مدل را جایگزین نمی‌کند.

## نوع آزمایش (دقیق بخوانید)

- مبدا: `C-CO0.npz`: آموزش مدل `Offset36_multi` فقط با `train_data` این Session.
- مقصدها: `C-CO1.npz`, `C-CO2.npz`, ...: ایجاد **Conv1D ورودی و خروجی مخصوص هر Session** با متد موجود `model.add_session`؛ آموزش **فقط همین دو Adapter مقصد** با `train_data` همان مقصد و **Backbone ثابت**.
- Decoder: برای هر Session یک GRU مستقل روی `train_data` همان Session و Embedding همان Session Fit می‌شود؛ تنها معیار گزارش‌شده `r2_holdout` روی `valid_data` همان Session است.
- برای Source نیز Decoder روی `train_data` مبدا Fit و روی `valid_data` مبدا Test می‌شود.
- **این Zero-shot نیست** چون Adapter و Decoder مقصد از Train مقصد استفاده می‌کنند. اسم درست: *Source-pretrained, session-adapter-calibrated transfer*.
- فایل‌های NPZ طبق پروتکل Exp11–14 شامل `train_data`, `train_label`, `valid_data`, `valid_label` اند. برای معنای «۲۰٪ انتهایی»، باید ثابت کرده باشید همین NPZها بر اساس ترتیب زمانی ساخته شده‌اند. کد نه این را حدس می‌زند نه `valid_data` را دوباره Shuffle می‌کند. اگر `train_idx` و `valid_idx` موجود باشند، ترتیب آن‌ها را چک می‌کند.
- برای `--standardize` از آمار **فقط Train** هر Session استفاده می‌شود؛ به صورت پیش‌فرض خام است، مانند fork قبلی؛ کد اصلی استاد به طور پیش‌فرض Train و Test را مستقل Z-score می‌کرد که از نظر نگاه‌به‌آینده در Test مسئله‌ساز بود.

## فایل‌هایی از پروژهٔ استاد که باید **بدون تغییر** موجود باشند

```
acorn/models/offset36_multi.py
acorn/models/encoder.py
acorn/models/multi_session.py
acorn/models/registry.py
acorn/train/encoder_trainer.py
acorn/train/adversarial.py
acorn/train/cebra_contrastive.py
acorn/eval/decoder_probe.py
acorn/models/decoder.py
cebra/                        # vendor CEBRA خود همین پروژه
```

دو فایل پایتون جدید این بسته را در ریشهٔ `acorn-main/` (همسطح `acorn/` و `cebra/`) قرار دهید:

```
acorn-main/
  acorn/                   # از zip استاد؛ دست‌نخورده
  cebra/                   # از zip استاد؛ دست‌نخورده
  run_multi_transfer.py    # NEW
  multi_dprime_bridge.py   # NEW
```

و در کنار آن باید فورک قبلی خودتان `Acorn-dprime/cebra/dprime/noise.py` و `calibration.py` موجود باشد. این بسته هیچ‌کدام را overwrite نمی‌کند.

## ARMها

| Arm | توضیح |
|---|---|
| `CEBRA` | CEBRA معمولی، بدون adversarial training، همان Offset36_multi |
| `ACORN_EPS1`, `ACORN_EPS3`, `ACORN_EPS6` | ACORN موجود پروژه با per-time-bin/cluster L2 PGD و ε برابر 1, 3, 6 |
| `SPDIFF_D8` | Noise-aware PGD در هندسهٔ difference-residual / Ledoit–Wolf / temporal white با d′=8 |
| `SPDIFF_AUTOBEH` | همان هندسه با ε=min cap, 0.363× ε_beh و کف 1؛ Supervised |
| `SPDIFF_AUTOSIG` | همان هندسه با ε=min cap, 0.24× ε_sig؛ Label-free calibration |
| `SP_AUTOBEH_POOL` | Whole-residual spatial noise model و covariance pool، AUTO_BEH؛ Supervised |
| `SPDIFF_GAUSS` | کنترل نویز رنگی تصادفی در مقیاس طبیعی sqrt(C×36)، بدون جهت گرادیانی |

**تفاوت‌ها با Exp14:** کد `Acorn-dprime` در Exp14، trainer و APGD خاص خود را داشت. اینجا از **همان فایل‌های `noise.py`/`calibration.py` فورک فریز شده** و PGD در مختصات Whitening استفاده می‌کنیم، اما Attack Loop و Encoder/GRU مربوط به Acorn Multi-session هستند؛ بنابراین این نتایج **معادل بازپخش عین Exp14 نیستند** و نباید آنها را یک مقایسهٔ بدون تغییر پروتکل خواند. کنترل ACORN با `cluster_pgd` استاد نیز از لحاظ هندسه و واحد ε با PGD_L2_EPS6 قبلی یکسان نیست.

## نصب و دستور اجرا

### روی Headnode (بدون GPU)

```bash
cd ~/sam/result/Aggregate
mkdir -p Acorn-multi
# فایل acorn-main (3) (1).zip را قبلاً روی Headnode آپلود کرده باشید
unzip -q 'acorn-main (3) (1).zip' -d Acorn-multi
# مسیر واقعی پروژه: ~/sam/result/Aggregate/Acorn-multi/acorn-main
cp /PATH/TO/run_multi_transfer.py /PATH/TO/multi_dprime_bridge.py \
   /PATH/TO/runai_launch_exp15.sh /PATH/TO/runai_submit_exp15.sh \
   Acorn-multi/acorn-main/
cd Acorn-multi/acorn-main
# بررسی نسخه Python و متعلقات پروژه (pyproject.toml می‌گوید >=3.11)
python -V
```

برای اجرای RunAI می‌توانید پس از کپی‌کردن فایل‌های `.sh`، از Headnode فرمان `bash runai_submit_exp15.sh` را اجرا کنید. توجه کنید `runai_launch_exp15.sh` مسیر venv پیش‌فرض Exp14 را استفاده می‌کند؛ قبل از اجرای اصلی، آن را به Python 3.11 سازگار با Acorn جدید تغییر دهید.

در محیطی اجرا شود که همهٔ Dependencyهای `acorn-main/pyproject.toml` نصب‌اند. به‌خصوص `torch`, `cebra` vendored, `gdown`, `scikit-learn`, `pydantic>=2`. نسخهٔ قدیمی venv پروژهٔ Exp14 پایتون 3.10 بود؛ اگر هنوز همان venv باشد، پشتیبانی رسمی این نسخه از Acorn (`python>=3.11`) برقرار نیست و باید محیط سازگار بسازید. نصب اشتباه داخل venv قدیمی، پروژهٔ Exp14 را به خطر می‌اندازد.

### پیش‌بررسی

```bash
python -B -u run_multi_transfer.py \
  --data-dir /data/hossein/mm_project/perich_data_valid_final_raw \
  --fork-dir ../../Acorn-dprime \
  --dry-run
```

**مسیر relative `../../Acorn-dprime` از محل `Acorn-multi/acorn-main` معتبر است** چون `Acorn-dprime` در Aggregate قرار دارد. اگر ساختار پوشهٔ شما فرق می‌کند، مسیر مطلق بدهید.

### تست کوتاه GPU (فقط یک Session و فقط CEBRA)

```bash
python -B -u run_multi_transfer.py \
  --fork-dir ../../Acorn-dprime \
  --targets C-CO1 --arms CEBRA --seeds 42 \
  --source-steps 10 --adapter-steps 10 --decoder-steps 10 \
  --out /data/hossein/mm_project/exp15_smoke
```

### اجرای اصلی

```bash
python -B -u run_multi_transfer.py \
  --data-dir /data/hossein/mm_project/perich_data_valid_final_raw \
  --fork-dir ../../Acorn-dprime \
  --out /data/hossein/mm_project/exp15_multi_transfer \
  --mode supervised \
  --source-steps 3000 --adapter-steps 1000 \
  --decoder-steps 2500 --batch-size 512 \
  --seeds 42 43 --resume
```

برای حالت Time-only، `--mode time_only` و `--arms CEBRA ACORN_EPS1 ACORN_EPS3 ACORN_EPS6 SPDIFF_D8 SPDIFF_AUTOSIG SPDIFF_GAUSS` بدهید و **یک پوشهٔ خروجی دیگر** انتخاب کنید.

## فایل خروجی

`--out/summary.csv`: سطرهای `(arm,seed,session)` با `r2_train`, `r2_holdout`, `n_neurons`, `n_train`, `n_test`, `train_dprime_epsilon`, `status` و `error`.

`--out/records.jsonl`: همهٔ نتایج و شکست‌ها؛ `--resume` موفق‌ها را دوباره اجرا نمی‌کند. `--out/manifest.json`: قفل پروتکل و hyperparameterها. `--out/ARM/seed42/source_encoder.pt`: checkpoint آموزش مبدا برای Resume. `source_calibration.json` و `C-CO*_calibration.json`: ثبت بودجه‌های d′ قبل از Training هر Session.

## هشدارهای پژوهشی

1. نتیجهٔ اصلی **انتقال با کالیبراسیون** است، نه Zero-shot.
2. تست روی `valid_data` انجام می‌شود، پس پیش‌ساخت chronological split باید اثبات شود؛ NPZ موجود خودش این ضمانت را از نام فایل نمی‌دهد.
3. فقط Clean held-out R² در `summary.csv` است؛ یک sweep حملهٔ adversarial روی *Decoder نهایی مقصد* هنوز در این رانر وجود ندارد. Robustness با آن جایگزین نشود.
4. انتخاب نام Session مقصد و انتخاب اعداد قدم‌ها باید قبل از مشاهدهٔ R² قفل شود؛ مهم‌تر آنکه تعداد جلسات و جست‌وجوی ابرپارامترها در گزارش ذکر شود.
5. اجرای اصلی تک-GPU است (همان Trainer اصلی Acorn) و نیاز به ۴ GPU ندارد. می‌توان آزمایش‌ها را در Jobهای مجزا موازی کرد، ولی نباید ۴ GPU یک Job رزرو کرد و تنها ۱ را مصرف کرد.
6. مسیر `/data/hossein/mm_project/` باید برای شما **قابل نوشتن** باشد. با توجه به Quota قبلی روی Home، خروجی را روی PVC Scratch نگه دارید.
7. فایل Python این بسته syntax-check شده است اما در این محیط به دلیل نبود Dependencies کامل (`gdown` و ...) و نبود Dataset واقعی `/data/...`، **اجرای واقعی Training تست نشده است**؛ ابتدا smoke test انجام شود.
