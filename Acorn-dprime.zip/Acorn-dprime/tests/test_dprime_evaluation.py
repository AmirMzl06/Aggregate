"""Tests of cebra.dprime.evaluation and of the common-metric report of the d′ training."""

import json

import numpy as np
import pytest
import sklearn.metrics
import torch

import cebra
from cebra.dprime import evaluation

_RNG = np.random.default_rng(0)
_RECORDING = _RNG.poisson(2.0, size=(400, 6)).astype("float32")
_EVAL = _RNG.poisson(2.0, size=(120, 6)).astype("float32")
_BEHAVIOUR = np.stack([_EVAL[:, :3].sum(1), _EVAL[:, 3:].sum(1)], axis=1)


def _fit(**kwargs):
    torch.manual_seed(0)
    config = dict(model_architecture="offset10-model", batch_size=32, max_iterations=6,
                  output_dimension=3, num_hidden_units=8, device="cpu", verbose=False)
    config.update(kwargs)
    model = cebra.CEBRA(**config)
    model.fit(_RECORDING)
    return model


def _dprime_fit(**kwargs):
    config = dict(training_mode="adversarial", adv_steps=2, adv_epsilon_mode="dprime",
                  adv_dprime_epsilon=1.0, adv_dprime_guard_mode="off",
                  adv_dprime_instance_adaptive=False, adv_dprime_nn_bank=50,
                  adv_dprime_margin_steps=3, adv_dprime_warmup=0.0, adv_dprime_curriculum=0.0)
    config.update(kwargs)
    return _fit(**config)


@pytest.fixture(scope="module")
def clean_pipeline():
    encoder = _fit()
    torch.manual_seed(1)
    decoder = torch.nn.Linear(3, 2)
    with torch.no_grad():
        z = torch.as_tensor(encoder.transform(_EVAL))
        solution = torch.linalg.lstsq(torch.cat([z, torch.ones(len(z), 1)], 1),
                                      torch.as_tensor(_BEHAVIOUR)).solution
        decoder.weight.copy_(solution[:3].T)
        decoder.bias.copy_(solution[3])
    return encoder, decoder


def test_windows_match_transform(clean_pipeline):
    encoder, _ = clean_pipeline
    model, left, right = evaluation._encoder_model(encoder)
    windows = evaluation._Windows(_EVAL, left, right, "cpu")
    with torch.no_grad():
        embedding = evaluation._embed(model.eval(), windows(torch.arange(len(_EVAL))))
    np.testing.assert_allclose(embedding.numpy(), encoder.transform(_EVAL), atol=1e-5)


def test_evaluate_decoding(clean_pipeline):
    encoder, decoder = clean_pipeline
    decoder.train()
    report = evaluation.evaluate_decoding(encoder, decoder, _RECORDING, _EVAL, _BEHAVIOUR,
                                          epsilons=(0.0, 1.0, 4.0, 16.0), steps=3,
                                          batch_size=50, margin_windows=40, margin_steps=20)
    json.dumps(report)
    assert decoder.training  # mode restored
    with torch.no_grad():
        prediction = decoder(torch.as_tensor(encoder.transform(_EVAL))).numpy()
    expected = sklearn.metrics.r2_score(_BEHAVIOUR, prediction, multioutput="raw_values").mean()
    assert report["clean_r2"] == pytest.approx(expected, abs=1e-5)
    assert report["sqrt_D"] == pytest.approx(np.sqrt(6 * 10))
    for name in evaluation.METRICS:
        curve = report[name]["robust_r2"]
        assert [point["epsilon"] for point in curve] == [0.0, 1.0, 4.0, 16.0]
        assert curve[0]["r2"] == pytest.approx(report["clean_r2"], abs=1e-5)
        assert curve[-1]["r2"] < curve[1]["r2"] < report["clean_r2"]
        # The worst case over budgets ≤ ε is monotone and at least as strong as each run.
        r2 = [point["r2"] for point in curve]
        assert all(later <= earlier + 1e-9 for earlier, later in zip(r2, r2[1:]))
        assert all(point["r2"] <= point["r2_single"] + 1e-9 for point in curve)
        assert curve[1]["dprime_mean"] <= 1.0 + 1e-4
        margin = report[name]["decoding_margin"]
        assert margin["n"] == 40 and margin["frac_already_adversarial"] == 0
        assert report[name]["contrastive_margin"]["decision"] == "chance"
    # Raw L2 radius = σ̄ · ε in the isotropic metric.
    point = report["isotropic"]["robust_r2"][2]
    assert point["raw_l2_median"] == pytest.approx(report["isotropic_sigma"] * 4.0, rel=1e-3)


def test_isotropic_metric_is_scaled_l2():
    models = evaluation.common_metrics(_RECORDING, 10)
    delta = torch.randn(4, 6, 10)
    sigma = np.sqrt((_RECORDING - _RECORDING.mean(0)).var(axis=0).mean())
    np.testing.assert_allclose(models["isotropic"].dprime(delta).numpy(),
                               delta.flatten(1).norm(dim=1).numpy() / sigma, rtol=1e-4)


def test_crossing():
    curve = [{"epsilon": 1.0, "r2": 0.8}, {"epsilon": 4.0, "r2": 0.2}]
    assert evaluation._crossing(curve, 0.5) == pytest.approx(2.0)
    assert evaluation._crossing(curve, 0.9) == 1.0
    assert evaluation._crossing(curve, 0.1) is None


@pytest.mark.parametrize("spatial,temporal,common", [("ledoit_wolf", "welch", "dprime_reference"),
                                                     ("isotropic", "white", "dprime_isotropic")])
def test_training_reports_common_units(spatial, temporal, common):
    model = _dprime_fit(adv_dprime_spatial=spatial, adv_dprime_temporal=temporal)
    report = model.dprime_report_
    json.dumps(report)
    realized = report["training"]["realized"]
    # The run's own metric is one of the common ones here, so both readings agree.
    assert realized[common]["median"] == pytest.approx(realized["dprime_training"]["median"],
                                                       rel=1e-3)
    assert realized["rms_per_entry"]["median"] == pytest.approx(
        realized["raw_l2"]["median"] / np.sqrt(60), rel=1e-6)
    for key in ("robustness_margin", "robustness_margin_reference",
                "robustness_margin_isotropic"):
        assert report[key]["n"] > 0


def test_common_metrics_do_not_depend_on_the_run():
    # A run with other residuals / geometry reports its sizes in the same fixed metrics.
    plain = _dprime_fit().dprime_report_["common_metrics"]
    other = _dprime_fit(adv_dprime_residuals="difference", adv_dprime_temporal="white")
    assert other.dprime_report_["noise_model"]["residual_mode"] == "difference"
    common = other.dprime_report_["common_metrics"]
    assert common["isotropic_sigma"] == pytest.approx(plain["isotropic_sigma"])
    sigma = np.sqrt((_RECORDING - _RECORDING.mean(0)).var(axis=0).mean())
    assert common["isotropic_sigma"] == pytest.approx(sigma, rel=1e-6)


def test_margin_search_starts_at_the_jnd():
    # With ε* ≈ 0 the DDN search used to start (and stay) at ε* and never cross the boundary.
    model = _dprime_fit(adv_dprime_epsilon=1e-6, adv_dprime_margin_steps=60)
    margin = model.dprime_report_["robustness_margin_reference"]
    assert margin["frac_never_broken"] < 1.0
