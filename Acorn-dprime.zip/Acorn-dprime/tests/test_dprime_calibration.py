"""Tests of cebra.dprime.calibration (ε_JND, ε_NN, ε_det, robustness margin)."""

import math

import numpy as np
import pytest
import torch
from sklearn.metrics import roc_auc_score

from cebra.dprime import calibration as cal


class IdentityNoise:
    device = None

    def whiten(self, delta):
        return delta


def test_make_classes():
    assert cal.make_classes(None) is None
    discrete = np.array([3, 1, 3, 2])
    assert np.array_equal(cal.make_classes(discrete), discrete)
    rng = np.random.default_rng(0)
    continuous = rng.normal(size=(500, 2))
    classes = cal.make_classes(continuous, n_classes=5)
    assert classes.shape == (500,) and len(np.unique(classes)) == 5


def test_valid_indices():
    idx = cal.valid_indices(100, 18, 18)
    assert idx[0] == 18 and idx[-1] == 82


def test_nearest_neighbour_matches_brute_force():
    rng = np.random.default_rng(0)
    neural = rng.normal(size=(300, 3)).astype(np.float32)
    classes = rng.integers(0, 2, size=300)
    left, right, exclusion = 2, 3, 5
    query, dist = cal.nearest_neighbour_dprime(neural, IdentityNoise(), left, right, classes,
                                              bank_size=None, exclusion=exclusion,
                                              batch_size=37)
    windows = np.stack([neural[t - left:t + right].T.reshape(-1) for t in query])
    for i in range(0, len(query), 17):
        candidates = [j for j in range(len(query))
                      if abs(query[i] - query[j]) >= exclusion and classes[query[j]] == classes[query[i]]]
        expected = min(np.linalg.norm(windows[i] - windows[j]) for j in candidates)
        assert dist[i] == pytest.approx(expected, rel=1e-5)


def test_eps_nn_and_per_index():
    distances = np.array([1.0, 2.0, 3.0, 4.0, np.inf])
    assert cal.eps_nn(distances, 0.5) == pytest.approx(2.5)
    table = cal.per_index_eps_nn(10, np.array([2, 5, 5]), np.array([1.0, 3.0, 2.0]))
    assert table[2] == 1.0 and table[5] == 2.0 and np.isinf(table[0])


def test_auc_matches_sklearn_with_ties():
    rng = np.random.default_rng(0)
    neg = rng.integers(0, 5, size=200).astype(float)
    pos = rng.integers(1, 6, size=150).astype(float)
    expected = roc_auc_score(np.r_[np.zeros(200), np.ones(150)], np.r_[neg, pos])
    assert cal.auc(neg, pos) == pytest.approx(expected)


def test_detection_curve_and_eps_det():
    torch.manual_seed(0)
    x_train, x_test = torch.randn(300, 4, 36), torch.randn(300, 4, 36)
    pattern = torch.sin(torch.linspace(0, 6, 36)).expand(4, 36)

    def attack_fn(x, eps, kind):
        return x + eps * pattern

    curve = cal.detection_curve(x_train, x_test, attack_fn, [0.0, 0.05, 3.0], detector_steps=150)
    assert curve[0.0]["auc"] == pytest.approx(0.5, abs=0.1)
    assert curve[3.0]["auc"] > 0.9
    eps_det, status = cal.eps_det_from_curve({0.1: 0.5, 0.2: 0.54, 0.4: 0.7})
    assert (eps_det, status) == (0.2, "ok")
    assert cal.eps_det_from_curve({0.1: 0.9})[1] == "below_grid"
    assert cal.eps_det_from_curve({0.1: 0.5, 1.0: 0.5}) == (1.0, "censored_above")


def test_epsilon_star_and_margin():
    assert cal.epsilon_star(eps_nn=3.0, eps_det=0.4) == (0.4, "det")
    assert cal.epsilon_star(eps_nn=math.inf, eps_det=None) == (1.0, "jnd")
    report = cal.robustness_margin(np.array([0.0, 1.0, 2.0, 3.0, np.inf]), eps_star=1.0)
    assert report["median"] == 2.0 and report["ratio"] == 2.0
    assert report["frac_already_adversarial"] == pytest.approx(0.2)
    assert report["frac_never_broken"] == pytest.approx(0.2)
    assert cal.ideal_observer_accuracy(1.0) == pytest.approx(0.6915, abs=1e-3)
