"""Tests of cebra.dprime.noise (Layer 1: the stationary noise metric)."""

import numpy as np
import pytest
import torch

from cebra.dprime import noise

C, T = 6, 36


def _ar1_recording(n=20000, phi=0.6, seed=0, num_channels=C):
    rng = np.random.default_rng(seed)
    a = rng.normal(size=(num_channels, num_channels))
    spatial = a @ a.T + num_channels * np.eye(num_channels)
    eps = rng.normal(size=(n, num_channels))
    x = np.zeros((n, num_channels))
    for t in range(1, n):
        x[t] = phi * x[t - 1] + eps[t]
    x = x @ np.linalg.cholesky(spatial).T * np.sqrt(1 - phi**2)
    temporal = phi**np.abs(np.arange(T)[:, None] - np.arange(T)[None, :])
    return x, spatial, temporal


@pytest.fixture(scope="module")
def ar1():
    return _ar1_recording()


def test_residual_modes():
    rng = np.random.default_rng(1)
    x = rng.normal(size=(500, 4)) + 3.0
    classes = rng.integers(0, 3, size=500)
    res = noise.compute_residuals(x, classes, mode="class_mean")
    for c in range(3):
        np.testing.assert_allclose(res[classes == c].mean(axis=0), 0, atol=1e-10)
    y = rng.normal(size=(500, 2))
    xr = x + y @ rng.normal(size=(2, 4))
    res = noise.compute_residuals(xr, y, mode="regression")
    yc = y - y.mean(0)
    # Orthogonal to the labels up to the tiny ridge.
    assert np.abs(yc.T @ res).max() < 1e-5 * np.abs(yc.T @ (xr - xr.mean(0))).max()
    np.testing.assert_allclose(noise.compute_residuals(x).mean(0), 0, atol=1e-10)
    assert np.allclose(noise.compute_residuals(x, classes), noise.compute_residuals(x, classes, "class_mean"))
    with pytest.raises(ValueError):
        noise.compute_residuals(x, None, mode="regression")


def test_difference_residuals_remove_slow_signal():
    # x = slow shared signal (rank 1) + white private noise: the first-difference residuals
    # estimate the noise covariance, the whole residuals the noise plus the signal.
    rng = np.random.default_rng(7)
    n, c = 40000, 5
    slow = np.zeros(n)
    for t in range(1, n):
        slow[t] = 0.999 * slow[t - 1] + rng.normal() * np.sqrt(1 - 0.999**2)
    loading = np.array([2.0, 1.5, 1.0, -1.0, 0.5])
    noise_sd = np.array([1.0, 0.8, 1.2, 0.9, 1.1])
    x = 3.0 * slow[:, None] * loading[None, :] + rng.normal(size=(n, c)) * noise_sd
    diff = noise.compute_residuals(x, mode="difference")
    assert diff.shape == (n - 1, c)
    np.testing.assert_allclose(diff.mean(0), 0, atol=1e-12)
    cov = diff.T @ diff / len(diff)
    expected = np.diag(noise_sd**2)
    assert np.linalg.norm(cov - expected) / np.linalg.norm(expected) < 0.06
    whole = noise.compute_residuals(x, mode="whole")
    assert np.linalg.norm(whole.T @ whole / n - expected) / np.linalg.norm(expected) > 1.0
    with pytest.warns(UserWarning):
        noise.fit_noise_model(x[:4000], window_len=T, residual_mode="difference",
                              temporal_method="welch", kronecker_channels=0)


@pytest.mark.parametrize("estimator", [e for e in noise.SPATIAL_ESTIMATORS if e != "isotropic"])
def test_spatial_covariance_recovers_truth(ar1, estimator):
    x, spatial, _ = ar1
    est = noise.spatial_covariance(x, estimator)
    assert np.all(np.linalg.eigvalsh(est) > 0)
    assert np.linalg.norm(est - spatial) / np.linalg.norm(spatial) < 0.1


def test_isotropic_spatial_covariance(ar1):
    # The control without a noise-aware geometry: mean variance × identity.
    x, _, _ = ar1
    est = noise.spatial_covariance(x, "isotropic")
    np.testing.assert_allclose(est, np.eye(x.shape[1]) * x.var(axis=0).mean(), rtol=1e-6)


def test_tyler_trace_and_heavy_tails():
    rng = np.random.default_rng(2)
    x = rng.standard_t(df=2, size=(4000, 5)) * np.array([1, 2, 3, 4, 5])
    cov = noise.tyler_covariance(x)
    empirical = x.T @ x / len(x)
    assert np.isclose(np.trace(cov), np.trace(empirical), rtol=1e-6)
    assert np.all(np.linalg.eigvalsh(cov) > 0)


@pytest.mark.parametrize("method", ["welch", "ar"])
def test_temporal_covariance_recovers_ar1(ar1, method):
    x, _, temporal = ar1
    est = noise.temporal_covariance(x, T, method)
    np.testing.assert_allclose(np.diag(est).mean(), 1.0, rtol=1e-12)
    assert np.linalg.norm(est - temporal) / np.linalg.norm(temporal) < 0.1
    spectrum = noise.covariance_spectrum(est)
    assert spectrum[0] > spectrum[len(spectrum) // 2] > spectrum[-1]
    np.testing.assert_allclose(noise.full_spectrum(spectrum, T).mean(), 1.0, rtol=1e-10)


def test_vanrossum_metric():
    tau = 3.0
    cov = noise.temporal_covariance(None, T, "vanrossum", tau=tau)
    lags = np.arange(T)[:, None] - np.arange(T)[None, :]
    kernel = np.where(lags >= 0, np.exp(-np.maximum(lags, 0) / tau), 0.0)
    delta = np.random.default_rng(3).normal(size=T)
    metric = delta @ np.linalg.inv(cov) @ delta
    scale = np.trace(np.linalg.inv(kernel.T @ kernel)) / T
    np.testing.assert_allclose(metric, scale * np.sum((kernel @ delta)**2), rtol=1e-6)
    spectrum = noise.covariance_spectrum(cov)
    assert spectrum[-1] > spectrum[0]  # slow perturbations are the expensive ones


def test_fit_vanrossum_tau_matches_ar1(ar1):
    x, _, _ = ar1
    tau = noise.fit_vanrossum_tau(x)
    np.testing.assert_allclose(tau, -1 / np.log(0.6), rtol=0.1)  # e-folding time of 0.6^k


def test_color_whiten_inverse_and_dprime(ar1):
    x, spatial, temporal = ar1
    model = noise.NoiseModel(spatial, temporal)
    z = torch.randn(5, C, T)
    np.testing.assert_allclose(model.whiten(model.color(z)).numpy(), z.numpy(), atol=1e-4)
    z2 = torch.randn(5, C, T)
    np.testing.assert_allclose(model.color(2 * z - z2).numpy(),
                               (2 * model.color(z) - model.color(z2)).numpy(), atol=1e-4)
    # d' is the Mahalanobis norm in the Kronecker metric.
    delta = model.color(z).double()
    precision = np.linalg.inv(np.kron(spatial, temporal))
    flat = delta.reshape(5, -1).numpy()
    expected = np.sqrt(np.einsum("bi,ij,bj->b", flat, precision, flat))
    np.testing.assert_allclose(model.dprime(delta.float()).numpy(), expected, rtol=1e-3)
    samples = model.sample(2048, generator=torch.Generator().manual_seed(0))
    np.testing.assert_allclose(model.dprime(samples).mean().item(), np.sqrt(C * T), rtol=0.02)


def test_odd_window_and_circulant_from_spectrum():
    spectrum = np.linspace(2.0, 0.5, 35 // 2 + 1)
    model = noise.NoiseModel.from_spectrum(np.eye(3), spectrum, 35)
    z = torch.randn(2, 3, 35)
    np.testing.assert_allclose(model.whiten(model.color(z)).numpy(), z.numpy(), atol=1e-4)
    # A circulant covariance is diagonalised by the DFT: its spectrum is the given one.
    expected = spectrum / noise.full_spectrum(spectrum, 35).mean()
    np.testing.assert_allclose(model.spectrum_half, expected, rtol=1e-6)


def test_kronecker_check(ar1):
    x, spatial, temporal = ar1
    report = noise.kronecker_check(x, T, n_channels=4, spatial_cov=spatial, temporal_cov=temporal)
    assert report["nearest_kronecker_rel_error"] < 0.3
    assert report["model_rel_error"] < report["nearest_kronecker_rel_error"] + 0.1
    # Channel-specific temporal structure is not Kronecker.
    rng = np.random.default_rng(4)
    y = np.zeros((20000, 4))
    eps = rng.normal(size=y.shape)
    phis = np.array([0.9, -0.9, 0.0, 0.5])
    for t in range(1, len(y)):
        y[t] = phis * y[t - 1] + eps[t]
    other = noise.kronecker_check(y + 0.3 * y[:, :1], T, n_channels=4)
    assert other["nearest_kronecker_rel_error"] > report["nearest_kronecker_rel_error"] + 0.1


def test_kronecker_check_sampling_floor(ar1):
    # The true model of a Kronecker process is only off by the sampling noise of the empirical
    # full covariance; a short recording has a higher floor.
    x, spatial, temporal = ar1
    report = noise.kronecker_check(x, T, n_channels=4, spatial_cov=spatial, temporal_cov=temporal)
    assert report["sampling_floor_rel_error"] > 0
    assert report["model_rel_error"] < 2.0 * report["sampling_floor_rel_error"]
    assert report["model_excess_rel_error"] < report["model_rel_error"]
    short = noise.kronecker_check(x[:len(x) // 8], T, n_channels=4)
    assert short["sampling_floor_rel_error"] > report["sampling_floor_rel_error"]


def test_fit_noise_model_and_pool(ar1):
    x, spatial, _ = ar1
    y = np.random.default_rng(5).normal(size=(len(x), 2))
    own, _ = noise.fit_noise_model(x, y, window_len=T)
    model, info = noise.fit_noise_model(x, y, window_len=T, cov_pool=[2 * own.spatial_cov])
    assert info["residual_mode"] == "regression" and info["label_kind"] == "continuous"
    assert model.pool_size == 2
    z = torch.randn(3, C, T)
    np.testing.assert_allclose(model.color(z, pool_index=1).numpy(),
                               np.sqrt(2) * model.color(z, pool_index=0).numpy(), rtol=2e-3,
                               atol=1e-3)
    coloring = model.stationary_coloring(1)
    radius = torch.tensor([0.0, 1.0, 2.5])
    rz = coloring.random_z(z, radius)
    np.testing.assert_allclose(coloring.dprime(rz).numpy(), radius.numpy(), atol=1e-5)
    with pytest.raises(IndexError):
        model.stationary_coloring(2)


def test_leadfield_coloring(ar1):
    x, spatial, temporal = ar1
    leadfield = np.random.default_rng(6).normal(size=(C, 3))
    model = noise.NoiseModel(spatial, temporal, leadfield=leadfield, leadfield_noise=0.5)
    x0 = torch.zeros(4, C, T)
    coloring = model.leadfield_coloring(x0, generator=torch.Generator().manual_seed(1))
    z = coloring.init_z(x0)
    assert z.shape == (4, 3, T)
    s = torch.randn(4, 3, T)
    delta = coloring.color(s) - coloring.color(torch.zeros_like(s))
    expected = torch.einsum("cs,bst->bct", torch.tensor(leadfield).float(), model.temporal(s))
    np.testing.assert_allclose(delta.numpy(), expected.numpy(), atol=1e-4)
    assert coloring.color(z).abs().sum() > 0  # the sensor noise
