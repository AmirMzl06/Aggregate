"""Tests of cebra.dprime.guards (Layer 3: physiological guards)."""

import math
import time

import numpy as np
import pytest
import torch

from cebra.dprime import guards as G


def _spd(n, seed):
    g = torch.Generator().manual_seed(seed)
    a = torch.randn(n, n, generator=g, dtype=torch.float64)
    return a @ a.T + n * torch.eye(n, dtype=torch.float64)


def test_periodogram_white_noise_density():
    torch.manual_seed(0)
    x = torch.randn(4000, 1, 64) * 2.0
    power, freqs = G.periodogram(x, fs=1.0)
    # Two-sided density of white noise with variance 4: E[power] = 4 away from DC (the mean
    # removal and the Hann leakage lower the first bins).
    assert torch.allclose(power.mean(dim=(0, 1))[3:-1], torch.full((29,), 4.0), rtol=0.1)
    assert freqs[-1] == pytest.approx(0.5)


def test_aperiodic_exponent_recovered():
    rng = np.random.default_rng(0)
    n, t, chi = 2000, 256, 1.5
    freqs = np.fft.rfftfreq(t)
    amplitude = np.zeros_like(freqs)
    amplitude[1:] = freqs[1:]**(-chi / 2)
    spectrum = amplitude * (rng.normal(size=(n, len(freqs))) + 1j * rng.normal(size=(n, len(freqs))))
    x = torch.from_numpy(np.fft.irfft(spectrum, n=t)).float().unsqueeze(1)
    _, exponent = G.aperiodic_params(x, f_range=(0.02, 0.4))
    assert float(exponent.mean()) == pytest.approx(chi, abs=0.3)


def test_riemann_distance_properties():
    a = torch.stack([_spd(5, s) for s in range(4)])
    b = torch.stack([_spd(5, s + 10) for s in range(4)])
    w = torch.randn(4, 5, 5, dtype=torch.float64) + 3 * torch.eye(5, dtype=torch.float64)
    assert torch.allclose(G.riemann_distance(a, a), torch.zeros(4, dtype=torch.float64), atol=1e-6)
    assert torch.allclose(G.riemann_distance(a, b), G.riemann_distance(b, a), rtol=1e-6)
    # Affine invariance: d(W A W^T, W B W^T) = d(A, B).
    wa, wb = w @ a @ w.transpose(1, 2), w @ b @ w.transpose(1, 2)
    assert torch.allclose(G.riemann_distance(wa, wb), G.riemann_distance(a, b), rtol=1e-5)
    # Diagonal matrices: sqrt(sum log^2(b_i / a_i)).
    da = torch.diag_embed(torch.tensor([[1.0, 2.0, 4.0]], dtype=torch.float64))
    db = torch.diag_embed(torch.tensor([[2.0, 2.0, 1.0]], dtype=torch.float64))
    expected = math.sqrt(math.log(2.0)**2 + math.log(0.25)**2)
    assert float(G.riemann_distance(da, db)) == pytest.approx(expected, rel=1e-6)


def test_riemann_distance_gradient_finite_at_zero():
    a = torch.stack([_spd(4, 0)])
    b = a.clone().requires_grad_(True)
    G.riemann_distance(a, b).sum().backward()
    assert torch.isfinite(b.grad).all()


def test_erp_features_planted_peak():
    x = torch.zeros(2, 3, 20)
    x[0, 1, 7] = -5.0
    x[1, 2, 12] = 3.0
    amplitude, latency = G.erp_features(x, (5, 15))
    assert float(amplitude[0, 1]) == -5.0 and float(latency[0, 1]) == 7.0
    assert float(amplitude[1, 2]) == 3.0 and float(latency[1, 2]) == 12.0


@pytest.fixture(scope="module")
def fitted():
    torch.manual_seed(0)
    windows = torch.randn(600, 8, 36)
    classes = torch.arange(600) % 3
    times = torch.arange(600) * 40
    guard = G.GuardSet(guards=("band_power", "aperiodic", "riemann", "erp", "artifact"),
                       erp_window=(10, 20), artifact_rate=0.05)
    return guard.fit(windows, classes, times, exclusion=36), windows


def test_identity_passes_and_large_fails_every_guard(fitted):
    guard, windows = fitted
    x0 = windows[:32]
    ok, details = guard.check(x0, x0)
    assert bool(ok.all())
    assert set(details) == {"band_power", "aperiodic", "riemann", "erp", "artifact"}
    big = x0 + 50.0 * torch.randn_like(x0)
    ok, details = guard.check(x0, big)
    assert not bool(ok.any())
    for name, passed in details.items():
        assert not bool(passed.any()), name


def test_artifact_rate_matches_target(fitted):
    guard, windows = fitted
    thresholds = guard.tolerances["artifact"]
    rate = float((G.peak_to_peak(windows) > thresholds).any(dim=1).float().mean())
    assert rate == pytest.approx(0.05, abs=0.02)


def test_soft_penalty_zero_inside_positive_outside(fitted):
    guard, windows = fitted
    x0 = windows[:8]
    assert torch.all(guard.soft_penalty(x0, x0) == 0)
    x_adv = (x0 + 3.0 * torch.randn_like(x0)).requires_grad_(True)
    penalty = guard.soft_penalty(x0, x_adv)
    assert bool((penalty > 0).all())
    penalty.sum().backward()
    assert torch.isfinite(x_adv.grad).all() and x_adv.grad.abs().sum() > 0


def test_report_is_json_serialisable(fitted):
    import json
    json.dumps(fitted[0].report())


def test_check_speed_large_batch():
    torch.manual_seed(1)
    guard = G.GuardSet().fit(torch.randn(512, 300, 36))
    x0 = torch.randn(2048, 300, 36)
    start = time.perf_counter()
    guard.check(x0, x0 + 0.01 * torch.randn_like(x0))
    assert time.perf_counter() - start < 30.0


def test_multitaper_periodogram_density_and_lower_spread():
    from cebra.dprime.trial_mask import dpss_tapers
    torch.manual_seed(0)
    x = torch.randn(4000, 1, 32) * 2.0
    tapers = dpss_tapers(32, 2.0, 3)
    hann, _ = G.periodogram(x)
    multi, _ = G.periodogram(x, tapers=tapers)
    assert torch.allclose(multi.mean(dim=(0, 1))[3:-1], torch.full((13,), 4.0), rtol=0.1)
    # 2K instead of 2 degrees of freedom: the log power is far less often near zero.
    assert float((multi[..., 3:-1] < 0.1).float().mean()) < 0.2 * float(
        (hann[..., 3:-1] < 0.1).float().mean())


def test_band_power_ignores_dc_bin():
    freqs = torch.fft.rfftfreq(10)
    masks = G._band_masks(freqs, G.DEFAULT_BANDS)
    assert torch.all(masks[:, 0] == 0)
    assert torch.all(masks.sum(dim=1) >= 1)


def test_small_colored_noise_passes_spike_count_guards():
    # Poisson counts: ties at the artifact threshold and near-zero single-window powers used to
    # reject arbitrarily small perturbations.
    g = torch.Generator().manual_seed(0)
    windows = torch.poisson(torch.full((600, 20, 10), 2.0), generator=g)
    guard = G.GuardSet().fit(windows)
    x0 = windows[:200]
    ok, details = guard.check(x0, x0 + 1e-3 * torch.randn(x0.shape, generator=g))
    assert bool(ok.all()), {k: float(v.float().mean()) for k, v in details.items()}
    rate = float((G.peak_to_peak(windows) > guard.tolerances["artifact"]).any(dim=1).float().mean())
    assert rate <= 0.01 + 1e-6


def test_short_windows_disable_spectral_guards():
    torch.manual_seed(0)
    with pytest.warns(UserWarning):
        guard = G.GuardSet().fit(torch.randn(64, 6, 2))
    assert "band_power" not in guard.guards and "aperiodic" not in guard.guards
    assert set(guard.report()["disabled"]) == {"band_power", "aperiodic"}
    x0 = torch.randn(4, 6, 2)
    ok, details = guard.check(x0, x0)
    assert bool(ok.all()) and set(details) == {"riemann", "artifact"}
