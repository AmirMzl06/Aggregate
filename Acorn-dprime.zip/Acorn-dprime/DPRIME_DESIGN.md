# Acorn-dprime: epsilon as a detectability index (d′) for ACORN / CEBRA

This fork implements Part 1 of the research note "Adversarial Attacks and Learnable
Augmentation for Neural Data" ("ε as a detectability index (d′)") on top of the ACORN
CEBRA fork (`CEBRA-main`). The original PGD (`adv_epsilon_mode="constant"`) is untouched and
bit-identical; everything new lives behind `adv_epsilon_mode="dprime"` and in the package
`cebra/dprime/`.

This document is the binding specification for the implementation (module APIs, tensor
conventions, math) and later the user documentation (Section 9 lists every new `cebra.CEBRA`
argument).

---------------------------------------------------------------------------------------------

## 0. Conventions (all modules)

* A **window** batch is a torch tensor `x` of shape `(B, C, T)`: B samples, C channels
  (neurons / electrodes), T time bins (the receptive field of the CEBRA model, e.g. 36 for
  `offset36-*`). This is exactly `batch.reference` in CEBRA.
* A **recording** is a `(n_time, C)` array (numpy or torch), e.g. `loader.dataset.neural`.
* Labels: `(n_time,)` int (discrete) or `(n_time, d)` float (continuous), or None.
* `D = C * T` is the dimension of one window.
* All public functions accept torch tensors on any device and return tensors on the same
  device; estimation code may use numpy/float64 internally. No in-place modification of inputs.
* "d′" of a perturbation `δ` is `‖Σ^{-1/2} δ‖₂` (Mahalanobis norm in the noise metric).
  Attacks are parameterised in the **whitened** variable `z`, with `δ = Color(z)` and
  `d′ = ‖z‖₂`, so the d′ ball is an ordinary L2 ball in z (Section 2 of the note).
* Randomness only through an explicit `torch.Generator` / numpy seed argument.
* Python ≥ 3.8, torch ≥ 1.12 (tested on 2.0.1), numpy, scipy ≥ 1.1, scikit-learn.
  Only these dependencies. No new package dependencies (no pyriemann, no fooof, no mne).

## 1. The core idea → `cebra/dprime/noise.py` (Layer 1: dataset-level stationary metric)

Ball: `δᵀ Σ⁻¹ δ ≤ ε²`, Σ = noise covariance of the dataset, Kronecker structured
`Σ = Σ_spatial ⊗ Σ_temporal`.

* **Residuals** (what "noise" means), `compute_residuals(neural, labels=None, mode="auto", label_kind=None)`
  returns `(n_time, C)` float64 numpy:
  * `"whole"`: neural minus its mean ("whole trials for oscillatory tasks where background dominates");
  * `"class_mean"`: neural minus the mean of its class (discrete labels) ("trial minus class mean for ERP data");
  * `"regression"`: neural minus a ridge regression of neural on the continuous labels (with
    intercept; ridge = 1e-6 x trace of the label Gram matrix) — the continuous-label analogue of
    "minus class mean";
  * `"auto"`: class_mean for discrete labels, regression for continuous labels, whole otherwise.
* **Spatial covariance** `spatial_covariance(residuals, estimator)` → `(C, C)` float64, SPD:
  `"ledoit_wolf"` (sklearn LedoitWolf), `"oas"` (sklearn OAS), `"empirical"`, `"tyler"`
  (regularised Tyler M-estimator, Chen–Wiesel–Hero fixed point with shrinkage ρ = 0.1 toward
  identity, trace-normalised shape rescaled to the trace of the empirical covariance; "EEG is
  heavy-tailed, so use robust covariance (Tyler's estimator)"). Eigenvalues floored at
  `1e-6 * mean eigenvalue`.
* **Temporal spectrum** `temporal_spectrum(residuals, window_len, method, ar_order=4, tau=None)`
  → `(window_len // 2 + 1,)` float64 half spectrum `S_half` on the grid `numpy.fft.rfftfreq(window_len)`,
  normalised so that the **full** (two-sided, length `window_len`) spectrum has mean 1 (unit
  per-sample variance, so the scale lives in Σ_spatial). Computed on per-channel standardised
  residuals and averaged over channels:
  * `"welch"`: `scipy.signal.welch(nperseg=window_len, noverlap=window_len//2, window="hann",
    detrend="constant")` ("a PSD from Welch");
  * `"ar"`: Yule–Walker AR(p) from the channel-averaged autocovariance,
    `S(f) = σ² / |1 − Σ_k a_k e^{−2πifk}|²` ("or an AR(p) fit");
  * `"white"`: all ones;
  * `"vanrossum"`: spike-train extension (Section 7): metric `‖K_τ ∗ δ‖` with the causal kernel
    `K_τ(t) = exp(−t/τ)` (circular, length window_len), i.e. `S(f) = 1 / |K̂_τ(f)|²`.
    `tau="auto"` uses `fit_vanrossum_tau`.
  Temporal whitening is the prewhitening filter `1/√S(f)`; coloring is `√S(f)`; both applied
  with `torch.fft.rfft/irfft(n=T, norm="ortho")` along the time axis (circulant approximation of
  Σ_temporal on the window).
* `fit_vanrossum_tau(residuals)` → e-folding time (bins, ≥ 0.5) of the channel-averaged
  residual autocorrelation ("τ fitted to the dataset's inter-trial variability").
* `kronecker_check(residuals, window_len, n_channels=8, max_windows=5000)` → dict with the
  relative Frobenius error `‖Σ_full − Σ_kron‖/‖Σ_full‖` of (a) the nearest Kronecker product
  (Van Loan–Pitsianis rank-1 rearrangement) and (b) the model's own `Σ_s ⊗ Σ_t` restricted to the
  slice, on the `n_channels` highest-variance channels ("the Kronecker assumption should be
  checked against a full covariance on a small C·T slice").
* `class NoiseModel`:
  ```
  NoiseModel(spatial_cov (C,C), spectrum_half (T//2+1,), window_len, cov_pool=None,
             leadfield=None, leadfield_noise=0.0, device=None)
  .to(device) -> self
  .color(z, pool_index=None)   (B,C,T) -> (B,C,T): Σ_s^{1/2} then temporal √S   (linear in z)
  .whiten(delta, pool_index=None) (B,C,T) -> (B,C,T): exact inverse of color
  .dprime(delta, pool_index=None) -> (B,) = ‖whiten(delta)‖₂ over (C,T)
  .sample(B, generator=None, pool_index=None) -> (B,C,T) colored Gaussian noise (d′² ~ χ²_D)
  .stationary_coloring(pool_index=None) -> Coloring          (Layer 1)
  .leadfield_coloring(x0, generator=None) -> Coloring          (Section 7, needs leadfield)
  .pool_size -> int  (1 + len(cov_pool))
  ```
  Matrix square roots via `eigh` (symmetric sqrt / inverse sqrt). `cov_pool` is an optional
  list of extra `(C,C)` spatial covariances (same C) — "sample Σ from the pool of per-subject
  covariances during training"; `pool_index=0` is the dataset's own Σ, `1..` the pool.
* `fit_noise_model(neural, labels=None, label_kind=None, window_len=..., residual_mode="auto",
  spatial_estimator="ledoit_wolf", temporal_method="welch", ar_order=4, vanrossum_tau="auto",
  cov_pool=None, leadfield=None, leadfield_noise=0.0, kronecker_channels=8, device=None)`
  → `(NoiseModel, info: dict)`; info holds residual mode used, estimator, τ, spectrum,
  Kronecker check, mean noise std (JSON-serialisable floats/lists only).

### The Coloring interface (implemented by noise.py and trial_mask.py)

```
coloring.init_z(x0)            -> zeros in the attack variable space, batch size B, on x0.device
coloring.color(z)              -> δ of shape (B, C, T); linear and differentiable in z
coloring.dprime(z)             -> (B,) d′ of the perturbation = ‖z‖₂ per sample (flattened)
coloring.random_z(x0, radius, generator=None) -> random z with ‖z_i‖ = radius_i (uniform direction)
```
`radius`/`epsilon` arguments are floats or `(B,)` tensors everywhere.

## 2. Layer 2: trial-level nonstationary masking → `cebra/dprime/trial_mask.py`

"Replace [Σ_temporal] per trial with a local time–frequency gain: compute the trial's multitaper
spectrogram P_c(t,f), parametrize δ = ISTFT(m ⊙ z) with m_c(t,f) = √P_c(t,f), and run PGD on z
with ‖z‖₂ ≤ ε."

* `dpss_tapers(n_fft, nw=2.0, k=3)` → `(k, n_fft)` torch float32 (scipy.signal.windows.dpss, unit energy).
* `multitaper_spectrogram(x, n_fft=16, hop=4, tapers=...)` → `(B, C, F, frames)`, F = n_fft//2+1,
  the average over tapers of `|STFT_taper(x)|²` (`torch.stft(center=True, pad_mode="reflect",
  return_complex=True)` with each taper as window).
* `class TrialMaskColoring(x0, spatial_sqrt, n_fft=16, hop=4, nw=2.0, k=3, floor=1e-3)`:
  the gain is `m = sqrt(P / mean_{f,t} P)` per (sample, channel) (unit mean power, relative
  floor `floor`), computed once from the clean window x0 (no gradient). The variable z is real
  `(B, C, F, frames, 2)`; `color(z) = Σ_s^{1/2} · ISTFT(m ⊙ complex(z))` with
  `torch.istft(window=hann(n_fft), center=True, length=T)`; the spatial factor `Σ_s^{1/2}` keeps
  the Kronecker structure "Σ_spatial ⊗ local time-frequency gain", so the ε scale stays comparable
  with Layer 1 ("conceptually this is still Layer 1 — d′ against a time-varying noise model").
  `dprime(z) = ‖z‖₂` (exact for a consistent STFT; ISTFT of an arbitrary z is its least-squares
  projection, so the realised d′ can only be smaller — document this).

## 3. Layer 3: physiological guards → `cebra/dprime/guards.py`

"Tolerances come from natural within-class, within-subject variability rather than hand-picked
thresholds." Features (torch, differentiable where noted):

* `periodogram(x, fs=1.0)` → power `(B,C,F)` (Hann-windowed rfft, F = T//2+1) and freqs (F,).
* `log_band_power(x, bands, fs)` → `(B,C,n_bands)`, log of the mean power in each band (+1e-12).
  Default bands, in cycles/bin × fs: `((0, .05), (.05, .15), (.15, .30), (.30, .50))`.
* `aperiodic_params(x, fs, f_range=None)` → `(offset (B,C), exponent (B,C))`, least-squares fit of
  `log10 P(f) = offset − exponent·log10 f` over the non-zero frequencies in f_range
  (specparam/FOOOF "fixed" aperiodic mode, no knee) ("aperiodic exponent and offset").
* `window_covariance(x, channels, shrink=0.1)` → `(B,c,c)` centred covariance of the selected
  channels + `shrink·trace/c·I`.
* `riemann_distance(A, B)` → `(B,)`, affine-invariant `sqrt(Σ log² λ_i(A^{-1/2} B A^{-1/2}))`
  via Cholesky of A and `eigvalsh` (differentiable).
* `erp_features(x, window)` → `(amplitude (B,C), latency (B,C))`: amplitude = value at the peak
  of |x| inside `window=(start, stop)` bins, latency = its position (bins).
* `peak_to_peak(x)` → `(B,C)`.
* `class GuardSet(guards=("band_power","aperiodic","riemann","artifact"), tau=1.0, bands=None,
  sampling_rate=1.0, erp_window=None, riemann_channels=32, riemann_shrink=0.1,
  artifact_rate=0.01, nn_max_per_class=256, seed=0)`:
  * `.fit(windows (M,C,T), classes=None, times=None, exclusion=0) -> self` computes tolerances:
    - band_power / aperiodic / erp: `tau × within-class SD` per channel (SD within each class,
      averaged over classes weighted by count; SD floor 1e-6);
    - riemann: `median same-class nearest-neighbour d_R` over the training windows (NN search in
      the log-Euclidean embedding, exact d_R for the NN pair; neighbours with
      `|t − t'| < exclusion` excluded; ≤ nn_max_per_class windows per class); channels = the
      `riemann_channels` highest-variance channels (all if C ≤ riemann_channels);
    - artifact: per-channel peak-to-peak thresholds at a common quantile q chosen (bisection) so
      that a fraction `artifact_rate` of the clean windows is rejected (Autoreject-style
      thresholds); "ICLabel" has no analogue for non-EEG data and is not implemented.
  * `.check(x0, x_adv) -> (ok (B,) bool, details {guard: (B,) bool})`: all channels/bands within
    tolerance; riemann `d_R(C_x0, C_xadv) ≤ tol`; artifact: x_adv is not rejected unless x0 is
    rejected too ("at the same rate as clean trials").
  * `.soft_penalty(x0, x_adv) -> (B,)` = `relu(d_R − tol)²` (differentiable; zeros if riemann is
    off) ("d_R is differentiable, so it can also be a soft penalty").
  * `.report() -> dict` (JSON-serialisable summary of the tolerances).

## 4. Attacks → `cebra/dprime/attacks.py`

* `dprime_pgd(loss_fn, x0, coloring, epsilon, steps=10, optimizer="apgd", restarts=1,
  guards=None, guard_mode="backtrack", max_backtrack=3, soft_penalty_weight=0.0, generator=None)`
  → `(x_adv (B,C,T) detached, info)`.
  * `loss_fn(x) -> (B,)` per-sample loss to MAXIMISE (differentiable in x).
  * Optimises z in the L2 ball `‖z_i‖ ≤ ε_i` (ε float or (B,) tensor; ε_i = 0 → no perturbation).
    Objective: `loss_fn(x0 + color(z)) − soft_penalty_weight · guards.soft_penalty(x0, x)`.
  * `optimizer="apgd"`: APGD (Croce & Hein 2020) for L2 in z: η₀ = 2ε, momentum α = 0.75,
    checkpoints p₀=0, p₁=0.22, p_{j+1}=p_j+max(p_j−p_{j−1}−0.03, 0.06), ρ = 0.75; at a
    checkpoint halve η and restart from the best point when (i) fewer than ρ·(w_j−w_{j−1})
    steps increased the loss or (ii) η and the best loss were both unchanged since the last
    checkpoint; per-sample best iterate returned ("APGD-style step adaptation").
    `optimizer="pgd"`: `z ← Proj(z + α g/‖g‖)`, α = 2.5 ε / steps.
  * Restart 0 starts at z = 0 (the note's sketch); restarts ≥ 1 start at a random point of
    radius ε/2; the per-sample best restart is kept ("and restarts").
  * Guards, `guard_mode="backtrack"`: after each step, samples whose candidate violates a guard
    get their step halved and retried up to `max_backtrack` times; if still violating, they keep
    their previous z ("if a guard is violated after a step, halve the step and retry (≤ K_bt)").
    `"backtrack"` and `"final"` both apply the final accept/reject: a rejected sample returns
    x0 (clean) ("return x + Color(z) if all guards pass else reject"). `"off"`: no guards.
  * `info`: `dprime (B,)` realised ‖z‖, `accepted (B,)` bool, `loss (B,)` final loss,
    `backtracks` int, `guard_failures` {guard: int} (final check), `epsilon (B,)`.
* `min_norm_ddn(is_adv_fn, loss_fn, x0, coloring, steps=50, init_epsilon=1.0, gamma=0.05,
  alpha=None, max_epsilon=None)` → `(dprime_min (B,), success (B,) bool)`: Decoupled Direction
  and Norm (Rony et al. 2019) in the whitened metric ("a minimum-norm attack (FMN/DDN in the
  whitened metric) to measure each trial's distance to the decision boundary in d′").
  `is_adv_fn(x) -> (B,) bool`. Samples adversarial at x0 have distance 0. Never-adversarial
  samples: `inf` and success False.
* `linf_pgd(loss_fn, x0, epsilon_abs, steps=10, alpha=None, generator=None)` → x_adv: plain
  L∞ PGD in input units (used to train detectors "across attacks").

## 5. Calibration → `cebra/dprime/calibration.py`

"Choosing ε per dataset: a calibration protocol, not a number":
1. **ε_JND = 1** (ideal-observer threshold; configurable).
2. **ε_NN**: "for each clean trial, the whitened distance to its nearest same-class, same-subject
   neighbour; take a low quantile (e.g., the 10th)".
3. **ε_det**: "the largest ε at which a detector trained to separate clean from adversarial
   trials (plus a clean-only anomaly detector such as an autoencoder) stays ≤ 0.55 AUC on
   held-out [data]".
`ε* = min(ε_JND, ε_NN, ε_det)`; robustness margin = `median(d′_boundary) / ε*`.

* `make_classes(labels, label_kind, n_classes=8, seed=0)` → `(n_time,)` int64 numpy or None
  (discrete labels as is; continuous labels → k-means on standardised labels; None → None).
* `valid_indices(n_time, offset_left, offset_right)` → indices t with a full window
  `[t − left, t + right)`.
* `whitened_windows(neural, indices, offset_left, offset_right, noise_model, batch_size)` →
  generator/tensor of flattened whitened windows `(M, D)`.
* `nearest_neighbour_dprime(neural, noise_model, offset_left, offset_right, classes=None,
  query_indices=None, bank_size=2000, exclusion=None, batch_size=512, seed=0, device=None)` →
  `(query_indices (Q,), distances (Q,))`: whitened (d′) distance of each query window to its
  nearest same-class window in a random bank, excluding temporal neighbours `|t − t'| <
  exclusion` (default: the window length, so overlapping windows never count). Distances via
  `torch.cdist` in chunks.
* `eps_nn(distances, quantile=0.10)` → float.
* `per_index_eps_nn(n_time, query_indices, distances)` → `(n_time,)` float32 array with the
  per-trial ε_NN,i (inf for invalid indices) (used for instance-adaptive budgets).
* Detectors: `ConvDetector(C)` (Conv1d(C,32,5)–ReLU–Conv1d(32,32,5)–ReLU–global mean–Linear(32,1))
  and `ConvAutoencoder(C)` (Conv1d(C,32,5,pad 2)–ReLU–Conv1d(32,8,5,pad 2)–ReLU–Conv1d(8,32,5,pad 2)
  –ReLU–Conv1d(32,C,5,pad 2)), trained with Adam(1e-3), minibatch 256, `detector_steps` steps.
* `auc(scores_neg, scores_pos)` → Mann–Whitney AUC (ties = 0.5).
* `detection_curve(x_train, x_test, attack_fn, eps_grid, detector_steps=300, device=None,
  seed=0)` → `{eps: {"cnn_auc", "ae_auc", "auc"(=max)}}`. `attack_fn(x, eps, kind) -> x_adv` for
  `kind in ("dprime", "colored_noise", "linf")`; the CNN detector is trained on clean vs the
  mixture of all three kinds on x_train ("detectors overfit to one attack, so train them across
  attacks") and evaluated on clean vs `"dprime"` on the held-out x_test; the autoencoder is trained
  on clean x_train only and scored by reconstruction error on x_test.
* `eps_det_from_curve(curve, threshold=0.55)` → `(eps_det, status)`: the largest grid ε with
  AUC ≤ threshold (status "ok"); if none → half the smallest grid value (status "below_grid");
  if all pass → the largest grid value (status "censored_above").
* `robustness_margin(dprime_min, eps_star)` → dict(median, quantiles 10/25/75/90, fraction
  already adversarial (d′=0), fraction never broken, ratio = median / eps_star).

## 6. Adversarial training (integration in `cebra/solver/base.py`)

"Drop d′-PGD into Madry-style AT or TRADES with a per-trial budget ε_i = min(ε*, ε_NN,i), i.e.,
instance-adaptive AT in the spirit of IAAT/MMA, with a curriculum from 0.25 up to ε*."

* `adv_epsilon_mode="dprime"` in `Solver` and `MultiobjectiveSolver`.
* In `fit()`, before the first step (`_fit_dprime(loader)`): read `loader.dataset.neural`
  (n_time, C) and labels (`continuous_index` / `discrete_index`), window = `model.get_offset()`;
  fit the NoiseModel (Layer 1), the GuardSet (Layer 3) on a sample of training windows, classes,
  ε_NN (global quantile + per-index), the Kronecker check. Single-session only (clear error
  otherwise).
* Batches carry the reference time indices: the single-session dataset returns an
  `IndexedBatch` (subclass of `Batch` with an extra `reference_index` slot); nothing else in
  CEBRA changes behaviour.
* ε*: `adv_dprime_epsilon="auto"` → calibrated after `adv_dprime_warmup × max_iterations` clean
  steps (ε_det needs the current model as the attacked decoder), using the current batch split by
  time (`reference_index` below / above its median = train / held-out); a float → used as ε*
  directly (no warm-up, no detectors).
* Curriculum: `ε_t = ε₀ + (ε* − ε₀) · min(1, progress / adv_dprime_curriculum)` with
  `ε₀ = min(0.25, ε*)`, progress = fraction of the post-warm-up steps.
* Per-trial budget (`adv_dprime_instance_adaptive=True`): `ε_i = min(ε_t, ε_NN,i)`.
* Coloring per step: Layer 1 (`adv_dprime_layer="stationary"`) or Layer 2 (`"trial_mask"`);
  leadfield coloring if a leadfield is given; Σ sampled uniformly from the pool if `cov_pool`.
* Objective: `"madry"` = the original ACORN structure (clean update, then an update on the d′
  adversarial reference); `"trades"` = one update on `InfoNCE(clean) + β·KL(p(x) ‖ p(x_adv))`
  where p is the softmax over the similarities of the reference to [positive, negatives], and
  the attack maximises that KL.
* End of `fit()`: robustness margin with `min_norm_ddn` on the last batch, decision = the positive
  is no longer the most similar candidate (`"top1"`) or no longer above chance (`"chance"`).
* Report: `solver.dprime_report` (dict) → `cebra.CEBRA.dprime_report_` after fit.
  Per-step stats in `solver.log`: `dprime_eps`, `dprime_mean`, `dprime_accept`.

## 7. Extensions

* **Leadfield** (`adv_dprime_leadfield`, (C, S) array): `δ = L·s + n`, budget in source space
  (`‖s‖₂ ≤ ε`, s temporally coloured), `n` = natural sensor noise sampled from the NoiseModel
  with scale `adv_dprime_leadfield_noise` (0 = none) ("source-space perturbation plus sensor noise
  with the budget in source space").
* **Spike trains**: `adv_dprime_temporal="vanrossum"` (van Rossum metric, τ fitted to the data).
  Discrete jitter/insertion/deletion are not differentiable and are not implemented.

## 8. Risks addressed

Tyler estimator (heavy tails); shrinkage (few trials); Kronecker check; detectors trained across
attacks and evaluated on held-out data; min-norm attack alongside PGD (gradient masking).

## 9. New `cebra.CEBRA(...)` arguments

(filled in by the integration step; see the README section at the end of this file)
