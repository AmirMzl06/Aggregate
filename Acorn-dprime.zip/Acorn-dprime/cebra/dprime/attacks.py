"""Attacks in the d′ metric (Section 4 of ``DPRIME_DESIGN.md``).

The note's sketch::

    dprimePGD(x, y, ε*):
      z ← 0
      for k in 1..K:
         δ   = Color(z)               # Σ_s^{1/2}, ×√S(f) or trial mask m
         g_z = ∇_z L(f(x+δ), y)       # autograd through Color
         z   = Proj_{‖z‖₂≤ε*}(z + α_k · g_z/‖g_z‖)
         if any Layer-3 guard violated: α_k ← α_k/2, retry (≤ K_bt)
      return x + Color(z) if all guards pass else reject

and "run ordinary PGD (with APGD-style step adaptation and restarts) on the whitened
coordinates under an L2 ball of radius ε". :py:func:`dprime_pgd` implements exactly that, with
APGD (Croce & Hein, 2020, following the AutoAttack reference implementation of the L2 version)
or plain PGD as the optimiser. :py:func:`min_norm_ddn` is the minimum-norm attack ("FMN/DDN in
the whitened metric") used for the robustness margin and to rule out gradient masking, and
:py:func:`linf_pgd` is an ordinary L∞ attack in input units used to train the detectors
"across attacks".

Collaborators are duck-typed. A *coloring* provides ``init_z(x0)``, ``color(z)`` (the
perturbation ``(B, C, T)``), ``dprime(z)`` (``(B,)``) and ``random_z(x0, radius, generator)``;
a *guard set* provides ``check(x0, x_adv) -> (ok (B,), details)`` and ``soft_penalty(x0,
x_adv) -> (B,)``. Only the attack variable is differentiated (``torch.autograd.grad``), so no
gradient accumulates in the model parameters. Every per-sample quantity is a batched tensor.
"""

import math
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch

__all__ = ["apgd_checkpoints", "dprime_pgd", "min_norm_ddn", "linf_pgd"]

LossFn = Callable[[torch.Tensor], torch.Tensor]
EpsilonLike = Union[float, torch.Tensor]

# APGD constants (Croce & Hein, 2020).
_APGD_MOMENTUM = 0.75
_APGD_RHO = 0.75
_APGD_P1 = 0.22
_APGD_DECREASE = 0.03
_APGD_MIN = 0.06


def _epsilon(epsilon: EpsilonLike, batch_size: int, like: torch.Tensor) -> torch.Tensor:
    eps = torch.as_tensor(epsilon, dtype=like.dtype, device=like.device)
    if eps.ndim == 0:
        eps = eps.expand(batch_size)
    eps = eps.reshape(-1)
    if eps.shape != (batch_size,):
        raise ValueError(f"epsilon must be a float or a ({batch_size},) tensor, "
                         f"got shape {tuple(eps.shape)}.")
    if bool((eps < 0).any()) or not bool(torch.isfinite(eps).all()):
        raise ValueError("epsilon must be finite and >= 0.")
    return eps.clone()


def _view(values: torch.Tensor, like: torch.Tensor) -> torch.Tensor:
    return values.view(-1, *([1] * (like.ndim - 1)))


def _norm(z: torch.Tensor) -> torch.Tensor:
    return torch.linalg.vector_norm(z.reshape(z.shape[0], -1), dim=1)


def _project(z: torch.Tensor, eps: torch.Tensor) -> torch.Tensor:
    """Project each sample onto the L2 ball of its radius."""
    norm = _norm(z)
    factor = torch.where(norm > eps, eps / norm.clamp_min(1e-12), torch.ones_like(norm))
    return z * _view(factor, z)


def _normalised(grad: torch.Tensor) -> torch.Tensor:
    return grad / _view(_norm(grad).clamp_min(1e-12), grad)


def apgd_checkpoints(steps: int) -> List[int]:
    """APGD checkpoints ``w_j = ⌈p_j · steps⌉``.

    ``p_0 = 0``, ``p_1 = 0.22``, ``p_{j+1} = p_j + max(p_j − p_{j−1} − 0.03, 0.06)``; ``w_0 = 0``
    is the start and not returned.

    Args:
        steps: Number of iterations ``N_iter``.

    Returns:
        Increasing iteration indices in ``(0, steps]``.
    """
    points = [0.0, _APGD_P1]
    while points[-1] < 1.0:
        points.append(points[-1] + max(points[-1] - points[-2] - _APGD_DECREASE, _APGD_MIN))
    checkpoints = sorted({int(math.ceil(p * steps)) for p in points[1:] if p <= 1.0})
    return [w for w in checkpoints if 0 < w <= steps]


class _Objective:
    """``loss_fn(x0 + color(z)) − w · soft_penalty`` and its gradient in ``z``."""

    def __init__(self, loss_fn: LossFn, x0: torch.Tensor, coloring, guards,
                 soft_penalty_weight: float):
        self.loss_fn = loss_fn
        self.x0 = x0
        self.coloring = coloring
        self.guards = guards
        self.weight = float(soft_penalty_weight)

    def __call__(self, z: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        z = z.detach().requires_grad_(True)
        with torch.enable_grad():
            x = self.x0 + self.coloring.color(z)
            loss = self.loss_fn(x)
            if loss.shape != (self.x0.shape[0],):
                raise ValueError(f"loss_fn must return a ({self.x0.shape[0]},) tensor, "
                                 f"got {tuple(loss.shape)}.")
            objective = loss
            if self.weight > 0 and self.guards is not None:
                objective = loss - self.weight * self.guards.soft_penalty(self.x0, x)
            grad, = torch.autograd.grad(objective.sum(), z)
        return objective.detach(), grad.detach()

    def perturbed(self, z: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            return self.x0 + self.coloring.color(z)


def _backtrack(objective: _Objective, z_old: torch.Tensor, z_new: torch.Tensor,
               max_backtrack: int) -> Tuple[torch.Tensor, torch.Tensor, int]:
    """Halve the step of the samples whose candidate violates a guard, up to ``max_backtrack``.

    Returns the accepted candidates (failing samples keep ``z_old``), a ``(B,)`` mask of the
    samples that needed at least one halving, and the number of halvings.
    """
    guards = objective.guards
    ok, _ = guards.check(objective.x0, objective.perturbed(z_new))
    needed = ~ok
    if bool(ok.all()):
        return z_new, needed, 0
    candidate = z_new.clone()
    count = 0
    for _ in range(max_backtrack):
        failing = ~ok
        if not bool(failing.any()):
            break
        count += 1
        step = (candidate - z_old)[failing] * 0.5
        candidate[failing] = z_old[failing] + step
        ok_now, _ = guards.check(objective.x0[failing], objective.x0[failing] +
                                 objective.coloring.color(candidate)[failing].detach())
        ok = ok.clone()
        ok[failing] = ok_now
    candidate[~ok] = z_old[~ok]
    return candidate, needed, count


def _run_pgd(objective: _Objective, z: torch.Tensor, eps: torch.Tensor, steps: int,
             guard_backtrack: bool, max_backtrack: int) -> Tuple[torch.Tensor, torch.Tensor, int]:
    """Plain normalised-gradient PGD in the L2 ball; returns the best iterate per sample."""
    alpha = 2.5 * eps / max(steps, 1)
    loss, grad = objective(z)
    best_z, best_loss = z.clone(), loss.clone()
    backtracks = 0
    for _ in range(steps):
        candidate = _project(z + _view(alpha, z) * _normalised(grad), eps)
        if guard_backtrack:
            candidate, _, count = _backtrack(objective, z, candidate, max_backtrack)
            backtracks += count
        z = candidate
        loss, grad = objective(z)
        better = loss > best_loss
        best_loss = torch.where(better, loss, best_loss)
        best_z[better] = z[better]
    return best_z, best_loss, backtracks


def _run_apgd(objective: _Objective, z: torch.Tensor, eps: torch.Tensor, steps: int,
              guard_backtrack: bool, max_backtrack: int) -> Tuple[torch.Tensor, torch.Tensor, int]:
    """APGD (L2) in the whitened variable, per-sample step sizes; returns the best iterate."""
    batch = z.shape[0]
    step_size = 2.0 * eps.clone()
    loss, grad = objective(z)
    best_z, best_loss, best_grad = z.clone(), loss.clone(), grad.clone()
    loss_steps = torch.zeros(steps + 1, batch, dtype=loss.dtype, device=loss.device)
    loss_steps[0] = loss
    z_old = z.clone()

    period = max(int(_APGD_P1 * steps), 1)
    decrease = max(int(_APGD_DECREASE * steps), 1)
    minimum = max(int(_APGD_MIN * steps), 1)
    counter = 0
    best_at_last_check = best_loss.clone()
    reduced_at_last_check = torch.zeros(batch, dtype=torch.bool, device=z.device)
    backtracks = 0

    for i in range(steps):
        with torch.no_grad():
            difference = z - z_old
            momentum = 1.0 if i == 0 else _APGD_MOMENTUM
            step = _project(z + _view(step_size, z) * _normalised(grad), eps)
            candidate = _project(z + (step - z) * momentum + difference * (1.0 - momentum), eps)
        if guard_backtrack:
            candidate, needed, count = _backtrack(objective, z, candidate, max_backtrack)
            backtracks += count
            step_size = torch.where(needed, 0.5 * step_size, step_size)
        z_old = z
        z = candidate
        loss, grad = objective(z)
        loss_steps[i + 1] = loss
        better = loss > best_loss
        best_loss = torch.where(better, loss, best_loss)
        best_z[better] = z[better]
        best_grad[better] = grad[better]

        counter += 1
        if counter == period:
            # The last `period` loss changes (AutoAttack's check_oscillation).
            window = loss_steps[i + 1 - period:i + 2]
            increases = (window[1:] > window[:-1]).sum(dim=0)
            oscillation = increases <= period * _APGD_RHO
            stalled = ~reduced_at_last_check & (best_at_last_check >= best_loss)
            reduce = oscillation | stalled
            reduced_at_last_check = reduce.clone()
            best_at_last_check = best_loss.clone()
            if bool(reduce.any()):
                step_size = torch.where(reduce, 0.5 * step_size, step_size)
                z = z.clone()
                grad = grad.clone()
                z[reduce] = best_z[reduce]
                grad[reduce] = best_grad[reduce]
            counter = 0
            period = max(period - decrease, minimum)
    return best_z, best_loss, backtracks


def dprime_pgd(loss_fn: LossFn,
               x0: torch.Tensor,
               coloring,
               epsilon: EpsilonLike,
               steps: int = 10,
               optimizer: str = "apgd",
               restarts: int = 1,
               guards=None,
               guard_mode: str = "backtrack",
               max_backtrack: int = 3,
               soft_penalty_weight: float = 0.0,
               generator: Optional[torch.Generator] = None) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """d′-PGD: maximise ``loss_fn`` over the whitened ball ``‖z_i‖₂ ≤ ε_i``.

    Args:
        loss_fn: ``loss_fn(x) -> (B,)`` per-sample loss to maximise (differentiable in ``x``).
        x0: ``(B, C, T)`` clean windows.
        coloring: Coloring object (Layer 1, Layer 2 or leadfield).
        epsilon: d′ budget, a float or a ``(B,)`` tensor (``0``: no perturbation).
        steps: Iterations per restart.
        optimizer: ``"apgd"`` (step-size adaptation, momentum 0.75, initial step 2ε) or
            ``"pgd"`` (step 2.5ε/steps).
        restarts: Number of restarts; restart 0 starts at ``z = 0`` (the note's sketch), the
            others at a random point of radius ε/2. The per-sample best restart is kept.
        guards: Optional guard set (Layer 3).
        guard_mode: ``"backtrack"`` (halve the step of violating samples and retry, up to
            ``max_backtrack`` times, then keep the previous iterate; plus the final check),
            ``"final"`` (only the final accept/reject) or ``"off"``.
        max_backtrack: ``K_bt``.
        soft_penalty_weight: Weight of ``guards.soft_penalty`` subtracted from the loss.
        generator: Generator of the random restarts.

    Returns:
        ``x_adv`` (detached ``(B, C, T)``; rejected samples are ``x0``) and ``info`` with
        ``dprime`` (realised ``‖z‖``, 0 if rejected), ``accepted`` (bool), ``loss`` (objective
        of the returned point; −inf if rejected), ``epsilon``, ``backtracks`` (int) and
        ``guard_failures`` ({guard: number of finally rejected samples failing it}).
    """
    if optimizer not in ("apgd", "pgd"):
        raise ValueError(f"optimizer must be 'apgd' or 'pgd', got {optimizer!r}.")
    if guard_mode not in ("backtrack", "final", "off"):
        raise ValueError(f"guard_mode must be 'backtrack', 'final' or 'off', got {guard_mode!r}.")
    if steps < 0 or restarts < 1 or max_backtrack < 0:
        raise ValueError("Need steps >= 0, restarts >= 1 and max_backtrack >= 0.")
    x0 = x0.detach()
    batch = x0.shape[0]
    if guards is None:
        guard_mode = "off"
    objective = _Objective(loss_fn, x0, coloring, guards,
                           soft_penalty_weight if guards is not None else 0.0)
    template = coloring.init_z(x0)
    eps = _epsilon(epsilon, batch, template)
    run = _run_apgd if optimizer == "apgd" else _run_pgd

    best_z = template.clone()
    best_loss = torch.full((batch,), -math.inf, dtype=template.dtype, device=template.device)
    accepted = torch.zeros(batch, dtype=torch.bool, device=template.device)
    last_z = template.clone()
    backtracks = 0
    for restart in range(restarts):
        if restart == 0:
            start = template.clone()
        else:
            start = _project(coloring.random_z(x0, 0.5 * eps, generator), eps)
        z, loss, count = run(objective, start, eps, steps, guard_mode == "backtrack",
                             max_backtrack)
        backtracks += count
        last_z = z
        if guard_mode != "off":
            ok, _ = guards.check(x0, objective.perturbed(z))
            loss = torch.where(ok, loss, torch.full_like(loss, -math.inf))
        else:
            ok = torch.ones(batch, dtype=torch.bool, device=template.device)
        better = loss > best_loss
        best_loss = torch.where(better, loss, best_loss)
        best_z[better] = z[better]
        accepted |= ok

    guard_failures: Dict[str, int] = {}
    if guard_mode != "off":
        # Report which guards the rejected samples (no restart passed) fail at their last try.
        rejected = ~accepted
        if bool(rejected.any()):
            _, details = guards.check(x0[rejected], objective.perturbed(last_z)[rejected])
            guard_failures = {name: int((~passed).sum()) for name, passed in details.items()}
        best_z[rejected] = 0.0
    with torch.no_grad():
        x_adv = x0 + coloring.color(best_z)
        x_adv[~accepted] = x0[~accepted]
    info = {
        "dprime": torch.where(accepted, coloring.dprime(best_z), torch.zeros_like(eps)),
        "accepted": accepted,
        "loss": best_loss,
        "epsilon": eps,
        "backtracks": int(backtracks),
        "guard_failures": guard_failures,
    }
    return x_adv.detach(), info


def min_norm_ddn(is_adv_fn: Callable[[torch.Tensor], torch.Tensor],
                 loss_fn: LossFn,
                 x0: torch.Tensor,
                 coloring,
                 steps: int = 50,
                 init_epsilon: float = 1.0,
                 gamma: float = 0.05,
                 alpha: Optional[float] = None,
                 max_epsilon: Optional[float] = None) -> Tuple[torch.Tensor, torch.Tensor]:
    """Minimum d′ to the decision boundary: Decoupled Direction and Norm (Rony et al., 2019).

    "Run a minimum-norm attack (FMN/DDN in the whitened metric) to measure each trial's
    distance to the decision boundary in d′." In the whitened variable: ``z ← z + α_k g/‖g‖``,
    ``ε ← (1 − γ) ε`` if the current point is adversarial else ``(1 + γ) ε``, ``z ← ε z/‖z‖``;
    ``α_k`` is cosine-annealed from ``alpha`` to ``alpha / 100``. The smallest ``‖z‖`` of an
    adversarial iterate is returned.

    Args:
        is_adv_fn: ``is_adv_fn(x) -> (B,)`` bool, True when the decision has flipped.
        loss_fn: ``loss_fn(x) -> (B,)`` loss whose increase pushes towards the boundary.
        x0: ``(B, C, T)`` clean windows.
        coloring: Coloring object.
        steps: Number of iterations.
        init_epsilon: Initial norm ε₀.
        gamma: Norm adaptation factor γ.
        alpha: Initial step α₀ (default ``init_epsilon``).
        max_epsilon: Optional cap of ε.

    Returns:
        ``dprime_min (B,)`` (0 for samples adversarial at ``x0``, ``inf`` if never
        adversarial) and ``success (B,)`` bool.
    """
    x0 = x0.detach()
    batch = x0.shape[0]
    z = coloring.init_z(x0)
    with torch.no_grad():
        adversarial_at_start = is_adv_fn(x0).reshape(-1).bool()
    best = torch.full((batch,), math.inf, dtype=z.dtype, device=z.device)
    best[adversarial_at_start] = 0.0
    eps = torch.full((batch,), float(init_epsilon), dtype=z.dtype, device=z.device)
    alpha0 = float(init_epsilon if alpha is None else alpha)
    active = ~adversarial_at_start
    for k in range(steps + 1):
        z = z.detach().requires_grad_(True)
        with torch.enable_grad():
            x = x0 + coloring.color(z)
            loss = loss_fn(x)
            grad, = torch.autograd.grad(loss.sum(), z)
        with torch.no_grad():
            adversarial = is_adv_fn(x).reshape(-1).bool()
            norm = coloring.dprime(z)
            improve = active & adversarial & (norm < best)
            best = torch.where(improve, norm, best)
            if k == steps:
                break
            eps = torch.where(adversarial, (1.0 - gamma) * eps, (1.0 + gamma) * eps)
            if max_epsilon is not None:
                eps = eps.clamp(max=float(max_epsilon))
            step = alpha0 * (0.01 + 0.99 * 0.5 * (1.0 + math.cos(math.pi * k / max(steps, 1))))
            z = z.detach() + step * _normalised(grad)
            norm = _norm(z)
            z = z * _view(torch.where(norm > 0, eps / norm.clamp_min(1e-12),
                                      torch.zeros_like(norm)), z)
            z[~active] = 0.0
    return best, torch.isfinite(best)


def linf_pgd(loss_fn: LossFn,
             x0: torch.Tensor,
             epsilon_abs: EpsilonLike,
             steps: int = 10,
             alpha: Optional[EpsilonLike] = None,
             generator: Optional[torch.Generator] = None) -> torch.Tensor:
    """Ordinary L∞ PGD in input units (random start, sign steps, box projection).

    Args:
        loss_fn: ``loss_fn(x) -> (B,)`` loss to maximise.
        x0: ``(B, C, T)`` clean windows.
        epsilon_abs: Box half-width (float or ``(B,)``).
        steps: Iterations.
        alpha: Step (default ``2.5 ε / steps``).
        generator: Generator of the random start.

    Returns:
        Detached ``x_adv`` with ``|x_adv − x0| ≤ ε`` elementwise.
    """
    x0 = x0.detach()
    eps = _view(_epsilon(epsilon_abs, x0.shape[0], x0), x0)
    step = 2.5 * eps / max(steps, 1) if alpha is None else _view(
        _epsilon(alpha, x0.shape[0], x0), x0)
    if generator is not None:
        noise = torch.rand(x0.shape, generator=generator, device=generator.device,
                           dtype=x0.dtype).to(x0.device)
    else:
        noise = torch.rand_like(x0)
    x = x0 + (2.0 * noise - 1.0) * eps
    for _ in range(steps):
        x = x.detach().requires_grad_(True)
        with torch.enable_grad():
            grad, = torch.autograd.grad(loss_fn(x).sum(), x)
        with torch.no_grad():
            x = x + step * grad.sign()
            x = torch.max(torch.min(x, x0 + eps), x0 - eps)
    return x.detach()
