"""Layer 2: trial-level nonstationary masking (Section 2 of ``DPRIME_DESIGN.md``).

"A stationary Σ_temporal is wrong for bursty signals [...]. Replace it per trial with a local
time–frequency gain: compute the trial's multitaper spectrogram P_c(t,f), parametrize
δ = ISTFT(m ⊙ z) with m_c(t,f) = √P_c(t,f), and run PGD on z with ‖z‖₂ ≤ ε. This is the
neural analogue of psychoacoustic masking in audio attacks: local power masks local
perturbation. [...] Conceptually this is still Layer 1 — it's d′ against a time-varying
noise model equal to the trial's own local power — so the ε scale stays comparable."

Implementation choices that keep the ε scale comparable with Layer 1:

* The STFT is used as a normalised tight frame: :py:meth:`TrialMaskColoring.analysis` is the
  Hann-window STFT with an orthonormal DFT, the one-sided bins weighted so the coefficient
  vector carries the energy of the two-sided one, and divided by the square root of the
  window overlap ``Σ_k w²(t − kH)``. Then ``‖analysis(x)‖ ≈ ‖x‖`` and
  :py:meth:`TrialMaskColoring.synthesis` (``torch.istft``, the least-squares inverse) gives
  ``synthesis(analysis(x)) = x``. For an arbitrary ``z`` (not a consistent STFT) the synthesis
  is a least-squares projection, so the realised perturbation can only be smaller than ``‖z‖``.
* The gain is relative: ``m = √(P / mean_{f,t} P)`` per (sample, channel), so only the
  time–frequency *shape* of the trial is used and the scale stays in ``Σ_spatial``:
  ``color(z) = Σ_spatial^{1/2} · synthesis(m ⊙ z)``. With ``m ≡ 1`` this is Layer 1 with a
  white temporal spectrum.
"""

from typing import Optional, Tuple, Union

import numpy as np
import scipy.signal.windows
import torch

__all__ = ["dpss_tapers", "multitaper_spectrogram", "TrialMaskColoring"]


def _stft_size(window_len: int, n_fft: int, hop: int) -> Tuple[int, int]:
    """Shrink ``n_fft`` (and the hop) for windows too short for reflect padding."""
    n_fft = int(n_fft)
    hop = int(hop)
    if n_fft < 2 or hop < 1:
        raise ValueError(f"Need n_fft >= 2 and hop >= 1, got {n_fft}, {hop}.")
    while n_fft // 2 >= window_len and n_fft > 2:
        n_fft //= 2
    hop = max(1, min(hop, n_fft // 2))
    return n_fft, hop


def dpss_tapers(n_fft: int, nw: float = 2.0, k: int = 3) -> torch.Tensor:
    """Discrete prolate spheroidal (Slepian) tapers with unit energy.

    Args:
        n_fft: Taper length.
        nw: Time-half-bandwidth product.
        k: Number of tapers (at most ``2·nw − 1`` are well concentrated).

    Returns:
        ``(k, n_fft)`` float32 tensor, each row with unit L2 norm.
    """
    if k < 1:
        raise ValueError(f"k must be >= 1, got {k}.")
    if n_fft < 2:
        raise ValueError(f"DPSS tapers need n_fft >= 2, got {n_fft}.")
    # Short tapers: NW < n_fft / 2 and at most n_fft − 1 tapers (scipy's limits).
    nw = min(float(nw), 0.5 * (int(n_fft) - 1))
    k = min(int(k), int(n_fft) - 1)
    tapers = np.atleast_2d(scipy.signal.windows.dpss(int(n_fft), float(nw), Kmax=int(k)))
    tapers = tapers / np.linalg.norm(tapers, axis=1, keepdims=True)
    return torch.from_numpy(tapers.astype(np.float32))


def multitaper_spectrogram(x: torch.Tensor,
                           n_fft: int = 16,
                           hop: int = 4,
                           tapers: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Multitaper spectrogram ``P_c(t, f)`` of each channel of each window.

    The average over the tapers of ``|STFT_taper(x)|²`` (``center=True``, reflect padding).

    Args:
        x: ``(B, C, T)`` windows.
        n_fft: FFT size of each frame (shrunk for very short windows).
        hop: Hop between frames.
        tapers: ``(K, n_fft)`` tapers; default :py:func:`dpss_tapers` ``(n_fft, 2, 3)``.

    Returns:
        ``(B, C, n_fft // 2 + 1, frames)`` non-negative tensor.
    """
    if x.ndim != 3:
        raise ValueError(f"Expected (B, C, T) windows, got {tuple(x.shape)}.")
    batch, channels, window_len = x.shape
    n_fft, hop = _stft_size(window_len, n_fft, hop)
    if tapers is None:
        tapers = dpss_tapers(n_fft)
    if tapers.shape[-1] != n_fft:
        raise ValueError(f"Tapers of length {tapers.shape[-1]} for n_fft={n_fft}.")
    tapers = tapers.to(device=x.device, dtype=x.dtype)
    flat = x.reshape(batch * channels, window_len)
    power = None
    for taper in tapers:
        spec = torch.stft(flat,
                          n_fft=n_fft,
                          hop_length=hop,
                          win_length=n_fft,
                          window=taper,
                          center=True,
                          pad_mode="reflect",
                          return_complex=True)
        term = spec.real**2 + spec.imag**2
        power = term if power is None else power + term
    power = power / len(tapers)
    return power.reshape(batch, channels, power.shape[-2], power.shape[-1])


class TrialMaskColoring:
    """Layer-2 coloring ``δ = Σ_spatial^{1/2} · ISTFT(m ⊙ z)`` with ``d′ = ‖z‖₂``.

    The gain ``m`` is computed once from the clean windows ``x0`` (no gradient): the
    multitaper spectrogram of every (sample, channel), divided by its mean over time and
    frequency, floored at ``floor`` (relative), renormalised to unit mean, and square-rooted.
    A silent channel (zero power) gets a flat gain.

    Args:
        x0: ``(B, C, T)`` clean windows.
        spatial_sqrt: ``(C, C)`` square root of Σ_spatial (identity allowed).
        n_fft: STFT size (shrunk for very short windows).
        hop: STFT hop (``n_fft / 4`` satisfies the overlap-add condition for the Hann window).
        nw: Time-half-bandwidth product of the DPSS tapers.
        k: Number of DPSS tapers.
        floor: Relative floor of the power gain ``P / mean P``.
        unit_gain: Use ``m ≡ 1`` (Layer 1 with a white spectrum; for tests and ablations).
    """

    def __init__(self,
                 x0: torch.Tensor,
                 spatial_sqrt: torch.Tensor,
                 n_fft: int = 16,
                 hop: int = 4,
                 nw: float = 2.0,
                 k: int = 3,
                 floor: float = 1e-3,
                 unit_gain: bool = False):
        if x0.ndim != 3:
            raise ValueError(f"Expected (B, C, T) windows, got {tuple(x0.shape)}.")
        self.batch_size, self.num_channels, self.window_len = (int(s) for s in x0.shape)
        if spatial_sqrt.shape != (self.num_channels, self.num_channels):
            raise ValueError(f"spatial_sqrt must be {self.num_channels}x{self.num_channels}, "
                             f"got {tuple(spatial_sqrt.shape)}.")
        if not floor > 0:
            raise ValueError(f"floor must be positive, got {floor}.")
        self.n_fft, self.hop = _stft_size(self.window_len, n_fft, hop)
        self.num_freqs = self.n_fft // 2 + 1
        dtype = x0.dtype if x0.is_floating_point() else torch.float32
        device = x0.device
        self.spatial_sqrt = spatial_sqrt.to(device=device, dtype=dtype)
        self.window = torch.hann_window(self.n_fft, device=device, dtype=dtype)
        # Tight-frame normalisation: mean of Σ_k w²(t − kH) and the one-sided bin weights.
        self.overlap = float((self.window**2).sum()) / self.hop
        weights = torch.full((self.num_freqs,), 2.0**0.5, device=device, dtype=dtype)
        weights[0] = 1.0
        if self.n_fft % 2 == 0:
            weights[-1] = 1.0
        self.bin_weights = weights.view(1, 1, -1, 1)
        self.frames = 1 + self.window_len // self.hop
        with torch.no_grad():
            power = multitaper_spectrogram(x0.detach().to(dtype), self.n_fft, self.hop,
                                           dpss_tapers(self.n_fft, nw, k))
            if unit_gain:
                gain = torch.ones_like(power)
            else:
                mean = power.mean(dim=(2, 3), keepdim=True)
                relative = torch.where(mean > 0, power / mean.clamp_min(1e-30),
                                       torch.ones_like(power))
                relative = relative.clamp_min(floor)
                relative = relative / relative.mean(dim=(2, 3), keepdim=True)
                gain = relative.sqrt()
        self.gain = gain
        self.frames = int(gain.shape[-1])

    # -- the normalised STFT frame ------------------------------------------------------
    def analysis(self, x: torch.Tensor) -> torch.Tensor:
        """Normalised STFT of ``(B, C, T)`` windows in the layout of ``z``: ``(B, C, F, frames, 2)``.

        Tight-frame normalisation (orthonormal DFT, one-sided bins weighted by √2, divided by
        the root window overlap), so ``‖analysis(x)‖ ≈ ‖x‖`` (exact away from the window edges).
        """
        batch, channels, window_len = x.shape
        spec = torch.stft(x.reshape(batch * channels, window_len),
                          n_fft=self.n_fft,
                          hop_length=self.hop,
                          win_length=self.n_fft,
                          window=self.window.to(x.dtype),
                          center=True,
                          pad_mode="reflect",
                          normalized=True,
                          return_complex=True)
        spec = spec.reshape(batch, channels, self.num_freqs, -1)
        spec = spec * self.bin_weights / self.overlap**0.5
        return torch.view_as_real(spec)

    def synthesis(self, z: torch.Tensor) -> torch.Tensor:
        """Least-squares inverse of :py:meth:`analysis`: ``(B, C, F, frames, 2) -> (B, C, T)``."""
        spec = torch.view_as_complex(z.contiguous())
        batch, channels = spec.shape[:2]
        spec = spec / self.bin_weights * self.overlap**0.5
        signal = torch.istft(spec.reshape(batch * channels, self.num_freqs, -1),
                             n_fft=self.n_fft,
                             hop_length=self.hop,
                             win_length=self.n_fft,
                             window=self.window.to(z.dtype),
                             center=True,
                             normalized=True,
                             length=self.window_len)
        return signal.reshape(batch, channels, self.window_len)

    # -- the Coloring interface ---------------------------------------------------------
    def _shape(self, batch_size: int) -> Tuple[int, ...]:
        return (batch_size, self.num_channels, self.num_freqs, self.frames, 2)

    def init_z(self, x0: torch.Tensor) -> torch.Tensor:
        """Zero perturbation ``(B, C, F, frames, 2)``."""
        return x0.new_zeros(self._shape(x0.shape[0]))

    def color(self, z: torch.Tensor) -> torch.Tensor:
        """``δ = Σ_spatial^{1/2} · synthesis(m ⊙ z)``: ``(B, C, T)``, linear in ``z``."""
        if tuple(z.shape[1:]) != self._shape(1)[1:]:
            raise ValueError(f"Expected z of shape (B, {self._shape(1)[1:]}), got {tuple(z.shape)}.")
        masked = z * self.gain.to(device=z.device, dtype=z.dtype).unsqueeze(-1)
        local = self.synthesis(masked)
        return torch.einsum("ij,bjt->bit", self.spatial_sqrt.to(device=z.device, dtype=z.dtype),
                            local)

    def dprime(self, z: torch.Tensor) -> torch.Tensor:
        """d′ = ``‖z‖₂`` per sample."""
        return torch.linalg.vector_norm(z.reshape(z.shape[0], -1), dim=1)

    def random_z(self,
                 x0: torch.Tensor,
                 radius: Union[float, torch.Tensor],
                 generator: Optional[torch.Generator] = None) -> torch.Tensor:
        """Random ``z`` with ``‖z_i‖₂ = radius_i`` (uniform direction)."""
        shape = self._shape(x0.shape[0])
        if generator is not None:
            z = torch.randn(shape, generator=generator, device=generator.device, dtype=x0.dtype)
            z = z.to(x0.device)
        else:
            z = torch.randn(shape, device=x0.device, dtype=x0.dtype)
        norm = self.dprime(z).clamp_min(1e-12)
        radius = torch.as_tensor(radius, dtype=z.dtype, device=z.device)
        if radius.ndim == 0:
            radius = radius.expand(shape[0])
        return z * (radius / norm).view(-1, 1, 1, 1, 1)
