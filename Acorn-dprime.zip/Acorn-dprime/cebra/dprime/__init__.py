"""ε as a detectability index (d′) for adversarial training of CEBRA (see ``DPRIME_DESIGN.md``).

Modules:
    noise        Layer 1: noise covariance Σ = Σ_spatial ⊗ Σ_temporal, coloring/whitening, d′.
    trial_mask   Layer 2: trial-level time–frequency masking (multitaper spectrogram).
    guards       Layer 3: physiological guards with tolerances from natural variability.
    attacks      d′-PGD (APGD / PGD, restarts, guard backtracking), DDN minimum-norm attack.
    calibration  ε_JND, ε_NN, ε_det (detectors), ε* and the robustness margin.
    training     The d′ adversarial training used by ``cebra.solver`` in
                 ``adv_epsilon_mode="dprime"``.
"""

from cebra.dprime import attacks
from cebra.dprime import calibration
from cebra.dprime import guards
from cebra.dprime import noise
from cebra.dprime import trial_mask
from cebra.dprime.attacks import dprime_pgd
from cebra.dprime.attacks import min_norm_ddn
from cebra.dprime.calibration import robustness_margin
from cebra.dprime.guards import GuardSet
from cebra.dprime.noise import fit_noise_model
from cebra.dprime.noise import NoiseModel
from cebra.dprime.trial_mask import TrialMaskColoring

__all__ = [
    "attacks",
    "calibration",
    "guards",
    "noise",
    "trial_mask",
    "dprime_pgd",
    "min_norm_ddn",
    "robustness_margin",
    "GuardSet",
    "fit_noise_model",
    "NoiseModel",
    "TrialMaskColoring",
]
