"""d-prime (detectability-index) adversarial budgets for ACORN. See DPRIME_DESIGN.md."""
