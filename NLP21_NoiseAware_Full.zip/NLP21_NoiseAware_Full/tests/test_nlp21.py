import hashlib
import json
from pathlib import Path
import numpy as np
import pytest
import torch
from nlp21.attacks import noise, calibration, fit_contexts, DprimeAttack, l2_attack
from nlp21.metrics import edit_distance, ctc_loss, evaluate
from nlp21.data import BatchStream, collate
from nlp21.training import make_model, train_model
from utils.augmentation import Unfolder

# Keep smoke tests small; production defaults are tested by runner-plan assertions.
torch.set_num_threads(2)


def config(out='unused'):
    return dict(out_dir=str(out),datasetPath='unused',device='cpu',seed=0,
        ceb_out=8,kernel=4,stride=4,hidden=8,layers=1,dropout=0.0,
        bidir=True,cebra_unfolder=False,gru=True,gauss_in=True,no_gauss=False,
        no_rnn=False,ceb_bn=False,cebra_window_10=False,
        is_speech=False,nlp_10=False,is_nejm=False,adv=True,adv_norm='l2',
        method='pgd_l2',adv_eps=.8,attack_steps=1,dprime_window=36,aligned_labels=None,
        batchSize=2,nBatch=2,offset=2,cont_batch=8,temperature=.4,
        sample_single=False,random_offset=True,all_ref=False,no_noise=True,
        whiteNoiseSD=.8,constantOffsetSD=.2,lrStart=.001,lrEnd=.0001,l2_decay=1e-5,
        resume=False,no_amp=True,eval_every=1,save_every=1)


def items():
    g=torch.Generator().manual_seed(12)
    return [(torch.randn(t,192,generator=g),'ab',0) for t in (80,88,96)]


def test_original_source_hashes():
    root=Path(__file__).resolve().parents[1]
    for name,digest in json.loads((root/'FROZEN_SHA256.json').read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest


def test_unfolder_lengths():
    u=Unfolder(32,4)
    x,ll=u(torch.zeros(2,100,192),torch.tensor([100,96]))
    assert ll.tolist()==[18,17]
    assert x.shape[1]==18


def test_cer_ctc_and_infeasible_targets():
    assert edit_distance([1,2],[1,3,2])==1
    logits=torch.full((1,5,4),-8.)
    logits[0,torch.arange(5),torch.tensor([1,1,0,2,2])]=8
    class Stub(torch.nn.Module):
        def forward(self,x,lengths):return logits,torch.tensor([5])
    r=evaluate(Stub(),[(torch.zeros(5,192),'>,',0)],1,torch.device('cpu'))
    assert r['cer']==0 and r['characters']==2
    with pytest.raises(ValueError,match='CTC-infeasible'):
        ctc_loss(torch.randn(1,2,4),torch.tensor([[1,1]]),torch.tensor([2]),torch.tensor([2]))


def test_end_to_end_ctc_gradients():
    torch.manual_seed(2)
    model=make_model(config(),torch.device('cpu'))
    x,y,xl,yl,_=collate(items()[:2]); logits,ll=model(x,xl)
    ctc_loss(logits,y,ll,yl).backward()
    for name,module in [('encoder',model.cebra),('gru',model.rnn),('head',model.final_decoder)]:
        assert any(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum()>0
                   for p in module.parameters()),name


@pytest.mark.parametrize('eps',[.5,.8,1,2,3,6])
def test_dprime_budget_padding_and_gradient(eps):
    cov=np.array([[2.,.4],[.4,1.]])
    ctx={0:dict(covariances=[cov],window=36,epsilons=[eps])}
    attack=DprimeAttack(ctx,torch.device('cpu'))
    x=torch.zeros(2,80,2); lengths=torch.tensor([80,53]); sessions=torch.tensor([0,0])
    direction=torch.arange(x.numel()).reshape_as(x).float()/100
    xa=attack(x,lengths,sessions,lambda v:(v*direction).sum(),steps=3)
    delta=xa-x
    assert torch.count_nonzero(delta[1,53:])==0
    pad=torch.nn.functional.pad(delta,(0,0,0,28))
    blocks=pad.reshape(2,3,36,2).permute(0,1,3,2).reshape(-1,2,36)
    assert torch.max(attack.models[0].dprime(blocks))<=eps+1e-4
    assert (xa*direction).sum()>0


def test_l2_identity_geometry_equivalence():
    x=torch.zeros(2,8,3); lens=torch.tensor([8,5]); sessions=torch.tensor([0,0])
    objective=lambda v:v.sum()
    ctx={0:dict(covariances=[np.eye(3)],window=1,epsilons=[.8])}
    torch.manual_seed(3); a=l2_attack(x,lens,objective,.8,2)
    torch.manual_seed(3); b=DprimeAttack(ctx,torch.device('cpu'))(x,lens,sessions,objective,2)
    # Pool selection consumes RNG in dprime; compare boundary and final direction, not draws.
    assert a.norm(dim=-1).max()<=.80001 and b.norm(dim=-1).max()<=.80001
    assert a[1,5:].abs().sum()==0 and b[1,5:].abs().sum()==0


def test_frozen_calibration_single_trial_equivalence():
    rng=np.random.default_rng(3)
    x=np.cumsum(rng.normal(size=(150,3)),axis=0)+rng.normal(size=(150,3))
    ctx=fit_contexts([(torch.tensor(x), 'ab',0)],'SPDIFF_AUTOSIG',.8)
    nm,_=noise.fit_noise_model(x,window_len=36,residual_mode='difference',
                              temporal_method='white',kronecker_channels=0)
    expected=min(calibration.eps_energy_detector(3,36),
                 .24*calibration.eps_signal(x,nm.spatial_cov,nm.temporal_cov,lag=1))
    assert ctx[0]['epsilons'][0]==pytest.approx(expected,rel=1e-8)
    with pytest.raises(ValueError,match='AUTO_BEH'):
        fit_contexts([(torch.tensor(x),'ab',0)],'SPDIFF_AUTOBEH',.8)


def test_batchstream_resume():
    a=BatchStream(items(),2,42);a.next();s=a.state_dict()
    b=BatchStream(items(),2,99);b.load_state_dict(s)
    for _ in range(4):
        aa,bb=a.next(),b.next()
        for x,y in zip(aa,bb):assert torch.equal(x,y)


def test_train_save_resume_exact_and_eval(tmp_path,monkeypatch):
    import nlp21.training as tr
    split={'train':items(),'seed_holdout':items()[:1],
           'online_no_recalibration':items()[1:2], 'online_recalibration':items()[2:]}
    monkeypatch.setattr(tr,'load_splits',lambda *args,**kwargs:split)
    a=config(tmp_path/'full'); train_model(a)
    expected=torch.load(tmp_path/'full/modelWeights',weights_only=True)
    original=tr.atomic_torch
    def crash(path,obj):
        original(path,obj)
        if Path(path).name=='modelWeights':raise RuntimeError('simulated interruption')
    monkeypatch.setattr(tr,'atomic_torch',crash)
    b=config(tmp_path/'resumed')
    with pytest.raises(RuntimeError,match='simulated'):train_model(b)
    monkeypatch.setattr(tr,'atomic_torch',original)
    b['resume']=True;train_model(b)
    got=torch.load(tmp_path/'resumed/modelWeights',weights_only=True)
    assert all(torch.equal(expected[k],got[k]) for k in expected)
    r=json.loads((tmp_path/'resumed/results.json').read_text())
    assert r['completed_steps']==2 and r['metrics']['all_eval']['characters']==6


def test_default_runner_plan():
    from run_nlp21 import DEFAULT_ARMS,ARMS,BASE
    assert len(DEFAULT_ARMS)==10
    assert ARMS['PGD_L2_EPS0.8']==('pgd_l2',.8)
    assert {ARMS[x][1] for x in DEFAULT_ARMS if x.startswith('SPDIFF_D')}=={.5,.8,1.,2.,3.,6.}
    assert '--no_noise' in BASE and '--gru' in BASE


def test_mat_loader_split_boundaries(tmp_path):
    from scipy.io import savemat
    from nlp21.data import load_splits
    paths=['seed_model_training_data/mat','online_evaluation_data/no_recalibration/mat',
           'online_evaluation_data/recalibration/mat']
    rng=np.random.default_rng(9)
    for sub in paths:
        path=tmp_path/sub;path.mkdir(parents=True)
        feats=np.empty((1,3),object);texts=np.empty((1,3),object);blocks=np.empty((1,3),object)
        for i in range(3):
            feats[0,i]=rng.normal(size=(80+i*4,192)).astype(np.float32)
            texts[0,i]='ab';blocks[0,i]=np.array([[i+1]])
        savemat(path/'session.mat',{'tx_feats':feats,'sentences':texts,'blocks':blocks})
    got=load_splits(tmp_path)
    assert len(got['train'])==2 and len(got['seed_holdout'])==1
    assert len(got['online_no_recalibration'])==len(got['online_recalibration'])==3
    assert got['seed_holdout'][0][0].shape==(88,192)
    assert all(torch.isfinite(x).all() for split in got.values() for x,_,_ in split)


@pytest.mark.parametrize('arm',['SPDIFF_AUTOSIG','SP_AUTOSIG','SP_AUTOSIG_POOL'])
def test_auto_modes_and_pool_budgets(arm):
    rng=np.random.default_rng(1)
    trials=[(torch.tensor(np.cumsum(rng.normal(size=(100,3)),axis=0),dtype=torch.float32),'ab',0)
            for _ in range(2)]
    ctx=fit_contexts(trials,arm,.8)
    assert len(ctx[0]['epsilons'])==(2 if arm.endswith('POOL') else 1)
    assert all(0<e<=ctx[0]['cap'] for e in ctx[0]['epsilons'])
    attack=DprimeAttack(ctx,torch.device('cpu'))
    x=torch.zeros(2,80,3)
    out=attack(x,torch.tensor([80,53]),torch.tensor([0,0]),lambda xx:xx.sum(),steps=1)
    assert torch.isfinite(out).all() and out[1,53:].abs().sum()==0


def test_full_ctc_model_dprime_attack():
    torch.manual_seed(8)
    model=make_model(config(),torch.device('cpu'))
    x,y,xl,yl,sessions=collate(items()[:2])
    ctx={0:dict(covariances=[np.eye(192)],window=36,epsilons=[.8])}
    attack=DprimeAttack(ctx,torch.device('cpu'))
    def objective(xx):
        logits,ll=model(xx,xl)
        return ctc_loss(logits,y,ll,yl)
    xa=attack(x,xl,sessions,objective,steps=2)
    assert torch.isfinite(xa).all() and not torch.equal(xa,x)
    assert torch.equal(xa[0,80:],x[0,80:])
    objective(xa).backward()
    assert model.final_decoder.weight.grad.abs().sum()>0
    assert next(model.cebra.parameters()).grad.abs().sum()>0
