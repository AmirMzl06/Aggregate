# Preservation boundary and NLP21 adapter

This is a new NLP21 integration, not an unchanged Perich protocol. Original code is retained in original_sources; original dprime numerical modules are immutable and hash-checked. The source archive and active code are deliberately separate.

## Unchanged scientific core

Ledoit-Wolf spatial covariance; difference residual `(x[t]-x[t-1])/sqrt(2)` or whole residual; white temporal covariance; symmetric covariance roots and exact noise.color/whiten; detector energy cap; 0.24 signal fraction; 0.363 behaviour fraction and floor 1; empirical + isotropic covariance pool; whitened PGD normalization and projection. All original dprime modules, including other research utilities, are archived; only the methods listed in README are integrated as runnable training arms.

The bundled NLP21 encoder implementation is the user's CEBRA-main fork, not Acorn-SVD or an installed replacement. CTC + InfoNCE train encoder/GRU/head jointly. A clean Adam update followed by an adversarial Adam update per iteration preserves the provided trainer's optimization scheme.

## Explicit sequence-adapter choices

1. Fit each training-session covariance from its own training trials only. Difference/whole residuals are computed and centered within each trial using the unchanged residual function, then pooled for Ledoit-Wolf. This removes fictitious trial-boundary increments. It differs from treating all trials as one continuous Perich recording.
2. With white temporal covariance, eps_sig² = 2*T*g1. Compute the original `signal_lag_traces(...,1)` independently within each trial and average signed lag-1 traces with weights n_trial-1. Then apply the original fraction and cap. Do not average individually clipped budgets or silently substitute a fixed epsilon when signal is nonpositive. A single-trial equivalence test compares against original fit_noise_model + eps_signal.
3. Behaviour mode, when valid independent aligned continuous behaviour is supplied, uses original cross-fitted behaviour_prediction and eps_behaviour separately per trial; combine squared scales weighted by trial length, then original fraction/cap/floor. This preserves primitives but adapts aggregation to trials. It is not available from transcripts alone and is not in default runs. Nonfinite per-trial behaviour estimates fail explicitly.
4. Fixed dprime budgets constrain each nonoverlapping 36-bin raw-input window, not the full trial. This is a new blockwise full-sequence attack adapter: all windows are optimized jointly through the full CTC + InfoNCE loss. The original Perich attack acted on sampled encoder windows; numerical budget equality does not imply an identical threat set. White temporal covariance makes masked partial windows well-defined. There are no attack increments in padded bins. Pool index is sampled once per session/batch and held fixed during the inner attack, with its own calibrated budget.
5. The original PGD-L2 axis (channels per time bin) and random radius distribution are retained. Padding is masked for both methods, whereas the original trainer also perturbed padding. Training-step attack loss uses the model's training-mode dropout, as in the original. This is the training attack, not a benchmark-strength robustness evaluator.
6. Data normalization is unchanged: each block uses its own unlabeled mean/std, including evaluation blocks. This is the original offline, block-normalized/transductive preprocessing convention, not a training-statistics-only deployment claim. Noise/epsilon fitting uses train only. Seed holdout and online subsets are separated; online labels do not calibrate epsilon or select checkpoints.

## Engineering fixes applied identically to all arms

- Seed initialization occurs before model construction (original trainer seeded afterwards).
- Correct Unfolder output lengths to floor((L-kernel)/stride)+1. The original omitted +1; old-checkpoint CER is therefore not guaranteed numerically identical. PyTorch reference: https://docs.pytorch.org/docs/stable/generated/torch.nn.Unfold.html
- CTC receives float32 log probabilities in [T,B,C]; explicitly check repeated-character alignment feasibility. `zero_infinity=True` remains, but infeasible targets raise instead of being silently ignored. Reference: https://docs.pytorch.org/docs/stable/generated/torch.nn.CTCLoss.html
- Fail immediately on nonfinite objective/gradients; never backward/step on NaN.
- Fixed batch-permutation stream independent of attack RNG, checkpointed with all RNG/optimizer/scheduler state and completed step count. Validate config and hash of training samples on resume. No silent checkpoint reset.
- Save modelWeights after the final step; original saved only when batch%150==0, leaving final iterations unsaved.
- One process/GPU avoids incorrect mutable-attribute embedding access under DataParallel.
- CER is character-weighted with per-trial edit counts. Separate split evaluation avoids silently truncating differently sized online file lists via zip. Batch order is fixed within each split and differs from the original interleaved online evaluator; bidirectional GRU padding can make ordering/batching affect predictions. All new arms share the same evaluation order and batch size. Do not mix old CER and new CER in a paired comparison.

## Operational scope

The supported active experiment path is NLP21 with the user's Offset36 + GRU setup. Speech/nlp10 and alternate encoder modes are not validated and are rejected. Their original sources remain in the archived project. `utils/trainer.py` is the untouched legacy trainer, retained as reference; active start_trainer imports nlp21.training.

Full EPFL-data training and H200 CUDA validation require the user's cluster. Synthetic CPU tests cannot establish better CER or validate memory requirements of batchSize=16, hidden=1024, layers=5 on the real longest trials. Runner logs preserve failures and resume from the latest successful checkpoint. Requirements specify compatible packages, not a fully locked cluster environment; tested local package versions are in TEST_ENVIRONMENT.txt.
