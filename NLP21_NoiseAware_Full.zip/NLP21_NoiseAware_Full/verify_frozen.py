import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
for name,want in json.loads((root/'FROZEN_SHA256.json').read_text()).items():
    got=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if got!=want:raise SystemExit('MODIFIED: '+name)
print('FROZEN DPRIME SOURCE VERIFIED')
