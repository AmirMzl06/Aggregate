"""NLP21 paths and normalization from the supplied loader; no temporal joins."""
from pathlib import Path
import torch
from utils.data_loader import get_input
from utils.dataset import charset


def load_splits(root, gauss_in=True, no_gauss=False, train=True):
    root = Path(root)
    paths = {'train': root/'seed_model_training_data/mat',
             'seed_holdout': root/'seed_model_training_data/mat',
             'online_no_recalibration': root/'online_evaluation_data/no_recalibration/mat',
             'online_recalibration': root/'online_evaluation_data/recalibration/mat'}
    out = {}
    for name, path in paths.items():
        if name == 'train' and not train:
            continue
        if not path.is_dir() or not any(path.rglob('*.mat')):
            raise FileNotFoundError(f'Missing NLP21 MAT files: {path}')
        out[name] = get_input(str(path), norm=True,
            gauss=not (gauss_in or no_gauss), train=name == 'train',
            valid=name == 'seed_holdout', gauss_sigma=2.0)
        if not out[name]:
            raise ValueError(f'Empty split: {name}')
    return out


def collate(items):
    xs, texts, sessions = zip(*items)
    lengths = torch.tensor([len(x) for x in xs], dtype=torch.long)
    xpad = torch.stack([torch.cat([x, x[-1:].expand(int(lengths.max())-len(x), -1)]) for x in xs])
    ys = [torch.tensor(charset.text_to_int(t), dtype=torch.long) for t in texts]
    if any(len(y) == 0 for y in ys):
        raise ValueError('Empty encoded transcript; check character mapping.')
    ypad = torch.nn.utils.rnn.pad_sequence(ys, batch_first=True)
    return xpad, ypad, lengths, torch.tensor([len(y) for y in ys]), torch.tensor(sessions)


class BatchStream:
    """Checkpointable permutation stream; sampling independent of attack RNG."""
    def __init__(self, items, batch_size, seed):
        self.items, self.batch_size = items, batch_size
        self.generator = torch.Generator().manual_seed(seed)
        self.order = []; self.position = 0

    def next(self):
        if self.position >= len(self.order):
            self.order = torch.randperm(len(self.items), generator=self.generator).tolist()
            self.position = 0
        ids = self.order[self.position:self.position+self.batch_size]
        self.position += len(ids)
        return collate([self.items[i] for i in ids])

    def state_dict(self):
        return {'order': self.order, 'position': self.position, 'generator': self.generator.get_state()}

    def load_state_dict(self, state):
        self.order, self.position = state['order'], state['position']
        self.generator.set_state(state['generator'].cpu())
