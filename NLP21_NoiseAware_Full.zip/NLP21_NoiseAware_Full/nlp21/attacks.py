"""Full-sequence loss; L2 per time bin, dprime per nonoverlapping raw-time window."""
import importlib.util
from pathlib import Path
import sys
import numpy as np
import torch


def frozen_module(name):
    key = 'nlp21_frozen_' + name
    if key in sys.modules:
        return sys.modules[key]
    path = Path(__file__).resolve().parents[1]/'frozen_dprime'/f'{name}.py'
    spec = importlib.util.spec_from_file_location(key, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


noise = frozen_module('noise')
calibration = frozen_module('calibration')


def fit_contexts(items, arm, fixed_eps, window=36, seed=0, aligned_labels=None):
    """Per training-session covariance; no evaluation items accepted by the caller.

    Trial adapter pools residuals and lag traces without cross-trial differences.
    Original numerical routines and calibration fractions are kept unchanged.
    """
    if 'AUTOBEH' in arm and aligned_labels is None:
        raise ValueError('AUTO_BEH requires --aligned-labels NPZ containing train-only, independently '
                         'time-aligned continuous behaviour. Transcripts are not aligned behaviour.')
    labels = np.load(aligned_labels, allow_pickle=False) if aligned_labels else None
    contexts = {}
    for sid in sorted({int(d) for _, _, d in items}):
        indexed = [(i, x.detach().cpu().numpy().astype(np.float64))
                   for i, (x, _, d) in enumerate(items) if int(d) == sid]
        if any(len(x) <= window for _, x in indexed):
            raise ValueError(f'Session {sid}: calibration trial too short for window {window}')
        mode = 'difference' if arm.startswith('SPDIFF') else 'whole'
        residuals = np.concatenate([noise.compute_residuals(x, mode=mode) for _, x in indexed])
        cov = noise.spatial_covariance(residuals, 'ledoit_wolf')
        pool = [noise.spatial_covariance(residuals, 'isotropic')] if arm.endswith('_POOL') else None
        nm = noise.NoiseModel(cov, np.eye(window), cov_pool=pool, device='cpu')
        cap = float(calibration.eps_energy_detector(nm.num_channels, window))
        epsilons, signals = [], []
        for pi in range(nm.pool_size):
            if 'AUTOSIG' in arm:
                # Σ_t=I => eps_sig²=2*T*g_1. Average signed traces, not sqrt/NaN values.
                traces = [calibration.signal_lag_traces(x, nm.spatial_cov_of(pi), 1)[1]
                          for _, x in indexed]
                g1 = np.average(traces, weights=[len(x)-1 for _, x in indexed])
                if not np.isfinite(g1) or g1 <= 0:
                    raise ValueError(f'Session {sid}: no positive signal estimate; no fallback epsilon.')
                sig = float(np.sqrt(2*window*g1))
                eps = min(cap, 0.24*sig)
            elif 'AUTOBEH' in arm:
                vals, weights = [], []
                for i, x in indexed:
                    key = f'trial_{i:06d}'
                    if key not in labels:
                        raise ValueError(f'Missing aligned label key {key}')
                    y = labels[key]
                    if len(y) != len(x):
                        raise ValueError(f'{key}: labels must match the neural time axis')
                    pred, _ = calibration.behaviour_prediction(x, y,
                        lags=(-8,-4,0,4,8), features=400, folds=5, seed=seed)
                    value = calibration.eps_behaviour(x, pred, nm.spatial_cov_of(pi), nm.temporal_cov)
                    if not np.isfinite(value):
                        raise ValueError(f'{key}: invalid behaviour signal, no fallback epsilon')
                    vals.append(value**2); weights.append(len(x))
                sig = float(np.sqrt(np.average(vals, weights=weights)))
                eps = max(1., min(cap, 0.363*sig))
            else:
                sig = None; eps = float(fixed_eps)
            if not np.isfinite(eps) or eps <= 0:
                raise ValueError(f'Invalid budget: {eps}')
            signals.append(sig); epsilons.append(eps)
        contexts[sid] = {'covariances': nm.spatial_covs, 'window': window,
            'epsilons': epsilons, 'signal_scales': signals, 'cap': cap, 'arm': arm,
            'residual_mode': mode, 'n_trials': len(indexed), 'n_bins': sum(len(x) for _, x in indexed)}
    if labels is not None:
        labels.close()
    return contexts


class DprimeAttack:
    def __init__(self, contexts, device):
        self.contexts = contexts
        self.models = {sid: noise.NoiseModel(ctx['covariances'][0], np.eye(ctx['window']),
                       cov_pool=ctx['covariances'][1:], device=device) for sid, ctx in contexts.items()}

    def __call__(self, x, lengths, sessions, objective, steps=10):
        b, t, c = x.shape
        window = next(iter(self.contexts.values()))['window']
        blocks = (t+window-1)//window
        shape = (b, blocks, c, window)
        valid = torch.arange(blocks*window, device=x.device)[None] < lengths[:, None]
        mask = valid.reshape(b, blocks, 1, window)
        pool_indices = {sid: int(torch.randint(nm.pool_size, ()).item()) for sid, nm in self.models.items()}
        budget = torch.tensor([self.contexts[int(s)]['epsilons'][pool_indices[int(s)]]
                               for s in sessions.tolist()], device=x.device).reshape(b,1,1,1)

        def color(z):
            colored = torch.zeros_like(z)
            for sid, nm in self.models.items():
                sel = sessions == sid
                if sel.any():
                    zz = z[sel].reshape(-1,c,window)
                    colored[sel] = nm.color(zz, pool_index=pool_indices[sid]).reshape(-1,blocks,c,window)
            return colored.permute(0,1,3,2).reshape(b,blocks*window,c)[:, :t]

        def norm(z):
            return z.square().sum((-2,-1),keepdim=True).sqrt().clamp_min(1e-12)
        z = torch.randn(shape, device=x.device) * mask
        z = z/norm(z) * budget * torch.rand((b,blocks,1,1), device=x.device)
        for _ in range(steps):
            z = z.detach().requires_grad_(True)
            loss = objective(x + color(z))
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite dprime attack loss')
            grad, = torch.autograd.grad(loss, z)
            if not torch.isfinite(grad).all():
                raise FloatingPointError('Nonfinite dprime attack gradient')
            with torch.no_grad():
                grad = grad * mask
                z = (z + (budget/5.0)*grad/norm(grad))*mask
                z = z*(budget/norm(z)).clamp(max=1.)
        return (x+color(z.detach())).detach()


def l2_attack(x, lengths, objective, eps=0.8, steps=10):
    # Original norm axis and radial initialization; mask padded bins consistently.
    mask = (torch.arange(x.shape[1], device=x.device)[None] < lengths[:,None])[...,None]
    z = torch.randn_like(x)*mask
    norm = lambda a: a.norm(p=2,dim=-1,keepdim=True).clamp_min(1e-12)
    z = z/norm(z) * eps * torch.rand((*x.shape[:2],1), device=x.device)
    for _ in range(steps):
        z = z.detach().requires_grad_(True)
        loss = objective(x+z)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite L2 attack loss')
        grad, = torch.autograd.grad(loss,z)
        if not torch.isfinite(grad).all():
            raise FloatingPointError('Nonfinite L2 attack gradient')
        with torch.no_grad():
            z = (z+(eps/5.)*grad/norm(grad))*mask
            z = z*(eps/norm(z)).clamp(max=1.)
    return (x+z).detach()
