import contextlib
import hashlib
import json
import os
from pathlib import Path
import pickle
import random
import numpy as np
import torch
from utils.model import Encoder_Decoder
from utils.criterion import InfoNCE
from utils.sample_positive_negative import get_batch
from .data import load_splits, BatchStream
from .metrics import ctc_loss, evaluate
from .attacks import fit_contexts, DprimeAttack, l2_attack


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False


def make_model(a, device):
    return Encoder_Decoder(192, a['ceb_out'], a['kernel'], a['stride'], 32,
        a['hidden'], a['layers'], a['dropout'], a['bidir'], a['cebra_unfolder'],
        a['gru'], 2.0, gauss_in=a['gauss_in'] and not a['no_gauss'],
        no_rnn=a['no_rnn'], cebra_bn=a['ceb_bn'],
        cebra_window_10=a['cebra_window_10']).to(device)


def atomic_json(path, obj):
    p=Path(path); tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False)); os.replace(tmp,p)


def atomic_torch(path, obj):
    p=Path(path); tmp=p.with_suffix(p.suffix+'.tmp')
    torch.save(obj,tmp); os.replace(tmp,p)


def rng_state():
    return {'python':random.getstate(), 'numpy':np.random.get_state(),
            'torch':torch.get_rng_state(),
            'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def restore_rng(s):
    random.setstate(s['python']); np.random.set_state(s['numpy']); torch.set_rng_state(s['torch'].cpu())
    if s['cuda'] is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([v.cpu() for v in s['cuda']])


def fingerprint(items):
    h=hashlib.sha256()
    for x, y, d in items:
        h.update(str((tuple(x.shape),str(y),int(d))).encode())
        h.update(x.contiguous().numpy().tobytes())
    return h.hexdigest()


def canonical_args(a):
    return {k:v for k,v in a.items() if k not in ('resume','out_dir','device','eval_every','save_every')}


def train_model(a):
    if a['is_speech'] or a['nlp_10'] or a['is_nejm']:
        raise ValueError('This experiment entry point is for NLP21 only; original sources are archived.')
    if a['adv_norm'] != 'l2' and a['adv'] and a['method'] == 'pgd_l2':
        raise ValueError('Use --adv_norm l2 for the requested baseline.')
    if a['ceb_bn'] or a['cebra_window_10'] or a['cebra_unfolder'] or a['no_rnn']:
        raise ValueError('This validated experiment uses the supplied default Offset36 -> GRU architecture.')
    if any(a[k]<1 for k in ('batchSize','nBatch','offset','attack_steps','eval_every','save_every','dprime_window')):
        raise ValueError('Batch size, steps and offset must be positive')
    if 'AUTOBEH' in a['method'] and not a['aligned_labels']:
        raise ValueError('AUTO_BEH needs independent train-only time-aligned behaviour; see README.')
    device=torch.device(a['device'])
    if device.type=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable. Use --device cpu for smoke tests only.')
    if device.type=='cuda':
        device = torch.device('cuda', device.index if device.index is not None else 0)
        torch.cuda.set_device(device)
    seed_all(a['seed'])
    out=Path(a['out_dir']); out.mkdir(parents=True,exist_ok=True)
    cp=out/'checkpoint.pt'
    if cp.exists() and not a['resume']:
        raise FileExistsError(f'{cp} exists; use --resume or a new out_dir')
    if a['resume'] and not cp.exists():
        raise FileNotFoundError(f'--resume requested but {cp} is missing')
    splits=load_splits(a['datasetPath'],a['gauss_in'],a['no_gauss'])
    data_hash=fingerprint(splits['train'])
    model=make_model(a,device)
    optimizer=torch.optim.Adam(model.parameters(),lr=a['lrStart'],betas=(0.9,0.999),
                               eps=0.1,weight_decay=a['l2_decay'])
    scheduler=torch.optim.lr_scheduler.LinearLR(optimizer,start_factor=1.,
        end_factor=a['lrEnd']/a['lrStart'],total_iters=a['nBatch'])
    stream=BatchStream(splits['train'],a['batchSize'],a['seed'])
    contexts=None; completed=0
    if a['resume']:
        state=torch.load(cp,map_location='cpu',weights_only=False)
        if canonical_args(a)!=canonical_args(state['args']) or data_hash!=state['data_sha256']:
            raise ValueError('Checkpoint configuration/data mismatch; use a new output directory')
        model.load_state_dict(state['model_state_dict'])
        optimizer.load_state_dict(state['optimizer_state_dict'])
        for s in optimizer.state.values():
            for k,v in s.items():
                if torch.is_tensor(v): s[k]=v.to(device)
        scheduler.load_state_dict(state['scheduler_state_dict'])
        stream.load_state_dict(state['stream']); completed=state['completed_steps']
        contexts=state['contexts']; restore_rng(state['rng'])
    elif a['method'].startswith('SP'):
        contexts=fit_contexts(splits['train'],a['method'],a['adv_eps'],
            a['dprime_window'],a['seed'],a['aligned_labels'])
    attack=DprimeAttack(contexts,device) if contexts else None
    if contexts:
        note={str(k):{kk:vv for kk,vv in v.items() if kk!='covariances'} for k,v in contexts.items()}
        atomic_json(out/'calibration.json',note)
    atomic_json(out/'config.json',a)
    with (out/'args').open('wb') as f: pickle.dump(a,f)
    amp=device.type=='cuda' and not a['no_amp'] and torch.cuda.is_bf16_supported()
    criterion=InfoNCE(a['temperature'])

    def save(step):
        atomic_torch(cp,{'model_state_dict':model.state_dict(),'optimizer_state_dict':optimizer.state_dict(),
            'scheduler_state_dict':scheduler.state_dict(),'completed_steps':step,
            'args':a,'data_sha256':data_hash,'contexts':contexts,'stream':stream.state_dict(),'rng':rng_state()})
        atomic_torch(out/'modelWeights',model.state_dict())
        atomic_json(out/'training_progress.json',{'completed_steps':step,'target_steps':a['nBatch']})

    for step in range(completed,a['nBatch']):
        model.train()
        x,y,xl,yl,sessions=[t.to(device) for t in stream.next()]
        if not a['no_noise']:
            x=x+torch.randn_like(x)*a['whiteNoiseSD']
            x=x+torch.randn((len(x),1,x.shape[-1]),device=device)*a['constantOffsetSD']
        # Sample the contrastive pairs once, then reuse them in all inner/outer adversarial passes.
        with torch.autocast(device.type,dtype=torch.bfloat16,enabled=amp):
            pred,lengths=model(x,xl)
            emb,el=model.get_cebra_embs()
            if int(el.min()) <= 2*a['offset']+1:
                raise ValueError('Trial too short for the original contrastive sampler and offset')
            sampled=get_batch(emb,el,a['cont_batch'],a['offset'],a['sample_single'],
                              a['random_offset'],True,a['all_ref'])
            ref,pos,neg,*indices=sampled
            contrast=criterion(ref,pos,neg)[0]
        clean=ctc_loss(pred,y,lengths,yl)+contrast
        if not torch.isfinite(clean): raise FloatingPointError('Nonfinite clean loss')
        optimizer.zero_grad(set_to_none=True); clean.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),5.,error_if_nonfinite=True); optimizer.step()

        def objective(xx, inner=True):
            with torch.autocast(device.type,dtype=torch.bfloat16,enabled=amp):
                logits,ll=model(xx,xl); ee,_=model.get_cebra_embs()
                rb,rt,pt,nb,nt=indices
                rr,pp,nn=ee[rb,rt],ee[rb,pt],ee[nb,nt]
                if inner: pp,nn=pp.detach(),nn.detach()
                cont=criterion(rr,pp,nn)[0]
            return ctc_loss(logits,y,ll,yl)+cont

        if a['adv'] or attack is not None:
            if attack is None:
                xa=l2_attack(x.detach(),xl,objective,a['adv_eps'],a['attack_steps'])
            else:
                xa=attack(x.detach(),xl,sessions,objective,a['attack_steps'])
            optimizer.zero_grad(set_to_none=True)
            advloss=objective(xa,inner=False)
            if not torch.isfinite(advloss): raise FloatingPointError('Nonfinite outer adversarial loss')
            advloss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),5.,error_if_nonfinite=True); optimizer.step()
        scheduler.step()
        done=step+1
        if done%a['eval_every']==0 or done==a['nBatch']:
            # Monitoring only; final weights, never online-CER-based model selection.
            r=evaluate(model,splits['seed_holdout'],a['batchSize'],device,amp)
            record={'step':done,'seed_holdout_CER':r['cer'],'ctc_loss':r['ctc_loss'],'clean_loss':float(clean.detach())}
            with (out/'history.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
            print(f"step {done}/{a['nBatch']} | seed_holdout CER: {r['cer']:.6f} ({r['cer_percent']:.2f}%) | CTC: {r['ctc_loss']:.6f}",flush=True)
        if done%a['save_every']==0 or done==a['nBatch']: save(done)
    evaluate_run(a,model=model,splits=splits)


def evaluate_run(a,model=None,splits=None):
    supplied_model = model is not None
    device=torch.device(a['device']); out=Path(a['out_dir'])
    if model is None:
        model=make_model(a,device)
        model.load_state_dict(torch.load(out/'modelWeights',map_location=device,weights_only=True))
    if splits is None: splits=load_splits(a['datasetPath'],a['gauss_in'],a['no_gauss'],train=False)
    results={}
    for name,items in splits.items():
        if name=='train':continue
        r=evaluate(model,items,a['batchSize'],device,
                   device.type=='cuda' and not a['no_amp'] and torch.cuda.is_bf16_supported())
        atomic_json(out/f'{name}_trials.json',r.pop('trials'))
        results[name]=r
        print(f"{name} | CER: {r['cer']:.6f} ({r['cer_percent']:.2f}%) | CTC loss: {r['ctc_loss']:.6f}",flush=True)
    for name,keys in [('online_combined',['online_no_recalibration','online_recalibration']),
                      ('all_eval',['seed_holdout','online_no_recalibration','online_recalibration'])]:
        edits=sum(results[k]['edits'] for k in keys); chars=sum(results[k]['characters'] for k in keys)
        results[name]={'edits':edits,'characters':chars,'cer':edits/chars,'cer_percent':100*edits/chars}
        print(f"{name} | CER: {edits/chars:.6f} ({100*edits/chars:.2f}%)",flush=True)
    progress = ({'completed_steps':a['nBatch']} if supplied_model else
        json.loads((out/'training_progress.json').read_text()))
    atomic_json(out/'results.json',{'method':a['method'],
        'epsilon':None if 'AUTO' in a['method'] else a['adv_eps'],
        'eval_data_sha256':{k:fingerprint(v) for k,v in splits.items() if k!='train'},
        'seed':a['seed'],'completed_steps':progress['completed_steps'],'metrics':results})
    return results
