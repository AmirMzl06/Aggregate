"""Micro CER: sum of character edits / sum of reference characters."""
import torch
from .data import collate


def edit_distance(a, b):
    row = list(range(len(b)+1))
    for i, x in enumerate(a, 1):
        nxt = [i]
        for j, y in enumerate(b, 1):
            nxt.append(min(nxt[-1]+1, row[j]+1, row[j-1]+(x != y)))
        row = nxt
    return row[-1]


def ctc_loss(logits, y, lengths, y_len):
    # A repeated adjacent target requires an intervening blank frame.
    repeats = ((y[:, 1:] == y[:, :-1]) &
        (torch.arange(y.shape[1]-1, device=y.device)[None] < (y_len-1)[:, None])).sum(1)
    if torch.any(lengths < y_len + repeats):
        raise ValueError('CTC-infeasible trial: output frames < target length + repeats.')
    with torch.autocast(logits.device.type, enabled=False):
        return torch.nn.functional.ctc_loss(logits.float().log_softmax(-1).transpose(0, 1),
            y, lengths.to('cpu', dtype=torch.long), y_len.to('cpu', dtype=torch.long),
            blank=0, reduction='mean', zero_infinity=True)


@torch.no_grad()
def evaluate(model, items, batch_size, device, amp=False):
    was_training = model.training
    model.eval()
    edits = chars = 0
    loss_sum = 0.0
    trials = []
    for start in range(0, len(items), batch_size):
        x, y, xl, yl, sessions = [t.to(device) for t in collate(items[start:start+batch_size])]
        with torch.autocast(device.type, dtype=torch.bfloat16, enabled=amp):
            logits, lengths = model(x, xl)
        loss_sum += float(ctc_loss(logits, y, lengths, yl)) * len(x)
        for i in range(len(x)):
            hyp = logits[i, :int(lengths[i])].argmax(-1).unique_consecutive().tolist()
            hyp = [v for v in hyp if v != 0]
            ref = y[i, :int(yl[i])].tolist()
            e = edit_distance(ref, hyp)
            edits += e; chars += len(ref)
            trials.append({'trial': start+i, 'session': int(sessions[i]), 'edits': e,
                           'characters': len(ref), 'reference_ids': ref, 'prediction_ids': hyp})
    model.train(was_training)
    return {'cer': edits/chars, 'cer_percent': 100*edits/chars, 'edits': edits,
            'characters': chars, 'ctc_loss': loss_sum/len(items), 'n_trials': len(items), 'trials': trials}
