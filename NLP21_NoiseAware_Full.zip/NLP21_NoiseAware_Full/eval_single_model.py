"""Evaluate final NLP21 weights: original CLI, with CER explicitly reported."""
import argparse
import json
from pathlib import Path
from nlp21.training import evaluate_run

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out_dir',required=True)
    p.add_argument('--datasetPath',required=True)
    p.add_argument('--batch_size',type=int,default=None)
    p.add_argument('--device',default='cuda')
    a=p.parse_args()
    config=json.loads((Path(a.out_dir)/'config.json').read_text())
    config.update(out_dir=a.out_dir,datasetPath=a.datasetPath,device=a.device)
    if a.batch_size is not None: config['batchSize']=a.batch_size
    evaluate_run(config)

if __name__=='__main__':main()
