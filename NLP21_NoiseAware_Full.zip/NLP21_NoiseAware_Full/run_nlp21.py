#!/usr/bin/env python3
"""Plan/run/status/summarize paired NLP21 experiments, one process per GPU."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import json
import os
from pathlib import Path
import queue
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
ARMS={'PGD_L2_EPS0.8':('pgd_l2',0.8),
      **{f'SPDIFF_D{v}':('SPDIFF_FIXED',float(v)) for v in ('0.8','0.5','1','2','3','6')},
      **{x:(x,0.8) for x in ('SPDIFF_AUTOSIG','SP_AUTOSIG','SP_AUTOSIG_POOL',
                             'SPDIFF_AUTOBEH','SP_AUTOBEH','SP_AUTOBEH_POOL')}}
DEFAULT_ARMS=list(ARMS)[:10]
BASE=['--offset','4','--gru','--gauss_in','--bidir','--batchSize','16',
      '--whiteNoiseSD','0.8','--constantOffsetSD','0.2','--adv','--adv_norm','l2',
      '--no_noise','--random_offset','--hidden','1024','--dropout','0.4',
      '--layers','5','--kernel','32','--stride','4']


def jobs(a):
    result=[]
    for seed in a.seeds:
        for arm in a.arms:
            method,eps=ARMS[arm]
            out=(a.out/arm/f'seed{seed}').resolve()
            cmd=[sys.executable,'-u',str(ROOT/'start_trainer.py'),*BASE,
                 '--datasetPath',str(a.datasetPath.resolve()),'--out_dir',str(out),
                 '--nBatch',str(a.nBatch),'--seed',str(seed),'--method',method,
                 '--adv_eps',str(eps),'--dprime_window',str(a.dprime_window)]
            if a.aligned_labels:cmd+=['--aligned_labels',str(a.aligned_labels.resolve())]
            result.append({'arm':arm,'seed':seed,'out':str(out),'command':cmd})
    return result


def status(job):
    p=Path(job['out'])
    if (p/'DONE.json').exists():return 'done'
    if (p/'checkpoint.pt').exists():return 'checkpoint'
    if (p/'failure.json').exists():return 'failed'
    return 'pending'


def summarize(planned,out):
    rows=[]
    eval_hashes=None
    for j in planned:
        p=Path(j['out'])/'results.json'
        if not p.exists():continue
        r=json.loads(p.read_text())
        if eval_hashes is None:eval_hashes=r.get('eval_data_sha256')
        elif eval_hashes!=r.get('eval_data_sha256'):
            raise ValueError('Evaluation sample hashes differ across runs')
        for split,m in r['metrics'].items():
            rows.append({'arm':j['arm'],'seed':j['seed'],'split':split,
                         'cer':m['cer'],'cer_percent':m['cer_percent'],
                         'edits':m['edits'],'characters':m['characters']})
    if not rows:
        print('No completed evaluation results.');return
    baseline={(r['seed'],r['split']):r for r in rows if r['arm']=='PGD_L2_EPS0.8'}
    for r in rows:
        b=baseline.get((r['seed'],r['split']))
        r['delta_CER_vs_PGD']=r['cer']-b['cer'] if b else ''
        r['better_than_PGD']=r['cer']<b['cer'] if b else ''
        if b and b['characters']!=r['characters']:
            raise ValueError('Evaluation reference counts differ across arms')
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Primary comparison: all_eval. Negative delta means better CER than PGD.')
    for r in rows:
        if r['split']=='all_eval':
            d=r['delta_CER_vs_PGD']
            print(f"{r['arm']:24s} seed={r['seed']} CER={r['cer']:.6f} delta={d}")
    print('Saved',out/'summary.csv')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['plan','run','status','summarize'])
    p.add_argument('--datasetPath',type=Path,default=Path('/data/hossein/mm_project/CORP_data_release'))
    p.add_argument('--out',type=Path,default=Path('NLP21_RESULTS'))
    p.add_argument('--arms',nargs='+',choices=list(ARMS),default=DEFAULT_ARMS)
    p.add_argument('--seeds',nargs='+',type=int,default=[0])
    p.add_argument('--gpus',nargs='+',default=['0'])
    p.add_argument('--nBatch',type=int,default=20000)
    p.add_argument('--dprime-window',type=int,default=36)
    p.add_argument('--aligned-labels',type=Path)
    p.add_argument('--resume',action='store_true')
    a=p.parse_args()
    if len(a.arms)!=len(set(a.arms)) or len(a.seeds)!=len(set(a.seeds)) or len(a.gpus)!=len(set(a.gpus)):
        p.error('Duplicate arms/seeds/GPUs are not allowed')
    if any('AUTOBEH' in x for x in a.arms) and not a.aligned_labels:
        p.error('AUTO_BEH requires --aligned-labels; transcript-based pseudo-alignments are not substituted')
    a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=True)
    manifest=a.out/'plan.json'; planned=jobs(a)
    if manifest.exists():
        old=json.loads(manifest.read_text())
        if a.stage in ('status','summarize'):planned=old
        elif old!=planned:raise ValueError('Plan differs from existing plan.json; use a new --out')
    elif a.stage in ('plan','run'):
        manifest.write_text(json.dumps(planned,indent=2))
    if a.stage=='plan':
        import shlex
        for j in planned:print(shlex.join(j['command']))
        print(f'Total runs: {len(planned)}');return
    if a.stage=='status':
        for j in planned:print(j['arm'],j['seed'],status(j))
        print('DONE',sum(status(j)=='done' for j in planned),'/',len(planned));return
    if a.stage=='summarize':summarize(planned,a.out);return
    # Fail before launching anything if output reuse was not explicitly requested.
    for j in planned:
        if Path(j['out']).exists() and not a.resume:
            raise FileExistsError(f"{j['out']} exists; use --resume")
    pending=queue.Queue()
    for j in planned:
        if status(j)!='done':pending.put(j)
    failures=[]
    def worker(gpu):
        while True:
            try:j=pending.get_nowait()
            except queue.Empty:return
            out=Path(j['out']);out.mkdir(parents=True,exist_ok=True)
            cmd=list(j['command'])
            if (out/'checkpoint.pt').exists():cmd+=['--resume']
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=gpu,OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
            print('START',gpu,j['arm'],j['seed'],flush=True)
            try:
                with (out/'run.log').open('a') as log:
                    subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
                if not (out/'results.json').is_file():raise RuntimeError('Training exited without results.json')
                if json.loads((out/'results.json').read_text())['completed_steps'] != a.nBatch:
                    raise RuntimeError('Evaluation is from an incomplete training run')
                (out/'DONE.json').write_text(json.dumps({'command':j['command']}))
                (out/'failure.json').unlink(missing_ok=True)
                print('DONE',gpu,j['arm'],j['seed'],flush=True)
            except Exception as e:
                failures.append(j)
                (out/'failure.json').write_text(json.dumps({'error':str(e)}))
                print('FAILED',gpu,j['arm'],'see',out/'run.log',flush=True)
    with ThreadPoolExecutor(max_workers=len(a.gpus)) as pool:
        list(pool.map(worker,a.gpus))
    summarize(planned,a.out)
    if failures:raise SystemExit(f'{len(failures)} runs failed; rerun with --resume')

if __name__=='__main__':main()
