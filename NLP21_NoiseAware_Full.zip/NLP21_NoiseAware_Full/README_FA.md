# NLP21 — PGD-L2 و Noise-Aware d′، آموزش end-to-end

هدف: آیا روش‌های ما پس از آموزش، روی **همان دادهٔ ارزیابی** CER کمتری از PGD-L2 با ε=0.8 دارند؟ نتیجهٔ واقعی هنوز اندازه‌گیری نشده است. داده و GPU کلاستر داخل این ZIP نیست.

## اجرای سریع

در محیط Python/CUDA فعلی خودت، پوشه را جدا از پروژهٔ قبلی باز کن:

```bash
unzip NLP21_NoiseAware_Full.zip
cd NLP21_NoiseAware_Full
python -m pip install -r requirements_experiment.txt
python verify_frozen.py
python -m pytest -q tests
python run_nlp21.py plan --out NLP21_RESULTS
python run_nlp21.py run --out NLP21_RESULTS --gpus 0 1 2 3
```

مسیر پیش‌فرض داده `/data/hossein/mm_project/CORP_data_release` است. برای تغییر آن `--datasetPath` بده. از PyTorch با پشتیبانی CUDA در محیط فعلی استفاده کن؛ لازم نیست CEBRA دیگری نصب کنی، کد CEBRA خود ZIP همراه بسته است.

هر GPU یک آزمایش مستقل اجرا می‌کند؛ یک مدل روی چهار GPU شکسته نمی‌شود. علت: مدل اولیه embedding را در attribute نگه می‌دارد و DataParallel آن را درست برای InfoNCE جمع‌آوری نمی‌کند.

پیش‌فرض: seed=0، تعداد iteration=20000، ۱۰ گام PGD. با `--seeds 0 1` تعداد اجراها ۲۰ می‌شود. `--nBatch` فقط برای اجرای آزمایشی قابل تغییر است؛ مقایسهٔ نهایی باید برای همه یکسان باشد.

ادامه پس از قطع:

```bash
python run_nlp21.py run --out NLP21_RESULTS --gpus 0 1 2 3 --resume
python run_nlp21.py status --out NLP21_RESULTS
python run_nlp21.py summarize --out NLP21_RESULTS
```

برای resume همان گزینه‌های plan اولیه، به‌ویژه seeds، arms، nBatch و datasetPath را تکرار کن. اجرای کامل‌شده دوباره آموزش نمی‌بیند. خطای checkpoint پنهان نمی‌شود و به شروع از صفر تبدیل نمی‌شود. `--resume` از آخرین checkpoint ذخیره‌شده ادامه می‌دهد؛ پیش‌فرض هر ۱۵۰ iteration. RNG، ترتیب batchها، optimizer و scheduler ذخیره می‌شوند. برابری بیت‌به‌بیت روی CPU در تست بررسی می‌شود؛ الگوریتم‌های CUDA الزاماً قطعی نیستند.

## حالت‌ها

| نام رانر | روش | بودجه |
|---|---|---|
| PGD_L2_EPS0.8 | baseline دستور خودت | L2 = 0.8 به ازای هر bin زمانی |
| SPDIFF_D0.8 | Noise-aware، difference residual | d′ = 0.8 |
| SPDIFF_D0.5 | همان | d′ = 0.5 |
| SPDIFF_D1 | همان | d′ = 1 |
| SPDIFF_D2 | همان | d′ = 2 |
| SPDIFF_D3 | همان | d′ = 3 |
| SPDIFF_D6 | همان | d′ = 6 |
| SPDIFF_AUTOSIG | انتخاب خودکار، difference residual | min(cap, 0.24 × eps_sig) |
| SP_AUTOSIG | انتخاب خودکار، whole residual | همان فرمول |
| SP_AUTOSIG_POOL | covariance pool تجربی + isotropic | همان فرمول برای هر covariance |

این ۱۰ حالت پیش‌فرض‌اند. برای اجرای فقط هفت حالت دستی:

```bash
python run_nlp21.py run --out NLP21_FIXED --gpus 0 1 2 3 --arms PGD_L2_EPS0.8 SPDIFF_D0.8 SPDIFF_D0.5 SPDIFF_D1 SPDIFF_D2 SPDIFF_D3 SPDIFF_D6
```

## دستور مستقیم baseline

```bash
python start_trainer.py --datasetPath /data/hossein/mm_project/CORP_data_release --offset 4 --out_dir nlp21-l208-rdpns0-offset10ro --gru --gauss_in --bidir --batchSize 16 --whiteNoiseSD 0.8 --constantOffsetSD 0.2 --adv --adv_eps 0.8 --adv_norm l2 --no_noise --random_offset --hidden 1024 --dropout 0.4 --layers 5 --nBatch 20000 --kernel 32 --stride 4 --seed 0
```

برای نسخهٔ D0.8 همین دستور را با `--method SPDIFF_FIXED` و out_dir مستقل اجرا کن. برای D0.5 مقدار `--adv_eps 0.5` و برای بقیه مقدار متناظر را بده. برای AUTO_SIG از `--method SPDIFF_AUTOSIG` استفاده کن؛ مقدار `adv_eps` در این حالت بودجه را تعیین نمی‌کند و بودجهٔ واقعی داخل `calibration.json` است.

ارزیابی:

```bash
python eval_single_model.py --datasetPath /data/hossein/mm_project/CORP_data_release --out_dir nlp21-l208-rdpns0-offset10ro
```

این entry point مدل‌های همین بسته را با `config.json` می‌خواند. اسکریپت اصلی ارزیابی و پروژهٔ اولیه بدون تغییر داخل `original_sources/nlpich-main.zip` نگه داشته شده‌اند؛ برای checkpointهای قدیمی از کد سازندهٔ همان checkpoint استفاده کن.

## چه چیزهایی دقیقاً حفظ شده‌اند؟

- فایل‌های اصلی dprime از `Exp13_bundle.zip/Acorn-dprime/cebra/dprime` کپی شده‌اند؛ هیچ بایت از آن‌ها و فرمول‌هایشان تغییر نکرده است. SHA256 داخل `FROZEN_SHA256.json` است.
- نسخهٔ مرجع `multi_dprime_bridge.py` و یادداشت طراحی اصلی داخل `frozen_dprime` هستند.
- معماری CEBRA خود nlpich، Gaussian smoothing، Unfolder، GRU دوطرفه و linear head حفظ شده‌اند.
- loss اصلی برابر `CTC + InfoNCE` است. در هر iteration یک به‌روزرسانی clean و یک به‌روزرسانی adversarial مثل trainer اولیه داریم. تمام پارامترهای encoder، GRU و head در optimizer هستند.
- PGD از ۱۰ گام و alpha=epsilon/5 استفاده می‌کند. همان جفت‌های contrastive در گام‌های حمله استفاده می‌شوند؛ positive و negative فقط در inner attack از گرادیان جدا می‌شوند، مثل کد اولیه.
- baseline نرم L2 را روی محور کانال‌ها در **هر bin زمانی** اعمال می‌کند؛ نرم کل trial نیست.
- `--no_noise` افزودن نویز تصادفی augmentation را خاموش می‌کند؛ `--gauss_in` smoothing داخل مدل را روشن نگه می‌دارد، این دو یکی نیستند.

**ولی اتصال به nlp21 یک adapter جدید است، نه اجرای بایت‌به‌بایت آزمایش Perich.** اجتناب از تغییر هسته به معنی اجتناب از نوشتن adapter نیست. انتخاب‌های ضروری adapter در فایل `METHOD_AND_CHANGES.md` دقیق آمده‌اند.

## تعریف d′ و طول پنجره

حمله در فضای سفیدشده z انجام می‌شود: `delta = noise.color(z)` و `||z||₂ ≤ d`.

برای دنبالهٔ طول‌متغیر، پنجره‌های غیرهمپوشان **۳۶ bin در ورودی عصبی، پیش از smoothing و unfolding** ساخته می‌شوند. هر پنجره بودجهٔ خودش را دارد؛ دنبالهٔ کامل یک بودجهٔ واحد ندارد. آخرین پنجره ناقص است و بخش padding حمله نمی‌شود. temporal covariance مثل bridge قبلی white است. طول ۳۶ در اینجا لزوماً receptive field خام مدل نیست، چون مدل قبل از CEBRA unfolding دارد.

مقدار عددی D0.8 با L2=0.8 هم‌ارز نیست؛ هم هندسه و هم واحد اعمال بودجه متفاوت‌اند. این آزمایش کیفیت CER روش‌های آموزشی را مقایسه می‌کند، نه robustness با بودجهٔ فیزیکی مساوی. تغییر `--dprime-window` تعریف آزمایش را تغییر می‌دهد و باید در پوشه و plan جدا ثبت شود. پیش‌فرض ثابت ۳۶ است.

## AUTO_BEH و شرط حفظ ایده

`AUTO_BEH` اصلی به رفتار پیوستهٔ هم‌تراز با هر bin نیاز دارد. متن trial در nlp21 آن اطلاعات را ندارد. کد اصلی موجود است و فرمول `max(1, min(cap, 0.363*eps_beh))` حفظ شده، اما این حالت‌ها بدون دادهٔ مناسب اجرا نمی‌شوند:

- SPDIFF_AUTOBEH
- SP_AUTOBEH
- SP_AUTOBEH_POOL

اختیار `--aligned-labels` در رانر (یا `--aligned_labels` در start_trainer) یک NPZ می‌پذیرد که `trial_000000`, `trial_000001`, ... را برای **همهٔ trialهای train پس از فیلتر دیتالودر و با همان ترتیب** دارد؛ هر آرایه `[T_i, behaviour_features]` است. طول آن باید با trial عصبی یکسان باشد. فقط برچسب مستقل از decoder ارزیابی و خارج از holdout مجاز است. کد انطباق هم‌ترازی را از روی شکل آرایه بررسی می‌کند؛ اعتبار علمی منبع برچسب را نمی‌تواند تضمین کند.

هیچ forced alignment، تکرار یکسان کاراکترها روی زمان، یا جایگزینی AUTO_SIG به‌جای AUTO_BEH انجام نشده است. از متن تنها نمی‌توان همین AUTO_BEH قبلی را بدون تعریف ایدهٔ جدید فعال کرد.

## معیار نتیجه

CER = مجموع Levenshtein edits روی کاراکترها / مجموع تعداد کاراکتر مرجع. CTC decoding از نوع greedy و بدون language model است. همان charset پروژهٔ اصلی استفاده می‌شود؛ CER بر حسب token کاراکترهای این charset است، WER نیست.

`results.json` و `summary.csv` این بخش‌ها را جدا دارند:

- seed_holdout: آخرین block هر فایل seed-model
- online_no_recalibration
- online_recalibration
- online_combined: تجمیع دو بخش آنلاین
- all_eval: تجمیع تمام سه بخش، متناظر با دامنهٔ دادهٔ eval_single_model اولیه

**مقایسهٔ اصلی برای سؤال تو all_eval است**؛ online_combined و دو بخش آنلاین جدا هم گزارش می‌شوند تا اختلاف پنهان نماند. تجمیع با مجموع تعداد کاراکتر انجام می‌شود، نه میانگین ساده CER trialها.

`delta_CER_vs_PGD = CER_method - CER_PGD`؛ عدد منفی یعنی CER کمتر و بهتر. مدل نهایی پس از دقیقاً 20000 iteration مقایسه می‌شود؛ انتخاب checkpoint با CER آنلاین انجام نمی‌شود. monitoring فقط روی seed_holdout است. انتخاب بهترین D با test CER یک نتیجهٔ اکتشافیِ sweep است، نه انتخاب خودکار بی‌نشت. برای ادعای برتری تکرار با چند seed و ارزیابی مستقل لازم است. این baseline تنها PGD با ε=0.8 است، نه «بهترین PGD ممکن».

این بسته CER **clean پس از آموزش adversarial** را می‌سنجد. بهترشدن این CER به‌تنهایی اثبات مقاومت در برابر حملهٔ زمان آزمون نیست.
