#!/usr/bin/env python3
"""Exp15: the 1/2 rule, an automatic training budget without fitted constants (Perich tests).

Keep next to Acorn-dprime and dprime_exp9.py. It reuses the runner's training, decoder, evaluation,
folders and GPU queue unchanged; the fork is not changed (v5). synthetic_benchmark.py imports the
same arms and the same jackknife for its "halfrule" suite.

Why. Each automatic budget has one fitted constant, the fraction x* of the separation it refers to:
auto_beh 0.363 of eps_beh (supervised) and auto_sig 0.24 of eps_sig (time-only). Both were set by
matching DIFF8 (the mean of 8 / eps over the nine Exp5-8 sessions), so they inherit the hand-picked
budget 8. The decoders break where theory says they should: an attack of size eps_task / 2 moves a
window to the midpoint between two states of the signal the objective keeps (x = 1/2; Exp10 LOSO
0.505-0.53; the pre-registered x_beh >= 0.5 rule had AUC 0.954 in Exp11 and 0.988 in Exp14). So the
budget is referenced to the midpoint instead of to DIFF8:

    HALF   supervised  eps = max(1, min((2D)^(1/4), 1/2 * eps_beh,low))
           time-only   eps =        min((2D)^(1/4), 1/2 * eps_sig,low)

eps_task,low is the one-sided 95% lower bound of eps_task, exp(-1.645 * SE) * eps_task, with SE the
leave-one-block-out jackknife standard error of log eps_task over 10 contiguous blocks of the
training data (the fork's own estimator, refitted without each block). Only conventions are left
(JND = 1, 95%), no fitted number. Before any training the coordinator computes the fraction
1/2 * exp(-1.645 * SE) of every session, writes it to HALF_RULE.json (pre-registration), and the
worker passes it to the fork's auto_beh / auto_sig (adv_dprime_beh_fraction / _sig_fraction).

Exp14 facts behind the design (EXP14_ALL_RESULTS.csv, no training):
  - The cap (2D)^(1/4) binds in 22/30 supervised and 15/28 time-only sessions. There the fraction
    does not matter and HALF = AUTO, so only sessions where the rule changes the budget are run
    (screened from --data-dir before training).
  - Within sessions, log kappa rose with log budget below the midpoint (slope 0.32 supervised, 0.11
    time-only) and fell off a cliff above it (DIFF8 at x_beh 0.76 in C-RT1: AUTO x10.8).
  - Time-only runs never went above x_sig = 0.33, so the time-only cliff is untested (ladder-time).

Suites (seeds 42 43; 3,000 iterations; evaluation as Exp12-14: --eval-refine 4 --eval-kappa
--no-eval-margins are the defaults here):
  half-sup     MADRY_SPDIFF_AUTOBEH vs MADRY_SPDIFF_HALFBEH on the screened sessions (at most
               --max-sessions, in a seeded random order).
  half-time    MADRY_SPDIFF_AUTOSIG vs MADRY_SPDIFF_HALFSIG, the same for time-only.
  ladder-sup   DIFF at x_beh = 0.30 / 0.42 / 0.54 / 0.66 of eps_beh, no cap (MADRY_SPDIFF_XBEH30 ...),
               on the first --ladder-sessions screened sessions: where is the supervised cliff?
  ladder-time  DIFF at x_sig = 0.30 / 0.42 / 0.54 / 0.66 of eps_sig, no cap (MADRY_SPDIFF_XSIG30 ...):
               is the time-only cliff also at 1/2?
  A ladder suite writes into the folder of the half suite of its mode, so its runs are paired with
  AUTO and HALF in the same sessions and seeds.

Pre-registered in <output-root>/HALF_RULE.json and HALF_RULE_PREDICTIONS.csv before any training
(never overwritten; new sessions and arms are only added):
  R1 supervised: no HALFBEH run fails (refined reference eps1/2 < 0.5).
  R2 supervised: kappa(HALFBEH) / kappa(AUTOBEH) > 1 (session bootstrap CI above 1), about
     (budget ratio)^0.32 as predicted from Exp14.
  R3 time-only (exploratory): no HALFSIG failure, and the ratio > 1 (predicted (budget ratio)^0.11).
  L1 supervised ladder: failures only at x_beh >= 0.5 (the Exp10 rule), and kappa at 0.54 and 0.66
     not above kappa at 0.42 (the gain stops at the midpoint).
  L2 time-only ladder (exploratory): the same with x_sig.

Usage (4 GPUs). --dry-run screens the sessions, pre-registers and prints the plan, without training;
the screen runs on the CPU once per output folder (about 10-30 s per session that needs the
jackknife) and is then reused.
  python -u half_rule.py --suite half-sup --dry-run
  python -u half_rule.py --suite half-sup --gpu-workers 4
  python -u half_rule.py --suite ladder-sup --gpu-workers 4
  python -u half_rule.py --suite half-time --gpu-workers 4
  python -u half_rule.py --suite ladder-time --gpu-workers 4
  python half_rule.py --summarize > exp15_report.txt
Re-running with --resume skips finished jobs.
"""
from __future__ import annotations

import csv
import io
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import dprime_exp9 as runner  # noqa: E402  training, decoder, evaluation and queue of Exp11-14

HALF = 0.5           # the midpoint: theory, not fitted
Z_RISK = 1.645       # one-sided 95 % lower bound of eps_task
JACKKNIFE_BLOCKS = 10
Q_FLOOR = 0.05       # keeps the fraction positive if the jackknife fails (no signal in a block)
HALF_FRACTION = "half_jackknife"  # sentinel of the HALF arms, resolved per session before training
CHANGE_TOLERANCE = 0.05  # |log(HALF / AUTO budget)| below this: the rule does not change the session
LADDER_SYNTH = (0.20, 0.30, 0.36, 0.42, 0.48, 0.54, 0.60, 0.70)
LADDER_PERICH = (0.30, 0.42, 0.54, 0.66)
ELASTICITY = {"supervised": 0.32, "time_only": 0.11}  # Exp14: d log kappa / d log budget
FAIL_REF_HALF = 0.5  # failure: refined reference eps1/2 below 0.5 (Exp11-14)
REFINE_FLOOR = 0.5 / 16  # below_floor: the bisection's smallest budget (an upper bound)
REFINE_TOP = 16.0        # above_grid: the largest evaluation budget (a lower bound)
MODES = ("supervised", "time_only")
TASK = {"supervised": "beh", "time_only": "sig"}
AUTO = {"supervised": "MADRY_SPDIFF_AUTOBEH", "time_only": "MADRY_SPDIFF_AUTOSIG"}
HALF_ARM = {"supervised": "MADRY_SPDIFF_HALFBEH", "time_only": "MADRY_SPDIFF_HALFSIG"}
AUTO_FRACTION = {"supervised": runner.BEH_FRACTION, "time_only": runner.SIG_FRACTION}
OUTPUT = {"supervised": "DPRIME_EXP15_HALF_SUPERVISED", "time_only": "DPRIME_EXP15_HALF_TIMEONLY"}
STATE_FILE = "HALF_RULE.json"
PREDICTIONS_FILE = "HALF_RULE_PREDICTIONS.csv"
SCREEN_FILE = "HALF_RULE_SCREEN.csv"
RULE_TEXT = ("HALF: supervised eps = max(1, min((2D)^(1/4), 1/2 * eps_beh,low)); time-only eps = "
             "min((2D)^(1/4), 1/2 * eps_sig,low); eps_task,low = exp(-1.645 * SE) * eps_task, SE the "
             "jackknife SE of log eps_task over 10 contiguous blocks of the training data, in the "
             "training metric of the arm (DIFF: difference residuals, Ledoit-Wolf, white).")
HYPOTHESES = __doc__.split("Pre-registered")[1].split("Usage")[0].strip()

_BASE_CATALOGUE = runner.catalogue
_BASE_WORKER_COMMAND = runner.worker_command


# ============================================================================ arms
def _diff_overrides() -> Dict[str, Any]:
    """The DIFF8 settings without its budget (difference residuals, Ledoit-Wolf, white)."""
    base = {e.name: e for e in _BASE_CATALOGUE()}["MADRY_SPDIFF_D8"].overrides
    return {k: v for k, v in base.items() if k != "adv_dprime_epsilon"}


def _rule_overrides(mode: str, fraction: Any, cap: str) -> Dict[str, Any]:
    """auto_beh (supervised) or auto_sig (time-only) with the given fraction and cap."""
    if TASK[mode] == "beh":
        return dict(adv_dprime_epsilon="auto_beh", adv_dprime_beh_fraction=fraction,
                    adv_dprime_beh_lags=runner.BEH_LAGS,
                    adv_dprime_beh_features=runner.BEH_FEATURES, adv_dprime_sig_cap=cap)
    return dict(adv_dprime_epsilon="auto_sig", adv_dprime_sig_fraction=fraction,
                adv_dprime_sig_lag=runner.SIG_LAG, adv_dprime_sig_cap=cap)


def ladder_name(mode: str, x: float) -> str:
    return f"MADRY_SPDIFF_X{TASK[mode].upper()}{int(round(100 * x)):02d}"


def ladder_arm(mode: str, x: float) -> "runner.Experiment":
    """DIFF at the fraction x of eps_task, without the cap (the fork's auto rule)."""
    return runner.Experiment(ladder_name(mode, x),
                             {**_diff_overrides(), **_rule_overrides(mode, float(x), "none")},
                             TASK[mode] == "beh")


def half_arm(mode: str) -> "runner.Experiment":
    """The HALF rule; its fraction is a sentinel until resolve() inserts the session's value."""
    return runner.Experiment(HALF_ARM[mode],
                             {**_diff_overrides(), **_rule_overrides(mode, HALF_FRACTION, "blind")},
                             TASK[mode] == "beh")


def new_arms() -> List["runner.Experiment"]:
    arms = [half_arm(mode) for mode in MODES]
    for mode in MODES:
        arms += [ladder_arm(mode, x) for x in sorted(set(LADDER_SYNTH) | set(LADDER_PERICH))]
    return arms


def catalogue() -> List["runner.Experiment"]:
    """dprime_exp9's arms plus the half-rule arms."""
    arms = list(_BASE_CATALOGUE()) + new_arms()
    if len(arms) != len({e.name for e in arms}):
        raise RuntimeError("Duplicate arm names")
    return arms


def arm_by_name(name: str) -> Optional["runner.Experiment"]:
    return {e.name: e for e in new_arms()}.get(name)


def is_half(exp: "runner.Experiment") -> bool:
    o = exp.overrides
    return HALF_FRACTION in (o.get("adv_dprime_beh_fraction"), o.get("adv_dprime_sig_fraction"))


def resolve(exp: "runner.Experiment", fraction: Optional[float]) -> "runner.Experiment":
    """The arm with the session's frozen fraction in place of the sentinel (other arms unchanged)."""
    if not is_half(exp):
        return exp
    if fraction is None or not math.isfinite(float(fraction)) or float(fraction) <= 0:
        raise ValueError(f"{exp.name}: no valid pre-registered fraction ({fraction!r})")
    key = "adv_dprime_beh_fraction" if exp.auto_beh else "adv_dprime_sig_fraction"
    return runner.Experiment(exp.name, {**exp.overrides, key: float(fraction)}, exp.supervised_only)


# ============================================================================ the rule
def separations(x: np.ndarray, y: Optional[np.ndarray],
                exp: "runner.Experiment") -> Dict[str, Optional[float]]:
    """eps_sig, and with labels eps_beh and the behaviour R2, in the arm's training metric, with
    the fork's estimators and settings (as the fork computes them inside fit)."""
    from cebra.dprime import calibration, noise
    spatial, temporal = runner._metric_members(exp, x, y, noise)[0]
    out: Dict[str, Optional[float]] = {
        "eps_sig": calibration.eps_signal(x, spatial, temporal, runner.SIG_LAG),
        "eps_beh": None, "behaviour_r2": None}
    if y is not None:
        prediction, model = calibration.behaviour_prediction(
            x, y, lags=runner.BEH_LAGS, features=runner.BEH_FEATURES, seed=0)
        out["eps_beh"] = calibration.eps_behaviour(x, prediction, spatial, temporal)
        out["behaviour_r2"] = float(model["r2"])
    return out


def jackknife(x: np.ndarray, y: Optional[np.ndarray], task: str, exp: "runner.Experiment",
              blocks: int = JACKKNIFE_BLOCKS, z: float = Z_RISK) -> Dict[str, Any]:
    """The half-rule fraction 1/2 * exp(-z * SE) of one recording.

    SE is the leave-one-block-out jackknife standard error of log eps_task over ``blocks``
    contiguous blocks (the remaining blocks are concatenated; one junction per refit).
    """
    key = f"eps_{task}"
    labels = y if task == "beh" else None
    full = separations(x, labels, exp)[key]
    edges = np.linspace(0, len(x), blocks + 1).astype(int)
    values = []
    for start, stop in zip(edges[:-1], edges[1:]):
        keep = np.r_[0:start, stop:len(x)]
        values.append(separations(x[keep], None if labels is None else labels[keep], exp)[key])
    values = np.array([np.nan if v is None else v for v in values], dtype=float)
    ok = full is not None and math.isfinite(full) and full > 0 and bool(np.all(values > 0))
    if ok:
        logs = np.log(values)
        se = math.sqrt((blocks - 1) / blocks * float(np.sum((logs - logs.mean())**2)))
    else:
        se = math.inf
    q = max(math.exp(-z * se), Q_FLOOR)
    return dict(task=task, eps_task=full, eps_jackknife=[float(v) for v in values], se_log=se,
                q=q, eps_task_low=(q * full if ok else None), fraction=HALF * q, blocks=blocks, z=z)


def budget(mode: str, eps_task: Optional[float], fraction: float, cap: float) -> Tuple[float, str]:
    """The fork's auto_beh (supervised) or auto_sig (time-only) budget and what binds it."""
    finite = eps_task is not None and math.isfinite(eps_task)
    if TASK[mode] == "beh":
        if not finite:
            return runner.JND, "floor_jnd"
        value = fraction * eps_task
        if value > cap:
            return cap, "blind_cap"
        if value < runner.JND:
            return runner.JND, "floor_jnd"
        return value, "behaviour"
    if not finite:
        return math.nan, "no_signal"
    value = fraction * eps_task
    return (cap, "blind_cap") if value > cap else (value, "signal")


# ============================================================================ screen + registration
def _clean(value: Any) -> Any:
    """JSON-safe copy (non-finite floats become None)."""
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (int, np.integer)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    return value


def _number(value: Any) -> float:
    return math.nan if value is None else float(value)


def screen_session(args, session: str, mode: str, force_jackknife: bool = False) -> Dict[str, Any]:
    """Budgets of AUTO and HALF for one session (no training). The jackknife runs only where the
    AUTO budget is set by its fraction (elsewhere both rules give the cap) or when forced."""
    from cebra.dprime import calibration
    row: Dict[str, Any] = {"session": session, "mode": mode, "usable": False, "reason": ""}
    try:
        x, _, y, _ = runner.load_data(args.data_dir / f"{session}.npz")
    except Exception as exc:  # an unusable file: record why
        row["reason"] = f"{type(exc).__name__}: {exc}"
        return row
    row.update(n_train=int(len(x)), neurons=int(x.shape[1]), label_dims=int(y.shape[1]))
    if len(x) < args.min_train_bins or x.shape[1] < args.min_channels:
        row["reason"] = f"{len(x)} training bins, {x.shape[1]} neurons"
        return row
    exp = half_arm(mode)  # AUTO, HALF and the ladder share this metric (DIFF)
    seps = separations(x, y, exp)
    task = TASK[mode]
    cap = calibration.eps_energy_detector(x.shape[1], runner.WINDOW)
    eps_task = seps[f"eps_{task}"]
    auto_budget, auto_binding = budget(mode, eps_task, AUTO_FRACTION[mode], cap)
    row.update(seps, eps_task=eps_task, eps_cap=cap, auto_fraction=AUTO_FRACTION[mode],
               auto_budget=auto_budget, auto_binding=auto_binding,
               usable=auto_binding != "no_signal")
    if not row["usable"]:
        row["reason"] = "no signal in the training metric"
        return row
    if auto_binding in ("behaviour", "signal") or force_jackknife:
        jack = jackknife(x, y, task, exp, args.jackknife_blocks)
        half_budget, half_binding = budget(mode, eps_task, jack["fraction"], cap)
        ratio = half_budget / auto_budget
        row.update(jackknife=jack, half_q=jack["q"], half_se_log=jack["se_log"],
                   half_fraction=jack["fraction"], half_budget=half_budget,
                   half_binding=half_binding, budget_ratio=ratio,
                   changed=bool(abs(math.log(ratio)) >= CHANGE_TOLERANCE))
    else:  # AUTO at the cap: HALF is at the cap too unless q < 2 x* (never seen)
        row.update(jackknife=None, half_q=None, half_se_log=None, half_fraction=None,
                   half_budget=None, half_binding="not computed (AUTO at the cap)",
                   budget_ratio=None, changed=False)
    return row


def state_path(root: Path) -> Path:
    return root / STATE_FILE


def save_state(root: Path, state: Dict[str, Any]) -> None:
    runner.atomic_write_json(state_path(root), _clean(state))
    fields = ["session", "usable", "reason", "n_train", "neurons", "behaviour_r2", "eps_beh",
              "eps_sig", "eps_task", "eps_cap", "auto_budget", "auto_binding", "half_q",
              "half_se_log", "half_fraction", "half_budget", "half_binding", "budget_ratio",
              "changed"]
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(_clean(row) for row in state["screen"].values())
    runner.atomic_write_text(root / SCREEN_FILE, stream.getvalue())


def screen(args, mode: str) -> Dict[str, Any]:
    """Screen --data-dir once per output folder (or the --sessions given), stored in
    HALF_RULE.json; later calls reuse it and only add sessions that were not screened."""
    root = args.output_root
    path = state_path(root)
    if path.is_file():
        state = json.loads(path.read_text(encoding="utf-8"))
        if state["mode"] != mode:
            raise RuntimeError(f"{path} belongs to mode {state['mode']}; use another --output-root")
        missing = [s for s in (args.sessions or []) if s not in state["screen"]]
        for session in missing:
            state["screen"][session] = screen_session(args, session, mode)
            print(f"screened {_screen_line(state['screen'][session])}", flush=True)
        if missing:
            save_state(root, state)
        return state
    names = list(args.sessions) if args.sessions else sorted(
        f.stem for f in args.data_dir.glob("*.npz"))
    if not names:
        raise FileNotFoundError(f"No sessions (*.npz) in {args.data_dir}")
    print(f"Screening {len(names)} sessions for {mode} (no training)", flush=True)
    rows = {}
    for session in names:
        rows[session] = screen_session(args, session, mode)
        print(f"screened {_screen_line(rows[session])}", flush=True)
    eligible = [s for s in names if rows[s].get("changed")]
    order = np.random.default_rng(args.selection_seed).permutation(len(eligible))
    state = {
        "created_utc": runner.now_utc(), "mode": mode, "data_dir": str(args.data_dir.resolve()),
        "rule": RULE_TEXT, "hypotheses": HYPOTHESES,
        "constants": {"half": HALF, "z": Z_RISK, "jackknife_blocks": args.jackknife_blocks,
                      "q_floor": Q_FLOOR, "change_tolerance": CHANGE_TOLERANCE,
                      "auto_fraction": AUTO_FRACTION[mode], "elasticity": ELASTICITY[mode],
                      "fail_ref_half": FAIL_REF_HALF, "ladder": list(LADDER_PERICH)},
        "selection_seed": args.selection_seed, "min_train_bins": args.min_train_bins,
        "min_channels": args.min_channels,
        "fork_fingerprints": runner._fingerprints(args.fork_dir, runner.FORK_TRAIN_FILES),
        "screen": rows, "eligible": [eligible[int(i)] for i in order], "registrations": []}
    root.mkdir(parents=True, exist_ok=True)
    save_state(root, state)
    usable = sum(r["usable"] for r in rows.values())
    print(f"{usable} usable sessions; the rule changes the budget in {len(eligible)} -> {path}",
          flush=True)
    return state


def _screen_line(row: Dict[str, Any]) -> str:
    if not row.get("usable"):
        return f"{row['session']}: skipped ({row.get('reason')})"
    text = (f"{row['session']}: n_train {row['n_train']} neurons {row['neurons']} eps_task "
            f"{row['eps_task']:.2f} cap {row['eps_cap']:.2f} | AUTO {row['auto_budget']:.2f} "
            f"({row['auto_binding']})")
    if row.get("half_budget") is not None:
        text += (f" | HALF {row['half_budget']:.2f} ({row['half_binding']}; q {row['half_q']:.3f})"
                 f"{' changed' if row['changed'] else ''}")
    return text


PREDICTION_FIELDS = ["session", "arm", "mode", "eps_task", "eps_beh", "eps_sig", "eps_cap",
                     "fraction", "budget", "binding", "x_task", "x_beh", "x_sig",
                     "predicted_broken", "predicted_kappa_ratio_vs_auto", "registered_utc"]


def register(args, plan: "runner.Plan", state: Dict[str, Any]) -> None:
    """Freeze the fractions of the HALF arms and pre-register budgets and predictions (rows are
    only ever added)."""
    root = args.output_root
    mode = plan.mode
    needs_half = any(is_half(e) for e in plan.arms)
    changed = False
    for session in plan.sessions:
        row = state["screen"].get(session)
        if row is None:
            row = state["screen"][session] = screen_session(args, session, mode, needs_half)
            changed = True
        if not row.get("usable"):
            raise RuntimeError(f"{session} is not usable: {row.get('reason')}")
        if needs_half and row.get("half_fraction") is None:
            state["screen"][session] = screen_session(args, session, mode, force_jackknife=True)
            changed = True
    path = root / PREDICTIONS_FILE
    rows = list(csv.DictReader(path.open(encoding="utf-8"))) if path.is_file() else []
    done = {(r["session"], r["arm"]) for r in rows}
    stamp = runner.now_utc()
    added = []
    for session in plan.sessions:
        s = state["screen"][session]
        for exp in plan.arms:
            if (session, exp.name) in done:
                continue
            if is_half(exp):
                fraction, cap = s["half_fraction"], s["eps_cap"]
            elif exp.name == AUTO[mode]:
                fraction, cap = AUTO_FRACTION[mode], s["eps_cap"]
            else:
                key = "adv_dprime_beh_fraction" if exp.auto_beh else "adv_dprime_sig_fraction"
                fraction = float(exp.overrides[key])
                cap = s["eps_cap"] if exp.overrides.get("adv_dprime_sig_cap") == "blind" else math.inf
            value, binding = budget(mode, _number(s["eps_task"]), fraction, cap)
            row = dict.fromkeys(PREDICTION_FIELDS)
            row.update(session=session, arm=exp.name, mode=mode, eps_task=s["eps_task"],
                       eps_beh=s.get("eps_beh"), eps_sig=s.get("eps_sig"), eps_cap=s["eps_cap"],
                       fraction=fraction, budget=value, binding=binding,
                       x_task=value / _number(s["eps_task"]),
                       x_beh=value / _number(s.get("eps_beh")),
                       x_sig=value / _number(s.get("eps_sig")), registered_utc=stamp)
            row["predicted_broken"] = bool(row["x_task"] >= HALF)
            if is_half(exp) and s.get("auto_budget"):
                row["predicted_kappa_ratio_vs_auto"] = (value / s["auto_budget"])**ELASTICITY[mode]
            rows.append(_clean(row))
            added.append([session, exp.name])
    if added:
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=PREDICTION_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
        runner.atomic_write_text(path, stream.getvalue())
        state["registrations"].append({
            "registered_utc": stamp, "suite": plan.suite, "pairs": added,
            "fork_fingerprints": runner._fingerprints(args.fork_dir, runner.FORK_TRAIN_FILES)})
        changed = True
        print(f"Pre-registered {len(added)} (session, arm) budgets -> {path}", flush=True)
    else:
        print(f"Predictions already registered in {path} (kept unchanged)", flush=True)
    if changed:
        save_state(root, state)


# ============================================================================ runner hooks
SUITES: Dict[str, Dict[str, Any]] = {
    "half-sup": dict(mode="supervised", arms=(AUTO["supervised"], HALF_ARM["supervised"]),
                     sessions=(), max_iterations=runner.MAX_ITER, epochs=None, train_bins=None,
                     output=OUTPUT["supervised"]),
    "half-time": dict(mode="time_only", arms=(AUTO["time_only"], HALF_ARM["time_only"]),
                      sessions=(), max_iterations=runner.MAX_ITER, epochs=None, train_bins=None,
                      output=OUTPUT["time_only"]),
    "ladder-sup": dict(mode="supervised",
                       arms=tuple(ladder_name("supervised", x) for x in LADDER_PERICH),
                       sessions=(), max_iterations=runner.MAX_ITER, epochs=None, train_bins=None,
                       output=OUTPUT["supervised"]),
    "ladder-time": dict(mode="time_only",
                        arms=tuple(ladder_name("time_only", x) for x in LADDER_PERICH),
                        sessions=(), max_iterations=runner.MAX_ITER, epochs=None,
                        train_bins=None, output=OUTPUT["time_only"]),
}


def _worker_command(args, plan, job, slot):
    """dprime_exp9's worker command, pointed at this file (which knows the new arms)."""
    cmd = _BASE_WORKER_COMMAND(args, plan, job, slot)
    if cmd[3] != "--_worker":
        raise RuntimeError("Unexpected dprime_exp9 worker command layout")
    cmd[2] = str(Path(__file__).resolve())
    return cmd


def install() -> None:
    """Let dprime_exp9 plan, queue and run this file's arms (its code is reused unchanged)."""
    runner.catalogue = catalogue
    runner.worker_command = _worker_command
    runner.SUITES.update(SUITES)


def worker(args) -> int:
    """One (session, seed, arm) job; a HALF arm gets its frozen fraction from HALF_RULE.json."""
    plan = runner.resolve_plan(args)
    jobs = runner.plan_jobs(plan)
    if len(jobs) != 1:
        raise ValueError("A worker runs exactly one (session, seed, arm) job")
    job = jobs[0]
    if is_half(job.exp):
        state = json.loads(state_path(plan.output_root.resolve()).read_text(encoding="utf-8"))
        fraction = (state["screen"].get(job.session) or {}).get("half_fraction")
        job = runner.Job(job.session, job.seed, resolve(job.exp, fraction), job.root)
    return runner.worker_run(args, plan, job)


def build_parser():
    install()
    p = runner.build_parser()
    p.description = __doc__
    p.set_defaults(seeds=[42, 43], eval_refine=4, eval_kappa=True, no_eval_margins=True)
    p.add_argument("--max-sessions", type=int, default=30,
                   help="half suites: at most this many screened sessions")
    p.add_argument("--ladder-sessions", type=int, default=8,
                   help="ladder suites: the first N screened sessions")
    p.add_argument("--jackknife-blocks", type=int, default=JACKKNIFE_BLOCKS)
    p.add_argument("--summarize", action="store_true",
                   help="Report both modes (or only --output-root)")
    return p


def _check_args(args, plan) -> None:
    """The input checks of dprime_exp9.main (it cannot be called with this file's arms)."""
    eps = args.eval_epsilons
    if args.batch_size < 1 or args.mlp_epochs < 1 or args.cpu_threads < 1:
        raise ValueError("Batch size, MLP epochs and CPU threads must be >= 1")
    if not eps or any(not np.isfinite(e) or e < 0 for e in eps) or eps != sorted(set(eps)):
        raise ValueError("--eval-epsilons must be unique sorted nonnegative numbers")
    if args.eval_refine < 0 or args.eval_restarts < 1 or args.eval_steps < 1:
        raise ValueError("Invalid evaluation settings")
    if args.device not in ("cuda_if_available", "cuda", "cuda:0"):
        raise ValueError("With one-GPU workers, --device must be cuda_if_available, cuda or cuda:0")
    if not args.eval_tag.replace("_", "").replace("-", "").isalnum() or len(args.eval_tag) > 48:
        raise ValueError("--eval-tag must be a short alphanumeric/-/_ label")
    for session in plan.sessions:
        if not (args.data_dir / f"{session}.npz").is_file():
            raise FileNotFoundError(f"No data for {session} in {args.data_dir}")


def main() -> int:
    args = build_parser().parse_args()
    if args._worker:
        return worker(args)
    if args.summarize:
        return summarize(args)
    if args.suite not in SUITES:
        raise SystemExit(f"--suite must be one of {sorted(SUITES)} (or --summarize)")
    suite = SUITES[args.suite]
    mode = suite["mode"]
    if args.mode not in (None, mode):
        raise SystemExit(f"--suite {args.suite} is {mode}")
    args.mode = mode
    args.output_root = (args.output_root or ROOT / suite["output"]).resolve()
    args.fork_dir = args.fork_dir.resolve()
    runner.load_fork(args.fork_dir)
    state = screen(args, mode)
    if not args.sessions:
        count = args.ladder_sessions if args.suite.startswith("ladder") else args.max_sessions
        args.sessions = list(state["eligible"][:count])
    if not args.sessions:
        print("No session where the rule changes the budget: nothing to run.", flush=True)
        return 0
    plan = runner.resolve_plan(args)
    register(args, plan, state)
    if args.dry_run:
        runner.show_plan(args, plan)
        return 0
    _check_args(args, plan)
    code = runner.orchestrate(args, plan)
    summarize(args)
    return code


# ============================================================================ summary
def _boot(values: np.ndarray) -> Dict[str, float]:
    boot = values[np.random.default_rng(2026).integers(0, len(values),
                                                      size=(20000, len(values)))].mean(axis=1)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return dict(mean=float(values.mean()), lo=float(lo), hi=float(hi),
                up=int((values > 0).sum()), n=len(values))


def _ratio_text(r: Dict[str, float]) -> str:
    return (f"x{math.exp(r['mean']):.3f} [x{math.exp(r['lo']):.3f}, x{math.exp(r['hi']):.3f}], "
            f"sessions up {r['up']}/{r['n']}")


def _call(r: Optional[Dict[str, float]], expect_up: bool = True) -> str:
    if r is None:
        return "no data"
    up = r["lo"] > 0 and r["up"] >= 0.75 * r["n"]
    down = r["hi"] < 0 and r["up"] <= 0.25 * r["n"]
    if up:
        return "SUPPORTED" if expect_up else "CONTRADICTED"
    if down:
        return "CONTRADICTED" if expect_up else "SUPPORTED"
    return "inconclusive"


def load_runs(root: Path, tag: str = "v1"):
    """Successful records of one output folder, with the refined eps1/2, kappa and failures."""
    import pandas as pd
    rows = []
    for session_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        for seed_dir in sorted(session_dir.glob("seed*")):
            rows += [json.loads(p.read_text(encoding="utf-8"))
                     for p in runner.record_files(seed_dir, tag)]
    if not rows:
        return None
    d = pd.DataFrame(rows)
    d = d[d.status == "success"].copy()
    if d.empty:
        return None

    def column(name: str):
        return (pd.to_numeric(d[name], errors="coerce") if name in d
                else pd.Series(np.nan, index=d.index))

    value = column("ref_half_refined")
    value = value.where(value.notna(), column("ref_half"))
    status = d["ref_status"].fillna("") if "ref_status" in d else pd.Series("", index=d.index)
    value = value.where(status != "below_floor", REFINE_FLOOR)
    d["half"] = value.where(status != "above_grid", REFINE_TOP)
    d["kappa"] = d.half / column("ref_eps_beh")
    d["fail"] = d.half < FAIL_REF_HALF
    d["x"] = column("x_train")
    return d


def _paired(g, a: str, b: str, column: str = "half"):
    """Per-session mean log ratio a / b (seeds averaged) with its session bootstrap."""
    piv = g.pivot_table(index=["session", "seed"], columns="experiment", values=column)
    if a not in piv or b not in piv:
        return None, None
    lr = np.log(piv[a] / piv[b]).replace([np.inf, -np.inf], np.nan).dropna()
    if lr.empty:
        return None, None
    per_session = lr.groupby(level=0).mean()
    return _boot(per_session.to_numpy()), per_session


def summarize(args) -> int:
    import pandas as pd
    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", 30)
    pd.set_option("display.max_rows", 300)
    if args.output_root:
        roots = [Path(args.output_root).resolve()]
    else:
        roots = [(ROOT / OUTPUT[m]).resolve() for m in MODES]
    verdicts = []
    for root in roots:
        if not state_path(root).is_file():
            print(f"\n(no {STATE_FILE} in {root})")
            continue
        state = json.loads(state_path(root).read_text(encoding="utf-8"))
        mode = state["mode"]
        screen_rows = pd.DataFrame(state["screen"].values())
        usable = screen_rows[screen_rows.usable.astype(bool)]
        print(f"\n==================== {mode}: {root}")
        if usable.empty:
            print("0  screen: no usable session")
            continue
        print(f"0  screen: {len(screen_rows)} sessions, {len(usable)} usable; AUTO binding "
              f"{usable.auto_binding.value_counts().to_dict()}; rule changes the budget in "
              f"{len(state['eligible'])}")
        jack = usable[pd.to_numeric(usable.half_q, errors="coerce").notna()]
        if len(jack):
            print(f"   jackknife q median {jack.half_q.median():.3f} [{jack.half_q.min():.3f}, "
                  f"{jack.half_q.max():.3f}] -> HALF fraction median {jack.half_fraction.median():.3f};"
                  f" HALF / AUTO budget median {jack.budget_ratio.median():.3f} "
                  f"[{jack.budget_ratio.min():.3f}, {jack.budget_ratio.max():.3f}]")
        d = load_runs(root, args.eval_tag)
        if d is None:
            print("   no successful runs yet")
            continue
        print(f"   runs: {d.groupby('experiment').size().to_dict()}")
        auto, half = AUTO[mode], HALF_ARM[mode]
        pred_path = root / PREDICTIONS_FILE
        pred = pd.read_csv(pred_path) if pred_path.is_file() else None
        # 1  HALF vs AUTO
        r, per_session = _paired(d, half, auto)
        if r is not None:
            print(f"\n1  {half} / {auto}, refined reference eps1/2 (= kappa ratio; same session)")
            print(f"   observed {_ratio_text(r)}")
            table = pd.DataFrame({"obs_ratio": np.exp(per_session)})
            if pred is not None:
                p = pred[pred.arm == half].set_index("session").predicted_kappa_ratio_vs_auto
                table["pred_ratio"] = p.reindex(table.index)
                lp = np.log(table.pred_ratio.dropna())
                print(f"   predicted from Exp14 (budget ratio^{ELASTICITY[mode]}): mean "
                      f"x{math.exp(lp.mean()):.3f}"
                      + (f"; r(log obs, log pred) {np.corrcoef(np.log(table.loc[lp.index].obs_ratio), lp)[0, 1]:+.2f}"
                         if len(lp) > 2 else ""))
            for arm_name in (auto, half):
                g = d[d.experiment == arm_name]
                table[f"kappa_{'half' if arm_name == half else 'auto'}"] = (
                    g.groupby("session").kappa.mean())
                table[f"x_{'half' if arm_name == half else 'auto'}"] = g.groupby("session").x.mean()
            r2 = d.pivot_table(index=["session", "seed"], columns="experiment", values="r2")
            if auto in r2 and half in r2:
                print(f"   clean R2 HALF - AUTO {(r2[half] - r2[auto]).mean():+.4f}")
            for arm_name in (auto, half):
                g = d[d.experiment == arm_name]
                print(f"   failures {arm_name}: {int(g.fail.sum())}/{len(g)}")
            print(table.round(3).to_string())
            verdicts.append((f"R{'2' if mode == 'supervised' else '3'} {mode} HALF > AUTO "
                             f"(kappa ratio)", _call(r), _ratio_text(r)))
            fails = int(d[d.experiment == half].fail.sum())
            verdicts.append((f"R{'1' if mode == 'supervised' else '3'} {mode} no HALF failure",
                             "SUPPORTED" if fails == 0 else f"CONTRADICTED ({fails} runs)", ""))
        # 2  ladder, with AUTO and HALF as extra points
        ladder = [ladder_name(mode, x) for x in LADDER_PERICH]
        lad = d[d.experiment.isin(ladder + [auto, half])]
        if lad.experiment.isin(ladder).any():
            print("\n2  dose-response: kappa against x = eps / eps_task(M_train) (ladder: no cap)")
            t = lad.groupby("experiment").agg(runs=("kappa", "size"), x=("x", "median"),
                                              kappa=("kappa", "median"), fails=("fail", "sum"),
                                              clean_r2=("r2", "mean")).sort_values("x")
            print(t.round(3).to_string())
            low = lad[lad.fail & (lad.x < HALF)]
            print(f"   failures below x = 0.5: {len(low)}; failing x: "
                  f"{sorted(lad[lad.fail].x.round(3).tolist())}")
            sessions = lad[lad.experiment.isin(ladder)]
            mean_k = sessions.groupby(["session", "experiment"]).kappa.mean().unstack()
            best = mean_k.idxmax(axis=1).map(lambda n: float(n[-2:]) / 100)
            print(f"   best ladder x per session: {best.to_dict()}")
            base = ladder_name(mode, 0.42)
            for high in (0.54, 0.66):
                rr, _ = _paired(lad, ladder_name(mode, high), base, "kappa")
                if rr is not None:
                    print(f"   kappa x{high:g} / x0.42: {_ratio_text(rr)}")
                    above = rr["lo"] > 0 and rr["up"] >= 0.75 * rr["n"]  # the gain continues
                    verdicts.append((f"L{'1' if mode == 'supervised' else '2'} {mode} kappa at "
                                     f"x {high:g} not above x 0.42",
                                     "CONTRADICTED" if above else "SUPPORTED", _ratio_text(rr)))
            verdicts.append((f"L{'1' if mode == 'supervised' else '2'} {mode} failures only at "
                             f"x >= 0.5", "SUPPORTED" if len(low) == 0 else
                             f"CONTRADICTED ({len(low)} runs)", ""))
    if verdicts:
        print("\n3  pre-registered hypotheses")
        for label, verdict, detail in verdicts:
            print(f"  {verdict:>13}  {label}  {detail}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
