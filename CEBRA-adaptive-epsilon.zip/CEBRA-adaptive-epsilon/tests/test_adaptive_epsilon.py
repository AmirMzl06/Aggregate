"""CPU regression tests for adaptive reference PGD; no real dataset required."""
import copy
import random

import numpy as np
import pytest
import torch
from torch import nn

import cebra
from cebra.data import Batch
from cebra.solver.single_session import SingleSessionSolver

torch.set_num_threads(1)


class Loader:
    device = "cpu"

    def __init__(self, batches):
        self.batches = batches

    def __iter__(self):
        return iter(self.batches)


def make_batch():
    gen = torch.Generator().manual_seed(61)
    reference = torch.randn(8, 3, 2, generator=gen)
    return Batch(reference, reference + .2 * torch.randn(8, 3, 2, generator=gen),
                 torch.randn(8, 3, 2, generator=gen))


def make_solver(**kwargs):
    torch.manual_seed(91)
    model = nn.Sequential(nn.Flatten(), nn.Linear(6, 8), nn.Tanh(), nn.Linear(8, 4))
    criterion = cebra.models.InfoNCE()
    optimizer = torch.optim.Adam(model.parameters(), lr=.001)
    config = dict(training_mode="adversarial", adv_epsilon=.2,
                  adv_alpha=.04, adv_steps=3, tqdm_on=False)
    config.update(kwargs)
    return SingleSessionSolver(model=model, criterion=criterion,
                               optimizer=optimizer, **config)


@pytest.mark.parametrize("norm", ["linf", "l2"])
@pytest.mark.parametrize("mode", ["fixed", "positive", "gain", "hybrid"])
def test_budget_reference_only_and_update_counts(norm, mode):
    solver = make_solver(attack_norm=norm, adv_epsilon_mode=mode,
                         adv_gain_interval=1, adv_warmup_steps=1)
    batch = make_batch()
    original = [x.clone() for x in (batch.reference, batch.positive, batch.negative)]
    captured = []
    measure = solver._measure_adv_gain

    def record(clean, adv):
        captured.append(adv.reference.clone())
        assert torch.equal(adv.positive, original[1])
        assert torch.equal(adv.negative, original[2])
        return measure(clean, adv)

    solver._measure_adv_gain = record
    solver.fit(Loader([batch] * 4))
    logs = solver.log
    assert logs["adv_warmup"] == [1, 0, 0, 0]
    assert len(captured) == 3
    assert solver.epsilon_state["train_steps"] == 4
    assert solver.epsilon_state["attack_steps"] == 3
    for attack, epsilon, alpha in zip(captured, logs["adv_epsilon"][1:], logs["adv_alpha"][1:]):
        delta = (attack - batch.reference).flatten(1)
        sizes = delta.abs().amax(1) if norm == "linf" else delta.norm(dim=1)
        assert sizes.max().item() <= epsilon + 1e-6
        assert alpha / epsilon == pytest.approx(.04 / .2)
    for value, expected in zip((batch.reference, batch.positive, batch.negative), original):
        assert torch.equal(value, expected)
    # One clean update per iteration, plus one update per attacked iteration.
    first = next(solver.model.parameters())
    assert solver.optimizer.state[first]["step"].item() == 7


@pytest.mark.parametrize("norm,expected", [("linf", 4.0), ("l2", 5.0)])
def test_quantile_uses_all_channels_and_time(norm, expected):
    ref = torch.zeros(4, 2, 2)
    pos = ref.clone()
    pos[:, 0, 0] = 3
    pos[:, 1, 1] = 4
    solver = make_solver(attack_norm=norm, adv_epsilon_mode="hybrid")
    solver.calibrate_epsilon(Loader([Batch(ref, pos, ref)]))
    state = solver.epsilon_state
    assert state["epsilon"] == expected * .5
    assert state["maximum"] == expected
    assert state["calibration"]["pairs"] == [4]


def test_zero_quantile_keeps_zero_pairs_and_fails():
    solver = make_solver(adv_epsilon_mode="positive")
    batch = make_batch()
    batch.positive = batch.reference.clone()
    with pytest.raises(ValueError, match="quantile is zero"):
        solver.calibrate_epsilon(Loader([batch]))


def test_calibration_restores_global_and_loader_rngs():
    class RandomLoader:
        device = "cpu"

        def __init__(self):
            self.generator = torch.Generator().manual_seed(5)

        def __iter__(self):
            for _ in range(3):
                random.random()
                np.random.random()
                x = torch.randn(8, 3, 2)
                pos = x + torch.randn(8, 3, 2, generator=self.generator)
                yield Batch(x, pos, x)

    solver = make_solver(adv_epsilon_mode="positive")
    loader = RandomLoader()
    torch_state = torch.get_rng_state().clone()
    local_state = loader.generator.get_state().clone()
    py_state, np_state = random.getstate(), np.random.get_state()
    solver.calibrate_epsilon(loader)
    assert torch.equal(torch_state, torch.get_rng_state())
    assert torch.equal(local_state, loader.generator.get_state())
    assert py_state == random.getstate()
    assert np.array_equal(np_state[1], np.random.get_state()[1])


def test_gain_direction_interval_deadband_and_bounds():
    solver = make_solver(adv_epsilon_mode="gain", adv_epsilon_min=.1,
                         adv_epsilon_max=.3, adv_gain_interval=2,
                         adv_gain_ema_decay=0, adv_gain_rate=.1)
    solver._update_epsilon_controller(0)
    assert solver.epsilon_state["epsilon"] == .2
    solver._update_epsilon_controller(0)
    assert solver.epsilon_state["epsilon"] == pytest.approx(.22)
    for _ in range(2):
        solver._update_epsilon_controller(.2)
    assert solver.epsilon_state["epsilon"] == pytest.approx(.2)
    for _ in range(2):
        solver._update_epsilon_controller(.05)
    assert solver.epsilon_state["epsilon"] == pytest.approx(.2)
    for _ in range(100):
        solver._update_epsilon_controller(0)
    assert solver.epsilon_state["epsilon"] == .3
    for _ in range(100):
        solver._update_epsilon_controller(1)
    assert solver.epsilon_state["epsilon"] == .1
    with pytest.raises(FloatingPointError):
        solver._update_epsilon_controller(float("nan"))


def test_controller_uses_ema_not_latest_gain():
    solver = make_solver(adv_epsilon_mode="gain", adv_gain_interval=1,
                         adv_gain_ema_decay=.9)
    solver._update_epsilon_controller(.2)
    before = solver.epsilon_state["epsilon"]
    solver._update_epsilon_controller(0)
    assert solver.epsilon_state["gain_ema"] == pytest.approx(.18)
    assert solver.epsilon_state["epsilon"] < before


def test_probe_preserves_batchnorm_dropout_modes_buffers_and_rng():
    solver = make_solver()
    solver.model = nn.Sequential(nn.Flatten(), nn.Linear(6, 4),
                                 nn.BatchNorm1d(4), nn.Dropout(.5))
    solver.model.train()
    solver.model[1].eval()  # Preserve mixed module flags, too.
    flags = [module.training for module in solver.model.modules()]
    buffers = {name: value.clone() for name, value in solver.model.named_buffers()}
    rng = torch.get_rng_state().clone()
    batch = make_batch()
    clean, adv, gain = solver._measure_adv_gain(batch, batch)
    assert gain == 0 and clean == adv
    assert flags == [module.training for module in solver.model.modules()]
    assert torch.equal(rng, torch.get_rng_state())
    for name, value in solver.model.named_buffers():
        assert torch.equal(value, buffers[name])


def test_solver_checkpoint_continues_same_trajectory_and_accepts_legacy():
    a = make_solver(adv_epsilon_mode="hybrid", adv_gain_interval=1)
    batch = make_batch()
    a.fit(Loader([batch] * 2))
    state = copy.deepcopy(a.state_dict())
    b = make_solver()
    b.load_state_dict(state)
    assert a.epsilon_state == b.epsilon_state
    rng = torch.get_rng_state()
    a.step(batch)
    torch.set_rng_state(rng)
    b.step(batch)
    assert a.epsilon_state == b.epsilon_state
    for left, right in zip(a.model.parameters(), b.model.parameters()):
        torch.testing.assert_close(left, right, rtol=0, atol=0)
    state.pop("adversarial_config")
    state.pop("epsilon_state")
    make_solver().load_state_dict(state, strict=True)


@pytest.mark.parametrize("mode", ["fixed", "positive", "gain", "hybrid"])
@pytest.mark.parametrize("norm", ["linf", "l2"])
def test_sklearn_fit_save_load_resume(mode, norm, tmp_path):
    from sklearn.base import clone
    rng = np.random.default_rng(25)
    x = rng.normal(size=(100, 6)).astype("float32")
    y = np.arange(100, dtype="float32")[:, None]
    model = cebra.CEBRA(device="cpu", batch_size=16, max_iterations=3,
                       training_mode="adversarial", adv_epsilon_mode=mode,
                       attack_norm=norm, adv_steps=2, adv_calibration_batches=2,
                       adv_gain_interval=1, adv_warmup_steps=1)
    assert clone(model).get_params() == model.get_params()
    model.fit(x, y)
    epsilon_state = copy.deepcopy(model.solver_.epsilon_state)
    path = tmp_path / "model.pt"
    model.save(path, backend="sklearn")
    loaded = cebra.CEBRA.load(path, backend="sklearn", weights_only=False)
    assert loaded.solver_.epsilon_state == epsilon_state
    assert loaded.solver_.adv_epsilon_mode == mode
    np.testing.assert_allclose(model.transform(x), loaded.transform(x))
    solver = loaded.solver_
    loaded.partial_fit(x, y)
    assert loaded.solver_ is solver
    assert solver.epsilon_state["train_steps"] == 6
    assert solver.epsilon_state["attack_steps"] == 5
    assert solver.epsilon_state["calibration"] == epsilon_state["calibration"]


@pytest.mark.parametrize("norm", ["linf", "l2"])
def test_multiobjective_model_support(norm):
    rng = np.random.default_rng(23)
    x = rng.normal(size=(100, 6)).astype("float32")
    y = np.arange(100, dtype="float32")[:, None]
    model = cebra.CEBRA(device="cpu", batch_size=16, max_iterations=2,
                       output_dimension=8, hybrid=True, training_mode="adversarial",
                       adv_epsilon_mode="hybrid", attack_norm=norm,
                       adv_steps=2, adv_calibration_batches=2)
    model.fit(x, y)
    assert model.solver_.epsilon_state["attack_steps"] == 2
    assert len(model.solver_.epsilon_state["calibration"]["objective_distances"]) == 2
    assert np.isfinite(model.solver_.log["adv_gain"]).all()


def test_full_batch_rejected_instead_of_attacking_indices():
    model = cebra.CEBRA(device="cpu", max_iterations=1,
                       training_mode="adversarial", adv_epsilon_mode="gain")
    x = np.random.default_rng(4).normal(size=(100, 6)).astype("float32")
    with pytest.raises(NotImplementedError, match="mini-batch"):
        model.fit(x)


@pytest.mark.parametrize("norm", ["linf", "l2"])
def test_fixed_matches_original_pgd_parameter_updates(norm):
    import importlib.util
    from pathlib import Path
    spec = importlib.util.spec_from_file_location(
        "legacy_pgd_fixture", Path(__file__).with_name("legacy_pgd_fixture.py"))
    legacy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)
    original = make_solver(attack_norm=norm)
    revised = make_solver(attack_norm=norm)
    batch = make_batch()
    for _ in range(3):
        rng = torch.get_rng_state()
        legacy.legacy_step(original, batch)
        torch.set_rng_state(rng)
        revised.step(batch)
    for left, right in zip(original.model.parameters(), revised.model.parameters()):
        torch.testing.assert_close(left, right, rtol=0, atol=0)
