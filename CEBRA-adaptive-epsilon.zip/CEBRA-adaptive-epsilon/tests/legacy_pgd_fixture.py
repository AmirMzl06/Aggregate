# Exact original Solver.step from the user-provided CEBRA-main2.zip.
# Apache-2.0; see the project LICENSE.md. Used only for regression tests.
import torch
import cebra
from cebra.solver.base import _l2_normalize, _rand_radius_like, _proj_l2_ball

def legacy_step(self, batch: cebra.data.Batch) -> dict:
        # ------------------------------------------------------------
        # 1) ordinary contrastive update
        # ------------------------------------------------------------
        self.optimizer.zero_grad()
        pred = self._inference(batch)
        loss, align, uniform = self.criterion(
            pred.reference, pred.positive, pred.negative
        )
        loss.backward()
        self.optimizer.step()
        # print(self.training_mode, self.attack_norm)
        if self.training_mode == "adversarial":
            if self.attack_norm == "linf":
                self.optimizer.zero_grad()

                adv_epsilon = self.adv_epsilon
                adv_alpha = self.adv_alpha
                adv_steps = self.adv_steps

                self.optimizer.zero_grad()

                # Create adversarial examples
                # x_adv = batch.reference.clone().detach()

                perturb = torch.empty_like(batch.reference) \
                    .uniform_(-self.adv_epsilon, self.adv_epsilon)
                x_adv = (batch.reference + perturb).clone()

                x_adv.requires_grad = True

                for _ in range(self.adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    with torch.enable_grad():
                        # Forward pass with adversarial examples
                        adv_batch = cebra.data.Batch(
                            reference=x_adv,
                            positive=batch.positive,
                            negative=batch.negative
                        )
                        adv_output = self._inference(adv_batch)
                        loss, _, _ = self.criterion(adv_output.reference,
                                                    adv_output.positive,
                                                    adv_output.negative)

                    grad_x, = torch.autograd.grad(
                        loss, x_adv,
                        retain_graph=False,
                        create_graph=False
                    )

                    with torch.no_grad():
                        grad_sign = grad_x.sign()
                        x_adv = x_adv + self.adv_alpha * grad_sign
                        x_adv = torch.max(torch.min(x_adv, batch.reference + self.adv_epsilon),
                                          batch.reference - self.adv_epsilon)
                        x_adv.requires_grad = True

                # Final forward pass with adversarial examples
                adv_batch = cebra.data.Batch(
                    reference=x_adv,
                    positive=batch.positive,
                    negative=batch.negative
                )
                output = self._inference(adv_batch)
                loss, _, _ = self.criterion(output.reference,
                                            output.positive,
                                            output.negative)
                loss.backward()
                self.optimizer.step()
            elif self.attack_norm == "l2":
                self.optimizer.zero_grad()

                adv_eps, adv_alpha, adv_steps = self.adv_epsilon, self.adv_alpha, self.adv_steps

                x_adv = batch.reference.clone().detach()
                noise = _l2_normalize(torch.randn_like(x_adv))
                noise *= _rand_radius_like(x_adv) * adv_eps
                x_adv = (batch.reference + noise).clone().detach().requires_grad_(True)

                for _ in range(adv_steps):
                    if x_adv.grad is not None:
                        x_adv.grad.zero_()

                    adv_b = cebra.data.Batch(reference=x_adv,
                                             positive=batch.positive,
                                             negative=batch.negative)
                    adv_out = self._inference(adv_b)
                    adv_loss, _, _ = self.criterion(
                        adv_out.reference, adv_out.positive, adv_out.negative
                    )
                    grad_x, = torch.autograd.grad(
                        adv_loss, x_adv,
                        retain_graph=False,
                        create_graph=False
                    )

                    with torch.no_grad():
                        x_adv += adv_alpha * _l2_normalize(grad_x)
                        x_adv = _proj_l2_ball(x_adv, batch.reference, adv_eps)
                        x_adv.requires_grad = True

                adv_b = cebra.data.Batch(reference=x_adv,
                                         positive=batch.positive,
                                         negative=batch.negative)
                out = self._inference(adv_b)
                loss3, _, _ = self.criterion(out.reference, out.positive, out.negative)
                loss3.backward()
                self.optimizer.step()

        self.history.append(loss.item())
        stats = dict(
            pos=align.item(),
            neg=uniform.item(),
            total=loss.item(),
            temperature=self.criterion.temperature,
        )
        for k, v in stats.items():
            self.log[k].append(v)
        return stats
