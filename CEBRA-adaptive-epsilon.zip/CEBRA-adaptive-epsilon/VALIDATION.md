# Validation

29 focused tests passed on CPU (Python 3.12, PyTorch 2.14.0+cpu).

Command from project root:

```bash
python -m pytest -o addopts= -q tests/test_adaptive_epsilon.py
```

Covered: all four epsilon modes with l2/linf, reference-only perturbation budgets,
clean/adversarial optimizer update counts and warm-up, quantile dimensions and zero
quantile rejection, sampler RNG preservation, controller direction/EMA/deadband/
interval/bounds, deterministic gain probes with BatchNorm/Dropout, legacy solver
checkpoint loading, estimator clone/fit/save/load/resume, and behavior+time objectives.
The fixed single-objective PGD parameter updates match the original uploaded
Solver.step exactly over three training iterations under identical random states
for both norms. Metrics logging was made consistent across norms.

This is implementation validation with synthetic inputs. Real neural data,
GPU/CUDA behavior, decoding R2, and experimental efficacy were not evaluated.
