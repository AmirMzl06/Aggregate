# Adaptive epsilon for reference-only PGD

این نسخه بر اساس همان `CEBRA-main2.zip` پیوست‌شده ساخته شده است. تنها دو فایل
اجرایی پروژه تغییر کرده‌اند:

```
cebra/solver/base.py
cebra/integrations/sklearn/cebra.py
```

فایل‌های تست و این راهنما اضافه شده‌اند. فایل‌های `base_2.py` و `base____.py`
قدیمی هستند؛ مسیر اجرای این قابلیت `base.py` است. این نسخه انتخاب زیرمجموعهٔ
نورون‌ها یا تغییر gamma را اضافه نمی‌کند؛ موضوع آزمایش فقط بودجهٔ epsilon است.

## نصب و انتخاب حالت

از پوشهٔ کامل همین بسته استفاده کن تا فایل‌های نسخه‌های مختلف ترکیب نشوند.
اگر می‌خواهی فقط دو فایل را جایگزین کنی، مقصد باید همان نسخهٔ ZIP اولیه باشد.

```bash
cd CEBRA-adaptive-epsilon
python -m pip install -e . --no-deps
python -c "import cebra; print(cebra.__file__)"
```

اگر اسکریپت آزمایش `sys.path.insert(...)` دارد، آن مسیر هم باید به همین پوشه
اشاره کند. نصب editable به تنهایی مسیر صریح یک فورک دیگر را تغییر نمی‌دهد.

پارامترهای زیر را به ساخت `cebra.CEBRA` در اسکریپت فعلی اضافه کن. پارامترهای
encoder، داده، decoder و محاسبهٔ R² همان تنظیمات آزمایش خودت بمانند.

```python
attack = dict(
    training_mode="adversarial",
    attack_norm="linf",          # یا "l2"
    adv_epsilon=0.2,             # مقدار اولیهٔ کنترلر / بودجهٔ baseline
    adv_alpha=0.04,              # برای نمونه؛ مقدار آزمایش خودت را حفظ کن
    adv_steps=10,
    adv_warmup_steps=100,        # در هر چهار حالت یکسان؛ 0 = بدون warm-up
    adv_positive_quantile=0.10,
    adv_positive_scale=0.5,
    adv_positive_cap_scale=1.0,
    adv_calibration_batches=32,
    adv_gain_target=0.05,
    adv_gain_ema_decay=0.9,
    adv_gain_rate=0.05,
    adv_gain_interval=10,
    adv_gain_deadband=0.10,
    adv_epsilon_min=1e-6,
)

# در هر اجرای مستقل، فقط نام حالت را عوض کن:
model = cebra.CEBRA(
    # سایر تنظیمات قبلی مدل خودت ...
    batch_size=512,             # مقدار قبلی خودت؛ نباید None باشد
    adv_epsilon_mode="hybrid",  # fixed | positive | gain | hybrid
    **attack,
)
model.fit(X_train, y_train)     # فقط train؛ validation وارد fit نمی‌شود
```

مقادیر بالا برای شروع آزمایش‌اند؛ روی داده‌های تو تنظیم یا اعتبارسنجی نشده‌اند.
پیش‌فرض API برای `adv_warmup_steps` صفر است تا اجرای قبلی بدون تنظیم جدید
warm-up نگیرد. با مقدار 100، از کل `max_iterations` همان 100 مرحله clean-only
است؛ مرحلهٔ اضافی به تعداد iterationها افزوده نمی‌شود. از آن به بعد هر مرحله،
مثل فایل اصلی، یک update تمیز و یک update خصمانه دارد.

| `adv_epsilon_mode` | رفتار |
|---|---|
| `fixed` | مقدار `adv_epsilon` ثابت؛ بدون کالیبراسیون یا کنترل بازخوردی |
| `positive` | یک بار `epsilon = adv_positive_scale * Q_q(distance)` از train؛ سپس ثابت |
| `gain` | شروع از `adv_epsilon`؛ افزایش/کاهش ضربی با EMA gain |
| `hybrid` | مقدار اولیه از فاصلهٔ positive؛ کنترلر در محدودهٔ سقف مبتنی بر همان فاصله |

در تمام حالت‌ها: **reference only + یک random restart + آخرین iterate**.
positive و negative تغییر نمی‌کنند. epsilon برای همهٔ نمونه‌های یک batch
مشترک است؛ این پیاده‌سازی per-sample epsilon نیست.

## فاصله، سقف و گام PGD

برای هر نمونه، فاصله روی **تمام کانال‌ها و زمان‌های پنجرهٔ ورودی** محاسبه می‌شود:

```
distance_b = norm(flatten(x_ref[b] - x_pos[b]), p)
D = quantile(distance, adv_positive_quantile)
```

این تعریف برای `l2` دقیقاً با projection فایل اصلی یکسان است. داده از loader
آموزش و پس از preprocessing خودت می‌آید؛ نرمال‌سازی اضافه انجام نمی‌شود.
حداکثر 32 batch (یا تمام batchهای loader اگر کمتر باشند) کالیبره می‌شوند.
وضعیت RNG عمومی Python/NumPy/Torch و generatorهای loader/distributionهای این
فورک حفظ می‌شود تا کالیبراسیون توالی نمونه‌گیری آموزش را جلو نبرد.
loader سفارشی با state داخلی غیر از این RNGها نیاز به بررسی جدا دارد.

- `positive`: مقدار اولیه `0.5 * D` و بعد ثابت.
- `gain`: سقف پیش‌فرض `4 * adv_epsilon`.
- `hybrid`: مقدار اولیه `0.5 * D`، سقف پیش‌فرض `1.0 * D`.
- `adv_epsilon_max` در حالت‌های تطبیقی می‌تواند سقف صریح بدهد؛ در hybrid،
  کوچک‌ترِ سقف صریح و سقف حاصل از فاصله استفاده می‌شود.
- `fixed` محدودیت‌های جدید min/max را اعمال نمی‌کند و همان بودجهٔ قبلی را دارد.

اگر در هر چهار حالت می‌خواهی یک سقف صریح مشابه بررسی کنی، `adv_epsilon_max`
را در سه حالت تطبیقی یکسان بده و baseline را در همان محدوده انتخاب کن.

در حالت‌های تطبیقی:

```
alpha_used = adv_alpha * epsilon_used / adv_epsilon
```

پس نسبت گام به بودجه ثابت می‌ماند. در fixed همان `adv_alpha` اصلی استفاده می‌شود.
`adv_epsilon` در constructor تغییر نمی‌کند؛ مقدار جاری در `epsilon_state` است.

فاصله‌های صفر حذف نمی‌شوند. اگر quantile منتخب صفر باشد، کالیبراسیون با پیام
روشن متوقف می‌شود تا جفت‌های تکراری، preprocessing یا q بررسی شوند. مقدار
زیر `adv_epsilon_min` هم بی‌صدا بزرگ نمی‌شود و خطا می‌دهد. سقف حاصل از فاصله
یک قاعدهٔ تجربی است و شعاع امن معنایی را تضمین نمی‌کند.

## تعریف gain و کنترلر

ابتدا update تمیز اجرا می‌شود، سپس PGD ساخته می‌شود. قبل از update خصمانه،
دو لاس روی یک batch، همان positive/negativeها، همان وزن‌ها و همان دما محاسبه می‌شوند:

```
adv_gain = loss(x_adv) - loss(x_clean)
```

اندازه‌گیری در `eval()` و بدون gradient است؛ Dropout خاموش است و BatchNorm
آمارش را عوض نمی‌کند. وضعیت training تمام زیرماژول‌ها پس از اندازه‌گیری
برمی‌گردد. خود PGD و updateهای آموزش، مانند فایل اصلی، در حالت آموزش‌اند.
بنابراین برای مدل دارای Dropout/BatchNorm، gain یک probe در eval است و با
لاس تصادفی train یکی نیست. دو forward اضافی برای این اندازه‌گیری در هر
چهار حالت وجود دارد تا مقایسه و ثبت لاگ یکسان باشد.

EMA با اولین gain مقداردهی می‌شود و در هر حمله تازه می‌شود. کنترلر هر
`adv_gain_interval` حمله، epsilon **batch بعدی** را تعیین می‌کند:

```
EMA > target * (1 + deadband)  => epsilon /= (1 + rate)
EMA < target * (1 - deadband)  => epsilon *= (1 + rate)
otherwise                    => no change
```

سپس epsilon به محدودهٔ min/max بریده می‌شود. در warm-up نه gain محاسبه می‌شود
و نه شمارندهٔ حمله جلو می‌رود. مقدار منفی gain کلیپ نمی‌شود؛ چون last-iterate
PGD می‌تواند حملهٔ ضعیفی بدهد، منفی‌بودن پایدار gain نیاز به بررسی قدرت حمله دارد.
این کنترلر همگرایی، robustness یا بهترشدن R² را تضمین نمی‌کند.

## لاگ و ادامهٔ آموزش

```python
logs = model.solver_.log
print(logs["adv_epsilon"])       # بودجهٔ واقعاً استفاده‌شده؛ در warm-up صفر
print(logs["adv_epsilon_next"])  # مقدار برنامه‌ریزی‌شده برای batch بعد
print(logs["adv_gain"])
print(logs["adv_gain_ema"])
print(model.solver_.epsilon_state)  # مقدار جاری، سقف، calibration و شمارنده‌ها

model.save("hybrid.pt", backend="sklearn")
# فقط برای checkpoint مورداعتمادِ خودت:
loaded = cebra.CEBRA.load("hybrid.pt", backend="sklearn", weights_only=False)
loaded.partial_fit(X_train, y_train)  # ادامه با optimizer و controller قبلی
```

در warm-up مقادیر gain/probe برابر NaN هستند چون اندازه‌گیری نشده‌اند.
`total` و `history` اکنون همیشه لاس تمیز را ثبت می‌کنند؛ در کد اصلی logging
لاس `linf` و `l2` متفاوت بود. لاس‌های probe با نام‌های `adv_clean_probe` و
`adv_loss_probe` جدا ثبت می‌شوند. در multiobjective نیز ثبت تکراری history
اصلاح شده است.

checkpoint جدید configuration، مقدار ε، EMA، شمارنده‌ها و calibration را
حفظ می‌کند. checkpointهای قدیمی بدون state تطبیقی قابل بارگذاری‌اند.
`partial_fit` پس از بارگذاری sklearn، loader را بازسازی می‌کند و solver قبلی
را نگه می‌دارد. این ادامه باید روی همان داده/پیش‌پردازش انجام شود؛ برای سشن
جدید، مدل جدید بساز یا `fit(adapt=True)` را استفاده کن تا کالیبراسیون تازه شود.
وضعیت RNG/توالی دقیق batchهای آموزش در checkpoint ذخیره نمی‌شود؛ بنابراین
ادامهٔ آموزش به معنی بازتولید بیت‌به‌بیت توالی sampling قبلی نیست.

## دامنه و مقایسهٔ منصفانه

- هر سشن را مستقل و با `batch_size` عددی آموزش بده. مدل joint multisession
  و `batch_size=None` در این PGD پشتیبانی نمی‌شوند و زود خطا می‌دهند؛ مسیر
  clean این حالت‌ها تغییر نکرده است.
- `hybrid=True` خودِ CEBRA (لاس behavior + time) با
  `adv_epsilon_mode="hybrid"` متفاوت است. اولی نیز پشتیبانی شده: برای تعیین
  مقیاس، quantile هر نوع positive جدا محاسبه و کوچک‌تر انتخاب می‌شود.
  حمله و gain در هر دو نُرم از مجموع دو لاس استفاده می‌کنند. این موضوع
  یک ناسازگاری قدیمیِ شاخهٔ `l2` multiobjective را هم اصلاح می‌کند؛ آن شاخه
  فقط لاس behavior را حمله می‌کرد و گرادیان‌های PGD را انباشته می‌کرد.
- برای ablation، تنظیمات encoder، decoder، تقسیم داده، seedها و warm-up
  را در همهٔ حالت‌ها یکسان نگه دار. decoder هر حالت جدا آموزش ببیند.
- همان R² اعتبارسنجی و R² هر خروجی را مقایسه کن؛ target gain معیار موفقیت نیست.
  تنظیم target/q بر اساس test نهایی انجام نشود.

## تست

از ریشهٔ همین پروژه:

```bash
python -m pytest -o addopts= -q tests/test_adaptive_epsilon.py
```

تست‌ها شامل چهار حالت و دو نُرم، محدودیت perturbation، ثابت‌ماندن positive و
negative، شمارش updateها و warm-up، جهت/EMA/باند کنترلر، حفظ RNG در کالیبراسیون،
حفظ حالت Dropout/BatchNorm، save/load/resume و مقایسهٔ عددی updateهای حالت ثابت
با تابع اصلی ZIP هستند. دادهٔ واقعی و CUDA در این تست‌ها استفاده نمی‌شود.
