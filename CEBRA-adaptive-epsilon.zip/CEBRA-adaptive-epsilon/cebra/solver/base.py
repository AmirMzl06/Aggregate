#
# CEBRA: Consistent EmBeddings of high-dimensional Recordings using Auxiliary variables
# © Mackenzie W. Mathis & Steffen Schneider (v0.4.0+)
# Source code:
# https://github.com/AdaptiveMotorControlLab/CEBRA
#
# Please see LICENSE.md for the full license document:
# https://github.com/AdaptiveMotorControlLab/CEBRA/blob/main/LICENSE.md
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""This package contains abstract base classes for different solvers.

Solvers are used to package models, criterions and optimizers and implement training
loops. When subclassing abstract solvers, in the simplest case only the
:py:meth:`Solver._inference` needs to be overridden.

For more complex use cases, the :py:meth:`Solver.step` and
:py:meth:`Solver.fit` method can be overridden to
implement larger changes to the training loop.
"""

import abc
import copy
import contextlib
import itertools
import math
import os
import random
from typing import Callable, Dict, List, Literal, Optional

import literate_dataclasses as dataclasses
import numpy as np
# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
import torch

import cebra
import cebra.data
import cebra.io
import cebra.models
from cebra.solver.util import Meter
from cebra.solver.util import ProgressBar


def _l2_normalize(t: torch.Tensor, eps: float = 1e-12):
    """Per-sample L2 normalisation (zero vectors stay zero)."""
    flat = t.reshape(t.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=eps)
    return t / norm.view(-1, *([1] * (t.dim() - 1)))


def _rand_radius_like(t: torch.Tensor):
    """U(0,1) radius shaped like t but broadcastable (B,1,1,…) ."""
    return torch.rand([t.size(0)] + [1] * (t.dim() - 1), device=t.device)


def _proj_l2_ball(adv: torch.Tensor, orig: torch.Tensor, epsilon: float):
    """Project adv back to the closed L2 ball of radius ε around orig."""
    if epsilon == 0:
        return orig.clone()
    delta = adv - orig
    flat = delta.reshape(delta.size(0), -1)
    norm = flat.norm(p=2, dim=1, keepdim=True).clamp(min=1e-12)
    factor = torch.where(norm > epsilon, norm / epsilon, torch.ones_like(norm))
    delta = delta / factor.view(-1, *([1] * (delta.dim() - 1)))
    return orig + delta


#

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# negative_perm= shuffle_and_permute(batch.negative)


# copied_data = copy.deepcopy(batch)#batch.clone().detach()
# copied_data.positive = torch.randn_like(batch.positive).cuda() #positive_perm
# copied_data.reference = torch.randn_like(batch.reference).cuda() #anchor_perm
# copied_data.negative = torch.randn_like(batch.negative).cuda() #negative_perm


# prediction_fix = self._inference(batch)

# prediction_perm= self._inference(copied_data)

# x_perm_ = torch.cat([prediction_perm.reference,prediction_perm.positive, prediction_perm.negative], dim=0)
# x_fix= torch.cat([prediction_fix.reference,prediction_fix.positive, prediction_fix.negative], dim=0)

# self.optimizer.zero_grad()

# cos_raw    = torch.nn.functional.cosine_similarity(x_perm_,x_fix)
# L_cos      = torch.log((2 + cos_raw) / 2).mean()  # log version
# # print(L_cos.item())
# L_cos.backward()
# self.optimizer.step()


# fake_data=torch.randn_like(batch.positive).cuda()


# self.optimizer.zero_grad()

# positive_perm= shuffle_and_permute(batch.positive)
# anchor_perm= shuffle_and_permute(batch.reference)
# fake_data=torch.randn_like(batch.positive).cuda()


# x_perm_ = torch.cat([anchor_perm,positive_perm, batch.negative], dim=0)

# idx = torch.randperm(x_perm_.size(0))[:positive_perm.size(0)]


# permed_data_negative   = x_perm_[idx]

# fake_batch = cebra.data.Batch(
#                 reference=batch.reference,
#                 positive=batch.positive,
#                 negative=batch.negative
#             )
# fake_prediction = self._inference(fake_batch)
# loss, align, uniform= self.criterion(fake_prediction.reference,
#                                       fake_prediction.positive,
#                                       fake_prediction.negative)
# loss.backward()
# self.optimizer.step()


def clone_batch(batch):
    # 1) shallow-copy the Batch container
    new_batch = copy.copy(batch)

    # 2) for each tensor attribute in the batch, clone & detach
    #    adjust this list to match the actual fields in your Batch
    tensor_fields = ['reference', 'positive', 'negative', 'anchor', 'other_tensor']
    for field in tensor_fields:
        tensor = getattr(batch, field, None)
        if isinstance(tensor, torch.Tensor):
            # clone and detach so it shares neither data nor grad
            setattr(new_batch, field, tensor.clone().detach())
        # if the field can be a list/tuple of tensors, you could also do:
        # elif (isinstance(tensor, (list, tuple)) and
        #       all(isinstance(t, torch.Tensor) for t in tensor)):
        #     cloned = [t.clone().detach() for t in tensor]
        #     setattr(new_batch, field, type(tensor)(cloned))

    return new_batch


def shuffle_and_permute(data: torch.Tensor) -> torch.Tensor:
    """
    Shuffle the second (M) and third (D) dimensions of a 3D tensor independently.

    Parameters:
        data (torch.Tensor): Input tensor of shape [N, M, D].

    Returns:
        torch.Tensor: Tensor with shuffled M and D dimensions.
    """
    N, M, D = data.size()

    # Create random permutations for the second and third dimensions
    perm_M = torch.randperm(M)
    # perm_D = torch.randperm(D)

    # Permute the second dimension (axis=1) first, then the third dimension (axis=2)
    shuffled_data = data[:, perm_M.cuda(), :]

    return shuffled_data


@dataclasses.dataclass
class Solver(abc.ABC, cebra.io.HasDevice):
    """Solver base class.

    A solver contains helper methods for bundling a model, criterion and optimizer.

    Attributes:
        model: The encoder for transforming reference, positive and negative samples.
        criterion: The criterion computed from the similarities between positive pairs
            and negative pairs. The criterion can have trainable parameters on its own.
        optimizer: A PyTorch optimizer for updating model and criterion parameters.
        history: Deprecated since 0.0.2. Use :py:attr:`log`.
        decode_history: Deprecated since 0.0.2. Use a hook during training for validation and
            decoding. See the arguments of :py:meth:`fit`.
        log: The logs recorded during training, typically contains the ``total`` loss as well
            as the logs for positive (``pos``) and negative (``neg``) pairs. For the standard
            criterions in CEBRA, also contains the value of the ``temperature``.
        tqdm_on: Use ``tqdm`` for showing a progress bar during training.
        training_mode: The training mode, either "clean" or "adversarial".
        adv_epsilon: The maximum perturbation allowed for adversarial training.
        adv_alpha: The step size for adversarial training.
        adv_steps: The number of steps for adversarial training.
        attack_norm: The norm used for adversarial training, either "l2" or "linf".
    """

    model: torch.nn.Module
    criterion: torch.nn.Module
    optimizer: torch.optim.Optimizer
    history: List = dataclasses.field(default_factory=list)
    decode_history: List = dataclasses.field(default_factory=list)
    log: Dict = dataclasses.field(default_factory=lambda: ({
        "pos": [],
        "neg": [],
        "total": [],
        "temperature": []
    }))
    tqdm_on: bool = True
    training_mode: str = "clean"
    adv_epsilon: float = 0.05
    adv_alpha: float = 0.01
    adv_steps: int = 10
    attack_norm: str = "linf"
    adv_epsilon_mode: str = "fixed"
    adv_positive_quantile: float = 0.1
    adv_positive_scale: float = 0.5
    adv_positive_cap_scale: float = 1.0
    adv_calibration_batches: int = 32
    adv_epsilon_min: float = 1e-6
    adv_epsilon_max: Optional[float] = None
    adv_gain_target: float = 0.05
    adv_gain_ema_decay: float = 0.9
    adv_gain_rate: float = 0.05
    adv_gain_interval: int = 10
    adv_gain_deadband: float = 0.1
    adv_warmup_steps: int = 0

    def __post_init__(self):
        cebra.io.HasDevice.__init__(self)
        self.best_loss = float("inf")
        self._reset_epsilon_state()

    def _adversarial_config(self):
        """Serializable attack configuration, including legacy PGD options."""
        names = ("training_mode", "attack_norm", "adv_epsilon", "adv_alpha",
                 "adv_steps", "adv_epsilon_mode", "adv_positive_quantile",
                 "adv_positive_scale", "adv_positive_cap_scale",
                 "adv_calibration_batches", "adv_epsilon_min", "adv_epsilon_max",
                 "adv_gain_target", "adv_gain_ema_decay", "adv_gain_rate",
                 "adv_gain_interval", "adv_gain_deadband", "adv_warmup_steps")
        return {name: getattr(self, name) for name in names}

    def _reset_epsilon_state(self):
        """Validate once and initialize state without changing constructor parameters."""
        modes = ("fixed", "positive", "gain", "hybrid")
        if self.adv_epsilon_mode not in modes:
            raise ValueError(f"adv_epsilon_mode must be one of {modes}.")
        if self.adv_epsilon_mode != "fixed" and self.training_mode != "adversarial":
            raise ValueError("Adaptive epsilon requires training_mode='adversarial'.")
        for name in ("adv_steps", "adv_calibration_batches", "adv_gain_interval",
                     "adv_warmup_steps"):
            value = getattr(self, name)
            minimum = 0 if name == "adv_warmup_steps" else 1
            if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < minimum:
                raise ValueError(f"{name} must be an integer >= {minimum}.")
        for name in ("adv_epsilon", "adv_alpha", "adv_epsilon_min",
                     "adv_positive_scale", "adv_positive_cap_scale",
                     "adv_gain_target", "adv_gain_rate"):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative.")
        for name in ("adv_positive_scale", "adv_positive_cap_scale", "adv_gain_target",
                     "adv_gain_rate"):
            if getattr(self, name) == 0:
                raise ValueError(f"{name} must be positive.")
        if not 0 < self.adv_positive_quantile <= 1:
            raise ValueError("adv_positive_quantile must be in (0, 1].")
        if not 0 <= self.adv_gain_ema_decay < 1:
            raise ValueError("adv_gain_ema_decay must be in [0, 1).")
        if not 0 <= self.adv_gain_deadband < 1:
            raise ValueError("adv_gain_deadband must be in [0, 1).")
        if self.adv_epsilon_max is not None:
            if not math.isfinite(self.adv_epsilon_max) or self.adv_epsilon_max <= 0:
                raise ValueError("adv_epsilon_max must be finite and positive.")
            if self.adv_epsilon_max < self.adv_epsilon_min:
                raise ValueError("adv_epsilon_max must be >= adv_epsilon_min.")
        if self.training_mode == "adversarial" and self.attack_norm not in ("linf", "l2"):
            raise ValueError("PGD supports attack_norm='linf' or 'l2'.")
        if self.adv_epsilon_mode != "fixed" and (self.adv_epsilon <= 0 or self.adv_alpha <= 0):
            raise ValueError("Adaptive modes require positive adv_epsilon and adv_alpha.")
        if self.adv_epsilon_mode in ("gain", "hybrid") and self.adv_epsilon_min <= 0:
            raise ValueError("Multiplicative control requires adv_epsilon_min > 0.")
        if self.adv_epsilon_mode == "hybrid" and self.adv_positive_scale > self.adv_positive_cap_scale:
            raise ValueError("adv_positive_scale cannot exceed adv_positive_cap_scale in hybrid mode.")
        maximum = self.adv_epsilon_max
        if maximum is None and self.adv_epsilon_mode == "gain":
            maximum = 4.0 * self.adv_epsilon
        if self.adv_epsilon_mode == "gain":
            if not self.adv_epsilon_min <= self.adv_epsilon <= maximum:
                raise ValueError("Initial adv_epsilon must lie within controller bounds.")
        self.epsilon_state = dict(
            epsilon=float(self.adv_epsilon), maximum=maximum,
            gain_ema=None, train_steps=0, attack_steps=0,
            calibrated=False, calibration=None)

    def _check_attack_support(self):
        # Full-batch loaders contain indices, and multi-session batches live in
        # different neural spaces. Neither can use this reference-only PGD.
        if self.training_mode != "adversarial":
            return
        if getattr(self, "_variant_name", "") not in ("single-session", "single-session-hybrid") or hasattr(self, "neural"):
            raise NotImplementedError(
                "Reference PGD requires a single-session mini-batch solver. "
                "Set batch_size to an integer; train each session separately.")

    def _check_attack_ready(self):
        self._check_attack_support()
        if (self.training_mode == "adversarial"
                and self.adv_epsilon_mode in ("positive", "hybrid")
                and not self.epsilon_state["calibrated"]):
            raise RuntimeError("Call solver.fit(train_loader) or calibrate_epsilon(train_loader) before step().")

    @contextlib.contextmanager
    def _preserve_sampling_rng(self, loader):
        """Calibration must not advance the training sampler's RNG streams."""
        seen, generators = set(), []

        def visit(obj):
            if id(obj) in seen:
                return
            seen.add(id(obj))
            if isinstance(obj, torch.Generator):
                generators.append((obj, obj.get_state()))
            elif isinstance(obj, dict):
                for value in obj.values():
                    visit(value)
            elif isinstance(obj, (tuple, list)):
                for value in obj:
                    visit(value)
            elif obj is loader or type(obj).__module__.startswith("cebra.distributions"):
                for key, value in vars(obj).items():
                    if key != "dataset":
                        visit(value)

        visit(loader)
        py_state, np_state = random.getstate(), np.random.get_state()
        devices = list(range(torch.cuda.device_count())) if torch.cuda.is_available() else []
        try:
            with torch.random.fork_rng(devices=devices):
                yield
        finally:
            random.setstate(py_state)
            np.random.set_state(np_state)
            for generator, state in generators:
                generator.set_state(state)

    @torch.no_grad()
    def calibrate_epsilon(self, loader):
        """Estimate a train-only positive distance quantile once per fitted solver.

        Distances use all non-batch dimensions, just like the PGD projection.
        Zeros are retained in the distribution. A zero selected quantile raises
        an error instead of silently changing the statistic or disabling PGD.
        For CEBRA's behavior/time hybrid objective, use the smaller of the two
        independently estimated quantiles as a conservative shared scale.
        """
        self._check_attack_support()
        if self.adv_epsilon_mode not in ("positive", "hybrid") or self.epsilon_state["calibrated"]:
            return
        distances = None
        batches = 0
        with self._preserve_sampling_rng(loader):
            for batch in itertools.islice(iter(loader), self.adv_calibration_batches):
                batch.to(self.device)
                reference, positive = batch.reference, batch.positive
                if not reference.is_floating_point() or reference.ndim < 2:
                    raise ValueError("Calibration needs floating-point input windows, not sample indices.")
                positives = (positive,)
                if isinstance(self, MultiobjectiveSolver):
                    if len(positive) != 2 * len(reference):
                        raise ValueError("Expected behavior and time positive batches.")
                    positives = positive.chunk(2, dim=0)
                if distances is None:
                    distances = [[] for _ in positives]
                for values, pos in zip(distances, positives):
                    if reference.shape != pos.shape:
                        raise ValueError("Positive and reference windows must have identical shapes.")
                    delta = (reference.detach().float() - pos.detach().float()).flatten(1)
                    d = delta.abs().amax(1) if self.attack_norm == "linf" else delta.norm(p=2, dim=1)
                    if not torch.isfinite(d).all():
                        raise ValueError("Non-finite positive distances; check training inputs.")
                    values.append(d.cpu())
                batches += 1
        if not batches:
            raise ValueError("Cannot calibrate epsilon from an empty training loader.")
        samples = [torch.cat(values) for values in distances]
        quantiles = [torch.quantile(values, self.adv_positive_quantile).item() for values in samples]
        distance = min(quantiles)
        if not math.isfinite(distance) or distance <= 0:
            raise ValueError("Positive-distance quantile is zero or invalid. Check duplicate pairs, preprocessing, or increase adv_positive_quantile.")
        epsilon = self.adv_positive_scale * distance
        maximum = self.adv_epsilon_max
        if self.adv_epsilon_mode == "hybrid":
            cap = self.adv_positive_cap_scale * distance
            maximum = cap if maximum is None else min(maximum, cap)
        if maximum is not None:
            if maximum < self.adv_epsilon_min:
                raise ValueError("Calibrated cap is below adv_epsilon_min; lower the minimum.")
            epsilon = min(epsilon, maximum)
        if epsilon < self.adv_epsilon_min:
            raise ValueError("Calibrated epsilon is below adv_epsilon_min; lower the minimum.")
        self.epsilon_state.update(
            epsilon=float(epsilon), maximum=maximum, calibrated=True,
            calibration=dict(quantile=self.adv_positive_quantile,
                             distance=distance, objective_distances=quantiles,
                             batches=batches, pairs=[len(x) for x in samples],
                             zero_fraction=[(x == 0).float().mean().item() for x in samples],
                             norm=self.attack_norm))

    def _objective(self, batch):
        prediction = self._inference(batch)
        if isinstance(self, MultiobjectiveSolver):
            terms = [self.criterion(p.reference, p.positive, p.negative)[0] for p in prediction]
            return sum(terms)
        return self.criterion(prediction.reference, prediction.positive, prediction.negative)[0]

    @torch.no_grad()
    def _measure_adv_gain(self, clean_batch, adv_batch):
        """Paired deterministic probe at identical weights, before the adv update.

        Eval mode removes dropout noise and avoids BatchNorm running-stat updates.
        Restore every module's previous training flag and global torch RNG state.
        The probe never backpropagates or changes the training attack objective.
        """
        modules = list(self.model.modules()) + list(self.criterion.modules())
        flags = [(module, module.training) for module in modules]
        devices = list(range(torch.cuda.device_count())) if torch.cuda.is_available() else []
        try:
            self.model.eval()
            self.criterion.eval()
            with torch.random.fork_rng(devices=devices):
                clean = self._objective(clean_batch).item()
                adversarial = self._objective(adv_batch).item()
        finally:
            for module, training in flags:
                module.training = training
        gain = adversarial - clean
        if not math.isfinite(gain):
            raise FloatingPointError("Non-finite adv_gain; epsilon controller was not updated.")
        return clean, adversarial, gain

    def _update_epsilon_controller(self, gain):
        state = self.epsilon_state
        if not math.isfinite(gain):
            raise FloatingPointError("adv_gain must be finite.")
        decay = self.adv_gain_ema_decay
        state["gain_ema"] = gain if state["gain_ema"] is None else decay * state["gain_ema"] + (1 - decay) * gain
        state["attack_steps"] += 1
        if self.adv_epsilon_mode not in ("gain", "hybrid"):
            return
        if state["attack_steps"] % self.adv_gain_interval:
            return
        target, band = self.adv_gain_target, self.adv_gain_deadband
        epsilon = state["epsilon"]
        if state["gain_ema"] > target * (1 + band):
            epsilon /= 1 + self.adv_gain_rate
        elif state["gain_ema"] < target * (1 - band):
            epsilon *= 1 + self.adv_gain_rate
        state["epsilon"] = float(min(state["maximum"], max(self.adv_epsilon_min, epsilon)))

    def _run_adversarial_update(self, batch):
        """One restart, last PGD iterate, reference only; clean update already ran."""
        if self.training_mode != "adversarial":
            return {}
        state = self.epsilon_state
        if self.adv_epsilon_mode in ("positive", "hybrid") and not state["calibrated"]:
            raise RuntimeError("Call solver.fit(train_loader) or calibrate_epsilon(train_loader) before step().")
        warmup = state["train_steps"] < self.adv_warmup_steps
        epsilon = 0.0 if warmup else state["epsilon"]
        alpha = self.adv_alpha
        if self.adv_epsilon_mode != "fixed":
            alpha *= epsilon / self.adv_epsilon
        clean_loss = adv_loss = gain = float("nan")
        if not warmup:
            original = batch.reference.detach()
            self.optimizer.zero_grad()
            if self.attack_norm == "linf":
                noise = torch.empty_like(original).uniform_(-epsilon, epsilon)
            else:
                noise = _l2_normalize(torch.randn_like(original))
                noise *= _rand_radius_like(original) * epsilon
            x_adv = (original + noise).detach()
            adv_batch = copy.copy(batch)
            for _ in range(self.adv_steps):
                x_adv.requires_grad_(True)
                adv_batch.reference = x_adv
                with torch.enable_grad():
                    attack_loss = self._objective(adv_batch)
                    grad, = torch.autograd.grad(attack_loss, x_adv)
                with torch.no_grad():
                    if self.attack_norm == "linf":
                        x_adv = x_adv + alpha * grad.sign()
                        x_adv = torch.max(torch.min(x_adv, original + epsilon), original - epsilon)
                    else:
                        x_adv = _proj_l2_ball(x_adv + alpha * _l2_normalize(grad), original, epsilon)
                x_adv = x_adv.detach()
            adv_batch.reference = x_adv
            clean_loss, adv_loss, gain = self._measure_adv_gain(batch, adv_batch)
            loss = self._objective(adv_batch)
            loss.backward()
            self.optimizer.step()
            self._update_epsilon_controller(gain)
        state["train_steps"] += 1
        ema = state["gain_ema"]
        return dict(adv_epsilon=epsilon, adv_alpha=0.0 if warmup else alpha,
                    adv_epsilon_next=state["epsilon"], adv_gain=gain,
                    adv_gain_ema=float("nan") if ema is None else ema,
                    adv_clean_probe=clean_loss, adv_loss_probe=adv_loss,
                    adv_warmup=int(warmup))

    def state_dict(self) -> dict:
        """Return a dictionary fully describing the current solver state.

        Returns:
            State dictionary, including the state dictionary of the models and
            optimizer. Also contains the training history and the CEBRA version
            the model was trained with.
        """

        return {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "loss": torch.tensor(self.history),
            "decode": self.decode_history,
            "criterion": self.criterion.state_dict(),
            "version": cebra.__version__,
            "log": self.log,
            "adversarial_config": self._adversarial_config(),
            "epsilon_state": copy.deepcopy(self.epsilon_state),
        }

    def load_state_dict(self, state_dict: dict, strict: bool = True):
        """Update the solver state with the given state_dict.

        Args:
            state_dict: Dictionary with parameters for the `model`, `optimizer`,
                and the past loss history for the solver.
            strict: Make sure all states can be loaded. Set to `False` to allow
                to partially load the state for all given keys.
        """

        def _contains(key):
            if key in state_dict:
                return True
            elif strict:
                raise KeyError(
                    f"Key {key} missing in state_dict. Contains: {list(state_dict.keys())}."
                )
            return False

        def _get(key):
            return state_dict.get(key)

        if _contains("model"):
            self.model.load_state_dict(_get("model"))
        if _contains("criterion"):
            self.criterion.load_state_dict(_get("criterion"))
        if _contains("optimizer"):
            self.optimizer.load_state_dict(_get("optimizer"))
        # TODO(stes): This will be deprecated at some point; the "log" attribute
        # holds the same information.
        if _contains("loss"):
            self.history = _get("loss").cpu().numpy().tolist()
        if _contains("decode"):
            self.decode_history = _get("decode")
        if _contains("log"):
            self.log = _get("log")
        # Old checkpoints have no epsilon/controller state and remain loadable.
        if "adversarial_config" in state_dict:
            for name, value in state_dict["adversarial_config"].items():
                if name in self._adversarial_config():
                    setattr(self, name, value)
        self._reset_epsilon_state()
        if "epsilon_state" in state_dict:
            self.epsilon_state = copy.deepcopy(state_dict["epsilon_state"])

    @property
    def num_parameters(self) -> int:
        """Total number of parameters in the encoder and criterion."""
        return sum(p.numel() for p in self.parameters())

    def parameters(self):
        """Iterate over all parameters."""
        for parameter in self.model.parameters():
            yield parameter

        for parameter in self.criterion.parameters():
            yield parameter

    def _get_loader(self, loader):
        return ProgressBar(
            loader,
            "tqdm" if self.tqdm_on else "off",
        )

    def fit(
            self,
            loader: cebra.data.Loader,
            valid_loader: cebra.data.Loader = None,
            *,
            save_frequency: int = None,
            valid_frequency: int = None,
            decode: bool = False,
            logdir: str = None,
            save_hook: Callable[[int, "Solver"], None] = None,
    ):
        """Train model for the specified number of steps.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            valid_loader: Data loader used for validation of the model.
            save_frequency: If not `None`, the frequency for automatically saving model checkpoints
                to `logdir`.
            valid_frequency: The frequency for running validation on the ``valid_loader`` instance.
            logdir:  The logging directory for writing model checkpoints. The checkpoints
                can be read again using the `solver.load` function, or manually via loading the
                state dict.

        TODO:
            * Refine the API here. Drop the validation entirely, and implement this via a hook?
        """

        self.to(loader.device)
        self._check_attack_support()
        if self.training_mode == "adversarial":
            self.calibrate_epsilon(loader)

        iterator = self._get_loader(loader)
        self.model.train()
        for num_steps, batch in iterator:
            stats = self.step(batch)
            iterator.set_description(stats)

            if save_frequency is None:
                continue
            save_model = num_steps % save_frequency == 0
            run_validation = (valid_loader
                              is not None) and (num_steps % valid_frequency
                                                == 0)
            if run_validation:
                validation_loss = self.validation(valid_loader)
                if self.best_loss is None or validation_loss < self.best_loss:
                    self.best_loss = validation_loss
                    self.save(logdir, "checkpoint_best.pth")
            if save_model:
                if decode:
                    self.decode_history.append(
                        self.decoding(loader, valid_loader))
                if save_hook is not None:
                    save_hook(num_steps, self)
                if logdir is not None:
                    self.save(logdir, f"checkpoint_{num_steps:#07d}.pth")

    # ----------------------------------------------------------------------
    # Drop-in replacement for Solver.step
    # ----------------------------------------------------------------------
    def step(self, batch: cebra.data.Batch) -> dict:
        self._check_attack_ready()
        self.optimizer.zero_grad()
        pred = self._inference(batch)
        loss, align, uniform = self.criterion(pred.reference, pred.positive, pred.negative)
        loss.backward()
        self.optimizer.step()
        attack_stats = self._run_adversarial_update(batch)
        # Keep clean objective metrics consistent between l2 and linf.
        self.history.append(loss.item())
        stats = dict(pos=align.item(), neg=uniform.item(), total=loss.item(),
                     temperature=self.criterion.temperature, **attack_stats)
        for key, value in stats.items():
            self.log.setdefault(key, []).append(value)
        return stats

    # ------------------------------------------------------------
    # 6) logging
    # ------------------------------------------------------------

    def validation(self,
                   loader: cebra.data.Loader,
                   session_id: Optional[int] = None):
        """Compute score of the model on data.

        Args:
            loader: Data loader, which is an iterator over `cebra.data.Batch` instances.
                Each batch contains reference, positive and negative input samples.
            session_id: The session ID, an integer between 0 and the number of sessions in the
                multisession model, set to None for single session.

        Returns:
            Loss averaged over iterations on data batch.
        """
        assert (session_id is None) or (session_id == 0)
        iterator = self._get_loader(loader)
        total_loss = Meter()
        self.model.eval()
        for _, batch in iterator:
            prediction = self._inference(batch)
            loss, _, _ = self.criterion(prediction.reference,
                                        prediction.positive,
                                        prediction.negative)
            total_loss.add(loss.item())
        return total_loss.average

    @torch.no_grad()
    def decoding(self, train_loader, valid_loader):
        """Deprecated since 0.0.2."""
        train_x = self.transform(train_loader.dataset[torch.arange(
            len(train_loader.dataset.neural))])
        train_y = train_loader.dataset.index
        valid_x = self.transform(valid_loader.dataset[torch.arange(
            len(valid_loader.dataset.neural))])
        valid_y = valid_loader.dataset.index
        decode_metric = train_loader.dataset.decode(
            train_x.cpu().numpy(),
            train_y.cpu().numpy(),
            valid_x.cpu().numpy(),
            valid_y.cpu().numpy(),
        )
        return decode_metric

    @torch.no_grad()
    def transform(self, inputs: torch.Tensor) -> torch.Tensor:
        """Compute the embedding.

        This function by default only applies the ``forward`` function
        of the given model, after switching it into eval mode.

        Args:
            inputs: The input signal

        Returns:
            The output embedding.

        TODO:
            * Remove eval mode
        """

        self.model.eval()
        return self.model(inputs)

    @abc.abstractmethod
    def _inference(self, batch: cebra.data.Batch) -> cebra.data.Batch:
        """Given a batch of input examples, return the model outputs.

        TODO: make this a public function?

        Args:
            batch: The input data, not necessarily aligned across the batch
                dimension. This means that ``batch.index`` specifies the map
                between reference/positive samples, if not equal ``None``.

        Returns:
            Processed batch of data. While the input data might not be aligned
            across the sample dimensions, the output data should be aligned and
            ``batch.index`` should be set to ``None``.
        """
        raise NotImplementedError

    def load(self, logdir, filename="checkpoint.pth"):
        """Load the experiment from its checkpoint file.

        Args:
            filename (str): Checkpoint name for loading the experiment.
        """

        savepath = os.path.join(logdir, filename)
        if not os.path.exists(savepath):
            print("Did not find a previous experiment. Starting from scratch.")
            return
        checkpoint = torch.load(savepath, map_location=self.device)
        self.load_state_dict(checkpoint, strict=True)

    def save(self, logdir, filename="checkpoint_last.pth"):
        """Save the model and optimizer params.

        Args:
            logdir: Logging directory for this model.
            filename: Checkpoint name for saving the experiment.
        """
        if not os.path.exists(os.path.dirname(logdir)):
            os.makedirs(logdir)
        savepath = os.path.join(logdir, filename)
        torch.save(
            self.state_dict(),
            savepath,
        )


@dataclasses.dataclass
class MultiobjectiveSolver(Solver):
    """Train models to satisfy multiple learning objectives.

    This variant of the standard :py:class:`cebra.solver.base.Solver` implements multi-objective
    or "hybrid" training.

    Attributes:
        model: A multi-objective CEBRA model
        optimizer: The optimizer used for training.
        num_behavior_features: The feature dimension for the features dedicated
            to satisfy the behavior contrastive objective. The remainder is used
            for time contrastive learning.
        renormalize_features: If ``True``, normalize the behavior and time
            contrastive features individually before computing similarity scores.
    """

    num_behavior_features: int = 3
    renormalize_features: bool = False
    output_mode: Literal["overlapping", "separate"] = "overlapping"

    @property
    def num_time_features(self):
        return self.num_total_features - self.num_behavior_features

    @property
    def num_total_features(self):
        return self.model.num_output

    def __post_init__(self):
        super().__post_init__()
        self._check_dimensions()
        self.model = cebra.models.MultiobjectiveModel(
            self.model,
            dimensions=(self.num_behavior_features, self.model.num_output),
            renormalize=self.renormalize_features,
            output_mode=self.output_mode,
        )

    def _check_dimensions(self):
        """Check the feature dimensions for behavior/time contrastive learning.

        Raises:
            ValueError: If feature dimensions are larger than the model features,
                or not sufficiently large for renormalization.
        """
        if self.output_mode == "separate":
            if self.num_behavior_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"behavior contrastive learning ({self.num_behavior_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
            if self.num_time_features >= self.num_total_features:
                raise ValueError(
                    "For multi-objective training, the number of features for "
                    f"time contrastive learning ({self.num_time_features}) cannot be as large or larger "
                    f"than the total feature dimension ({self.num_total_features})."
                )
        if self.renormalize_features:
            if self.num_behavior_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_behavior_features'."
                )
            if self.num_time_features < 2:
                raise ValueError(
                    "When renormalizing the features, the feature dimension needs "
                    "to be at least 2 for behavior. "
                    "Check the values of 'renormalize_features' and 'num_time_features'."
                )

    def step(self, batch: cebra.data.Batch) -> dict:
        self._check_attack_ready()
        self.optimizer.zero_grad()
        prediction_behavior, prediction_time = self._inference(batch)
        behavior_loss, behavior_align, behavior_uniform = self.criterion(
            prediction_behavior.reference, prediction_behavior.positive,
            prediction_behavior.negative)
        time_loss, time_align, time_uniform = self.criterion(
            prediction_time.reference, prediction_time.positive,
            prediction_time.negative)
        loss = behavior_loss + time_loss
        loss.backward()
        self.optimizer.step()
        attack_stats = self._run_adversarial_update(batch)
        self.history.append(loss.item())
        stats = dict(behavior_pos=behavior_align.item(),
                     behavior_neg=behavior_uniform.item(),
                     behavior_total=behavior_loss.item(),
                     time_pos=time_align.item(), time_neg=time_uniform.item(),
                     time_total=time_loss.item(), total=loss.item(),
                     temperature=self.criterion.temperature, **attack_stats)
        for key, value in stats.items():
            self.log.setdefault(key, []).append(value)
        return stats
